
/*

  SmartClient Ajax RIA system
  Version SNAPSHOT_v10.0d_2014-05-06/LGPL Development Only (2014-05-06)

  Copyright 2000 and beyond Isomorphic Software, Inc. All rights reserved.
  "SmartClient" is a trademark of Isomorphic Software, Inc.

  LICENSE NOTICE
     INSTALLATION OR USE OF THIS SOFTWARE INDICATES YOUR ACCEPTANCE OF
     ISOMORPHIC SOFTWARE LICENSE TERMS. If you have received this file
     without an accompanying Isomorphic Software license file, please
     contact licensing@isomorphic.com for details. Unauthorized copying and
     use of this software is a violation of international copyright law.

  DEVELOPMENT ONLY - DO NOT DEPLOY
     This software is provided for evaluation, training, and development
     purposes only. It may include supplementary components that are not
     licensed for deployment. The separate DEPLOY package for this release
     contains SmartClient components that are licensed for deployment.

  PROPRIETARY & PROTECTED MATERIAL
     This software contains proprietary materials that are protected by
     contract and intellectual property law. You are expressly prohibited
     from attempting to reverse engineer this software or modify this
     software for human readability.

  CONTACT ISOMORPHIC
     For more information regarding license rights and restrictions, or to
     report possible license violations, please contact Isomorphic Software
     by email (licensing@isomorphic.com) or web (www.isomorphic.com).

*/

if(window.isc&&window.isc.module_Core&&!window.isc.module_Solr){isc.module_Solr=1;isc._moduleStart=isc._Solr_start=(isc.timestamp?isc.timestamp():new Date().getTime());if(isc._moduleEnd&&(!isc.Log||(isc.Log&&isc.Log.logIsDebugEnabled('loadTime')))){isc._pTM={message:'Solr load/parse time: '+(isc._moduleStart-isc._moduleEnd)+'ms',category:'loadTime'};if(isc.Log&&isc.Log.logDebug)isc.Log.logDebug(isc._pTM.message,'loadTime');else if(isc._preLog)isc._preLog[isc._preLog.length]=isc._pTM;else isc._preLog=[isc._pTM]}isc.definingFramework=true;isc.defineClass("SolrDataSource","DataSource");isc.A=isc.SolrDataSource;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.baseURL="/solr";isc.A.pathToSchema="/admin/file";isc.A.pathToCores="/admin/cores";isc.A.fieldTypeConversionMapByType={"tint":"int","tfloat":"float","tlong":"long","tdouble":"double","tdate":"date","currency":"localeCurrency"};isc.A.fieldTypeConversionMapByClass={};isc.A.defaultFieldType="text";isc.B.push(isc.A.loadCores=function isc_c_SolrDataSource_loadCores(_1,_2,_3){if(!_2)_2=this.baseURL;if(!_3)_3={};var _4=_3.params?_3.params:{};_3.params=isc.addProperties({action:"STATUS"},_4);var _5=this;var _6=_2+this.pathToCores;isc.XMLTools.loadXML(_6,function(_10,_11){var _7=isc.XMLTools.toJS(_10);var _8=_7.lst.find("name","status");var _9=_8.lst.getProperty("name");if(_1)_5.fireCallback(_1,"cores",[_9])},_3)},isc.A.loadDS=function isc_c_SolrDataSource_loadDS(_1,_2,_3){var _4=_1.ID;var _5=_1.baseURL;if(!_5)_5=this.baseURL;if(!_3)_3={};var _6=_3.params?_3.params:{};_3.params=isc.addProperties({contentType:"text/xml",charset:"utf-8",file:"schema.xml"},_6);var _7=this;var _8=_5+this.pathToSchema;isc.XMLTools.loadXML(_8,function(_20,_21){var _9=isc.XMLTools.toJS(_20);var _10=[];var _11=_9.uniqueKey;var _12=_9.types.fieldType;var _13=_1.fields;var _14=isc.addProperties({},_1);delete _14.fields;for(var i=0;i<_9.fields.field.length;i++){var _16=_9.fields.field[i];if(!_16.name){_7.logWarn("["+_9.name+"] - skipping field def with bad name: "+isc.echoFull(_16));continue}
var _17=_7.convertSolrField(_16,_12.find("name",_16.type));if(_17==null)continue;if(_11&&_17.name==_11)_17.primaryKey=true;if(_17.multiValued)_17.canSort=false;if(_13){var _18=_13.find("name",_17.name);if(_18)isc.addProperties(_17,_18)}
_10.add(_17)}
var _19=isc.ClassFactory.getClass(_7.getClassName()).create({ID:_4?_4:_9.name,solrSchemaName:_9.name,baseURL:_5,fields:_10},_14);if(_2)_7.fireCallback(_2,"ds",[_19])},_3)},isc.A.convertSolrField=function isc_c_SolrDataSource_convertSolrField(_1,_2){var _3=isc.addProperties({},_1);for(var _4 in _3){var _5=_3[_4];if(_5==="false")_5=false;else if(_5==="true")_5=true;_3[_4]=_5}
_3.type=this.convertSolrFieldType(_2);_3.solrField=_1;_3.solrFieldType=_2;return _3},isc.A.convertSolrFieldType=function isc_c_SolrDataSource_convertSolrFieldType(_1){if(_1==null)return this.defaultFieldType;var _2=_1.name;var _3;if(isc.SimpleType.getType(_2))_3=_2;if(!_3)_3=this.fieldTypeConversionMapByType[_2];if(!_3)_3=this.fieldTypeConversionMapByClass[_1["class"]];if(!_3)_3=this.defaultFieldType;return _3});isc.B._maxIndex=isc.C+4;isc.A=isc.SolrDataSource.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.operationMap={fetch:"select",add:"update",update:"update",remove:"update"};isc.A.params={charset:"utf-8"};isc.A.requestProperties={};isc.A.adminPath="/admin";isc.A.queryTypeParam="qt";isc.A.writerTypeParam="wt";isc.A.queryParam="q";isc.A.queryOperatorParam="q.op";isc.A.outputsParam="fl";isc.A.sortParam="sort";isc.A.startRowParam="start";isc.A.numRowsParam="rows";isc.A.criteriaPolicy="dropOnChange";isc.A.dataFormat="custom";isc.A.dataProtocol="getParams";isc.A.dataTransport="scriptInclude";isc.A.callbackParam="json.wrf";isc.A.multipleValueSeparator="<br>";isc.A.enableFacetsParam="facet";isc.A.facetFieldParam="facet.field";isc.A.facetQueryParam="facet.query";isc.A.facetLimitParam="facet.limit";isc.A.filterQueryParam="fq";isc.A.hiliteHandling="mergeOntoRecord";isc.A.recordHiliteProperty="hilites";isc.B.push(isc.A.transformRequest=function isc_SolrDataSource_transformRequest(_1){isc.addProperties(_1,this.requestProperties);var _2=this.baseURL;_2+="/"+this.operationMap[_1.operationType]+"/";_1.actionURL=_2;var _3=_1.data={};isc.addProperties(_3,this.params);if(_1.originalData){var _4=["shards","facets","facetLimit","facetQueries","filterQueries"];_4.map(function(_19){if(_1.originalData[_19]){_1[_19]=_1.originalData[_19];delete _1.originalData[_19]}});var _5=[];for(var _6 in _1.originalData){var _7=_1.originalData[_6];if(_6=="q")_5.add(_7);else _5.add(_6+":"+_7+"*")}
_3[this.queryParam]=_5.join(" AND ")}
if(_1.startRow!=null)_3[this.startRowParam]=_1.startRow;if(_1.endRow!=null)_3[this.numRowsParam]=_1.endRow-_1.startRow;if(_1.sortBy){var _8="";for(var i=0;i<_1.sortBy.length;i++){var _10=_1.sortBy[i];var _11="asc";if(_10.startsWith("-")){_11="desc";_10=_10.substring(1)}
_8+=_10+" "+_11;if(i+1<_1.sortBy.length)_8+=","}
_3[this.sortParam]=_8}
if(_1.outputs){var _12=this.getPrimaryKeyFieldName(),_13=_1.outputs;if(isc.isA.String(_13)){_13=_13.split(",").map("trim")}
if(isc.isAn.Array(_13)){if(!_13.contains(_12))_13.add(_12);_1.outputs=_13.join(",")}
_3[this.outputsParam]=_1.outputs}
if(_1.facets){_3[this.enableFacetsParam]=true;_3[this.facetFieldParam]=_1.facets}
if(_1.shards){_3[this.shardsParam]=isc.isAn.Array(_1.shards)?_1.shards.join(","):_1.shards}
if(_1.facetLimit){_3[this.facetLimitParam]=_1.facetLimit}
if(_1.facetQueries){for(var _14 in _1.facetQueries){var _15=_1.facetQueries[_14];for(var i=0;i<_15.length;i++){var _16=_15[i];if(!_3[this.facetQueryParam])_3[this.facetQueryParam]=[];_3[this.facetQueryParam].add(_16)}}}
if(_1.filterQueries){if(isc.isAn.Array(_1.filterQueries)){_3[this.filterQueryParam]=_1.filterQueries}else{var _17=[];for(var _18 in _1.filterQueries){_17.add(_18+':"'+_1.filterQueries[_18]+'"')}
_3[this.filterQueryParam]=_17}}
if(this.dataTransport=="scriptInclude"){_1.callbackParam=this.callbackParam;_3[this.writerTypeParam]="json"}else{_1.serverOutputAsString=true}
isc.addProperties(_1.data,_1.params);return _1.data},isc.A.transformResponse=function isc_SolrDataSource_transformResponse(_1,_2,_3){if(this.dataTransport=="scriptInclude"){return this.transformJSONResponse(_1,_2,_3)}else{return this.transformXMLStringResponse(_1,_2,_3)}},isc.A.transformJSONResponse=function isc_SolrDataSource_transformJSONResponse(_1,_2,_3){var _4=_3.response;_1.startRow=_4.start;_1.endRow=_4.docs.length+_4.start;_1.totalRows=_4.numFound;var _5;var _6=[];var _7=this.getFieldNames();for(var i=0;i<_4.docs.length;i++){var _9=_4.docs[i];var _10={};for(var j=0;j<_7.length;j++){var _12=_7[j];var _13=this.getField(_12);var _14=_9[_12];var _15=this.convertSolrValue(_14,_13);if(_15!==_5)_10[_12]=_15}
_6.add(_10)}
if(_3.highlighting)_6=this.applyHiliting(_6,_3.highlighting);_1.data=_6;if(_3.facet_counts){_1.facetCounts=_3.facet_counts;_1.facetQueries=_3.facet_counts.facet_queries;_1.facetFields=_3.facet_counts.facet_fields;_1.facetDates=_3.facet_counts.facet_dates;_1.facetRanges=_3.facet_counts.facet_ranges}
return _1},isc.A.convertSolrValue=function isc_SolrDataSource_convertSolrValue(_1,_2){var _3=_1;var _4=isc.SimpleType.getType(_2.type);if(_1!=null&&isc.SimpleType.inheritsFrom(_2.type,"date")){_3=isc.Date.parseSchemaDate(_1)}
if(isc.isAn.Array(_1))_3=_1.join(this.multipleValueSeparator);return _3},isc.A.transformXMLStringResponse=function isc_SolrDataSource_transformXMLStringResponse(_1,_2,_3){_3=isc.XMLTools.toJS(isc.XMLTools.parseXML(_3));if(_3.result.doc&&!isc.isAn.Array(_3.result.doc))_3.result.doc=[_3.result.doc];_1.startRow=_3.result.start;_1.endRow=_3.result.doc?_3.result.doc.length+_3.result.start:0;_1.totalRows=_3.result.numFound;this.logWarn("Derived startRow: "+_1.startRow+", endRow: "+_1.endRow+" totalRows: "+_1.totalRows);var _4=[];if(!_3.result.doc)return _1;for(var i=0;i<_3.result.doc.length;i++){var _6=_3.result.doc[i];var _7={};if(!_6&&!(_6.str||_6.arr))continue;if(_6.str){for(var j=0;j<_6.str.length;j++){var _9=_6.str[j];var _10=_9.name;var _11=_9.xmlTextContent;_7[_10]=_11}}else if(_6.arr){for(var j=0;j<_6.arr.length;j++){var _12=_6.arr[j];var _10=_12.name;var _11=_12.xmlTextContent;_7[_10]=_11}}
_4.add(_7)}
if(_3.highlighting)_4=this.applyHiliting(_4,_3.highlighting);_1.data=_4;return _1},isc.A.applyHiliting=function isc_SolrDataSource_applyHiliting(_1,_2){if(!_1)return _1;var _3=(this.hiliteHandling=="mergeOntoRecord"),_4=(this.hiliteHandling=="propertyOnRecord"),_5=this.getPrimaryKeyFieldName();if(_5==null){this.logWarn("No primary key field defined on datasource--can't apply hiliting");return _1}
if(_3||_4){for(var _6 in _2){var _7=_1.find(_5,_6);if(_7==null){this.logDebug("Record with PK: "+_6+" not found");continue}
var _8=_2[_6];if(_4){_7[this.recordHiliteProperty]=_8
continue}else if(_3){for(var _9 in _8){var _10=this.getField(_9);if(_10&&_10.multiple){_7[_9]=_8[_9]}else{var _11=_10.multipleValueSeparator?_10.multipleValueSeparator:", ";_7[_9]=_8[_9].join(_11)}}}}}
return _1});isc.B._maxIndex=isc.C+6;isc.defineClass("SolrUIController").addProperties({params:{},dataSource:null,criteriaProviders:[],shardProviders:[],facetProviders:[],facetLimit:10,dataBoundComponent:null,init:function(){for(var i=0;i<this.facetProviders.length;i++){var _2=this.facetProviders[i];this.observe(_2,"queriesChanged","observer.doSearch()")}},doSearch:function(){var _1={},_2={};for(var i=0;i<this.criteriaProviders.length;i++){var c=null,_5=this.criteriaProviders[i];if(isc.isA.DynamicForm(_5)||isc.isA.ValuesManager(_5)){c=_5.getValuesAsCriteria()}else if(isc.isA.FilterBuilder(_5)){c=_5.getValues()}else continue;_2=isc.DataSource.combineCriteria(_2,c,"and")}
if(!isc.DataSource.canFlattenCriteria(_2)){this.logWarn("The criteria cannot be flattened: "+isc.echoAll(_2))}
isc.addProperties(_1,isc.DataSource.flattenCriteria(_2));for(var i=0;i<this.facetProviders.length;i++){var _6=this.facetProviders[i];var _7=_6.getFacetNames();_1.facets=_1.facets?_1.facets.addList(_7):_7;_1.facetLimit=this.facetLimit||_6.facetLimit;var _8=_6.getFilterQueries();_1.filterQueries=_1.filterQueries?_1.filterQueries.addList(_8):_8}
var _9=isc.addProperties({},this.params);for(var i=0;i<this.shardProviders.length;i++){var _10=this.shardProviders[i];var _11=_10.getShards();_1.shards=_1.shards?_1.shards.addList(_11):_11}
var _12=this;this.dataBoundComponent.filterData(_1,function(_13){_12.processResponse(_13)},{serverOutputAsString:true,params:_9})},processResponse:function(_1){var _2=_1.facetFields;this.facetProviders.map(function(_3){_3.updateFacetData(_2)})}});isc.defineInterface("FacetPicker").addInterfaceProperties({initInterface:function(){},setFacetLimit:function(_1){this.facetLimit=_1},getFacetLimit:function(){return this.facetLimit},facetSelected:function(_1,_2){this.filterQueries[_1]=_2;this.queriesChanged()},facetDeselected:function(_1){delete this.filterQueries[_1];this.queriesChanged()},getFilterQueries:function(){return this.filterQueries},queriesChanged:function(){},getFacetNames:function(){if(!this.facets)return[];return this.facets.getProperty("name")}});isc.defineClass("HGridFacetPicker","ListGrid","FacetPicker");isc.A=isc.HGridFacetPicker.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.height=100;isc.A.canReorderFields=false;isc.A.canSort=false;isc.A.facetLimit=10;isc.A.maxHeight=200;isc.A.facetPickerExpanded=false;isc.A.filterQueries={};isc.A.canSelectCells=true;isc.A.chartDefaults={width:500,height:500,chartType:"Pie",showEdges:true,backgroundColor:"#FFFFFF",showTitle:false};isc.A.autoFitFieldWidths=true;isc.A.autoFitWidthApproach="both";isc.A.autoFitFieldsFillViewport=false;isc.B.push(isc.A.initWidget=function isc_HGridFacetPicker_initWidget(){this.Super("initWidget",arguments);this.setFacets(this.facets)},isc.A.headerClick=function isc_HGridFacetPicker_headerClick(_1){if(this.suppressChart)return;var _2=this;var _3=this.getField(_1);if(_3.name=="expandField"){if(this.facetPickerExpanded){this.setHeight(25);_3.title=isc.Canvas.imgHTML(this.expansionFieldFalseImage,16,16)}else{_3.title=isc.Canvas.imgHTML(this.expansionFieldTrueImage,16,16);var _4=Math.min(20+(this.facetLimit*this.cellHeight)+10,this.maxHeight);this.setHeight(_4)}
this.header.getButton(_1).setTitle(_3.title);this.facetPickerExpanded=!this.facetPickerExpanded;return false}else{var _5=_3.name;var _6=this.createAutoChild("chart",{valueProperty:_3.name+"$1222",facets:[{id:_3.name,title:_3.title}],data:this.getData(),targetFacetName:_3.name,valueClick:function(_7){_2.$127o(this.targetFacetName,_7.record);this.destroy()},legendClick:function(_7,_8){_2.$127o(this.targetFacetName,this.data.find(this.targetFacetName,_7.id));this.destroy()}});this.chartMask=isc.EH.showClickMask(function(){_6.destroy()},"soft",[_6]);_6.showNextTo(this.header.getButton(_1),"bottom")}},isc.A.cellClick=function isc_HGridFacetPicker_cellClick(_1,_2,_3){var _4=this.getField(_3);if(_4.isFacet===false)return false;var _5=_4.name;this.$127o(_5,_1)},isc.A.$127o=function isc_HGridFacetPicker__facetSelected(_1,_2){this.facetSelected(_1,_2[_1+"$1223"])},isc.A.setFacets=function isc_HGridFacetPicker_setFacets(_1){this.facets=_1;var _2=[{name:"expandField",title:isc.Canvas.imgHTML(this.expansionFieldFalseImage,16,16),width:25,isFacet:false,leaveHeaderMenuButtonSpace:false,showDefaultContextMenu:false,showHover:false}];if(_1){for(var i=0;i<_1.length;i++){var _4=_1[i];var _5=isc.addProperties({},_4,{leaveHeaderMenuButtonSpace:false,showDefaultContextMenu:false,baseTitle:_4.title});_5.title=this.getFacetTitleForField(_5);_2.add(_5)}}
this.setData(_2)},isc.A.updateFacetData=function isc_HGridFacetPicker_updateFacetData(_1){var _2=[];var _3=0;this.facetCounts={};while(1){var _4=false;var _5={};for(var _6 in _1){var _7=_1[_6][_3];var _8=_1[_6][_3+1];if(_7!=null)_4=true;else continue;_5[_6]=_7+" ("+_8+")";_5[_6+"$1223"]=_7;_5[_6+"$1222"]=_8;if(!this.facetCounts[_6])this.facetCounts[_6]=0;this.facetCounts[_6]++}
if(!_4)break;_2.add(_5);_3+=2}
for(var _9 in this.facetCounts){var _10=this.getField(_9);if(!_10||_10.isFacet===false||!_10.baseTitle)continue;_10.title=this.getFacetTitleForField(_10);this.header.getButton(this.getFieldNum(_10.name)).setTitle(_10.title)}
this.setData(_2)},isc.A.getFacetTitleForField=function isc_HGridFacetPicker_getFacetTitleForField(_1){var _2="<u>"+_1.baseTitle;if(this.facetCounts&&this.facetCounts[_1.name]!=null){_2+=" ("+this.facetCounts[_1.name]+")"}
_2+="</u>";if(this.filterQueries&&this.filterQueries[_1.name]!=null){var _3=this.filterQueries[_1.name];_2+=": <b>"+_3+"</b> <span onmousedown='"+this.getID()+".$1224(\""+_1.name+"\");return false;'>[<u>x</u>]</span>"}
return _2},isc.A.$1224=function isc_HGridFacetPicker__deselectFacet(_1){this.suppressChart=true;this.facetDeselected(_1);this.suppressChart=false});isc.B._maxIndex=isc.C+8;isc.defineClass("VGridFacetPicker","VLayout","FacetPicker");isc.A=isc.VGridFacetPicker.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.facetLimit=10;isc.A.facetPickerExpanded=true;isc.A.filterQueries={};isc.A.selectedFacetStackDefaults={_constructor:"VStack",height:1,overflow:"visible",visibility:"hidden",setSelectedFacet:function(_1){var _2=this.getMembers().find("facetName",_1.facet);if(_2){this.removeMember(_2);_2.destroy()}
var _3=this,_4=this.creator;this.addMember({_constructor:"Button",height:22,width:null,align:"left",facetName:_1.facet,facetValue:_1.value,facetTitle:_1.title?_1.title:_1.facet,facetCount:_1.count,showRollOverIcon:true,iconOrientation:"right",iconSize:15,icon:"[SKINIMG]/actions/close.png",getTitle:function(){return"<b>"+this.facetTitle+":</b> "+this.facetValue+" ("+this.facetCount+")"},click:function(){_4.$1224(this.facetName);_3.removeMember(this);this.destroy()}});if(!this.isVisible())this.show()},reset:function(){var _1=this,_2=this.getMembers().duplicate();_2.map(function(_3){_1.removeMember(_3);_3.destroy()});this.creator.filterQueries={}},extraSpace:5};isc.A.facetGridDefaults={_constructor:"ListGrid",showHeader:false,maxHeight:200,showEmptyMessage:false,chartDefaults:{width:500,height:500,chartType:"Pie",showEdges:true,backgroundColor:"#FFFFFF",showTitle:false},autoFitFieldWidths:true,autoFitWidthApproach:"both",autoFitFieldsFillViewport:false,selectionAppearance:"checkbox",leaveScrollbarGap:false,isGrouped:true,groupByField:"title",defaultFields:[{name:"value",width:"*",formatCellValue:function(_1,_2){if(_1!=null&&_2.count!=null){_1=_1+" ("+_2.count+")"}
return _1}},{name:"title",showIf:"false"}],initWidget:function(){this.groupStartOpen=this.creator.facetPickerExpanded?"all":"none";this.Super("initWidget",arguments)},selectionChanged:function(_1,_2){if(_2)this.creator.$127o(_1.facet,_1.value)}};isc.A.autoChildren=["selectedFacetStack","facetGrid"];isc.B.push(isc.A.setFacets=function isc_VGridFacetPicker_setFacets(_1){this.facets=_1},isc.A.removeSelectedFacets=function isc_VGridFacetPicker_removeSelectedFacets(){this.selectedFacetStack.reset()},isc.A.updateFacetData=function isc_VGridFacetPicker_updateFacetData(_1){if(!_1){this.facetGrid.setData([]);return}
var _2=[];for(var _3 in _1){var _4=_1[_3],_5=this.getFacetTitleForField(_3);for(var i=0;i<_4.length;i+=2){var _7=_4[i],_8=_4[i+1];if(_7==null)continue;_2.add({facet:_3,title:_5,value:_7,count:_8})}}
var _9=[],_10=this.facets.getProperty("name");for(var i=0;i<_10.length;i++){var _11=_10[i],_12=this.filterQueries[_11];if(_12==null)continue;var _13=_2.find({facet:_11,value:_12});this.selectedFacetStack.setSelectedFacet(_13);_2.removeList(_2.findAll("facet",_11))}
this.facetGrid.setData(_2)},isc.A.getFacetTitleForField=function isc_VGridFacetPicker_getFacetTitleForField(_1){if(!this.facets)return _1;var f=this.facets.find("name",_1);if(f.title)return f.title;else return _1},isc.A.$127o=function isc_VGridFacetPicker__facetSelected(_1,_2){this.facetSelected(_1,_2)},isc.A.$1224=function isc_VGridFacetPicker__deselectFacet(_1){this.suppressChart=true;this.facetDeselected(_1);this.suppressChart=false});isc.B._maxIndex=isc.C+6;isc._nonDebugModules=(isc._nonDebugModules!=null?isc._nonDebugModules:[]);isc._nonDebugModules.push('Solr');isc.checkForDebugAndNonDebugModules();isc._moduleEnd=isc._Solr_end=(isc.timestamp?isc.timestamp():new Date().getTime());if(isc.Log&&isc.Log.logIsInfoEnabled('loadTime'))isc.Log.logInfo('Solr module init time: '+(isc._moduleEnd-isc._moduleStart)+'ms','loadTime');delete isc.definingFramework;if(isc.Page)isc.Page.handleEvent(null,"moduleLoaded",{moduleName:'Solr',loadTime:(isc._moduleEnd-isc._moduleStart)});}else{if(window.isc&&isc.Log&&isc.Log.logWarn)isc.Log.logWarn("Duplicate load of module 'Solr'.");}

/*

  SmartClient Ajax RIA system
  Version SNAPSHOT_v10.0d_2014-05-06/LGPL Development Only (2014-05-06)

  Copyright 2000 and beyond Isomorphic Software, Inc. All rights reserved.
  "SmartClient" is a trademark of Isomorphic Software, Inc.

  LICENSE NOTICE
     INSTALLATION OR USE OF THIS SOFTWARE INDICATES YOUR ACCEPTANCE OF
     ISOMORPHIC SOFTWARE LICENSE TERMS. If you have received this file
     without an accompanying Isomorphic Software license file, please
     contact licensing@isomorphic.com for details. Unauthorized copying and
     use of this software is a violation of international copyright law.

  DEVELOPMENT ONLY - DO NOT DEPLOY
     This software is provided for evaluation, training, and development
     purposes only. It may include supplementary components that are not
     licensed for deployment. The separate DEPLOY package for this release
     contains SmartClient components that are licensed for deployment.

  PROPRIETARY & PROTECTED MATERIAL
     This software contains proprietary materials that are protected by
     contract and intellectual property law. You are expressly prohibited
     from attempting to reverse engineer this software or modify this
     software for human readability.

  CONTACT ISOMORPHIC
     For more information regarding license rights and restrictions, or to
     report possible license violations, please contact Isomorphic Software
     by email (licensing@isomorphic.com) or web (www.isomorphic.com).

*/


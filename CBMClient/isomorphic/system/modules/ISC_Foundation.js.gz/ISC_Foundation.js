/*
 * Isomorphic SmartClient
 * Version v14.1p_2026-08-14 (2026-08-14)
 * Copyright(c) 1998 and beyond Isomorphic Software, Inc. All rights reserved.
 * "SmartClient" is a trademark of Isomorphic Software, Inc.
 *
 * licensing@smartclient.com
 *
 * http://smartclient.com/license
 */

if(window.isc&&window.isc.module_Core&&!window.isc.module_Foundation){isc.module_Foundation=1;isc._moduleStart=isc._Foundation_start=(isc.timestamp?isc.timestamp():new Date().getTime());if(isc._moduleEnd&&(!isc.Log||(isc.Log&&isc.Log.logIsDebugEnabled('loadTime')))){isc._pTM={message:'Foundation load/parse time: '+(isc._moduleStart-isc._moduleEnd)+'ms',category:'loadTime'};
if(isc.Log&&isc.Log.logDebug)isc.Log.logDebug(isc._pTM.message,'loadTime');
else if(isc._preLog)isc._preLog[isc._preLog.length]=isc._pTM;
else isc._preLog=[isc._pTM]}isc.definingFramework=true;if(window.isc&&isc.version!="v14.1p_2026-08-14/LGPL Deployment"&&!isc.DevUtil){isc.logWarn("SmartClient module version mismatch detected: This application is loading the core module from SmartClient version '"+isc.version+"' and additional modules from 'v14.1p_2026-08-14/LGPL Deployment'. Mixing resources from different SmartClient packages is not supported and may lead to unpredictable behavior. If you are deploying resources from a single package you may need to clear your browser cache, or restart your browser."
+(isc.Browser.isSGWT?" SmartGWT developers may also need to clear the gwt-unitCache and run a GWT Compile.":""))}
isc.ClassFactory.defineClass("Animation");isc.A=isc.Animation;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.interval=20;isc.A.registry=[];isc.A.animateTime=1000;isc.B.push(isc.A.smoothStart=function isc_c_Animation_smoothStart(_1){return Math.pow(_1,2)}
,isc.A.smoothEnd=function isc_c_Animation_smoothEnd(_1){return 1-Math.abs(Math.pow(_1-1,2))}
,isc.A.smoothStartEnd=function isc_c_Animation_smoothStartEnd(_1){return(-Math.cos(_1*Math.PI)+1)/2.0}
);isc.B._maxIndex=isc.C+3;isc.A=isc.Animation;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.timeBased=false;isc.A.$0c="ratio,ID,earlyFinish";isc.B.push(isc.A.generateAnimationID=function isc_c_Animation_generateAnimationID(){if(!this.$0d)this.$0d=0;return"_"+(this.$0d++)}
,isc.A.$1761=function isc_c_Animation__useRequestAnimationFrame(){if(this.$1762==null){this.$1762=window.requestAnimationFrame!=null}
return this.$1762}
,isc.A.timeoutAction=function isc_c_Animation_timeoutAction(){if(isc.Animation)isc.Animation.fireTimer()}
,isc.A.requestedAnimationAction=function isc_c_Animation_requestedAnimationAction(_1){if(isc.Animation)isc.Animation.fireTimer()}
,isc.A.registerAnimation=function isc_c_Animation_registerAnimation(_1,_2,_3,_4){if(this.$1761()){if(this.$1763==null){this.$1763=window.requestAnimationFrame(this.requestedAnimationAction);this.$0f=isc.timeStamp()}
}else{if(!this.$0e){this.$0e=isc.Timer.setTimeout(this.timeoutAction,this.interval);this.$0f=isc.timeStamp()}
}
if(!_4)_4=this;if(!_2)_2=this.animateTime;if(isc.isA.String(_3)){if(!isc.Animation.accelerationMap){isc.Animation.accelerationMap={smoothStart:isc.Animation.smoothStart,smoothEnd:isc.Animation.smoothEnd,smoothStartEnd:isc.Animation.smoothStartEnd
}
}
_3=isc.Animation.accelerationMap[_3]}
var _5=this.generateAnimationID();this.registry.add({ID:_5,target:_4,callback:_1,duration:_2,elapsed:0,totalFrames:Math.round(_2/this.interval),currentFrame:0,maxDuration:_2*3,acceleration:_3
});return _5}
,isc.A.clearAnimation=function isc_c_Animation_clearAnimation(_1){for(var i=0;i<this.registry.length;i++){if(this.registry[i]&&this.registry[i].ID==_1){this.registry.removeAt(i);break}
}
}
,isc.A.finishAnimation=function isc_c_Animation_finishAnimation(_1){for(var i=0;i<this.registry.length;i++){if(this.registry[i]&&this.registry[i].ID==_1){var _3=this.registry[i];break}
}
this.clearAnimation(_1);if(_3)this.fireAction(_3,1,true)}
,isc.A.fireTimer=function isc_c_Animation_fireTimer(){var _1=isc.timeStamp(),_2=(_1-this.$0f),_3=Math.max(0,this.interval-(_2-this.interval));if(this.$1761()){this.$1763=window.requestAnimationFrame(this.requestedAnimationAction)}else{this.$0e=isc.Timer.setTimeout(this.timeoutAction,_3)}
this.$0f=_1;for(var i=0;i<this.registry.length;i++){var _5=this.registry[i];if(_5==null)continue;_5.elapsed+=_2;var _6=_5.currentFrame+1;if(!isc.Animation.timeBased&&((_5.elapsed/_5.maxDuration)>(_6/_5.totalFrames)))
{_6=Math.min(_5.totalFrames,Math.ceil((_5.elapsed/_5.maxDuration)*_5.totalFrames))}
_5.currentFrame=_6;var _7=_5.elapsed/_5.duration,_8=_5.currentFrame/_5.totalFrames;var _9=!isc.Animation.timeBased&&(_7>_8),_10=_9?_8:_7;var _11=_10,_12=_5.acceleration;if(_12&&isc.isA.Function(_12)){if(!_5.accelerationTested){try{_11=_5.acceleration(_11)}catch(e){this.logWarn("Custom ratio function for animation:"+isc.Log.echoAll(_5)+"\nCaused an error:"+(e.message?e.message:e));_5.acceleration=null}
_5.accelerationTested=true}else{_11=_5.acceleration(_11)}
}
if(_10>=1){_11=1;this.registry[i]=null}
var _13=null;try{_13=this.fireAction(_5,_11)}catch(e){_13=e}
if(_13!=null){this.logWarn("Attempt to fire registered animation:"+isc.Log.echoAll(_5)+"\nCaused an error:"+(_13.message?_13.message:_13));this.registry[i]=null}
if(_10>=1){this.logDebug("animation "+_5.ID+" completed","animation")}
}
this.registry.removeEmpty();if(this.registry.length==0){if(this.$1761()){window.cancelAnimationFrame(this.$1763);this.$1763=null}else{isc.Timer.clearTimeout(this.$0e);this.$0e=null}
}
}
,isc.A.fireAction=function isc_c_Animation_fireAction(_1,_2,_3){var _4=_1.target;if(!_4||_4.destroyed){return"No valid target. Target may have been destroyed since animation commenced"}
_4.fireCallback(_1.callback,this.$0c,[_2,_1.ID,_3])}
,isc.A.isActive=function isc_c_Animation_isActive(){return(this.registry&&this.registry.length>0)}
);isc.B._maxIndex=isc.C+10;isc.A=isc.Canvas.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.animateTime=300;isc.A.animateAcceleration="smoothEnd";isc.A.$0g=["rect","fade","scroll","show","hide","resize","move"];isc.A.animateShowEffect="wipe";isc.A.animateHideEffect="wipe";isc.B.push(isc.A.$2196=function isc_Canvas__shouldRelayoutForAnimateResize(){switch(this.animateResizeLayoutMode){case"always":return true;case"overflow":return this.$u0;default:return false}
}
);isc.B._maxIndex=isc.C+1;isc.A=isc.Canvas.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$0h={};isc.A.$0i={};isc.A.$0j={};isc.A.$747="Animation";isc.A.$0k={};isc.A.$0l={};isc.A.$743=0;isc.A.$166n=0;isc.A.$0m="move";isc.A.$nx="resize";isc.A.$0n="rect";isc.A.$do="show";isc.A.$0o="slide";isc.A.$0p="wipe";isc.A.$0q="fade";isc.A.$0r="fly";isc.A.$0s="T";isc.A.$0t="L";isc.A.$0u={slide:"show",wipe:"show",fly:"move",fade:"fade"};isc.A.$zb="hide";isc.A.$0v={slide:"hide",wipe:"hide",fly:"move",fade:"fade"};isc.B.push(isc.A.registerAnimation=function isc_Canvas_registerAnimation(_1,_2,_3){if(!_3)_3=this.animationAcceleration;if(!_2)_2=this.animateTime;return isc.Animation.registerAnimation(_1,_2,_3,this)}
,isc.A.cancelAnimation=function isc_Canvas_cancelAnimation(_1){isc.Animation.clearAnimation(_1)}
,isc.A.getAnimateTime=function isc_Canvas_getAnimateTime(_1){if(!isc.isA.String(_1)||isc.isAn.emptyString(_1))return this.animateTime;if(!this.$0h[_1]){this.$0h[_1]="animate"+_1.substring(0,1).toUpperCase()+_1.substring(1)+"Time"}
return this[this.$0h[_1]]||this.animateTime}
,isc.A.getAnimateAcceleration=function isc_Canvas_getAnimateAcceleration(_1){if(!isc.isA.String(_1)||isc.isAn.emptyString(_1))return this.animateAcceleration;if(!this.$0i[_1]){this.$0i[_1]="animate"+_1.substring(0,1).toUpperCase()+_1.substring(1)+"Acceleration"}
return this[this.$0i[_1]]||this.animateAcceleration}
,isc.A.$0w=function isc_Canvas__getAnimationID(_1){if(!this.$0j[_1]){this.$0j[_1]=_1+this.$747}
return this.$0j[_1]}
,isc.A.$0x=function isc_Canvas__getAnimationMethodName(_1){if(!this.$0k[_1]){this.$0k[_1]="fireAnimation"+_1.substring(0,1).toUpperCase()+_1.substring(1)}
return this.$0k[_1]}
,isc.A.$0y=function isc_Canvas__startAnimation(_1,_2,_3,_4){var _5=this.$0w(_1);if(this[_5])this.finishAnimation(_1);if(!this.$0l[_1]){this.$0l[_1]="$"+_1+"AnimationInfo"}
this[this.$0l[_1]]=_2;if(_3==null)_3=this.getAnimateTime(_1);if(_4==null)_4=this.getAnimateAcceleration(_1);var _6=this[_5]=this.registerAnimation(this[this.$0x(_1)],_3,_4);if(this.logIsInfoEnabled("animation")){this.logInfo("starting animation "+_6+" of type: "+_1+", duration: "+_3+", acceleration: "+this.echoLeaf(_4),"animation")}
this.$743++;return _6}
,isc.A.$744=function isc_Canvas__clearAnimationInfo(_1){var _2=this.$0w(_1);if(!this[_2]){return}
delete this[_2];delete this[this.$0l[_1]];this.$743--}
,isc.A.animationComplete=function isc_Canvas_animationComplete(_1){}
,isc.A.$0z=function isc_Canvas__fireAnimationCompletionCallback(_1,_2,_3){if(!_1)return;var _4=this,_5=_2||_3;var _6=function(){_4.fireCallback(_1,"earlyFinish",[_2]);if(!_5)_4.$166n--;_4.animationComplete(_2)}
if(_5){_6()}else{isc.Timer.setTimeout(_6,0);this.$166n++}
}
,isc.A.finishAnimation=function isc_Canvas_finishAnimation(_1){if(_1==null){for(var i=0;i<this.$0g.length;i++){this.finishAnimation(this.$0g[i])}
return}
var _3=this.$0w(_1);if(!this[_3])return;if(this.logIsInfoEnabled("animation")){this.logInfo("manual finish for animations: "+this.echoAll(this[_3])+(this.logIsDebugEnabled("animation")?this.getStackTrace():""),"animation")}
isc.Animation.finishAnimation(this[_3])}
,isc.A.animateMove=function isc_Canvas_animateMove(_1,_2,_3,_4,_5){return this.animateRect(_1,_2,null,null,_3,_4,_5,this.$0m)}
,isc.A.fireAnimationMove=function isc_Canvas_fireAnimationMove(_1,_2,_3){return this.fireAnimationRect(_1,_2,_3,this.$0m)}
,isc.A.animateResize=function isc_Canvas_animateResize(_1,_2,_3,_4,_5){return this.animateRect(null,null,_1,_2,_3,_4,_5,this.$nx)}
,isc.A.fireAnimationResize=function isc_Canvas_fireAnimationResize(_1,_2,_3){return this.fireAnimationRect(_1,_2,_3,this.$nx)}
,isc.A.animateRect=function isc_Canvas_animateRect(_1,_2,_3,_4,_5,_6,_7,_8){if(_8==null){_8=this.$0n;if(this.resizeAnimation!=null)this.finishAnimation(this.$nx);if(this.moveAnimation!=null)this.finishAnimation(this.$0m)}
var _9={$00:this.getRect(),_left:_1,_top:_2,$02:_3,$o8:_4,$03:_5};return this.$0y(_8,_9,_6,_7)}
,isc.A.fireAnimationRect=function isc_Canvas_fireAnimationRect(_1,_2,_3,_4){var _5=(_4==this.$nx?this.$resizeAnimationInfo:(_4==this.$0m?this.$moveAnimationInfo:this.$rectAnimationInfo)),_6=_5.$00,_7=_5._left,_8=_5._top,_9=_5.$02,_10=_5.$o8,_11=_7!=null?this.$04(_6[0],_7,_1):null,_12=_8!=null?this.$04(_6[1],_8,_1):null;var _13,_14;if(_9!=null&&_11!=null&&(_7-_6[0]!=0)){var _15=(_9-_6[2])/(_7-_6[0]);if(Math.floor(_15)==_15){_13=_6[2]+(_15*(_11-_6[0]))}
}
if(_10!=null&&_12!=null&&(_8-_6[1]!=0)){var _15=(_10-_6[3])/(_8-_6[1]);if(Math.floor(_15)==_15){_14=_6[3]+(_15*(_12-_6[1]))}
}
if(_13==null&&_9!=null){_13=this.$04(_6[2],_9,_1)}
if(_14==null&&_10!=null){_14=this.$04(_6[3],_10,_1)}
if(_1<1&&(_9==null||_9==_13)&&(_10==null||_10==_14))
{_13=_14=null}
if(_1==1){if(_4==null)_4="rect";this.$744(_4)}
this.setRect(_11,_12,_13,_14,_1<1);if(this.isDirty())this.redraw("animated resize");if(_1==1){this.$0z(_5.$03,_3)}
}
,isc.A.$04=function isc_Canvas__getRatioTargetValue(_1,_2,_3){if(_2==null)return _1;return(_1+Math.floor(_3*(_2-_1)))}
,isc.A.animateFade=function isc_Canvas_animateFade(_1,_2,_3,_4){if(!this.isDrawn()){this.setOpacity(_1);this.$0z(_2,true);return}
if(this.visibility==isc.Canvas.HIDDEN){this.setOpacity(0);this.show()}
if(_1==null)_1=100;var _5={$05:this.opacity!=null?this.opacity:100,$06:_1,$03:_2};return this.$0y("fade",_5,_3,_4)
}
,isc.A.fireAnimationFade=function isc_Canvas_fireAnimationFade(_1,_2,_3){var _4=this.$fadeAnimationInfo,_5=_4.$05,_6=_4.$06;var _7=this.$04(_5,_6,_1);if(isc.Browser.isIE&&_7>0&&!_4.$07&&!isc.Browser.isIE9){var _8=this.getStyleHandle();if(_8){_8.visibility=isc.Canvas.VISIBLE;_8.visibility=isc.Canvas.INHERIT}
var _9=this.peers;if(_9&&_9.length>0){for(var i=0;i<_9.length;i++){if(_9[i].$nt){var _8=_9[i].getStyleHandle();if(_8){_8.visibility=isc.Canvas.VISIBLE;_8.visibility=isc.Canvas.INHERIT}
}
}
}
_4.$07=true}
if(_1==1){this.$744("fade")}
this.setOpacity(_7,(_1<1));if(_1==1)this.$0z(_4.$03,_3)}
,isc.A.animateScroll=function isc_Canvas_animateScroll(_1,_2,_3,_4,_5){var _6=this.overflow;if(this.overflow==isc.Canvas.VISIBLE)return;var _7={$08:this.getScrollLeft(),$09:this.getScrollTop(),$1a:_1,$1b:_2,$03:_3};return this.$0y("scroll",_7,_4,_5)}
,isc.A.fireAnimationScroll=function isc_Canvas_fireAnimationScroll(_1,_2,_3){var _4=this.$scrollAnimationInfo,_5=_4.$08,_6=_4.$1a,_7=_4.$09,_8=_4.$1b,_9=this.$04(_5,_6,_1),_10=this.$04(_7,_8,_1);if(_1==1){this.$744("scroll")}
this.scrollTo(_9,_10,null,(_1<1));if(_1==1&&_4.$03){this.$0z(_4.$03,_3)}
}
,isc.A.animateShow=function isc_Canvas_animateShow(_1,_2,_3,_4){if(_1==null)_1=this.animateShowEffect;var _5;if(isc.isAn.Object(_1)){_5=_1;_1=_1.effect}
if(this.$va!=null)this.finishAnimation(this.$va);if(this.isDrawn()&&this.isVisible()){return}
if(this.$vc!=null){return}
if(!this.isDrawn()){if(this.parentElement&&!this.parentElement.isDrawn()){this.show();this.logInfo("not animating show, component not drawn","animation");this.animateShowComplete(true);return}else{this.$vc=this.$0u[_1]||this.$do;this.draw()}
}
this.$vc=this.$0u[_1]||this.$do;this.$1c=_2;if(!this.$1d)
this.$1d={target:this,methodName:"animateShowComplete"}
if(_1==this.$0q){var _6=this.opacity;this.$1e=_2;this.setOpacity(0);this.show();if(_3==null)_3=this.animateShowTime;if(_4==null)_4=this.animateShowAcceleration;return this.animateFade(_6,this.$1d,_3,_4)}else if(_1==this.$0r){if(this.parentElement!=null){this.logInfo("animateShow() called with 'fly' effect - not supported for child widgets defaulting to standard 'wipe' animation instead.","animation");_1=this.$0p}else{if(_3==null)_3=this.animateShowTime;if(_4==null)_4=this.animateShowAcceleration;var _7=this.isRTL(),_8=this.getLeft(),_9=_7?isc.Page.getWidth()+isc.Page.getScrollLeft()
:0-this.getVisibleWidth();this.$58w=this._percent_left,this.setLeft(_9);this.show();return this.animateMove(_8,null,this.$1d,_3,_4)}
}
if(!this.$1f(_1)){this.logInfo("not animating show, can't do clip animations","animation");this.show();this.animateShowComplete(true);return}
if(this.isVisible())this.hide();var _10=this.getVisibleHeight(),_11=this.getVisibleWidth(),_12=_5?_5.startFrom==this.$0s:true,_13=(_12?this.getScrollTop():this.getScrollLeft()),_14=(_1=="slide"),_15={$po:this.$po,$1g:this.getHeight(),$1h:_10,$pn:this.$pn,$1i:this.getWidth(),$1j:_11,$58x:this._percent_width,$58y:this._percent_height,$1k:this.overflow,$1l:_12,$1m:_13,$1n:_14,$03:this.$1d
};if(_12){if(this.vscrollOn&&this.vscrollbar){_15.$495=this.vscrollbar.thumb.getTop();_15.$496=this.vscrollbar.thumb.getHeight();if(this.vscrollbar.thumb){this.vscrollbar.thumb.$jq=false;this.vscrollbar.thumb.$493=true}
this.vscrollbar.$494=true;this.vscrollbar.$493=true;this.vscrollbar.setHeight(1)}
if(this.hscrollOn&&this.hscrollbar){this.hscrollbar.$493=true;if(this.hscrollbar.thumb)this.hscrollbar.thumb.$493=true;if(!_15.$1n){this.hscrollbar.$jq=false}else{this.hscrollbar.setTop(this.getTop());this.hscrollbar.setHeight(1)}
}
}else{if(this.hscrollOn&&this.hscrollbar){_15.$495=this.hscrollbar.thumb.getLeft();_15.$496=this.hscrollbar.thumb.getWidth();this.hscrollbar.$494=true;this.hscrollbar.$493=true;if(this.hscrollbar.thumb){this.hscrollbar.thumb.$jq=false;this.hscrollbar.thumb.$493=true}
this.hscrollbar.setWidth(1)}
if(this.vscrollOn&&this.vscrollbar){this.vscrollbar.$493=true;if(this.vscrollbar.thumb)this.vscrollbar.thumb.$493=true;if(!_15.$1n){this.vscrollbar.$jq=false}else{this.vscrollbar.setLeft(this.getLeft());this.vscrollbar.setWidth(1)}
}
}
if(this.showEdges&&this.$l0){this.$l0.$za=true}
if(this.overflow==isc.Canvas.VISIBLE){this.setOverflowForAnimation(isc.Canvas.HIDDEN,this.overflow)}
if(this.overflow==isc.Canvas.AUTO||this.overflow==isc.Canvas.SCROLL){this.$417=true}
this.resizeTo((_12?_11:1),(_12?1:_10),true);if(_14)this.scrollTo((_12?null:_13+(_11-1)),(_12?_13+(_10-1):null));if(this.showEdges&&this.$l0){if(_12)
this.$u9(this.$l0.getHandle().firstChild.style,"height",_10);else
this.$u9(this.$l0.getHandle().firstChild.style,"width",_11);this.$l0.setOverflow(isc.Canvas.HIDDEN);if(_14){if(_12){var _16=this.$l0.$td;this.$u9(this.getStyleHandle(),"marginTop",(this.getTopMargin()-_16))}else{var _16=this.$l0.$tb;this.$u9(this.getStyleHandle(),"marginLeft",(this.getLeftMargin()-_16))}
}
this.$l0.show()}else{var _17=_12?(this.hscrollOn?this.hscrollbar:null)
:(this.vscrollOn?this.vscrollbar:null),_18=_12?(this.vscrollOn?this.vscrollbar:null)
:(this.hscrollOn?this.hscrollbar:null);if(_17&&_15.$1n){_17.show();if(_18)_18.show()}else{this.show()}
}
return this.$0y(this.$do,_15,_3,_4)}
,isc.A.fireAnimationShow=function isc_Canvas_fireAnimationShow(_1,_2,_3){var _4=this.$showAnimationInfo,_5=_4.$1l;if(_1<1){var _6=(_5?_4.$1h:_4.$1j),_7=this.$04(1,_6,_1),_8=_6-_7,_9=(this.showEdges&&this.$l0),_10,_11;if(_9){_10=(_4.$1n?(_5?this.$l0.$te
:this.$l0.$tc)
:(_5?this.$l0.$td
:this.$l0.$tb)),_11=(_4.$1n?(_5?this.$l0.$td
:this.$l0.$tb)
:(_5?this.$l0.$te
:this.$l0.$tc));this.$l0.resizeTo((_5?null:_7),(_5?_7:null),true);if(_4.$1n){if(_5)this.$l0.scrollToBottom();else this.$l0.scrollToRight()}
if(_7<_10)return;if(_8<=_11){if(_4.$1n){var _12=(_5?"marginTop":"marginLeft"),_13=(_5?this.getTopMargin()-_8
:this.getLeftMargin()-_8);this.$u9(this.getStyleHandle(),_12,_13);this.scrollTo((_5?null:_4.$1m),(_5?_4.$1o:null),null,true)}
return}
if(!this.isVisible()){this.$vd=true;this.show();delete this.$vd}
}
var _14=_5?this.vscrollOn:this.hscrollOn,_15=_5?this.hscrollOn:this.vscrollOn;if(_14){var _16;if(_5){_16=this.vscrollbar;if(_16)_16.resizeTo(null,_7)}else{_16=this.hscrollbar;var _17=_7;if(this.vscrollOn){if(_4.$1n){_17-=this.scrollbarSize}else{_17=Math.min(_7,_6-this.scrollbarSize)}
}
if(_17>0){if(_16)_16.resizeTo(_17,null)}
}
if(_4.$1n&&_16){if(_5)_16.scrollToBottom();else _16.scrollToRight()}
if(_16&&_16.thumb){var _18=_16.thumb;if(_4.$1n){var _19=_4.$495-_8,_20=_19+Math.min(_7,_4.$496),_21=_5?this.getTop():this.getLeft();if(_20<=_21){}else{_19=Math.max(_21,_19);var _22=Math.min(_20-_19,_7);_18.resizeTo(_5?null:_22,_5?_22:null);if(_5)_18.scrollToBottom()
else _18.scrollToRight();_18.moveTo(_5?null:_19,_5?_19:null);if(!_18.isVisible())_18.show()}
}else{var _19=_4.$495,_20=Math.min((_19+_4.$496),(_5?this.getTop()+_7:this.getLeft()+_7));var _23=(_5?this.getTop():this.getLeft())+_7
if(_23<=_19){}else{if(_5)_18.setHeight(_20-_19);else _18.setWidth(_20-_19);if(!_18.isVisible())_18.show()}
}
}
}
var _24=0;if(_15&&_25){var _25=_5?this.hscrollbar:this.vscrollbar;if(_4.$1n){var _26=_5?(this.getTop()+Math.max(0,(_7-this.scrollbarSize)))
:(this.getLeft()+Math.max(0,(_7-this.scrollbarSize)))
_25.moveTo(_5?null:_26,_5?_26:null);var _27=Math.min(_7,this.scrollbarSize);_25.resizeTo(_5?null:_27,_5?_27:null);if(_5){_25.scrollToBottom();if(_25.thumb)_25.thumb.scrollToBottom()}else{_25.scrollToRight();if(_25.thumb)_25.thumb.scrollToRight()}
if(_7>this.scrollbarSize&&!this.isVisible()){this.$vd=true;this.show();delete this.$vd}
}else{if(_8<=this.scrollbarSize){if(!_25.isVisible())_25.show();_25.resizeTo(_5?null:this.scrollbarSize-_8,_5?this.scrollbarSize-_8:null)}
}
if(_25.isVisible()){_24=this.scrollbarSize-
(_5?_25.getHeight()
:_25.getWidth())}else{_24=this.scrollbarSize}
}
var _28=_7;if(_9)_28+=_11;if(_24)_28+=_24
if(!this.resizeTo((_5?null:_28),(_5?_28:null),true))
{this.$5y()}
if(_4.$1n){this.scrollTo((_5?null:_4.$1m+_8),(_5?_4.$1m+_8:null),null,true)}
}else{if(!this.isVisible())this.show();this.$744("show");if(!this.resizeTo(_4.$1i,_4.$1g)){this.$5y()}
this.setOverflowForAnimation(_4.$1k);if(this.overflow==isc.Canvas.AUTO||this.overflow==isc.Canvas.SCROLL){delete this.$417;if(this.vscrollOn&&this.vscrollbar){if(this.vscrollbar.visibility==isc.Canvas.HIDDEN)this.vscrollbar.show();if(_5)delete this.vscrollbar.$494;delete this.vscrollbar.$493;this.vscrollbar.$jq=true;if(_4.$1n)this.vscrollbar.scrollTo(0,0);if(this.vscrollbar.thumb){delete this.vscrollbar.thumb.$493;this.vscrollbar.thumb.$jq=true;if(_4.$497)this.vscrollbar.thumb.scrollTo(0,0)}
if(!_5){this.vscrollbar.setWidth(this.getScrollbarSize());this.vscrollbar.setThumb()}
}
if(this.hscrollOn&&this.hscrollbar){if(this.hscrollbar.visibility==isc.Canvas.HIDDEN)this.hscrollbar.show();if(!_5){delete this.hscrollbar.$494}else{this.hscrollbar.setHeight(this.getScrollbarSize());this.hscrollbar.setThumb()}
delete this.hscrollbar.$493;this.hscrollbar.$jq=true;if(_4.$1n)this.hscrollbar.scrollTo(0,0);if(this.hscrollbar.thumb){delete this.hscrollbar.thumb.$493;this.hscrollbar.thumb.$jq=true;if(_4.$1n)this.hscrollbar.thumb.scrollTo(0,0)}
}
}
if(this.showEdges&&this.$l0){if(_4.$1n){var _12=(_5?"marginTop":"marginLeft"),_13=(_5?this.getTopMargin():this.getLeftMargin());this.$u9(this.getStyleHandle(),_12,_13);this.$l0.scrollTo((_5?null:0),(_5?0:null))}
if(_5)
this.$l0.getHandle().firstChild.style.height="100%";else
this.$l0.getHandle().firstChild.style.width="100%";this.$l0.setOverflow(isc.Canvas.VISIBLE);delete this.$l0.$za}
this.updateUserSize(_4.$pn,this.$o6);this.updateUserSize(_4.$po,this.$o5);this._percent_width=_4.$58x;this._percent_height=_4.$58y;if(_4.$1n)this.scrollTo((_5?null:_4.$1m),(_5?_4.$1m:null));if(_4.$03){this.$0z(_4.$03,_3)}
}
}
,isc.A.setOverflowForAnimation=function isc_Canvas_setOverflowForAnimation(_1,_2){if(_2!=null){this.$171m=_2}else{delete this.$171m}
this.setOverflow(_1)}
,isc.A.animateShowComplete=function isc_Canvas_animateShowComplete(_1){if(this.$58w!=null){this._percent_left=this.$58w;delete this.$58w}
this.$vc=null;var _2=this.$1c;this.$1c=null;if(_2)this.$0z(_2,_1,true)}
,isc.A.$1f=function isc_Canvas__canAnimateClip(_1){if(this.canAnimateClip!=null)return this.canAnimateClip;return(this.scrollTo==isc.Canvas.getInstanceProperty("scrollTo"))}
,isc.A.animateHide=function isc_Canvas_animateHide(_1,_2,_3,_4,_5){if(_1==null)_1=this.animateHideEffect;var _6;if(isc.isAn.Object(_1)){_6=_1;_1=_6.effect}
if(this.$vc!=null){this.finishAnimation(this.$vc)}
if(!this.isVisible())return;if(this.$va!=null)return;if(!this.isDrawn()&&!isc.isA.LayoutSpacer(this)){this.hide();if(_2)this.$0z(_2,true);return}
this.$va=this.$0v[_1]||this.$zb;this.$1p=_2;if(!this.$1q)
this.$1q={target:this,methodName:"$1r"}
if(_1==this.$0q){this.$1s=this.opacity;this.$1t=true;if(_3==null)_3=this.animateHideTime;if(_4==null)_4=this.animateHideAcceleration;return this.animateFade(0,this.$1q,_3,_4,_5)}else if(_1==this.$0r){this.$1u=this.getLeft();this.$58z=this._percent_left;if(this.parentElement!=null){this.logInfo("animateHide() called with 'fly' effect - not supported for child widgets defaulting to standard 'wipe' animation instead.","animation");_1=this.$0p}else{if(_3==null)_3=this.animateShowTime;if(_4==null)_4=this.animateShowAcceleration;var _7=this.isRTL(),_8=_7?isc.Page.getWidth()+isc.Page.getScrollLeft()
:0-this.getVisibleWidth();return this.animateMove(_8,null,this.$1q,_3,_4,_5)}
}
if((!this.$1f(_1)||!this.isDrawn())&&!this.isA(isc.LayoutSpacer))
{this.logInfo("not animating hide, can't do clip animations","animation");this.hide();this.$1r(true);return}
var _9=this.getVisibleHeight(),_10=this.getVisibleWidth(),_11=_6?_6.endsAt==this.$0s||_6.endAt==this.$0s:true,_12={$po:this.$po,$1g:this.getHeight(),$1h:_9,$pn:this.$pn,$1i:this.getWidth(),$1j:_10,$1m:(_11?this.getScrollTop():this.getScrollLeft()),$1l:_11,$1v:_1=="slide",$1k:this.overflow,$03:this.$1q,$1w:_5
};if(_12.$1v){if(_11&&this.vscrollOn&&this.vscrollbar){_12.$495=this.vscrollbar.thumb.getTop();_12.$496=this.vscrollbar.thumb.getHeight()}else if(!_11&&this.hscrollOn&&this.hscrollbar){_12.$495=this.hscrollbar.thumb.getLeft();_12.$496=this.hscrollbar.thumb.getWidth()}
}
this.resizeTo(_10,_9,true);if(this.overflow==isc.Canvas.VISIBLE){this.setOverflowForAnimation(isc.Canvas.HIDDEN,this.overflow)}
if(this.overflow==isc.Canvas.AUTO||this.overflow==isc.Canvas.SCROLL){this.$417=true;if(this.vscrollOn&&this.vscrollbar){this.vscrollbar.$jq=false;if(_11)this.vscrollbar.$494=true;this.vscrollbar.$493=true;if(this.vscrollbar.thumb){this.vscrollbar.thumb.$493=true}
}
if(this.hscrollOn&&this.hscrollbar){this.hscrollbar.$jq=false;if(!_11)this.hscrollbar.$494=true;this.hscrollbar.$493=true;if(this.hscrollbar.thumb){this.hscrollbar.thumb.$493=true}
}
}
if(this.showEdges){this.$l0.setOverflow("hidden");this.$l0.$za=true;this.$u9(this.$l0.getHandle().firstChild.style,(_11?"height":"width"),(_11?this.$l0.getHeight():this.$l0.getWidth()))}
return this.$0y(this.$zb,_12,_3,_4)}
,isc.A.fireAnimationHide=function isc_Canvas_fireAnimationHide(_1,_2,_3){var _4=this.$hideAnimationInfo,_5=_4.$1l;if(_1<1){var _6=(_5?_4.$1h:_4.$1j),_7=this.$04(_6,1,_1),_8=_6-_7,_9=(this.showEdges&&this.$l0),_10,_11,_12=this.hscrollOn&&this.hscrollbar,_13=this.vscrollOn&&this.vscrollbar;if(_9){_10=(_4.$1v?(_5?this.$l0.$td
:this.$l0.$tb)
:(_5?this.$l0.$te
:this.$l0.$tc));_11=(_4.$1v?(_5?this.$l0.$te
:this.$l0.$tc)
:(_5?this.$l0.$td
:this.$l0.$tb));this.$l0.resizeTo((_5?null:_7),(_5?_7:null),true);if(_4.$1v){if(_5)this.$l0.scrollToBottom();else this.$l0.scrollToRight()}
if(_8<_10){if(_4.$1v){var _14=(_5?"marginTop":"marginLeft"),_15=(_5?this.getTopMargin():this.getLeftMargin())
this.$u9(this.getStyleHandle(),_14,(_15-_8))}
this.$5y();return}
if(_4.$1v&&!this.$1y){var _14=(_5?"marginTop":"marginLeft"),_15=(_5?this.getTopMargin():this.getLeftMargin())
this.$u9(this.getStyleHandle(),_14,(_15-_10));this.$1y=true}
if(_9&&_7<=_11){this.$vb=true;this.getStyleHandle().visibility=isc.Canvas.HIDDEN;delete this.$vb}
}
var _16=_5?(_13?this.vscrollbar:null)
:(_12?this.hscrollbar:null);if(_16){if(_5)_16.setHeight(_7);else{var _17=_7;if(this.vscrollOn){if(_4.$1v){_17-=this.scrollbarSize}else{_17=Math.min(_7,_6-this.scrollbarSize)}
}
if(_17>0)_16.setWidth(_17);else _16.hide()}
if(_4.$1v){if(_5)_16.scrollToBottom();else _16.scrollToRight()}
if(_16.thumb&&_16.thumb.isVisible()){if(_4.$1v){var _18=_4.$495-_8,_19=_5?this.getTop():this.getLeft();if(_18>=_19){_16.thumb.moveTo(_5?null:_18,_5?_18:null)}else{_16.thumb.moveTo(_5?null:this.getLeft(),_5?this.getTop():null);var _20=_4.$496+(_18-_19);if(_20>0){_16.thumb.resizeTo(_5?null:_20,_5?_20:null);_16.thumb.scrollTo(_5?null:_19-_18,_5?_19-_18:null)}else{_16.thumb.hide()}
}
}else{if(_5){var _21=(this.getTop()+_7)
if(_16.thumb.getBottom()>_21){var _22=_21-_16.thumb.getTop();if(_22>0)_16.thumb.setHeight(_22);else _16.thumb.hide()}
}else{var _23=(this.getLeft()+_7)
if(_16.thumb.getRight()>_23){var _24=_23-_16.thumb.getLeft();if(_24>0)_16.thumb.setWidth(_24);else _16.thumb.hide()}
}
}
}
}
var _25=_5?(_12?this.hscrollbar:null)
:(_13?this.vscrollbar:null),_26=0;if(_25){var _27=this.scrollbarSize;if(_4.$1v){if(_7>=_27){var _28=(_5?this.getTop():this.getLeft())+_7-_27;_25.moveTo(_5?null:_28,_5?_28:null)}else{_25.moveTo(_5?null:this.getLeft(),_5?this.getTop():null);_25.resizeTo(_5?null:_7,_5?_7:null);if(_5)_25.scrollToBottom();else _25.scrollToRight();var _29=_25.thumb
if(_29){_29.resizeTo(_5?null:_7,_5?_7:null);if(_5)_29.scrollToBottom();else _29.scrollToRight()}
}
if(_7<=_27){this.$vb=true;if(this.isVisible())this.hide();delete this.$vb;return}
}else{if(_8<=_27){_25.resizeTo(_5?null:_27-_8,_5?_27-_8:null);if(_25.thumb){_25.thumb.resizeTo(_5?null:_27-_8,_5?_27-_8:null)}
}else{if(_25.isVisible())_25.hide()}
}
if(_25.isVisible()){_26=this.scrollbarSize-
(_5?_25.getHeight()
:_25.getWidth())}else{_26=this.scrollbarSize}
}
var _30=_7;if(_9)_30+=_10;if(_26)_30+=_26;if(!this.resizeTo((_5?null:_30),(_5?_30:null),true))
{this.$5y()}
var _31;if(_4.$1v){this.scrollTo((_5?null:_4.$1m+_8),(_5?_4.$1m+_8:null),null,true)}
}else{this.$744("hide");if(this.isVisible())this.hide();if(_4.$1k)this.setOverflowForAnimation(_4.$1k);if(this.showEdges&&this.$l0){delete this.$1y;this.$l0.setOverflow(isc.Canvas.VISIBLE);delete this.$l0.$za;if(_5)this.$l0.getHandle().firstChild.style.height="100%";else this.$l0.getHandle().firstChild.style.width="100%"
if(_4.$1v){var _32=this.$sd(),_14=(_5?"marginTop":"marginLeft"),_15=(_5?_32.top:_32.left)
this.$u9(this.getStyleHandle(),_14,_15)}
}
if(this.overflow==isc.Canvas.AUTO||this.overflow==isc.Canvas.SCROLL){delete this.$417;if(_5){if(this.vscrollOn&&this.vscrollbar){if(this.vscrollbar.isVisible())this.vscrollbar.hide();delete this.vscrollbar.$494;delete this.vscrollbar.$493;this.vscrollbar.$jq=true;if(this.vscrollbar.thumb){delete this.vscrollbar.thumb.suppressImageResize}
if(_4.$1v){this.vscrollbar.scrollTo(0,0);this.vscrollbar.setHeight(this.getHeight());if(this.vscrollbar.thumb)this.vscrollbar.thumb.scrollTo(0,0)}
}
if(this.hscrollOn&&this.hscrollbar){if(this.hscrollbar.isVisible())this.hscrollbar.hide();this.hscrollbar.$jq=true;delete this.hscrollbar.$493;if(_4.$1v)this.hscrollbar.scrollTo(0,0);if(this.hscrollbar.thumb){delete this.hscrollbar.thumb.$493;if(_4.$1v)this.hscrollbar.thumb.scrollTo(0,0)}
}
}else{if(this.hscrollOn&&this.hscrollbar){if(this.hscrollbar.isVisible())this.hscrollbar.hide();delete this.hscrollbar.$494;delete this.hscrollbar.$493;this.hscrollbar.$jq=true;if(this.hscrollbar.thumb)
delete this.hscrollbar.$493;if(_4.$1v){this.hscrollbar.scrollTo(0,0);this.hscrollbar.setWidth(this.getWidth());if(this.hscrollbar.thumb)this.hscrollbar.thumb.scrollTo(0,0)}
}
if(this.vscrollOn&&this.vscrollbar){if(this.vscrollbar.isVisible())this.vscrollbar.hide();this.vscrollbar.$jq=true;delete this.vscrollbar.$493;if(_4.$1v)this.vscrollbar.scrollTo(0,0);if(this.vscrollbar.thumb){if(_4.$1v)this.vscrollbar.thumb.scrollTo(0,0);delete this.vscrollbar.$493}
}
}
}
this.resizeTo(_4.$1i,_4.$1g);this.updateUserSize(_4.$pn,this.$o6);this.updateUserSize(_4.$po,this.$o5);if(_4.$1v)this.scrollTo((_5?null:_4.$1m),(_5?_4.$1m:null));if(_4.$03){this.$0z(_4.$03,_3,true)}
}
}
);isc.evalBoundary;isc.B.push(isc.A.$1r=function isc_Canvas__animateHideComplete(_1){delete this.$va;var _2=this.$1p;delete this.$1p;if(this.isVisible())this.hide();if(this.$1t){this.setOpacity(this.$1s);delete this.$1s;delete this.$1t}
if(this.$1u!=null){this.setLeft(this.$1u);delete this.$1u}
if(this.$58z!=null){this._percent_left=this.$58z;delete this.$58z}
if(_2){this.$0z(_2,_1,true)}
}
,isc.A.isAnimating=function isc_Canvas_isAnimating(_1){if(_1==null)return this.$743>0;if(_1&&!isc.isAn.Array(_1)){if(!this.$745)this.$745=[];this.$745[0]=_1;_1=this.$745}
if(!_1)_1=this.$0g;for(var i=0;i<_1.length;i++){if(this[this.$0w(_1[i])]!=null){return true}
}
return false}
);isc.B._maxIndex=isc.C+31;isc.ClassFactory.defineClass("StatefulCanvas","Canvas");isc.A=isc.StatefulCanvas;isc.A.STATE_UP="";isc.A.STATE_DOWN="Down";isc.A.STATE_OVER="Over";isc.A.STATE_DISABLED="Disabled";isc.A.BUTTON="button";isc.A.CHECKBOX="checkbox";isc.A.RADIO="radio";isc.A.FOCUSED="Focused";isc.A.SELECTED="Selected";isc.A.UNSELECTED="";isc.A.$1z={};isc.A.$1333={"left":"right","center":"center","right":"left"
};isc.A.$95r={};isc.A.$95t={};isc.A.$95m=["borderBottomLeftRadius","borderBottomRightRadius","borderTopRightRadius","borderTopLeftRadius","borderBottomColor","borderBottomStyle","borderBottomWidth","borderLeftColor","borderLeftStyle","borderLeftWidth","borderRightColor","borderRightStyle","borderRightWidth","borderTopColor","borderTopStyle","borderTopWidth"
];isc.A.$95n=4;isc.A.$95o=" ";isc.A.pushTableBorderStyleToDiv=false;isc.A.$132w={};isc.A.$132x={};isc.A.pushTableShadowStyleToDiv=null;isc.A=isc.StatefulCanvas.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.ignoreRTL=false;isc.A.state="";isc.A.showFocusedAsOver=true;isc.A.showDisabled=true;isc.A.actionType="button";isc.A.cursor=isc.Canvas.ARROW;isc.A.capSize=0;isc.A.align=isc.Canvas.CENTER;isc.A.valign=isc.Canvas.CENTER;isc.A.autoFitDirection=isc.Canvas.BOTH;isc.A.iconSize=16;isc.A.iconOrientation="left";isc.A.iconSpacing=6;isc.A.showIconState=true;isc.A.showDisabledIcon=true;isc.A.gripImgSuffix="grip";isc.A.overCanvasConstructor="Canvas";isc.A.overCanvasDefaults={mouseOut:function(){if(isc.EH.getTarget()!=this.creator)this.clear();return this.Super("mouseOut",arguments)}
};isc.B.push(isc.A.setRadioGroup=function isc_StatefulCanvas_setRadioGroup(_1){this.removeFromRadioGroup();this.addToRadioGroup(_1)}
,isc.A.getIconStyleForOrientation=function isc_StatefulCanvas_getIconStyleForOrientation(){if(this.vertical)return this.vIconStyle||this.iconStyle;return this.iconStyle}
);isc.B._maxIndex=isc.C+2;isc.A=isc.StatefulCanvas.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$2086={Over:"showImageRollOver",Focused:"showImageFocused",Down:"showImageDown",Disabled:"showImageDisabled",Selected:"showImageSelected"};isc.A.$42d="visualState";isc.A.showFlexEdge=false;isc.A.flexEdgeConstructor="Canvas";isc.A.flexEdgeDefaults={overflow:"hidden",canDragResposition:false,canDragResize:false,backgroundColor:"lightgrey",width:"100%",height:3,snapTo:"B",snapOffsetLeft:0,snapOffsetTop:0,borderRadius:"3px",initWidget:function(){this.Super("initWidget",arguments);this.observe(this.creator,"zIndexChanged","observer.updateForParentZIndex()");if(this.creator.flexEdgeBaseStyle){this.observe(this.creator,"stateChanged","observer.updateForParentState()")}
},draw:function(){this.Super("draw",arguments);var _1=this.creator.getFlexEdgeProperties();if(_1)this.setProperties(_1);if(this.creator.flexEdgeBaseStyle){this.updateForParentState()}
},destroy:function(){if(this.isObserving(this.creator,"zIndexChanged"))
this.ignore(this.creator,"zIndexChanged");if(this.isObserving(this.creator,"stateChanged"))
this.ignore(this.creator,"stateChanged");return this.Super("destroy",arguments)},updateForParentState:function(){var _1=this.creator.getStateSuffix(),_2=this.creator.flexEdgeBaseStyle+_1
;this.setStyleName(_2);this.updateForParentZIndex()},updateForParentZIndex:function(){this.moveAbove(this.creator)},click:function(){if(this.dragTarget.flexEdgeClick)this.dragTarget.flexEdgeClick()},doubleClick:function(){if(this.dragTarget.flexEdgeDoubleClick)this.dragTarget.flexEdgeDoubleClick()}};isc.A.observeCSSVariableChanges=true;isc.A.$2087={Over:"showRollOver",Focused:"showFocused",Down:"showDown",Disabled:"showDisabled"};isc.A.labelDefaults={$1240:true,$kk:function(){return this.masterElement.$kk()},focusChanged:function(_1){if(this.hasFocus)this.eventProxy.focus()},getContents:function(){return this.masterElement.getTitleHTML()},adjustOverflow:function(_1,_2,_3,_4){this.invokeSuper(null,"adjustOverflow",_1,_2,_3,_4);if(this.masterElement)this.masterElement.$10()}};isc.A.$11="label";isc.A.$12="Label overflowed.";isc.A.$64x="$5y";isc.A.autoApplyOverState=true;isc.A.autoApplyDownState=true;isc.B.push(isc.A.init=function isc_StatefulCanvas_init(){if(isc.isA.String(this.icon)){if(isc.Media.isEmptyStockIcon(this.icon))this.icon=null}
return this.Super("init",arguments)}
,isc.A.initWidget=function isc_StatefulCanvas_initWidget(){var _1=this.getClass().getPrototype().styleName;if(this.styleName!=null&&this.styleName!=_1){if(this.baseStyle!=null&&this.baseStyle!=this.styleName){this.logWarn("Explicit styleName detected ('"
+this.styleName+"'). This property will be ignored in favor of baseStyle ('"+this.baseStyle+"').")}
}
if(this.src==null)this.src=this.vertical?this.vSrc:this.hSrc;var _2=(this.state==isc.StatefulCanvas.STATE_DISABLED);if(_2){if(!this.showDisabled){this.logWarn("The state cannot be initialized to 'Disabled' if this.showDisabled is false. Setting to STATE_UP...");this.state=isc.StatefulCanvas.STATE_UP;_2=false}
}
if(this.isDisabled()){if(!_2)this.$42e=this.state;if(this.showDisabled){this.state=isc.StatefulCanvas.STATE_DISABLED;_2=true}
}
this.baseStyle=this.baseStyle||this.className;var _3=this.getStateName()
this.styleName=(this.suppressClassName?null:_3);this.className=this.styleName;this.$2088=_3;if(this.radioGroup!=null){var _4=this.radioGroup;this.radioGroup=null;this.addToRadioGroup(_4)}
this.$236l=true;this.setAutoFit(this.autoFit,true);if(this.showGrip){this.showTitle=true;this.labelVPad=0;this.labelHPad=0;this.iconSpacing=0;this.align=isc.Canvas.CENTER;this.$207g();this.showRollOverIcon=this.showRollOverGrip;this.showDownIcon=this.showDownGrip}
var _5=this.shouldShowLabel();if(_5)this.makeLabel();if(this.shouldShowFlexEdge()){var _6={dragTarget:this};if(this.flexEdgeBreadth){_6.width=_6.maxWidth=this.vertical?this.flexEdgeBreadth:this.flexEdgeLength}
if(this.flexEdgeLength){_6.height=this.vertical?this.flexEdgeLength:this.flexEdgeBreadth}
if(this.flexEdgeSnapTo)_6.snapTo=this.flexEdgeSnapTo;if(this.flexEdgeSnapOffsetLeft)_6.snapOffsetLeft=this.flexEdgeSnapOffsetLeft;if(this.flexEdgeSnapOffsetTop)_6.snapOffsetTop=this.flexEdgeSnapOffsetTop;if(this.flexEdgeBaseStyle)_6.baseStyle=this.flexEdgeBaseStyle;if(this.flexEdgeColor)_6.backgroundColor=this.flexEdgeColor;if(this.flexEdgeRadius)_6.borderRadius=this.flexEdgeRadius;this.flexEdge=this.createAutoChild("flexEdge",_6);if(this.flexEdge.vertical==null)this.flexEdge.vertical=this.vertical;this.addPeer(this.flexEdge)}}
,isc.A.$207g=function isc_StatefulCanvas__setGripIconDirection(){if(isc.isAn.Object(this.src)){this.icon=this.src}else if(isc.Media&&isc.Media.getStockIconKeyForSrc(this.src,this.skinImgDir,this)
||isc.Canvas.$1861(this.src))
{this.icon=this.src}else{this.icon=this.getImgURL(this.getURL(this.gripImgSuffix))}
this.iconSize=this.gripSize;if(this.cssOnly){this.iconWidth=null;this.iconHeight=null}else{this.iconWidth=this.vertical?this.gripBreadth:this.gripLength;this.iconHeight=this.vertical?this.gripLength:this.gripBreadth}
if(this.label){this.label.setProperties({icon:this.icon,iconSize:this.iconSize,iconWidth:this.iconWidth,iconHeight:this.iconHeight
})}}
,isc.A.getAriaLabel=function isc_StatefulCanvas_getAriaLabel(){var _1;if(this.ariaLabel!==_1)return this.ariaLabel;var _2=this.prompt||this.title;if(_2!=null&&_2!=""&&isc.Button.getInstanceProperty("title")!=_2){return String.htmlStringToString(_2)}
return null}
,isc.A.$2089=function isc_StatefulCanvas__shouldShowStatefulImage(_1){if(this.statelessImage)return false;var _2=this.$2086[_1],_3=this.$2087[_1];if(this[_2]!=null)return this[_2];if(!isc.isAn.Object(this.src)){return _3?this[_3]:true}else{return true}}
,isc.A.getURL=function isc_StatefulCanvas_getURL(_1,_2,_3,_4){if(this.statelessImage)return isc.Img.urlForState(this.src);if(_2==null)_2=this.state;if(_3==null)_3=this.selected;if(_4==null)_4=this.getFocusedState();if(_2&&!this.$2089(_2))_2=null;if(_3&&!this.$2089(isc.StatefulCanvas.STATE_SELECTED))_3=false;if(_4){if(!this.$2089(isc.StatefulCanvas.FOCUSED)){_4=false}else{var _5=this.showImageFocusedAsOver;if(_5==null)_5=this.showFocusedAsOver;if(_5&&!isc.isAn.Object(this.src)){if(this.$2089(isc.StatefulCanvas.STATE_OVER)&&(!_2||_2==isc.StatefulCanvas.STATE_UP))
{_2=isc.StatefulCanvas.STATE_OVER}
_4=false}
}
}
return isc.Img.urlForState(this.src,_3,_4,_2,_1,this.getCustomState())}
,isc.A.shouldShowLabel=function isc_StatefulCanvas_shouldShowLabel(){return this.showTitle}
,isc.A.setIgnoreRTL=function isc_StatefulCanvas_setIgnoreRTL(_1){this.ignoreRTL=!!_1;if(this.isDrawn())this.markForRedraw();if(this.label)this.label.setIgnoreRTL(_1)}
,isc.A.stateChanged=function isc_StatefulCanvas_stateChanged(_1){if(this.destroyed)return;if(!this.$236l)return;var _2=this.getStateName();var _3=(this.$2088!=_2);this.$2088=_2;if(this.logIsDebugEnabled(this.$42d)){this.logDebug("state changed to: "+_2,"visualState")}
if(_1||this.$179l()){this.markForRedraw("state change")}
if(!this.suppressClassName&&(_3||this.pendingMarkerVisible)){this.$300k=true;this.setStyleName(_2);delete this.$300k}
var _4=this.label;if(_4!=null){_4.setState(this.getState());_4.setSelected(this.isSelected());_4.setCustomState(this.getCustomState())}}
,isc.A.shouldShowFlexEdge=function isc_StatefulCanvas_shouldShowFlexEdge(){return this.showFlexEdge}
,isc.A.getFlexEdgeProperties=function isc_StatefulCanvas_getFlexEdgeProperties(){var _1=3,_2=this.vertical?"75%":"90%"
;if(this.flexEdge.vertical){return{width:_1,height:_2,snapTo:"L",snapOffsetLeft:4,snapOffsetTop:0
}}else{return{width:_2,height:_1,snapTo:"B",snapOffsetLeft:0,snapOffsetTop:-4,height:2
}
}}
,isc.A.cssVariablesChanged=function isc_StatefulCanvas_cssVariablesChanged(_1){this.stateChanged()}
,isc.A.$179l=function isc_StatefulCanvas__shouldRedrawOnStateChange(){return this.redrawOnStateChange}
,isc.A.setBaseStyle=function isc_StatefulCanvas_setBaseStyle(_1){if(this.pendingMarkerVisible==null&&this.baseStyle==_1)return;this.baseStyle=_1;if(this.label&&this.titleStyle==null)this.label.setBaseStyle(_1);this.stateChanged()}
,isc.A.setPendingMarkerVisible=function isc_StatefulCanvas_setPendingMarkerVisible(_1){this.pendingMarkerVisible=_1;if(this.baseStyle)this.setBaseStyle(this.baseStyle);else if(this.styleName)this.setStyleName(this.styleName)}
,isc.A.$141r=function isc_StatefulCanvas__getIconCursor(){var _1=this.iconCursor;if(this.isDisabled()&&this.disabledIconCursor!=null)_1=this.disabledIconCursor;return _1}
,isc.A.setTitleStyle=function isc_StatefulCanvas_setTitleStyle(_1){if(this.titleStyle==_1)return;this.titleStyle=_1;if(this.label){this.label.setBaseStyle(_1||this.baseStyle)}
this.stateChanged()}
,isc.A.setState=function isc_StatefulCanvas_setState(_1){if(_1==isc.StatefulCanvas.STATE_DISABLED&&!this.showDisabled){this.logWarn("The state cannot be changed to 'Disabled' when this.showDisabled is false.");return}
if(this.state==_1)return;this.state=_1;this.stateChanged()}
,isc.A.$sn=function isc_StatefulCanvas__updateChildrenTopElement(){this.Super("$sn",arguments);this.setHandleDisabled(this.isDisabled())}
,isc.A.getState=function isc_StatefulCanvas_getState(){return this.state}
,isc.A.setSelected=function isc_StatefulCanvas_setSelected(_1){if(this.selected==null&&_1==false){this.selected=false;return}
if(this.selected==_1)return;if(_1&&this.radioGroup!=null){var _2=isc.StatefulCanvas.$1z[this.radioGroup];if(_2==null){this.logWarn("'radioGroup' property set for this widget, but no corresponding group exists. To set up a new radioGroup containing this widget, or add this  widget to an existing radioGroup at runtime, call 'addToRadioGroup(groupID)'")}else{for(var i=0;i<_2.length;i++){if(_2[i]!=this&&_2[i].isSelected())
_2[i].setSelected(false)}
}
}
this.selected=_1;if(this.label)this.label.setSelected(this.isSelected());this.stateChanged()}
,isc.A.select=function isc_StatefulCanvas_select(){this.setSelected(true)}
,isc.A.deselect=function isc_StatefulCanvas_deselect(){this.setSelected(false)}
,isc.A.isSelected=function isc_StatefulCanvas_isSelected(){return this.selected}
,isc.A.getActionType=function isc_StatefulCanvas_getActionType(){return this.actionType}
,isc.A.setActionType=function isc_StatefulCanvas_setActionType(_1){if(_1==isc.StatefulCanvas.BUTTON&&this.isSelected()){this.setSelected(false)}
this.actionType=_1}
,isc.A.addToRadioGroup=function isc_StatefulCanvas_addToRadioGroup(_1){if(_1==null||this.radioGroup==_1)return;if(this.radioGroup!=null)this.removeFromRadioGroup();this.radioGroup=_1;if(!isc.StatefulCanvas.$1z[this.radioGroup]){isc.StatefulCanvas.$1z[this.radioGroup]=[]}
var _2=isc.StatefulCanvas.$1z[this.radioGroup];_2.add(this);if(this.selected){this.selected=false;this.setSelected(true)}}
,isc.A.removeFromRadioGroup=function isc_StatefulCanvas_removeFromRadioGroup(_1){if(this.radioGroup==null||(_1!=null&&_1!=this.radioGroup))return;var _2=isc.StatefulCanvas.$1z[this.radioGroup];if(_2)_2.remove(this);delete this.radioGroup;if(this.selected){this.selected=false;this.markForRedraw()}}
,isc.A.setHandleDisabled=function isc_StatefulCanvas_setHandleDisabled(_1,_2,_3,_4){this.invokeSuper(isc.StatefulCanvas,"setHandleDisabled",_1,_2,_3,_4);var _5=(this.state==isc.StatefulCanvas.STATE_DISABLED);if(_5==_1)return;if(_1==false){var _6=this.$42e||isc.StatefulCanvas.STATE_UP;if(_6==isc.StatefulCanvas.STATE_OVER){var _7=this.ns.EH;if(!this.visibleAtPoint(_7.getX(),_7.getY())){_6=isc.StatefulCanvas.STATE_UP;this.setState(_6)}else{this.$168c()}
}else this.setState(_6)}else{this.$42e=this.state;this.$168d(true);if(this.showDisabled){this.setState(isc.StatefulCanvas.STATE_DISABLED)}
}
if(this.showDisabled&&this.iconCursor!=null){if(this.icon!=null){var _8=this.getImage("icon",this.$1889());if(_8!=null)_8.style.cursor=this.$141r()}
}}
,isc.A.$5f=function isc_StatefulCanvas__getIconURL(){if(this.$2250==true)return null;var _1=this.icon;if(isc.isAn.Object(_1)&&_1.src!=null){_1=_1.src}
return _1}
,isc.A.$1889=function isc_StatefulCanvas__iconIsSprite(){var _1=this.$5f();return _1&&_1.startsWith("sprite:")}
,isc.A.getStateName=function isc_StatefulCanvas_getStateName(){var _1=this.getStateSuffix();if(_1)return this.baseStyle+_1;return this.baseStyle}
,isc.A.getTitleStateName=function isc_StatefulCanvas_getTitleStateName(){if(!this.titleStyle)return null;return this.titleStyle+(this.showDisabled&&this.isDisabled()?isc.StatefulCanvas.STATE_DISABLED:isc.emptyString)}
,isc.A.getStateSuffix=function isc_StatefulCanvas_getStateSuffix(){var _1=this.getState(),_2=this.$2087[_1];if(_1&&_2&&this[_2]===false){_1=null}
var _3=this.getFocusedState()&&this.showFocused,_4;if(_3){if(this.showFocusedAsOver){if(this.showRollOver&&(!_1||_1==isc.StatefulCanvas.STATE_UP)){_1=isc.StatefulCanvas.STATE_OVER}
}else{_4=isc.StatefulCanvas.FOCUSED}
}
var _5=this.isSelected()?isc.StatefulCanvas.SELECTED:null,_6=this.getCustomState();return this.$61l(_1,_5,_4,_6)}
,isc.A.$61l=function isc_StatefulCanvas__getStateSuffix(_1,_2,_3,_4){return isc.StatefulCanvas.$61l(_1,_2,_3,_4)}
,isc.A.setCustomState=function isc_StatefulCanvas_setCustomState(_1){if(_1==this.customState)return;this.customState=_1;this.stateChanged()}
,isc.A.getCustomState=function isc_StatefulCanvas_getCustomState(){return this.customState}
,isc.A.getPrintStyleName=function isc_StatefulCanvas_getPrintStyleName(){return this.printStyleName||this.getStateName()}
,isc.A.makeLabel=function isc_StatefulCanvas_makeLabel(){var _1=this.getAutoChildClass(this.$11,null,isc.Label);var _2=_1.createRaw();_2.ignoreRTL=this.ignoreRTL;_2.clipTitle=this.clipTitle;_2.showClippedTitleOnHover=false;_2.$115g=false;if(this.$115j!=null){_2.$115j=function(){return this.masterElement.$115j()}}
_2.align=this.align;_2.valign=this.valign;_2.$jo=false;_2.$jp=(this.$1155!=null?this.$1155:false);_2._redrawWithParent=false;_2.containedPeer=true;_2.icon=this.icon;_2.iconWidth=this.iconWidth;_2.iconHeight=this.iconHeight;_2.iconSize=this.iconSize;_2.iconOrientation=this.iconOrientation;_2.iconAlign=this.iconAlign;_2.iconSpacing=this.iconSpacing;_2.iconStyle=this.getIconStyleForOrientation();_2.vIconStyle=this.vIconStyle;_2.iconCursor=this.iconCursor;_2.disabledIconCursor=this.disabledIconCursor;_2.showDownIcon=this.showDownIcon;_2.showSelectedIcon=this.showSelectedIcon;_2.showRollOverIcon=this.showRollOverIcon;if(_2.showRollOverIcon)_2.showRollOver=true;_2.showFocusedIcon=this.showFocusedIcon;_2.showDisabledIcon=this.showDisabledIcon;_2.showRTLIcon=this.showRTLIcon;if(this.showIconState!=null)_2.showIconState=this.showIconState;_2.getFocusedAsOverState=function(){var _3=this.masterElement;if(_3&&_3.getFocusedAsOverState)return _3.getFocusedAsOverState()};_2.getFocusedState=function(){var _3=this.masterElement;if(_3&&_3.getFocusedState)return _3.getFocusedState()};_2.skinImgDir=this.labelSkinImgDir||this.skinImgDir;_2.baseStyle=this.titleStyle||this.baseStyle;_2.showDisabled=this.showDisabled;_2.state=this.getState();_2.customState=this.getCustomState();_2.getPrintStyleName=function(){return this.masterElement.getPrintStyleName()}
_2.overflow=this.overflow;_2.width=this.$15();_2.height=this.$16();_2.left=this.$17();_2.top=this.$18();_2.wrap=this.wrap!=null?this.wrap:this.vertical;_2.eventProxy=this;_2.isMouseTransparent=true;_2.zIndex=this.getZIndex(true)+1;_2.tabIndex=-1;this.$d3(this.$11,_2);_2=this.label=isc.SGWTFactory.extractFromConfigBlock(_2);_2.setDisabled(this.isDisabled());_2.setSelected(this.isSelected());this.addPeer(_2,null,null,true)}
,isc.A.setLabelSkinImgDir=function isc_StatefulCanvas_setLabelSkinImgDir(_1){this.labelSkinImgDir=_1;if(this.label!=null)this.label.setSkinImgDir(_1)}
,isc.A.setSkinImgDir=function isc_StatefulCanvas_setSkinImgDir(_1){this.Super("setSkinImgDir",arguments);if(this.labelSkinImgDir==null&&this.label!=null)this.label.setSkinImgDir(_1)}
,isc.A.setIconOrientation=function isc_StatefulCanvas_setIconOrientation(_1){this.iconOrientation=_1;if(this.label){this.label.iconOrientation=_1;this.label.markForRedraw()}else{this.markForRedraw()}}
,isc.A.setAutoFit=function isc_StatefulCanvas_setAutoFit(_1,_2){if(_2){this.$19=true;if(!_1)return}
if(!this.$19)return;_1=!!_1;if(!_2&&(!!this.autoFit==_1))return;this.$2a=true;this.autoFit=_1;var _3=(this.autoFitDirection==isc.Canvas.BOTH)||(this.autoFitDirection==isc.Canvas.HORIZONTAL),_4=(this.autoFitDirection==isc.Canvas.BOTH)||(this.autoFitDirection==isc.Canvas.VERTICAL);this.neverExpandWidth=_1&&_3;this.neverExpandHeight=_1&&_4;if(_1){this.$2b=this.overflow;this.setOverflow(isc.Canvas.VISIBLE);if(_3){this.$2c=this.width;this.setWidth(1)}
if(_4){this.$2d=this.height;this.setHeight(1)}
}else{var _5=this.$2c||this.defaultWidth,_6=this.$2d||this.defaultHeight;if(_3)this.setWidth(_5);if(_4)this.setHeight(_6);if(this.parentElement&&isc.isA.Layout(this.parentElement)){if(_3&&!this.$2c)this.updateUserSize(null,this.$o6);if(_4&&!this.$2d)this.updateUserSize(null,this.$o5)}
this.$2c=null;this.$2d=null;if(this.$2b)this.setOverflow(this.$2b);this.$2b=null}
delete this.$2a}
,isc.A.resizeBy=function isc_StatefulCanvas_resizeBy(_1,_2,_3,_4,_5,_6){var _7=this.parentElement;if(this.autoFit&&this.$19&&!this.$2a&&!(isc.isA.Layout(_7)&&_7.$2z))
{var _8=false;if(_1!=null&&(this.autoFitDirection==isc.Canvas.BOTH||this.autoFitDirection==isc.Canvas.HORIZONTAL))
{this.$2c=(1+_1);_8=true;_1=null}
if(_2!=null&&(this.autoFitDirection==isc.Canvas.BOTH||this.autoFitDirection==isc.Canvas.VERTICAL))
{this.$2d=(1+_2);_8=true;_2=null}
if(_8)this.setAutoFit(false)}
return this.invokeSuper(isc.StatefulCanvas,"resizeBy",_1,_2,_3,_4,_5,_6)}
,isc.A.getLabelHPad=function isc_StatefulCanvas_getLabelHPad(){if(this.labelHPad!=null)return this.labelHPad;if(this.vertical){return this.labelBreadthPad!=null?this.labelBreadthPad:0}else{return this.labelLengthPad!=null?this.labelLengthPad:this.capSize}}
,isc.A.getLabelVPad=function isc_StatefulCanvas_getLabelVPad(){if(this.labelVPad!=null)return this.labelVPad;if(!this.vertical){return this.labelBreadthPad!=null?this.labelBreadthPad:0}else{return this.labelLengthPad!=null?this.labelLengthPad:this.capSize}}
,isc.A.$17=function isc_StatefulCanvas__getLabelLeft(){var _1;if(this.isDrawn()){_1=(this.position==isc.Canvas.RELATIVE&&this.parentElement==null?this.getPageLeft():this.getOffsetLeft())}else{_1=this.getLeft()}
_1+=this.getLabelHPad();return _1}
,isc.A.$18=function isc_StatefulCanvas__getLabelTop(){var _1;if(this.isDrawn()){_1=(this.position==isc.Canvas.RELATIVE&&this.parentElement==null?this.getPageTop():this.getOffsetTop())}else{_1=this.getTop()}
_1+=this.getLabelVPad();return _1}
,isc.A.$15=function isc_StatefulCanvas__getLabelSpecifiedWidth(){var _1=this.getInnerWidth();_1-=2*this.getLabelHPad();return Math.max(_1,1)}
,isc.A.$16=function isc_StatefulCanvas__getLabelSpecifiedHeight(){var _1=this.getInnerHeight();_1-=2*this.getLabelVPad();return Math.max(_1,1)}
,isc.A.getImgBreadth=function isc_StatefulCanvas_getImgBreadth(){if(this.overflow==isc.Canvas.VISIBLE&&isc.isA.Canvas(this.label))
{return this.vertical?this.$2e():this.$2f()}
return(this.vertical?this.getInnerWidth():this.getInnerHeight())}
,isc.A.getImgLength=function isc_StatefulCanvas_getImgLength(){if(this.overflow==isc.Canvas.VISIBLE&&isc.isA.Canvas(this.label))
{return this.vertical?this.$2f():this.$2e()}
return(this.vertical?this.getInnerHeight():this.getInnerWidth())}
,isc.A.$2f=function isc_StatefulCanvas__getAutoInnerHeight(){var _1=this.getInnerHeight();if(!isc.isA.Canvas(this.label))return _1;var _2=this.getLabelVPad();var _3=this.label.getVisibleHeight()+2*_2;return Math.max(_3,_1)}
,isc.A.$2e=function isc_StatefulCanvas__getAutoInnerWidth(){var _1=this.getInnerWidth();if(!isc.isA.Canvas(this.label))return _1;var _2=this.getLabelHPad();var _3=this.label.getVisibleWidth()+2*_2;return Math.max(_3,_1)}
,isc.A.$160g=function isc_StatefulCanvas__getSizeTestHTML(_1){if(isc.isA.Canvas(this.label)){return"<table cellpadding=0 cellspacing=0><tr><td>"+isc.Canvas.spacerHTML(2*this.getLabelHPad(),1)+"</td><td>"+this.label.$160g(_1)+"</td></tr></table>"}
return"<div style='position:absolute;"+(this.wrap?"' ":"white-space:nowrap;' ")+"class='"+this.getStateName()+"'>"+_1+"</div>"}
,isc.A.$10=function isc_StatefulCanvas__labelAdjustOverflow(){if(this.overflow!=isc.Canvas.VISIBLE)return;this.adjustOverflow(this.$12)}
,isc.A.getScrollWidth=function isc_StatefulCanvas_getScrollWidth(_1,_2,_3,_4){if(this.overflow!=isc.Canvas.VISIBLE||!isc.isA.Canvas(this.label))
return this.invokeSuper(isc.StatefulCanvas,"getScrollWidth",_1,_2,_3,_4);if(this.$qz){this.$qz=null;this.adjustOverflow("widthCheckWhileDeferred")}
if(!_1&&this.$su!=null)return this.$su;var _5=this.$2e()
return(this.$su=_5)}
,isc.A.getScrollHeight=function isc_StatefulCanvas_getScrollHeight(_1,_2,_3,_4){if(this.overflow!=isc.Canvas.VISIBLE||!isc.isA.Canvas(this.label))
return this.invokeSuper(isc.StatefulCanvas,"getScrollHeight",_1,_2,_3,_4);if(this.$qz){this.$qz=null;this.adjustOverflow("heightCheckWhileDeferred")}
if(!_1&&this.$sz!=null)return this.$sz;var _5=this.$2f()
return(this.$sz=_5)}
,isc.A.setOverflow=function isc_StatefulCanvas_setOverflow(_1,_2,_3,_4,_5){if(this.autoFit&&this.$19&&!this.$2a&&_1!=isc.Canvas.VISIBLE){this.$2b=_1;this.setAutoFit(false);return}
this.invokeSuper(isc.StatefulCanvas,"setOverflow",_1,_2,_3,_4,_5);if(isc.isA.Canvas(this.label))this.label.setOverflow(_1,_2,_3,_4,_5)}
,isc.A.$5y=function isc_StatefulCanvas__resized(_1,_2,_3,_4,_5){this.invokeSuper(isc.StatefulCanvas,this.$64x,_1,_2,_3,_4,_5);if(this.label)this.label.resizeTo(this.$15(),this.$16())}
,isc.A.draw=function isc_StatefulCanvas_draw(_1,_2,_3){if(isc.$cv)arguments.$cw=this;var _4=isc.Canvas.$b4.draw.call(this,_1,_2,_3);if(this.position!=isc.Canvas.ABSOLUTE&&isc.isA.Canvas(this.label)){if(isc.Page.isLoaded())this.$42f();else isc.Page.setEvent("load",this.getID()+".$42f()")}
if(this.label!=null&&isc.Canvas.ariaEnabled()){var _5=this.getAriaLabel();if(_5!=null)this.setAriaState("label",_5)}
return _4}
,isc.A.$42f=function isc_StatefulCanvas__positionLabel(){if(!this.isDrawn())return;this.label.moveTo(this.$17(),this.$18())}
,isc.A.setAlign=function isc_StatefulCanvas_setAlign(_1){this.align=_1;if(this.isDrawn())this.markForRedraw();if(this.label)this.label.setAlign(_1)}
,isc.A.setVAlign=function isc_StatefulCanvas_setVAlign(_1){this.valign=_1;if(this.isDrawn())this.markForRedraw();if(this.label)this.label.setVAlign(_1)}
,isc.A.getPrintHTML=function isc_StatefulCanvas_getPrintHTML(_1,_2,_3,_4){var _5=this.shouldShowLabel();if(_5){if(this.label==null){this.makeLabel()}
return this.label.getPrintHTML(_1,_2,_3,_4)}
return this.Super("getPrintHTML",arguments)}
,isc.A.shouldHiliteAccessKey=function isc_StatefulCanvas_shouldHiliteAccessKey(){return this.hiliteAccessKey}
,isc.A.getTitleHTML=function isc_StatefulCanvas_getTitleHTML(){var _1=this.getTitle(true);_1=this.formatTitle(this,_1);if(!this.shouldHiliteAccessKey()||!isc.isA.String(_1)||this.accessKey==null){return _1}
return isc.Canvas.hiliteCharacter(_1,this.accessKey)}
,isc.A.formatTitle=function isc_StatefulCanvas_formatTitle(_1,_2){return _2}
,isc.A.getTitle=function isc_StatefulCanvas_getTitle(){return this.title}
,isc.A.setTitle=function isc_StatefulCanvas_setTitle(_1){this.title=_1;var _1=this.getTitleHTML();if(this.$116x!=null&&this.$116x==_1){return}else{this.$116x=_1}
if(this.label){if(this.label.$jp&&this.label.masterElement==this)this.label.$q7=true;this.label.setContents(_1);this.label.setState(this.getState());this.label.setSelected(this.isSelected())}else if(this.title!=null&&this.shouldShowLabel()){this.makeLabel()
}
if(isc.Canvas.ariaEnabled()){var _2=this.getAriaLabel();if(_2!=null)this.setAriaState("label",_2);else this.clearAriaState("label")}
this.markForRedraw("setTitle")}
,isc.A.setZIndex=function isc_StatefulCanvas_setZIndex(_1,_2,_3){isc.Canvas.$b4.setZIndex.call(this,_1,_2,_3);if(isc.isA.Canvas(this.label))this.label.moveAbove(this)}
,isc.A.$ur=function isc_StatefulCanvas__updateCanFocus(){this.Super("$ur",arguments);if(this.label!=null)this.label.$ur()}
,isc.A.setIcon=function isc_StatefulCanvas_setIcon(_1,_2){this.icon=_1;if(this.label)this.label.setIcon(_1);else if(_1&&this.shouldShowLabel())this.makeLabel();if(_2)this.markForRedraw()}
,isc.A.setIconStyle=function isc_StatefulCanvas_setIconStyle(_1){this.iconStyle=_1;if(this.label)this.label.setIconStyle(_1)}
,isc.A.handleMouseOver=function isc_StatefulCanvas_handleMouseOver(_1,_2){var _3;if(this.mouseOver!=null){_3=this.mouseOver(_1,_2);if(_3==false)return false}
this.$168c();return _3}
,isc.A.$168c=function isc_StatefulCanvas__doMouseOverStateChange(){if(this.ns.EH.mouseIsDown()&&this.autoApplyDownState){this.setState(isc.StatefulCanvas.STATE_DOWN)}else{if(this.autoApplyOverState)this.setState(isc.StatefulCanvas.STATE_OVER);if(this.showOverCanvas){if(this.overCanvas==null){this.addAutoChild("overCanvas",{autoDraw:false
})}
this.overCanvas.moveAbove(this);if(!this.overCanvas.isDrawn())this.overCanvas.draw()}
}}
,isc.A.handleMouseOut=function isc_StatefulCanvas_handleMouseOut(_1,_2){var _3;if(this.mouseOut!=null){_3=this.mouseOut(_1,_2);if(_3==false)return _3}
this.$168d();return _3}
,isc.A.$168d=function isc_StatefulCanvas__doMouseOutStateChange(_1){if(this.autoApplyOverState)this.setState(isc.StatefulCanvas.STATE_UP);if(this.showOverCanvas&&this.overCanvas!=null&&this.overCanvas.isVisible()&&(_1||!this.overCanvas.contains(this.ns.EH.getTarget(),true)))
{this.overCanvas.clear()}}
,isc.A.$lf=function isc_StatefulCanvas__focusChanged(_1,_2,_3,_4){var _5=this.invokeSuper(isc.StatefulCanvas,"$lf",_1,_2,_3,_4);this.updateStateForFocus(_1);return _5}
,isc.A.updateStateForFocus=function isc_StatefulCanvas_updateStateForFocus(_1){this.stateChanged();if(this.label)this.label.stateChanged()}
,isc.A.getFocusedAsOverState=function isc_StatefulCanvas_getFocusedAsOverState(){if(!this.showFocused||!this.showFocusedAsOver||this.isDisabled())return false;return this.hasFocus}
,isc.A.getFocusedState=function isc_StatefulCanvas_getFocusedState(){if(this.isDisabled())return false;return this.hasFocus}
,isc.A.handleMouseDown=function isc_StatefulCanvas_handleMouseDown(_1,_2){if(_1.target==this&&this.useEventParts){if(this.firePartEvent(_1,isc.EH.MOUSE_DOWN)==false)return false}
var _3;if(this.mouseDown){_3=this.mouseDown(_1,_2);if(_3==false)return false}
if(this.autoApplyDownState&&!this.isDisabled()){this.setState(isc.StatefulCanvas.STATE_DOWN)}
return _3}
,isc.A.handleMouseUp=function isc_StatefulCanvas_handleMouseUp(_1,_2){if(_1.target==this&&this.useEventParts){if(this.firePartEvent(_1,isc.EH.MOUSE_UP)==false)return false}
var _3;if(this.mouseUp){_3=this.mouseUp(_1,_2);if(_3==false)return false}
var _4=this.ns.EH;if(this.autoApplyDownState){this.setState(_4.$94y!=_4.$94w.TOUCH_ENDING
?isc.StatefulCanvas.STATE_OVER:isc.StatefulCanvas.STATE_UP)}
return _3}
,isc.A.handleActivate=function isc_StatefulCanvas_handleActivate(_1,_2){var _3=this.getActionType();if(_3==isc.StatefulCanvas.RADIO){this.select()}else if(_3==isc.StatefulCanvas.CHECKBOX){this.setSelected(!this.isSelected())}
if(this.showMenuOnClick&&this.showContextMenu){if(this.showContextMenu(_1)==false)return false}
if(this.activate)return this.activate(_1,_2);if(this.action)return this.action();if(this.click){if(this.convertToMethod("click"))return this.click(_1,_2)}}
,isc.A.handleClick=function isc_StatefulCanvas_handleClick(_1,_2){if(isc.$cv)arguments.$cw=this;if(_1.target==this&&this.useEventParts){if(this.firePartEvent(_1,isc.EH.CLICK)==false)return false}
return this.handleActivate(_1,_2)}
,isc.A.handleKeyPress=function isc_StatefulCanvas_handleKeyPress(_1,_2){if(isc.$cv)arguments.$cw=this;if(this.keyPress&&(this.keyPress(_1,_2)==false))return false;if(_1.keyName=="Space"||_1.keyName=="Enter"){if(this.handleActivate(_1,_2)==false)return false}
return true}
,isc.A.shouldPushTableBorderStyleToDiv=function isc_StatefulCanvas_shouldPushTableBorderStyleToDiv(){return isc.StatefulCanvas.shouldPushTableBorderStyleToDiv(this)}
,isc.A.shouldPushTableShadowStyleToDiv=function isc_StatefulCanvas_shouldPushTableShadowStyleToDiv(){return isc.StatefulCanvas.shouldPushTableShadowStyleToDiv(this)}
,isc.A.destroy=function isc_StatefulCanvas_destroy(){this.removeFromRadioGroup();return this.Super("destroy",arguments)}
);isc.B._maxIndex=isc.C+90;isc.StatefulCanvas.registerStringMethods({activate:isc.EH.$i3,action:""});isc.A=isc.StatefulCanvas;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$54k="SelectedFocused";isc.A.$1666="Selected";isc.A.$258q="Focused";isc.A.$152b=new RegExp("(?:\\([^)]*\\)|[^,])+","g");isc.B.push(isc.A.$61l=function isc_c_StatefulCanvas__getStateSuffix(_1,_2,_3,_4){var _5;if(_2||_3){_5=(_2&&_3)?this.$54k:_2?this.$1666:this.$258q}
if(!_4){if(_5)return _1?_5+_1:_5;else return _1}else if(_5){return _1?_5+_1+_4:_5+_4}else{return _1?_1+_4:_4}}
,isc.A.$95q=function isc_c_StatefulCanvas__buildBorderStyle(_1,_2){var _3=_1?"$"+_2:_2;if(this.$95r[_3]){return this.$95r[_3]}
var _4,_5={},_6=0;_4=_1?isc.StatefulCanvas.$95n:isc.StatefulCanvas.$95m.length;var _7=isc.Element.getStyleEdges(_2);if(_7){for(var j=0;j<_4;j++){var _9=isc.StatefulCanvas.$95m[j];if(_5[_9]==null&&_7[_9]!=isc.emptyString){_5[_9]=_7[_9]}
}
}
this.$95r[_3]=_5;return _5}
,isc.A.$95s=function isc_c_StatefulCanvas__getBorderCSSHTML(_1,_2){var _3=_1?"$"+_2:_2;if(this.$95t[_3]){return this.$95t[_3]}
var _4=this.$95q(_1,_2);var _5=isc.emptyString,_6=isc.StatefulCanvas.$95o;var _7=isc.SB.concat(_4.borderBottomWidth,_6,_4.borderBottomStyle,_6,_4.borderBottomColor).trim();var _8=isc.SB.concat(_4.borderLeftWidth,_6,_4.borderLeftStyle,_6,_4.borderLeftColor).trim();var _9=isc.SB.concat(_4.borderRightWidth,_6,_4.borderRightStyle,_6,_4.borderRightColor).trim();var _10=isc.SB.concat(_4.borderTopWidth,_6,_4.borderTopStyle,_6,_4.borderTopColor).trim();if(_7!=_8||_7!=_9||_7!=_10){if(_7!=isc.emptyString)_5+=isc.semi+"BORDER-BOTTOM:"+_7;if(_8!=isc.emptyString)_5+=isc.semi+"BORDER-LEFT:"+_8;if(_9!=isc.emptyString)_5+=isc.semi+"BORDER-RIGHT:"+_9;if(_10!=isc.emptyString)_5+=isc.semi+"BORDER-TOP:"+_10}else{if(_7!=isc.emptyString)_5+=isc.semi+"BORDER:"+_7}
var _11=_4.borderBottomLeftRadius,_12=_4.borderBottomRightRadius,_13=_4.borderTopRightRadius,_14=_4.borderTopLeftRadius;if(_11!=_12||_11!=_13||_11!=_14){if(_11!=null)_5+=isc.semi+"BORDER-BOTTOM-LEFT-RADIUS:"+_11;if(_12!=null)_5+=isc.semi+"BORDER-BOTTOM-RIGHT-RADIUS:"+_12;if(_13!=null)_5+=isc.semi+"BORDER-TOP-RIGHT-RADIUS:"+_13;if(_14!=null)_5+=isc.semi+"BORDER-TOP-LEFT-RADIUS:"+_14}else{if(_11!=null)_5+=isc.semi+"BORDER-RADIUS:"+_11}
this.$95t[_3]=_5;return _5}
,isc.A.clearBorderCSSCache=function isc_c_StatefulCanvas_clearBorderCSSCache(){this.$95r={};this.$95t={}}
,isc.A.$132y=function isc_c_StatefulCanvas__buildShadowStyle(_1,_2,_3){var _4=_1;if(_3)_4+="$191u";if(this.$132w[_4]){return this.$132w[_4]}
var _5={},_6="boxShadow";var _7=isc.Element.getStyleEdges(_1);if(!_7)return"";_5.boxShadow=_7.boxShadow;if(_5.boxShadow!=null&&_5.boxShadow.indexOf("inset")>=0){var _8=_5.boxShadow.match(this.$152b).callMethod("trim"),_9=_8.length,_10=[],_11=[],k=0
;for(var i=0;i<_9;++i){var _14=_8[i];if(_14.startsWith("inset")||_14.endsWith("inset")){_10.add(_14)}else{_11.add(_14)}
}
_8=_3?_10:_11;_5.boxShadow=_8.join(", ")}
this.$132w[_4]=_5;return _5}
,isc.A.$132z=function isc_c_StatefulCanvas__getShadowCSSHTML(_1){var _2=_1;var _3;if(this.$132x[_2]!==_3){return this.$132x[_2]}
var _4=this.$132y(_1);var _5;if(_4.boxShadow==null)_5=isc.emptyString;else _5="box-shadow:"+_4.boxShadow+";";this.$132x[_2]=_5;return _5}
,isc.A.clearShadowCSSCache=function isc_c_StatefulCanvas_clearShadowCSSCache(){this.$132w={};this.$132x={}}
,isc.A.shouldPushTableShadowStyleToDiv=function isc_c_StatefulCanvas_shouldPushTableShadowStyleToDiv(_1){if(isc.StatefulCanvas.pushTableShadowStyleToDiv!=null){return isc.StatefulCanvas.pushTableShadowStyleToDiv}
if(_1&&_1.$rw()!=isc.Canvas.VISIBLE){return true}
if(this.$1904==null){var _2=isc.Canvas.create({_generated:true,autoDraw:false,$1909:true,left:-500,top:-500,contents:'<table style="width:100px;height:100px;"><tr><td style="box-shadow:0 0 0 5px red;">x</td></tr></table>'
});_2.draw();var _3=_2.getScrollHeight(),_4=_2.getScrollHeight();if(_3>100||_4>100){this.$1904=true}else{this.$1904=false}
_2.markForDestroy()}
return this.$1904}
,isc.A.shouldPushTableBorderStyleToDiv=function isc_c_StatefulCanvas_shouldPushTableBorderStyleToDiv(_1){return isc.StatefulCanvas.pushTableBorderStyleToDiv
||isc.StatefulCanvas.shouldPushTableShadowStyleToDiv(_1)}
);isc.B._maxIndex=isc.C+9;isc.ClassFactory.defineClass("Layout","Canvas");isc.A=isc.Layout;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.FILL="fill";isc.A.$204n={effect:"slide",startFrom:"L",endAt:"L"
};isc.B.push(isc.A.reflowOnTEA=function isc_c_Layout_reflowOnTEA(_1,_2){var _3={theLayout:_1,reflowCount:_1.$3i,reason:_2
};if(this.reflowQueue==null)this.reflowQueue=[];var _4=this.reflowQueue;for(var i=0;i<_4.length;i++){if(_4[i]!=null&&_4[i].theLayout==_1){_4[i]=null}
}
this.reflowQueue.add(_3);if(!this.reflowTEASet){isc.EH.$ms(function(){isc.Layout.clearReflowQueue()});this.reflowTEASet=true}
}
,isc.A.clearReflowQueue=function isc_c_Layout_clearReflowQueue(){this.reflowTEASet=false;var _1=this.reflowQueue;this.reflowQueue=null;if(_1==null)return;for(var i=0;i<_1.length;i++){if(_1[i]==null)continue;var _3=_1[i].theLayout,_4=_1[i].reflowCount,_5=_1[i].reason;if(!_3.destroyed){if(_4!=null&&_4<_3.$3i)continue;_3.reflowNow(_5,_4)}
}
}
);isc.B._maxIndex=isc.C+2;isc.A=isc.Layout.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.orientation="horizontal";isc.A.vPolicy=isc.Layout.FILL;isc.A.hPolicy=isc.Layout.FILL;isc.A.minMemberSize=1;isc.A.minMemberLength=1;isc.A.minMemberBreadth=null;isc.A.enforcePolicy=true;isc.A.paddingAsLayoutMargin=true;isc.A.membersMargin=0;isc.A.defaultResizeBars="marked";isc.A.resizeBarDefaults={dragScrollType:"parentsOnly"
};isc.A.resizeBarClass="Splitbar";isc.A.resizeBarSize=7;isc.A.animateMemberEffect="slide";isc.A.canDropComponents=true;isc.A.dropLineThickness=2;isc.A.membersAreChildren=true;isc.B.push(isc.A.setDefaultResizeBars=function isc_Layout_setDefaultResizeBars(_1){if(this.defaultResizeBars==_1)return;this.defaultResizeBars=_1;this.$86g()}
,isc.A.setAnimateMemberEffect=function isc_Layout_setAnimateMemberEffect(_1){this.animateMemberEffect=!this.vertical&&_1=="slide"?isc.Layout.$204n:_1}
);isc.B._maxIndex=isc.C+2;isc.A=isc.Canvas.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.setLayoutAlign=function isc_Canvas_setLayoutAlign(_1){this.layoutAlign=_1;if(this.parentElement&&isc.isA.Layout(this.parentElement)&&this.parentElement.isDrawn())
{this.parentElement.reflow()}
}
,isc.A.setShowResizeBar=function isc_Canvas_setShowResizeBar(_1){if(this.showResizeBar==_1)return;this.showResizeBar=_1;var _2=this.parentElement;if(_2==null||!isc.isA.Layout(_2))return;_2.$86g()}
);isc.B._maxIndex=isc.C+2;isc.A=isc.Layout.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.managePercentBreadth=true;isc.A.$2g="layout";isc.A.$2h=["show","hide","rect"];isc.A.$2i=["rect","move"];isc.A.resizeMembersLimit=3;isc.A.fixLayoutOnMemberResize=true;isc.A.$254k=isc.Layout.$254j(["canDropComponents"]);isc.A.printFillWidth=true;isc.A.$2j=[];isc.A.$2k="membersAdded";isc.A.$2l="membersRemoved";isc.A.placeHolderDefaults={styleName:"layoutPlaceHolder",overflow:isc.Canvas.HIDDEN};isc.A.dropLineDefaults={styleName:"layoutDropLine",overflow:"hidden",isMouseTransparent:true};isc.A.$127h={align:true,defaultLayoutAlign:true,reverseOrder:true,vertical:true,orientation:true,vPolicy:true,minMemberSize:true,minMemberLength:true,minMemberBreadth:true,hPolicy:true,membersMargin:true};isc.B.push(isc.A.getMemberLength=function isc_Layout_getMemberLength(_1){return this.vertical?_1.getVisibleHeight():_1.getVisibleWidth()}
,isc.A.getMemberBreadth=function isc_Layout_getMemberBreadth(_1){return this.vertical?_1.getVisibleWidth():_1.getVisibleHeight()}
,isc.A.setMemberBreadth=function isc_Layout_setMemberBreadth(_1,_2){if(this.logIsDebugEnabled(this.$2g))this.$42g(_1,_2);this.vertical?_1.setWidth(_2):_1.setHeight(_2)}
,isc.A.getMemberMaxBreadth=function isc_Layout_getMemberMaxBreadth(_1){return this.vertical?_1.maxWidth:_1.maxHeight}
,isc.A.getMemberMinBreadth=function isc_Layout_getMemberMinBreadth(_1){return Math.max(this.vertical?_1.minWidth:_1.minHeight,this.minMemberBreadth)}
,isc.A.getMemberMaxLength=function isc_Layout_getMemberMaxLength(_1){return this.vertical?_1.maxHeight:_1.maxWidth}
,isc.A.getMemberMinLength=function isc_Layout_getMemberMinLength(_1){return Math.max(this.vertical?_1.minHeight:_1.minWidth,this.minMemberSize,this.minMemberLength)}
,isc.A.getLength=function isc_Layout_getLength(){if(this.vertical)return this.getInnerHeight();var _1=this.getInnerWidth();if(this.leaveScrollbarGap&&!this.vscrollOn)_1-=this.getRequiredScrollbarSpace();return _1}
,isc.A.getBreadth=function isc_Layout_getBreadth(){if(!this.vertical)return this.getInnerHeight();var _1=this.getInnerWidth();if(this.leaveScrollbarGap&&!this.vscrollOn)_1-=this.getRequiredScrollbarSpace();return _1}
,isc.A.getLengthPolicy=function isc_Layout_getLengthPolicy(){return this.vertical?this.vPolicy:this.hPolicy}
,isc.A.getBreadthPolicy=function isc_Layout_getBreadthPolicy(){return this.vertical?this.hPolicy:this.vPolicy}
,isc.A.memberHasInherentLength=function isc_Layout_memberHasInherentLength(_1){if(!(this.vertical?_1.hasInherentHeight():_1.hasInherentWidth())){return false}
if(this.vertical?_1.canAdaptHeight:_1.canAdaptWidth){return false}
var _2=this.$2m(_1);if(isc.isA.String(_2)&&(_2.endsWith(this.$o9)||_2==this.$pa))
{return false}
return true}
,isc.A.memberHasInherentBreadth=function isc_Layout_memberHasInherentBreadth(_1){return(this.vertical?_1.hasInherentWidth():_1.hasInherentHeight())}
,isc.A.$2n=function isc_Layout__overflowsLength(_1){return((this.vertical&&_1.canOverflowHeight())||(!this.vertical&&_1.canOverflowWidth()))}
,isc.A.$188d=function isc_Layout__canAdaptLength(_1){return this.vertical?_1.canAdaptHeight:_1.canAdaptWidth}
,isc.A.$2m=function isc_Layout__explicitLength(_1){return this.vertical?_1.$po:_1.$pn}
,isc.A.$2o=function isc_Layout__explicitBreadth(_1){return this.vertical?_1.$pn:_1.$po}
,isc.A.$2p=function isc_Layout__memberPercentLength(_1){return this.vertical?_1._percent_height:_1._percent_width}
,isc.A.scrollingOnLength=function isc_Layout_scrollingOnLength(){return this.vertical?this.vscrollOn:this.hscrollOn}
,isc.A.getMemberGap=function isc_Layout_getMemberGap(_1){return(_1.extraSpace||0)-(this.memberOverlap||0)
+(_1.$22||0)}
,isc.A.initWidget=function isc_Layout_initWidget(){if(isc.$cv)arguments.$cw=this;var _1=isc.Layout;if(this.vertical==null){this.vertical=(this.orientation==_1.VERTICAL)}else{this.orientation=(this.vertical?_1.VERTICAL:_1.HORIZONTAL)}
if(!this.vertical&&this.animateMemberEffect=="slide"){this.animateMemberEffect=isc.Layout.$204n}
if(this.isRTL()&&!this.vertical)this.reverseOrder=!this.reverseOrder;if(this.members==null)this.members=[];else if(!isc.isA.Array(this.members))this.members=[this.members];if(this.membersAreChildren){if(!this.$155w&&this.members.length==0&&this.children!=null&&!this.$2q())
{this.members=this.children=this.createMemberCanvii(this.children)}else{this.members=this.createMemberCanvii(this.members);if(this.children==null)this.children=[];for(var i=0;i<this.members.length;i++){if(!this.children.contains(this.members[i])){this.children.add(this.members[i])}
}
}
}else{this.logInfo("members are peers","layout");this.addMethods({draw:this.$2r});this.members=this.createMemberCanvii(this.members);if(this.peers==null)this.peers=[];this.peers.addList(this.members)}
for(var i=0;i<this.members.length;i++){this.$42h(this.members[i])}
this.setLayoutMargin();if(this.members&&this.members.length>0){this.$62s()}
this.checkAlign(this.align)}
,isc.A.setAlign=function isc_Layout_setAlign(_1){this.checkAlign(_1);this.align=_1}
,isc.A.checkAlign=function isc_Layout_checkAlign(_1){if(this.vertical){if(_1==isc.Canvas.LEFT||_1==isc.Canvas.RIGHT){this.logWarn("Layout.align set to "+_1+", which is invalid for vertical layouts")}
}else{if(_1==isc.Canvas.TOP||_1==isc.Canvas.BOTTOM){this.logWarn("Layout.align set to "+_1+", which is invalid for horizontal layouts")}
}}
,isc.A.createMemberCanvii=function isc_Layout_createMemberCanvii(_1){for(var i=_1.length-1;i>=0;i--){if(isc.isA.LayoutResizeBar(_1[i])){this.initResizeBarMember(_1[i])}
}
_1=this.createCanvii(_1);for(var i=_1.length-1;i>=0;i--){if(_1[i]==null)continue;if(!isc.isA.Canvas(_1[i])){this.logWarn("Layout unable to resolve member:"+this.echo(_1[i])+" to a Canvas - ignoring this member");_1.removeAt(i)}
}
var _3=this.$239i(_1);if(_3.length!=0){this.logWarn("Specified members array contains the following component(s) multiple times:"+_3+". This is unsupported. Duplicate Canvas entries will be removed. Duplicate LayoutSpacer entries will be replaced with new LayoutSpacers with the same dimensions.")}
return _1}
,isc.A.$239i=function isc_Layout__checkMembersForDuplicates(_1){var _2=[];for(var i=0;i<_1.length;i++){var _4=_1[i],_5=_1.indexOf(_4,i+1);if(_5!=-1)_2.add(_4);while(_5!=-1){if(isc.isA.LayoutSpacer(_4)){_1[_5]=isc.LayoutSpacer.create({height:_4.height,width:_4.width,minHeight:_4.minHeight,minWidth:_4.minWidth
});_5=_1.indexOf(_4,_5+1)}else{_1.removeAt(_5);_5=_1.indexOf(_4,_5)}
}
}
return _2}
,isc.A.$2q=function isc_Layout__allGeneratedChildren(){for(var i=0;i<this.children.length;i++){var _2=this.children[i];if(_2!=null&&!_2._generated)return false}
return true}
,isc.A.setPadding=function isc_Layout_setPadding(){this.Super("setPadding",arguments);if(this.paddingAsLayoutMargin){this.setLayoutMargin()}}
,isc.A.setLayoutMargin=function isc_Layout_setLayoutMargin(_1){if(_1!=null)this.layoutMargin=_1;var _2=this.layoutHMargin,_3=this.layoutVMargin,_4=this.layoutMargin,_5=this.reverseOrder?this.layoutEndMargin:this.layoutStartMargin,_6=this.reverseOrder?this.layoutStartMargin:this.layoutEndMargin;var _7,_8,_9,_10;if(this.paddingAsLayoutMargin){var _11=this.$tq();_7=_11.left;_8=_11.right;_9=_11.top;_10=_11.bottom}
this.$tb=this.$du(this.layoutLeftMargin,(!this.vertical?_5:null),_2,_4,_7,0);this.$tc=this.$du(this.layoutRightMargin,(!this.vertical?_6:null),_2,_4,_8,0);this.$td=this.$du(this.layoutTopMargin,(this.vertical?_5:null),_3,_4,_9,0);this.$te=this.$du(this.layoutBottomMargin,(this.vertical?_6:null),_3,_4,_10,0);this.$2s=true;this.reflow()}
,isc.A.$2t=function isc_Layout__getSideMargin(_1){if(this.$tb==null)this.setLayoutMargin();if(_1)return this.$tb+this.$tc;else return this.$td+this.$te}
,isc.A.$2u=function isc_Layout__getBreadthMargin(){return this.$2t(this.vertical)}
,isc.A.$2v=function isc_Layout__getLengthMargin(){return this.$2t(!this.vertical)}
,isc.A.$312u=function isc_Layout__centerResizeBarOffset(_1,_2,_3){if(this.defaultLayoutAlign===isc.Canvas.CENTER&&_2>_3){return _1+Math.floor((_2-_3)/2)}
return _1}
,isc.A.$2r=function isc_Layout__drawOverride(){if(isc.$cv)arguments.$cw=this;if(!this.membersAreChildren){this.$2w();this.layoutChildren(this.$od);this.drawPeers();this.$if=true;return}
isc.Canvas.$b4.draw.apply(this,arguments)}
,isc.A.setStyleName=function isc_Layout_setStyleName(_1){if(this.styleName!=_1){this.Super("setStyleName",arguments);this.setLayoutMargin(this.layoutMargin)}}
,isc.A.resizePeersBy=function isc_Layout_resizePeersBy(_1,_2,_3){if(!this.membersAreChildren)return;isc.Canvas.$b4.resizePeersBy.call(this,_1,_2,_3)}
,isc.A.markForRedraw=function isc_Layout_markForRedraw(){if(this.membersAreChildren)return this.Super("markForRedraw",arguments);this.reflow("markedForRedraw")}
,isc.A.drawChildren=function isc_Layout_drawChildren(){if(this.membersAreChildren){this.$2w();this.$240n();this.updateChildTabPositions();this.layoutChildren(this.$od);this.$2x();if(this.componentMaskShowing){this.$168q()}
}
return}
,isc.A.$2w=function isc_Layout__setupMembers(){if(!this.members)return;for(var i=0;i<this.members.length;i++){var _2=this.members[i];if(_2==null){this.logWarn("members array: "+this.members+" includes null entry at position "
+i+". Removing");this.members.removeAt(i);i-=1;continue}
this.autoSetBreadth(_2)}}
,isc.A.$240n=function isc_Layout__setupMembersRuleScope(){if(this.members){for(var i=0;i<this.members.length;i++){var _2=this.members[i];if(_2.$239j){_2.$1632();_2.$1912();_2.$1633();delete _2.$239j}
_2.computeRuleScope();_2.$1630(true,true)}
}}
,isc.A.$2x=function isc_Layout__drawNonMemberChildren(){if(!this.membersAreChildren||!this.children)return;for(var i=0;i<this.children.length;i++){var _2=this.children[i];if(this.members.contains(_2))continue;if(!isc.isA.Canvas(_2)){_2.autoDraw=false;_2=isc.Canvas.create(_2)}
if(!this.drawChildWithParent(_2))continue;if(!_2.isDrawn())_2.draw()}}
,isc.A.revealChild=function isc_Layout_revealChild(_1){if(isc.isA.String(_1))_1=window[_1];if(_1){if(this.children&&this.children.contains(_1)&&!_1.isVisible()){_1.show()}else{if(this.members&&this.members.contains(_1)&&!_1.isVisible()){_1.show()}
}
}}
,isc.A.getMemberDefaultBreadth=function isc_Layout_getMemberDefaultBreadth(_1,_2){return _2}
,isc.A.$54l=function isc_Layout__getMemberDefaultBreadth(_1){var _2=this.$2o(_1),_3=isc.isA.String(_2)&&isc.endsWith(_2,this.$o9)
?_2:null,_4=Math.max(this.getBreadth()-this.$2u(),1);var _5=this.$170t;if(_5&&_5!=_1){var _6=this.getMemberBreadth(_5);if(_6>_4)_4=_6}
if(!this.leaveScrollbarGap){if(this.$3a!=null){_4+=((this.$3a?-1:1)*this.getRequiredScrollbarSpace())}
}
var _7=(_3==null?_4:Math.floor(_4*(parseInt(_3)/100)));if(this.getMemberDefaultBreadth!=null){_7=this.getMemberDefaultBreadth(_1,_7)}
var _8=this.getMemberMinBreadth(_1),_9=this.getMemberMaxBreadth(_1);if(_7<_8)_7=_8;else if(_7>_9)_7=_9;return _7}
,isc.A.autoSetBreadth=function isc_Layout_autoSetBreadth(_1){if(!this.shouldAlterBreadth(_1))return false;var _2=this.$2z;this.$2z=true;this.setMemberBreadth(_1,this.$54l(_1));this.$2z=_2;return true}
,isc.A.shouldAlterBreadth=function isc_Layout_shouldAlterBreadth(_1){var _2=this.$2o(_1);if(_2!=null){return(this.managePercentBreadth&&this.getBreadthPolicy()==isc.Layout.FILL&&isc.isA.String(_2)&&isc.endsWith(_2,this.$o9))}
if((this.vertical&&_1.neverExpandWidth)||(!this.vertical&&_1.neverExpandHeight))return false;if(this.getBreadthPolicy()==isc.Layout.FILL)return true;return false}
,isc.A.$20=function isc_Layout__moveOffscreen(_1){return isc.Canvas.moveOffscreen(_1)}
,isc.A.getMarginSpace=function isc_Layout_getMarginSpace(){var _1,_2,_3,_4,_5=this.$2v()
;for(var i=0;i<this.members.length;i++){var _7=this.members[i],_8=isc.isA.LayoutResizeBar(_7),_9=_7.$86h,_10=this.$21(_7)
;if(_9){_5+=this.resizeBarSize}
if(i>0&&!_3){if(!_1&&!_2&&!_8){if(_10)_4=true;else _5+=this.membersMargin}else if(_1&&!_8&&_4){_5+=this.membersMargin;_4=false}
}
_2=_8;_3=_9;_1=_10;if(_10){if(_9)_4=false}else{_5+=this.getMemberGap(_7)}
}
if(this.memberOverlap!=null)_5+=this.memberOverlap;return _5}
,isc.A.getTotalMemberSpace=function isc_Layout_getTotalMemberSpace(){return this.getLength()-this.getMarginSpace()}
,isc.A.$23=function isc_Layout__getTotalMemberLength(){var _1=0;for(var i=0;i<this.members.length;i++){var _3=this.members[i];if(this.$21(_3))continue;_1+=this.getMemberLength(_3)}
return _1+this.getMarginSpace()}
,isc.A.ignoreMember=function isc_Layout_ignoreMember(_1){_1.$52f=true}
,isc.A.stopIgnoringMember=function isc_Layout_stopIgnoringMember(_1){if(!this.hasMember(_1))return;var _2=this.$21(_1);_1.$52f=false;if(_2&&!this.$21(_1))this.reflow()}
,isc.A.isIgnoringMember=function isc_Layout_isIgnoringMember(_1){return!!_1.$52f}
,isc.A.$21=function isc_Layout__shouldIgnoreMember(_1){if(_1.visibility==isc.Canvas.HIDDEN
&&!(_1.$l0&&_1.$l0.isVisible()))return true;if(this.isIgnoringMember(_1))return true;return false}
,isc.A.ignoreMemberZIndex=function isc_Layout_ignoreMemberZIndex(_1){if(!_1||!this.members||this.members.indexOf(_1)==-1)return;_1.$52g=true;this.reflow()}
,isc.A.stopIgnoringMemberZIndex=function isc_Layout_stopIgnoringMemberZIndex(_1){_1.$52g=false;this.reflow()}
,isc.A.$52h=function isc_Layout__isIgnoringMemberZIndex(_1){if(this.isIgnoringMember(_1))
return true;else if(_1.$52g)
return _1.$52g;return false}
,isc.A.gatherSizes=function isc_Layout_gatherSizes(_1,_2,_3){if(!_2){_2=this.$25;if(_2==null){_2=this.$25=[]}else{_2.length=0}
}
var _4=this.getLengthPolicy();var _5=this.logIsInfoEnabled(this.$2g);for(var i=0;i<this.members.length;i++){var _7=this.members[i];var _8=_2[i];if(_8==null){_8=_2[i]={}}
if(this.$21(_7)
&&!_7.$26
){_8.$27=0;if(_5)_8.$28="hidden";continue}
if(this.memberHasInherentLength(_7)||_4==isc.Layout.NONE){_8.$27=this.getMemberLength(_7);if(_5){_8.$28=(_4==isc.Layout.NONE?"no length policy":"inherent size")}
continue}
if(this.resizeMembersLimit!=null&&this.resizeMembersLimit!=0&&_8.$2695!=null&&_8.$2695==this.resizeMembersLimit)
{_8.$27=this.getMemberLength(_7);if(_5){_8.$28="Hit maximum resize attempts ("+_8.$2695+")"}
continue}
var _9=this.$2n(_7),_10=this.vertical?_7.getHeight():_7.getWidth(),_11=_9?this.getMemberLength(_7):_10
;if(this.$188d(_7)){_8.$27=_1&&!_9?_3[i]:_11;_8.$29=_11>_10;if(_5){_8.$28="adaptive length"}
continue}
if(_9){if(_10<_11){_8.$2696=_11}
if(_1){var _12=_11;if(_12!=_3[i]&&this.$1656(_3,i)){if(_5){this.logInfo("member: "+_7+" overflowed.  set length: "+_3[i]+" got length: "+_12,"layout");_8.$28="length overflowed"}
var _13=_8.$27;_8.$29=isc.Canvas.isStretchResizePolicy(_13)?_13:true;_8.$27=_12}
continue}
}
if(this.$2m(_7)!=null){_8.$27=this.vertical?_7.$po:_7.$pn;if(_5)_8.$28="explicit size";continue}
if(_8.$27==null){_8.$27=this.$pa;if(_5)_8.$28="no length specified"}
}
return _2}
,isc.A.$114s=function isc_Layout__hasCosmeticOverflowOnly(){var _1=this.members,_2,_3;for(var i=0;i<_1.length;++i){var _5=_1[i];if(!_5)continue;var _6=_5.peers;if(_6){for(var j=0;j<_6.length;++j){var _8=_6[j];if(_8.$114r){if(_2==null){var _9=this.getClipHandle();_2=this.getPageRight()-isc.Element.getRightBorderSize(_9);_3=this.getPageBottom()-isc.Element.getBottomBorderSize(_9)}
var _10=_8.getPeerRect();if((_10[0]+_10[2])>=_2||(_10[1]+_10[3])>=_3)
{for(var k=0;k<_1.length;++k){_5=_1[k];if(_5.getPageRight()>=_2||_5.getPageBottom()>=_3)
{return false}
}
return true}
}
}
}
}
return false}
,isc.A.resizeMember=function isc_Layout_resizeMember(_1,_2,_3,_4){var _5=this.logIsInfoEnabled(this.$2g);if(this.$21(_1))return;var _6=_1==this.$170t;if(_4!=null&&_4!=this.$2n(_1)
&&!(_6&&this.shouldAlterBreadth(_1))
)
{return}
var _7=null;if(this.shouldAlterBreadth(_1)){if(_5)_3.$3b="breadth policy: "+this.getBreadthPolicy();_7=_3.$3c=this.$54l(_1)}else{_3.$3c=this.getMemberBreadth(_1);if(_5){_3.$3b=this.getBreadthPolicy()==isc.Layout.NONE?"no breadth policy":"explicit size"}
}
var _8=this.$188d(_1);var _9=null;if(this.getLengthPolicy()!=isc.Layout.NONE&&!this.memberHasInherentLength(_1)){if(_8&&this.$2n(_1)){var _10=this.vertical?_1.getHeight():_1.getWidth();if(_2<_10){_9=_3.$3d=_2;if(_5){this.logInfo("size-adaptive member: "+_1+" had to be resized narrower to ensure that adaptWidthBy()/adaptHeightBy() can assume its size is overflow-driven",this.$1655)}
}
}else if(!_3.$29){_9=_3.$3d=_2}
}
if(_9!=null&&!_8&&this.$2n(_1)&&!_1.isDirty()&&(!_1.$114s||!_1.$114s()))
{var _10=(this.vertical?_1.getHeight():_1.getWidth()),_11=this.getMemberLength(_1);if(_11>_10&&this.getMemberMinLength(_1)<=_10&&_9<=_11&&(_7==null||_7<=this.getMemberBreadth(_1)))
{if(_5)this.logInfo("not applying "+this.getLengthAxis()+": "+_9+" to overflowed member: "+_1+" w/"+this.getLengthAxis()+": "+_11,"layout");_9=null}
}
if(!_1.isAnimating(this.$2h)){var _12=this.vertical?_7:_9,_13=this.vertical?_9:_7;if(((_12!=null)||(_13!=null))&&!_1.$1652(_12,_13)){if(!(_4&&(_1.getVisibleHeight()==_13)&&(_1.getVisibleWidth()==_12)))
{if(_3.$2695==null)_3.$2695=0;_3.$2695++;if(this.logIsDebugEnabled(this.$2g))this.$42g(_1,_7,_9,_3);_1.resizeTo(_12,_13)}
}
}
if(_1.isDrawn()){if(_1.isDirty())_1.redrawForNewSize("Layout getting new size")}else{_1.$3e=true}
if(this.$2n(_1)&&!_8){var _14=this.getMemberLength(_1);if(_14>_2){if(_5){this.logInfo("resizeMembers(): member: "+_1+" overflowed.  Set length: "+_2+", got length: "+_14+"; skipping resize of remaining members","layout")}
return true}
}}
,isc.A.resizeMembers=function isc_Layout_resizeMembers(_1,_2,_3){if(this.overflow==isc.Canvas.AUTO){var _4=_1.sum()>this.getTotalMemberSpace(),_5=this.scrollingOnLength();this.$3a=null;if(_4){if(!_5){this.logInfo("scrolling will be required on length axis, after overflow",this.$2g);this.$3a=true}
}else{if(_5){this.logInfo("scrolling will no longer be required on length axis, after overflow",this.$2g);this.$3a=false}
}
}
var _6,_7=this.$170u,_8=this.$170t;if(_8){if(this.resizeMember(_8,_1[_7],_2[_7],_3))
{_6=_7}
}
if(_6==null){var _9=this.members;for(var i=0;i<_9.length;i++){if(i==_7)continue;if(this.resizeMember(_9[i],_1[i],_2[i],_3))
{_6=i;break}
}
}
return(_1.maxResizedIndex=_6)==null}
,isc.A.$52i=function isc_Layout__enforceStackZIndex(){if(!this.stackZIndex||this.members.length<2)return;for(var _1=0;_1<this.members.length;_1++)
if(!this.$52h(this.members[_1]))break;var _2=this.members[_1],_3=_2.getZIndex();var _4,_5;for(var i=_1+1;i<this.members.length;i++){if(this.$52h(this.members[i]))continue;_4=_2;_5=_4.getZIndex();_2=this.members[i];_3=_2.getZIndex();if((_3<=_5)&&this.stackZIndex=="lastOnTop")
_2.moveAbove(_4);else if((_3>=_5)&&this.stackZIndex=="firstOnTop")
_2.moveBelow(_4)}}
,isc.A.stackMembers=function isc_Layout_stackMembers(_1,_2,_3){if(_3==null)_3=true;var _4=(this.membersAreChildren?0:this.getOffsetLeft()),_5=(this.membersAreChildren?0:this.getOffsetTop()),_6=this.reverseOrder,_7=(_6?-1:1);var _8=this.vertical,_9=(_8?this.getInnerWidth():this.getInnerHeight())-this.$2u()
;var _10=isc.Canvas,_11=_9,_12=this.$171m||this.overflow;if(_12!=_10.HIDDEN&&(_8?(_12!=_10.CLIP_H):(_12!=_10.CLIP_V)))
{for(var i=0;i<this.members.length;i++){var _14=this.members[i];if(this.$21(_14))continue;var _15=this.getMemberBreadth(_14);if(_15>_11)_11=_15}
}
if(this.logIsDebugEnabled(this.$2g)){this.logDebug("centering wrt visible breadth: "+_11,this.$2g)}
var _16;if(_6){var _17=this.isRTL()&&this.overflow!=isc.Canvas.VISIBLE;if(_17){_16=this.getLength()}else{_16=Math.max(this.getLength(),this.$23())}
}
var _18=_8?(!_6?_5:_5+_16):(!_6?_4:_4+_16)
;if(this.align!=null){var _19=this.$23(),_20=Math.max(this.getLength(),_19),_21=_20-_19;if(((!_6&&(this.align==_10.BOTTOM||this.align==_10.RIGHT))||(_6&&(this.align==_10.LEFT||this.align==_10.TOP))))
{_18+=(_7*_21)}else if(this.align==isc.Canvas.CENTER){_18+=(_7*Math.round(_21/2))}
}
var _22=_8?_4+this.$tb:_5+this.$td,_23=false,_24=false,_25=false,_26=false,_27=0;for(var i=0;i<_1.length;i++){var _14=_1[i],_28=isc.isA.LayoutResizeBar(_14),_29=this.$21(_14),_30=_2?_2[i]:null;if(i==0){var _31;if(_8)_31=(_6?this.$te:this.$td);else _31=(_6?this.$tc:this.$tb);_18+=(_7*_31)}else{if(_23){_18+=(_7*this.resizeBarSize)}else if(!_25&&!_24&&!_28){if(_29)_26=true;else _18+=(_7*this.membersMargin)}else if(_25&&!_28&&_26){_18+=(_7*this.membersMargin);_26=false}
}
var _32=_14.isAnimating(this.$2i);if(_29){if(!this.isIgnoringMember(_14)
&&!_32
){_14.moveTo(_4+this.$tb,_5+this.$td)}
if(_14.$86h){var _33=this.getBreadth()-this.$2u();this.makeResizeBar(_14,this.$312u(_22,_11,_33),_18,_33);_23=true;_26=false}else{if(_14.$3f!=null)_14.$3f.hide();_23=false}
_24=_28;_25=true;_27++;continue}else{_25=false}
var _34=_22,_35=this.getLayoutAlign(_14)
;if(this.isRTL()&&_8&&(_12==_10.AUTO||_12==_10.SCROLL))
{var _36=_11-_9;if(_36>0)_34-=_36}
if(_35==_10.RIGHT||_35==_10.BOTTOM){_34+=_11-this.getMemberBreadth(_14)}else if(_35==_10.CENTER){_34+=Math.floor((_11-this.getMemberBreadth(_14))/2)}
if(this.getMemberOffset!=null){_34=this.getMemberOffset(_14,_34,_35)}
var _37=this.getMemberLength(_14);if(!_32){if(_8){if(!_6)_14.moveTo(_34,_18);else _14.moveTo(_34,_18-_37)}else{if(!_6)_14.moveTo(_18,_34);else _14.moveTo(_18-_37,_34)}
}
_18+=(_7*_37);_18+=(_7*this.getMemberGap(_14));if(_14.$86h){var _33=this.getBreadth()-this.$2u();this.makeResizeBar(_14,this.$312u(_22,_11,_33),_18,_33)}else{if(_14.$3f!=null)_14.$3f.hide()}
_23=_14.$86h;_24=_28;if(_3)this.memberSizes[i-_27]=_37;if(_2)_30.$3g=_37}
if(_3)this.memberSizes.length=(i-_27);if(_12!=isc.Canvas.VISIBLE)this.$3h();this.$52i()}
,isc.A.getLayoutAlign=function isc_Layout_getLayoutAlign(_1){if(_1.layoutAlign!=null)return _1.layoutAlign;if(this.defaultLayoutAlign!=null)return this.defaultLayoutAlign;return this.vertical?(this.isRTL()?isc.Canvas.RIGHT:isc.Canvas.LEFT)
:isc.Canvas.TOP}
,isc.A.$3h=function isc_Layout__enforceScrollSize(){var _1,_2,_3=false,_4=false,_5,_6,_7,_8,_9=this.vertical;if(_9){_2=this.$te||0;_1=this.$tc||0}else{_2=this.$tc||0;_1=this.$te||0}
if(_2>0||_1>0)_3=true;var _10=this.getInnerWidth(),_11=this.getInnerHeight();if(_3){for(var i=this.members.length-1;i>=0;i--){_6=this.members[i];if(!_6.isVisible())continue;if(_9){if(_5==null){_5=_6;_7=_6.getTop()+_6.getVisibleHeight()}
var _13=_6.getLeft()+_6.getVisibleWidth();if(_8==null||_8<_13)_8=_13}else{if(_5==null){_5=_6;_8=_6.getLeft()+_6.getVisibleWidth()}
var _14=_6.getTop()+_6.getVisibleHeight();if(_7==null||_7<_14)_7=_14}
}
if(_7==null)_7=0;if(_8==null)_8=0}else{var _15=false;for(var i=this.members.length-1;i>=0;i--){var _6=this.members[i];if(isc.isA.LayoutSpacer(_6)&&_6.isVisible()){var _16=_6.getWidth(),_17=_6.getHeight();if(i==this.members.length-1){_4=true;if(_9)_7=_6.getTop()+_17;else _8=_6.getLeft()+_16}
if(_9){if(_16>_10&&(_8==null||_16>_8)){_15=true;_8=_16}
}else if(_17>_11&&(_7==null||_17>_7)){_15=true;_7=_17}
}
}
if(_15&&!_4){for(var i=this.members.length-1;i>=0;i--){var _6=this.members[i];if(isc.isA.LayoutSpacer(_6))continue;if(this.vertical){var _16=_6.getVisibleWidth();if(_16>=_8){_15=false;break}
}else{var _17=_6.getVisibleHeight();if(_17>=_7){_15=false;break}
}
}
if(_15)_4=true}
if(_4){if(_8==null)_8=1;if(_7==null)_7=1}
}
if(_4||_3){if(this.vertical){_8+=_1;_7+=_2}else{_8+=_2;_7+=_1}
this.enforceScrollSize(_8,_7)}
else this.stopEnforcingScrollSize()}
,isc.A.setOverflow=function isc_Layout_setOverflow(_1,_2,_3,_4,_5){var _6=this.overflow;if(_6==isc.Canvas.VISIBLE&&_1!=isc.Canvas.VISIBLE){this.$3h()}else if(_6!=isc.Canvas.VISIBLE&&_1==isc.Canvas.VISIBLE){this.stopEnforcingScrollSize()}
return this.invokeSuper(isc.Layout,"setOverflow",_1,_2,_3,_4,_5)}
,isc.A.layoutChildren=function isc_Layout_layoutChildren(_1,_2,_3){if(isc.$cv)arguments.$cw=this;if(this.destroying)return;if(this.$3i==null)this.$3i=1;else this.$3i++;if(!this.members)this.members=[];if(this.children&&this.children.length){for(var i=0;i<this.children.length;i++){this.$60y(this.children[i])}
}
if(!this.isDrawn()&&_1!=this.$od)return;var _5=this.$2z;this.$2z=true;if(_2!=null||_3!=null){if((this.vertical&&isc.isA.Number(_2))||(!this.vertical&&isc.isA.Number(_3)))
{this.$2s=true}
}
if(this.isDrawn()&&this.getLengthPolicy()==isc.Layout.NONE&&!this.$2s){if(this.logIsInfoEnabled(this.$2g)){this.logInfo("Restacking, reason: "+_1,this.$2g)}
this.stackMembers(this.members);this.$2s=false;this.$3j(_1,_5);return}
this.$2s=false;var _6=this.getTotalMemberSpace()
if(this.manageChildOverflow)this.$qv=true;var _7=[];var _8=this.getMember(this.minBreadthMember);if(_8){if(!_8.isDrawn()){this.$20(_8);_8.draw();_7[0]=_8}
this.$170u=this.members.indexOf(_8);this.$170t=_8}else{delete this.$170u;delete this.$170t}
for(var i=0;i<this.members.length;i++){var _9=this.members[i];if(this.$188d(_9)&&!_9.allowAdaptSizeBeforeDraw&&!_9.isDrawn())
{this.$20(_9);_9.draw();_7[_7.length]=_9}
if(_9.minHeight==null&&_9.$188x){_9.minHeight=_9.$188x()}
}
if(this.manageChildOverflow&&_7.length>0){this.$qx(_7)}
_7=[];var _10=this.$3k(_6),_11=this.$25;var _12=0;var _13=[];do{var _14=!this.resizeMembers(_10,_11,true);if(this.manageChildOverflow)this.$qv=true;for(var i=0;i<this.members.length;i++){var _9=this.members[i];if(_9.$3e){_9.$3e=null;this.$20(_9);_9.draw();_7[_7.length]=_9}
}
if(this.manageChildOverflow&&_7.length>0){this.$qx(_7)}
if(!_14){for(var i=0;i<_7.length;i++){if(_7[i]==null)continue;var _9=_7[i];if(this.$2n(_9)&&this.getMemberLength(_9)>_10[i]){if(_10.maxResizedIndex==null)_10.maxResizedIndex=i;_14=true;break}
}
}
_7=[];_12++;this.$3k(_6,true,_10,_11);var _15=_10.join(",");if(_14&&_13.contains(_15)){break}else{_13.push(_15)}
}while(_14);this.resizeMembers(this.memberSizes=_10,_11,false);if(this.manageChildOverflow)this.$qv=true;for(var i=0;i<this.members.length;i++){var _9=this.members[i];if(_9.$3e){_9.$3e=null;this.$20(_9);_9.draw();_7[_7.length]=_9}
}
if(this.manageChildOverflow&&_7.length>0){this.$qx(this.members)}
this.stackMembers(this.members,_11);this.reportSizes(_11,_1);this.$3j(_1,_5)}
);isc.evalBoundary;isc.B.push(isc.A.$182b=function isc_Layout__completeChildrenOverflowOnHTMLInit(){if(this.manageChildOverflow&&this.children!=null&&(this.parentElement==null||!this.parentElement.$qv))
{var _1=[];if(this.members&&(this.members.length<this.children.length)){for(var i=0;i<this.children.length;i++){if(this.members.indexOf(this.children[i])==-1){_1.add(this.children[i])}
}
}
this.$qx(_1)}}
,isc.A.$60y=function isc_Layout__resolvePercentageSizeForChild(_1){var _2=this.members.contains(_1)&&!this.$21(_1);if(_2&&this.snapTo==null){var _3,_4,_5=this.getLengthPolicy()==isc.Layout.FILL,_6=this.getBreadthPolicy()==isc.Layout.FILL
;if(this.vertical){_3=_6?null:_1._percent_width;_4=_5?null:_1._percent_height}else{_3=_5?null:_1._percent_width;_4=_6?null:_1._percent_height}
if(_1._percent_left||_1._percent_top||_4||_3){_1.setRect(_1._percent_left,_1._percent_top,_3,_4)}
}
if(isc.isA.Canvas(_1))_1.parentResized(_2)}
,isc.A.$188e=function isc_Layout__getCanAdaptLengthMembers(_1){var _2=[];for(var i=0;i<this.members.length;i++){var _4=this.members[i];if(this.$188d(_4)){_2.add(_4);_4.$1658=i}
}
_2.sortByProperty(this.vertical?"adaptiveHeightPriority":"adaptiveWidthPriority",!_1);if(this.logIsInfoEnabled(this.$1655)){var _5=_1?"descending":"ascending";this.logInfo("found "+_2.length+" size-adaptable members ("+_5+"): "+_2.map(function(_4){return _4.getID()}),this.$1655)}
return _2}
,isc.A.$1659=function isc_Layout__getRemainingSpace(_1,_2,_3,_4){var _5=this.getClass().$166a(_1,_1,_2,this),_6=this.vertical,_7=_5.staticSize,_8=_5.starCount+_5.percentCount;if(this.useOriginalStretchResizePolicy||this.ignoreStretchResizeMemberSizeLimits){_7+=_8*_3}else{for(var i=0;i<_1.length;i++){if(isc.Canvas.isStretchResizePolicy(_1[i])){var _10=this.members[i],_11=_6?_10.minHeight:_10.minWidth;if(_4&&_4[i].$2696){_11=Math.max(_11,_4[i].$2696)}
_7+=Math.max(_11,_3)}
}
}
var _12=_2-_7;if(this.logIsInfoEnabled(this.$1655)){this.logInfo("Layout.$1659(): remaining space is "+_12+" after reserving minimums for "+_8+" stretch members",this.$1655)}
return _12}
,isc.A.$166b=function isc_Layout__revertOverflowedStretchSizedPolicyLengths(_1,_2){for(var i=0;i<this.members.length;i++){var _4=_1[i];if(isc.isA.String(_4.$29)){_2[i]=_4.$27=_4.$29;delete _4.$29}
}
delete _2.maxResizedIndex;if(this.logIsInfoEnabled(this.$1655)){this.logInfo("Layout.$166b(): overflowAsFixed processing has been reset for all affected members",this.$1655)}}
,isc.A.adaptMembersToSpace=function isc_Layout_adaptMembersToSpace(_1,_2,_3,_4){var _5=false,_6=this.vertical,_7=Math.max(this.minMemberSize,this.minMemberLength),_8=this.$1659(_1,_2,_7,_4)
;var _9=this.$188e(_8>0);for(var i=0;i<_9.length;i++){if(_8==0)break;var _11=_9[i],_12=_6?_11.adaptHeightBy:_11.adaptWidthBy
;if(!isc.isA.Function(_12)){this.logWarn("adaptMembersToSpace(): member "+_11.getID()+" specified as canAdaptWidth/canAdaptHeight: true, but no corresponding adaptWidthBy/adaptHeightBy() function is present",this.$1655);continue}
delete _11.$1653;var _13=_11.$1658,_14,_15=_1[_13],_16=this.$2n(_11),_17=_11.$188f,_18=!_16&&isc.Canvas.$186q(this.$2m(_11))
;if(_18&&_17){_14=_12.call(_11,_8+_15-_17,_17,!_3)}else{_14=_12.call(_11,_8,_15,!_3,_4[_13].$29)}
if(!isc.isA.Number(_14)){this.logWarn("adaptMembersToSpace(): ignoring nonsense value "+_14+" returned from adaptWidthBy/adaptHeightBy() by member "+_11.getID(),this.$1655);continue}
if(_18&&_17)_14+=_17-_15;if(_14==0){if(_18)_11.$188f=_15;if(this.logIsInfoEnabled(this.$1655)){this.logInfo("adaptMembersToSpace(): member "+_11.getID()+" has rejected offer of "+_8,this.$1655)}
continue}
if(_8<0&&_14>0){this.logWarn("adaptMembersToSpace(): ignoring request for "+_14+" px returned from adaptWidthBy/adaptHeightBy() by member "+_11.getID()+" since no remaining space is available; no length increase is allowed",this.$1655);continue}
if(_8>0&&_14>_8){this.logWarn("adaptMembersToSpace(): ignoring request for "+_14+" px returned from adaptWidthBy/adaptHeightBy() by member "+_11.getID()+" since it exceeds offer of "+_8,this.$1655);continue}
var _19=Math.max(_7,_6?_11.minHeight:_11.minWidth);if(_15+_14<_19){this.logWarn("adaptMembersToSpace(): ignoring request for "+_14+" px returned from adaptWidthBy/adaptHeightBy() by member "+_11.getID()+" since it would reduce member length below minimum of "+_19,this.$1655);continue}
var _20=_6?_11.maxHeight:_11.maxWidth;if(_15+_14>_20){this.logWarn("adaptMembersToSpace(): ignoring request for "+_14+" px returned from adaptWidthBy/adaptHeightBy() by member "+_11.getID()+" since it would increase member length above maximum of "+_20,this.$1655);continue}
var _21=_8;if(this.logIsInfoEnabled(this.$1655)){this.logInfo("adaptMembersToSpace(): member "+_11.getID()+" has accepted offer of "+_14+"("+_8+" offered) pixels",this.$1655)}
_11.$1653=_14;_1[_13]+=_14;_8-=_14;_5=true;if(_18)_11.$188f=_1[_13];else if(_16)delete _11.$188f;if(_21<0&&_8>0)return _8}
return null}
,isc.A.$3k=function isc_Layout__getMemberSizes(_1,_2,_3,_4){if(!_3){_3=this.$3l;if(_3==null)_3=this.$3l=[];else _3.length=this.members.length}
_4=this.gatherSizes(_2,_4,_3);this.$3m(_3,_4);var _5=this.adaptMembersToSpace(_3,_1,_2,_4);if(_2&&_5){this.$166b(_4,_3)}
var _6=_4.getProperty("$2696");return this.applyStretchResizePolicy(_3,_1,Math.max(this.minMemberSize,this.minMemberLength),true,_6)}
,isc.A.$3j=function isc_Layout__layoutChildrenDone(_1,_2){this.$3a=null;this.$3n=false;this.$2z=_2;if(this.$rm&&!this.$417&&this.isDrawn()&&!this.$uw&&(_1!="resized"||this.shouldRedrawOnResize()))
{if(this.notifyAncestorsOnReflow&&this.parentElement!=null){this.notifyAncestorsAboutToReflow()}
this.adjustOverflow();if(this.notifyAncestorsOnReflow&&this.parentElement!=null){this.notifyAncestorsReflowComplete()}
}
if(!this.enforcePolicy){this.vertical?this.vPolicy=isc.Layout.NONE:this.hPolicy=isc.Layout.NONE}}
,isc.A.$3m=function isc_Layout__getPolicyLengths(_1,_2){for(var i=0;i<_2.length;i++){_1[i]=_2[i].$27}}
,isc.A.$1656=function isc_Layout__isSizesValidForMember(_1,_2){var _3=_1.maxResizedIndex;if(_3==null)return true;var _4=this.$170u;return _2==_4?true:_2<=_3}
,isc.A.getMemberSizes=function isc_Layout_getMemberSizes(){if(this.memberSizes)return this.memberSizes.duplicate();return this.memberSizes}
,isc.A.getScrollWidth=function isc_Layout_getScrollWidth(_1){if(isc.$cv)arguments.$cw=this;if(this.$qz){this.$qz=null;this.adjustOverflow("widthCheckWhileDeferred")}
if(!_1&&this.$su!=null)return this.$su;var _2=this.children?this.$sy(this.children,true):0,_3=this.members?this.$sy(this.members,true):0,_4=isc.isA.Number(this.$tc)?this.$tc:0,_5=this.isRTL()&&this.overflow!=isc.Canvas.VISIBLE
?Math.max(_2,_3)
:Math.max(_2,_3+_4);if(this.overflow==isc.Canvas.VISIBLE&&this.useClipDiv&&!this.$1000(false,true))
{_5+=isc.Element.$sw(this.styleName)}
return(this.$su=_5)}
,isc.A.getScrollHeight=function isc_Layout_getScrollHeight(_1){if(isc.$cv)arguments.$cw=this;if(this.$qz){this.$qz=null;this.adjustOverflow("heightCheckWhileDeferred")}
if(!_1&&this.$sz!=null)return this.$sz;var _2=this.children?this.$s3(this.children,true):0,_3=this.children?this.$s3(this.members,true):0,_4=isc.isA.Number(this.$te)?this.$te:0,_5=Math.max(_2,_3+_4);return(this.$sz=_5)}
,isc.A.layoutIsDirty=function isc_Layout_layoutIsDirty(){return this.$3n==true}
,isc.A.reflow=function isc_Layout_reflow(_1){if(this.$3n)return;if(this.isDrawn()){this.$3n=true;if(this.instantRelayout){this.layoutChildren(_1)}else{isc.Layout.reflowOnTEA(this,_1)}
}}
,isc.A.reflowNow=function isc_Layout_reflowNow(_1,_2){if(!this.isDrawn())return;if(_2!=null&&_2<this.$3i)return;this.layoutChildren(_1)}
,isc.A.$217q=function isc_Layout__childResizingOnDragStart(_1,_2){if(!this.fixLayoutOnMemberResize)return this.Super("$217q",arguments);if(this.members.contains(_1)){var _3=this.vertical?_2.contains("B"):_2.contains("R");if(_3){for(var i=0;i<this.members.indexOf(_1);i++){var _5=this.members[i];if(this.$217s(_5)){_5.updateUserSize(this.vertical?_5.getHeight():_5.getWidth(),this.vertical?"height":"width","Fixing other member sizes for drag resize"
)}
}
}
}}
,isc.A.$217s=function isc_Layout__memberWillResizeOnReflow(_1){if(this.$2p(_1)!=null)return true;var _2=this.$2m(_1);if(_2!=null){return _2=="*"}else{var _3=this.getLengthPolicy();return(_3=="fill"?!this.memberHasInherentLength(_1):false)}}
,isc.A.childResized=function isc_Layout_childResized(_1,_2,_3,_4){if(isc.$cv)arguments.$cw=this;if(this.componentMask==_1)return;var _5=_1.isAnimating(this.$do),_6=_1.isAnimating(this.$zb),_7=_1.isAnimating(this.$0n),_8=_1.isAnimating(this.$nx),_9=(_5||_6||_7||_8);if(this.suppressMemberAnimations&&_9){_1.finishAnimation(_5?this.$do:(_6?this.$zb:(_7?this.$0n:this.$nx)));return}
this.$t6("child resize");if(this.$2z){return}
if(_1.$pp)return;if(!this.members.contains(_1))return;var _10=_1;if(_4!="overflow"&&_4!="overflow changed"&&_4!="Overflow on initial draw"){if(_2!=null&&_2!=0){_10.updateUserSize(_10._percent_width||_10.getWidth(),this.$o6,_4)}
if(_3!=null&&_3!=0){_10.updateUserSize(_10._percent_height||_10.getHeight(),this.$o5,_4)}
}
if(this.getDrawnState()==isc.Canvas.UNDRAWN){return}
var _11=isc.SB.concat("memberResized: (",_2,",",_3,"): ",_10.getID());if(_9)this.reflowNow(_11);else
this.reflow(_11)}
,isc.A.$3p=function isc_Layout__reportNewSize(_1,_2,_3,_4){if(!this.logIsDebugEnabled(this.$2g))return;var _5=_4?_2.$pn:_2.$po;if(_5!=_1){this.logDebug("new user "+(_4?"width: ":"height: ")+_5+" for member "+_2+", oldSize: "+_1+" reason: "+_3+(this.logIsDebugEnabled("userSize")?this.getStackTrace():""),"layout")}}
,isc.A.childUserSizeChanged=function isc_Layout_childUserSizeChanged(_1,_2){if(!this.hasMember(_1))return false;var _3=_2==this.$o6;if(this.isDrawn()&&this.vertical!=_3){this.reflow(_1.getID()+" set "+_2+" to '*'")}
return true}
,isc.A.childVisibilityChanged=function isc_Layout_childVisibilityChanged(_1,_2,_3,_4,_5){if(!this.members.contains(_1))return;if(!_1.isDrawn())this.$2s=true;this.reflow("member changed visibility: "+_1);var _6=_1.$3f;if(_6==null||_6.target!=_1){_6=null;var _7=this.members[this.members.indexOf(_1)-1];if(_7&&_7.$3f!=null&&_7.$3f.target==_1){_6=_7.$3f}
}
if(_6!=null&&_6.showGrip&&_6.showClosedGrip&&_6.label){_6.label.stateChanged()}
this.invokeSuper(isc.Layout,"childVisibilityChanged",_1,_2,_3,_4,_5)}
,isc.A.pageResize=function isc_Layout_pageResize(){var _1=this.$3i;this.Super("pageResize",arguments);if(this.isDrawn()&&(this.$3i==null||_1==this.$3i))
{this.reflow("pageResize")}}
,isc.A.getUISummary=function isc_Layout_getUISummary(_1,_2){_2=_2||[];_2.add("children");var _3=this.Super("getUISummary",[_1,_2]);var _4=[];_4.addList(_1);_4.addList(_2);if(!_4.contains("members")){this.$254n(_3,"members",_4,_1)}
return _3}
,isc.A.sectionHeaderClick=function isc_Layout_sectionHeaderClick(_1){var _2=_1.section;if(_2==null)return;if(!isc.isAn.Array(_2))_2=[_2];var _3=false;for(var i=0;i<_2.length;i++){if(isc.isA.String(_2[i]))_2[i]=window[_2[i]];if(_2[i].visibility!="hidden")_3=true}
if(_3){_2.callMethod("hide");_1.setExpanded(false)}else{_2.callMethod("show");_1.setExpanded(true)}}
,isc.A.getMember=function isc_Layout_getMember(_1){var _2=this.getMemberNumber(_1);if(_2==-1)return null;return this.members[_2]}
,isc.A.getMemberNumber=function isc_Layout_getMemberNumber(_1){if(isc.isA.String(_1)){var _2=this.members.findIndex("name",_1);if(_2!=-1)return _2;_1=window[_1];return this.members.indexOf(_1)}else if(isc.isA.Canvas(_1)){return this.members.indexOf(_1)}
if(isc.isA.Number(_1))return _1;return-1}
,isc.A.hasMember=function isc_Layout_hasMember(_1){var _2=this.members.contains(_1);return _2}
,isc.A.getMembers=function isc_Layout_getMembers(_1){return this.members}
,isc.A.getMembersLength=function isc_Layout_getMembersLength(_1){if(!this.members)return 0;return this.members.length}
,isc.A.getPrintChildren=function isc_Layout_getPrintChildren(){var _1=this.members;if(!_1||_1.length==0)return;var _2=[];for(var i=0;i<_1.length;i++){if(this.shouldPrintChild(_1[i]))_2.add(_1[i])}
return(_2.length>0)?_2:null}
,isc.A.$134u=function isc_Layout__joinChildrenPrintHTML(_1){if(_1!=null&&!this.vertical){if(!isc.isAn.Array(_1))_1=[_1];return"<table><tr><td>"+_1.join("</td><td>")+"</td></tr></table>"}else{return this.Super("$134u",arguments)}}
,isc.A.getCompletePrintHTMLFunction=function isc_Layout_getCompletePrintHTMLFunction(_1,_2){var _3=this;return function(_5){_3.isPrinting=false;var _4=_3.vertical||_3.printVertical;if(isc.isAn.Array(_5)&&_5.length>0){if(_4)_5=_5.join(isc.emptyString);else{_5="<TABLE"+(_3.printFillWidth?" WIDTH=100%>":">")+"<TR><TD valign=top>"+_5.join("</TD><TD valign=top>")+"</TD></TR></TABLE>"}
}
if(_5)_1[2]=_5;_1=_1.join(isc.emptyString);delete _3.currentPrintProperties;if(_2){_3.fireCallback(_2,"html, callback",[_1,_2]);return null}else{return _1}
}}
,isc.A.addMember=function isc_Layout_addMember(_1,_2,_3,_4){this.addMembers(_1,_2,_3,_4);return this}
,isc.A.addMembers=function isc_Layout_addMembers(_1,_2,_3,_4){if(!_1)return;if(isc.$cv)arguments.$cw=this;this.$3q();if(this.logIsInfoEnabled(this.$2g)){this.logInfo("adding newMembers: "+_1+(_2!=null?" at position: "+_2:""),"layout")}
if(!isc.isAn.Array(_1)){this.$2j[0]=_1;_1=this.$2j}
if(this.members==null)this.members=[];if(_2>this.members.length)_2=this.members.length;var _5=this.isDrawn(),_6=0;var _7=this.$239i(_1);if(_7.length!=0){this.logWarn("addMembers(): new members array contained the following component(s) multiple times:"+_7+". This is unsupported. Duplicate Canvas entries will be removed. Duplicate LayoutSpacer entries will be replaced with new LayoutSpacers with the same dimensions.")}
for(var i=0;i<_1.length;i++){var _9=_1[i];if(!_9){++_6;continue}
if(isc.isA.LayoutResizeBar(_9))this.initResizeBarMember(_9);if(!isc.isAn.Instance(_9)){_9=this.createCanvas(_9)}
if(!isc.isA.Canvas(_9)){this.logWarn("addMembers() unable to resolve member:"+this.echo(_9)+" to a Canvas - ignoring");++_6;continue}
if(this.members.contains(_9)){if(_2!=null){var d=i-_6,_11=this.members.indexOf(_9),_12=_2+d;if(_11<_12){++_6;--_12}
this.members.slide(_11,_12);if(this.isDrawn())this.updateMemberTabPosition(_9)}
continue}
if(_9.addAsPeer||_9.snapEdge){this.addPeer(_9,null,false);++_6;continue}else if(_9.addAsChild||_9.snapTo){this.addChild(_9,null,false);++_6;continue}
if(_9.parentElement!==this){if(_9.parentElement)_9.deparent();if(_9.isDrawn())_9.clear()}
if(_2!=null){this.members.addAt(_9,_2+i-_6)}else{this.members.add(_9)}
this.$42h(_9);this.autoSetBreadth(_9);var _13=_5&&this.animateMembers&&!_3&&_1.length==1&&_9.visibility!=isc.Canvas.HIDDEN;if(_13)_9.hide();var _14=(_5&&this.getLengthPolicy()==isc.Layout.NONE);if(this.membersAreChildren){this.addChild(_9,null,_14)}else{this.addPeer(_9,null,_14)}
_9.moveTo(0,0);if(this.isDrawn()&&this.memberHasInherentLength(_9)){this.$20(_9);if(!_9.isDrawn())_9.draw()}
}
if(this.editingOn&&this.visibility==isc.Canvas.HIDDEN&&!this.isDrawn()){for(var i=0;i<_1.length;i++){var _9=_1[i];if(!_9)continue;_9.computeRuleScope();_9.$239j=true}
}
this.$2j[0]=null;if(_13){this.$3r(_9,_4)}else
this.reflow(this.$2k);this.$62s()}
,isc.A.$42h=function isc_Layout__getUserSizes(_1){if(_1==null)return;if(_1._percent_width){_1.updateUserSize(_1._percent_width,this.$o6)}
if(_1._percent_height){_1.updateUserSize(_1._percent_height,this.$o5)}
if(this.memberHasInherentLength(_1)){if(!_1.$po&&!_1.$t9){_1.restoreDefaultSize(true)}
if(!_1.$pn&&!_1.$t8){_1.restoreDefaultSize()}
}}
,isc.A.$3s=function isc_Layout__animateMargin(_1,_2){var _3=this;var _4=_1;var _5=this.getMemberNumber(_1);if(_5==this.members.length-1)_1=this.getMember(--_5);if(!_1)return;var _6=this.getMember(_5+1),_7=isc.isA.LayoutResizeBar(_1)||isc.isA.LayoutResizeBar(_6)?0:this.membersMargin
;var _8=_7+this.getMemberGap(_1);if(_2)_1.$22=-(_8+1);this.registerAnimation(function(_10){var _9=Math.floor(_10*_8);if(_2)_9=_8-_9;_1.$22=-_9;if(_10==1)_1.$22=null},this.animateMemberTime
)}
,isc.A.removeChild=function isc_Layout_removeChild(_1,_2){isc.Canvas.$b4.removeChild.call(this,_1,_2);if(this.membersAreChildren&&this.members.contains(_1)){this.removeMember(_1)}}
,isc.A.removeMember=function isc_Layout_removeMember(_1,_2,_3){this.removeMembers(_1,_2,_3)}
,isc.A.removeMembers=function isc_Layout_removeMembers(_1,_2,_3){if(_1==null||(isc.isAn.Array(_1)&&_1.length==0))return;this.$3q();if(!isc.isAn.Array(_1)){this.$2j[0]=_1;_1=this.$2j}
if(_1===this.members)_1=_1.duplicate();for(var i=0;i<_1.length;i++){var _5=_1[i];if(isc.isA.Canvas(_7))continue;_1[i]=this.getMember(_5);if(_1[i]==null){this.logWarn("couldn't find member to remove: "+this.echoLeaf(_5));_1.removeAt(i);i-=1}
}
var _6=(this.animateMembers&&_1.length==1&&!_2),_7=(_6?_1[0]:null);if(_6){if(_7.parentElement!=this||_7.destroying||!_7.isVisible())
{_6=false}
}
if(_6){var _8=this,_9=_1.duplicate();this.$3u(_7,function(){_8.$3t(_9);if(_3)_3.apply(_7,arguments)})}else{this.$3t(_1)}
this.$2j[0]=null;this.$62s()}
,isc.A.$3t=function isc_Layout__completeRemoveMembers(_1){if(!_1)return;for(var i=0;i<_1.length;i++){var _3=_1[i];this.members.remove(_3);if(this.membersAreChildren&&_3.parentElement==this)_3.deparent();_3.$t9=_3.$t8=null;if(_3.$3f){_3.$3f.destroy();_3.$3f=null}
if(_3.showTarget==this)delete _3.showTarget;if(isc.isA.LayoutResizeBar(_3)){delete _3.vertical;delete _3.layout}
if(_3.$3v)_3.destroy()}
this.reflow(this.$2l)}
,isc.A.setMembers=function isc_Layout_setMembers(_1){if(_1==this.members||!isc.isAn.Array(_1))return;var _2=[];if(this.members!=null){for(var i=0;i<this.members.length;i++){if(!_1.contains(this.members[i]))_2.add(this.members[i])}
}
var _4=this.instantRelayout;this.instantRelayout=false;this.removeMembers(_2,true);this.addMembers(_1,0,true);this.instantRelayout=_4;if(_4)this.reflow("set members")}
,isc.A.showMember=function isc_Layout_showMember(_1,_2){return this.showMembers([_1],_2)}
,isc.A.showMembers=function isc_Layout_showMembers(_1,_2){if(this.isDrawn()&&this.animateMembers&&_1.length==1){this.$3r(_1[0],_2)}else{for(var i=0;i<_1.length;i++){var _4=this.getMember(_1[i]);_4.show()}
this.fireCallback(_2)}}
,isc.A.$3r=function isc_Layout__animateMemberShow(_1,_2){_1=this.getMember(_1);this.setNewMemberLength(_1);_1.animateShow(this.animateMemberEffect,_2,this.animateMemberTime);if(_1.isAnimating())this.$3s(_1,true)}
,isc.A.setNewMemberLength=function isc_Layout_setNewMemberLength(_1){_1.$26=true;var _2=this.$3k(this.getTotalMemberSpace());delete _1.$26;var _3=_2[this.members.indexOf(_1)];var _4=this.$2z;this.$2z=true;this.vertical?_1.setHeight(_3):_1.setWidth(_3);this.$2z=_4}
,isc.A.hideMember=function isc_Layout_hideMember(_1,_2){return this.hideMembers([_1],_2)}
,isc.A.hideMembers=function isc_Layout_hideMembers(_1,_2){this.$3x=_2;if(this.animateMembers&&_1.length==1){this.$3u(_1[0],_2)}else{for(var i=0;i<_1.length;i++){var _4=this.getMember(_1[i]);_4.hide()}
this.fireCallback(_2)}}
,isc.A.$3u=function isc_Layout__animateMemberHide(_1,_2){_1=this.getMember(_1);_1.animateHide(this.animateMemberEffect,_2,this.animateMemberTime);if(_1.isAnimating())this.$3s(_1)}
,isc.A.setVisibleMember=function isc_Layout_setVisibleMember(_1){var _2=this.getMember(_1);if(_2==null)return;this.hideMembers(this.members);this.showMember(_2)}
,isc.A.reorderMember=function isc_Layout_reorderMember(_1,_2){this.reorderMembers(_1,_1+1,_2)}
,isc.A.reorderMembers=function isc_Layout_reorderMembers(_1,_2,_3){this.members.slideRange(_1,_2,_3);for(var i=_3;i<_3+(_2-_1);i++){this.updateMemberTabPosition(this.members[i])}
this.$87o("membersReordered")}
,isc.A.$87o=function isc_Layout__membersReordered(_1){this.layoutChildren(_1);this.$62s()}
,isc.A.$2097=function isc_Layout__replaceMember(_1,_2){var _3=this.instantRelayout;this.instantRelayout=false;var _4=this.getMemberNumber(_1);if(_4<0){this.logWarn("$2097(): "+_1.getID()+" is not a member");_4=0}else{this.removeMember(_1,true)}
this.addMember(_2,_4,true);this.instantRelayout=_3;if(_3)this.reflowNow()}
,isc.A.replaceMember=function isc_Layout_replaceMember(_1,_2){if(_1==_2)return;if(!this.hasMember(_1)){this.logWarn("replaceMember(): the first argument must already be a member widget");return}
var _3=this.hasMember(_2);var _4=this.layoutIsDirty();this.$3n=true;var _5=_1.$pn,_6=_1.$po,_7=_1.getVisibleWidth(),_8=_1.getVisibleHeight()
;var _9=_1.getLeft(),_10=_1.getTop()
;var _11;if(isc.isA.Canvas(_2)){_2.resizeTo(_1.width,_1.height)}else{_11=this.getMemberNumber(_1);_2.width=_1.width;_2.height=_1.height}
this.$2097(_1,_2);if(_11!=null)_2=this.getMember(_11);_2.updateUserSize(_5,this.$o6);_2.updateUserSize(_6,this.$o5);_2.moveTo(_9,_10);if(!_2.isDrawn())_2.draw();this.$3n=_4;if(!_4&&this.isDrawn()){if(_2.getVisibleHeight()!=_8||_3||_2.getVisibleWidth()!=_7)
{this.reflow()}
}}
,isc.A.$62s=function isc_Layout__membersChanged(){if(!this.destroying){this.$86g()}
if(this.membersChanged)this.membersChanged()}
,isc.A.$86g=function isc_Layout__computeShowResizeBarsForMembers(){var _1,_2,_3=this.defaultResizeBars;for(var i=this.members.length-1;i>=0;i--,_2=_1){_1=this.members[i];if(_1==null)continue;var _5=false;if(_3==isc.Canvas.MARKED){_5=_1.showResizeBar}else if(_3==isc.Canvas.MIDDLE){_5=(i<this.members.length-1)&&(_1.showResizeBar!=false)}else if(_3==isc.Canvas.ALL){_5=_1.showResizeBar!=false}
if(this.neverShowResizeBars){_5=false}
if(_5&&isc.isA.LayoutResizeBar(_2)){if(!_2.hasOwnProperty("resizeDirection")){this.$2051(_1,_2,i+1)}
_5=false}
var _6=_1.$86h;_1.$86h=_5;if(_6!=_5)this.reflow("$86h changed")}
for(var i=this.members.length-1;i>=0;i--){var _1=this.members[i];if(isc.isA.LayoutResizeBar(_1))_1.$2052(i)}}
,isc.A.$2051=function isc_Layout__applyAutoChildSettingsToResizeBar(_1,_2,_3){var _4,_5;if(_1.resizeBarTarget=="next"){_5=this.getMember(_3+1);if(_5)_4=true}
if(!_5)_5=_1;var _6=_5;if(_1.resizeBarHideTarget!=null){_6=_1.resizeBarHideTarget=="next"?this.getMember(_3+1):null;if(!_6)_6=_1}
_2.setResizeDirection(_4?isc.Splitbar.AFTER:isc.Splitbar.BEFORE);if(_5!=_6)_2.setProperty("hideTarget",_6)}
,isc.A.initResizeBarMember=function isc_Layout_initResizeBarMember(_1){if(_1.layout==this)return;else _1.layout=this;var _2=!this.vertical;if(_2!=_1.vertical){_1.setVertical(_2,true)}
if(_2){_1.setProperties({dragScrollDirection:isc.Canvas.HORIZONTAL,width:this.resizeBarSize,inherentWidth:true
})}else{_1.setProperties({dragScrollDirection:isc.Canvas.VERTICAL,height:this.resizeBarSize,inherentHeight:true
})}}
,isc.A.$237d=function isc_Layout__getChildrenInDefaultTabOrder(){var _1=[];if(!this.members||!this.children)return _1;for(var i=0;i<this.members.length;i++){if(!this.members[i].updateTabPositionOnReparent)continue;_1.add(this.members[i])}
if(this.members.length!=this.children.length){for(var i=0;i<this.children.length;i++){if(!this.children[i].updateTabPositionOnReparent||this.members.contains(this.children[i]))
{continue}
_1.add(this.children[i])}
}
return _1}
,isc.A.updateMemberTabPosition=function isc_Layout_updateMemberTabPosition(_1){this.logDebug("Update member tab position:"+_1+", index in this.members?:"+this.members.indexOf(_1),"TabIndexManager");return this.updateChildTabPosition(_1)}
,isc.A.dragRepositionStart=function isc_Layout_dragRepositionStart(){var _1=isc.EH.dragTarget;if(!this.hasMember(_1)||_1.getDragAppearance(isc.EH.DRAG_REPOSITION)!="target")return;var _2=_1.getPageLeft(),_3=_1.getPageTop();this.$3y(_1,_2,_3)}
,isc.A.$3y=function isc_Layout__popOutDraggingMember(_1,_2,_3){this.$3z=_1;var _4=this.$30(_1,"$31",this.showDragPlaceHolder)
_1.$32=_4;var _5=this.instantRelayout;this.instantRelayout=false;this.$95u(_4,_1);if(!_1.isDrawn()||_1.readyToRedraw()){_1.deparent();_1.eventParent=this;this.instantRelayout=_5;_1.moveTo(_2,_3);_1.draw()}else{var _6=_1.getClipHandle();_1.getDocumentBody(true).appendChild(_6);var _7=[];var _8=function(_10){if(_10.$if){_7.add(_10);if(_10.$145l()){var _9=_10.parentElement;while(_9!=null){_9.$1440();_9=_9.parentElement}
}
_10.$if=false}
};var _10=_1;var _11=[];var _3=_10;while(_3!=null){_8(_3);if(_3.children!=null)_11.push.apply(_11,_3.children);_3=_11.pop()}
_1.deparent();for(var _12=_7.length;_12>0;--_12){var _10=_7[_12-1];_10.$if=true;_10.$qa()}
_1.eventParent=this;this.instantRelayout=_5;_1.moveTo(_2,_3)}}
,isc.A.$95u=function isc_Layout__doPopOutDragMember(_1,_2){this.addMember(_1,this.getMemberNumber(_2),true)}
,isc.A.dragRepositionStop=function isc_Layout_dragRepositionStop(){var _1=isc.EH.dragTarget;if(!this.members.contains(_1)&&_1!=this.$3z)return;var _2=_1.getDragAppearance(isc.EH.DRAG_REPOSITION),_3=_2==isc.EH.TARGET;if(!_3&&(_2!=isc.EH.OUTLINE))return false;var _4=_3?isc.EH.STOP_BUBBLING:false;this.$3z=null;if(_1.eventParent==this)_1.eventParent=null;if(_1.dropSucceeded)return _4;var _5=_1.$32;if(_5!=null){if(_1.parentElement!=null||_1.destroyed){this.$33(_1)}else{_1.$32=null;var _6=this.getMemberNumber(_5),_7=_5.getPageRect(),_8=this,_9=function(){if(_1.$105q!=null){_1.canDrag=_1.$105q;delete _1.$105q}
if(_1.$105r!=null){_1.canDragReposition=_1.$105r;delete _1.$105r}
_8.$2097(_5,_1)}
;if(this.animateMembers){_1.$105q=_1.canDrag;_1.canDrag=false;_1.$105r=_1.canDragReposition;_1.canDragReposition=false;_1.animateRect(_7[0],_7[1],_7[2],_7[3],_9)}else
_9(true)}
}
return _4}
,isc.A.$30=function isc_Layout__createSpacer(_1,_2,_3){var _4,_5;if(_3){_4=this.createAutoChild("placeHolder",_5,isc.Canvas)}else{_4=isc.LayoutSpacer.create(_5)}
_4.setRect(_1.getRect());_4.updateUserSize(_4.getWidth(),this.$o6);_4.updateUserSize(_4.getHeight(),this.$o5);_4.layoutAlign=_1.layoutAlign;_4.extraSpace=(_1.extraSpace||0);_4.$3v=true;return _4}
,isc.A.removePlaceHolder=function isc_Layout_removePlaceHolder(_1){if(this.animateMembers&&!isc.isA.LayoutSpacer(_1)){var _2=this.$30(_1);this.$2097(_1,_2);_1.destroy();_1=_2}
this.removeMember(_1)}
,isc.A.willAcceptDrop=function isc_Layout_willAcceptDrop(){if(!this.canDropComponents){return this.canAcceptDrop?true:null}else if(!this.canAcceptDrop){return null}
return this.invokeSuper(isc.Layout,"willAcceptDrop")}
,isc.A.dropOver=function isc_Layout_dropOver(){if(this.editingOn&&this.editProxy&&!this.editProxy.willAcceptDrop())return;if(!this.willAcceptDrop())return;this.showDropLine();isc.EventHandler.dragTarget.bringToFront();return true}
,isc.A.dropMove=function isc_Layout_dropMove(){if(this.editingOn&&this.editProxy&&!this.editProxy.willAcceptDrop())return;if(!this.willAcceptDrop())return;this.showDropLine()}
,isc.A.dropOut=function isc_Layout_dropOut(){this.hideDropLine()}
,isc.A.dropStop=function isc_Layout_dropStop(){this.hideDropLine()}
,isc.A.getDropComponent=function isc_Layout_getDropComponent(_1,_2){if(!isc.isA.Palette(_1))return _1;var _3=_1.transferDragData(),_4=(isc.isAn.Array(_3)?_3[0]:_3);return _4.liveObject}
);isc.evalBoundary;isc.B.push(isc.A.drop=function isc_Layout_drop(){if(!this.willAcceptDrop()||this.$88z)return;var _1=this.getDropPosition();var _2=this.getDropComponent(isc.EventHandler.getDragTarget(),_1);if(!_2)return _2;var _3=this.members.indexOf(_2);if(_3==-1&&_2.$32)
_3=this.members.indexOf(_2.$32)
if(_3!=-1&&(_3==_1||_3+1==_1))
{return false}
_2.dropSucceeded=true;if(isc.Browser.isMoz){this.delayCall("$34",[_2,_1])}else{this.$34(_2,_1)}
return isc.EH.STOP_BUBBLING}
,isc.A.$34=function isc_Layout__completeDrop(_1,_2){this.hideDropLine();var _3=_1.parentElement;if(_3&&_1.getDragAppearance(isc.EH.dragOperation)==isc.EH.OUTLINE&&this.animateMembers&&isc.isA.Layout(_3)&&_3.hasMember(_1))
{_3.$3y(_1,isc.EH.dragOutline.getPageLeft(),isc.EH.dragOutline.getPageTop())}
var _4=false;if(this.members.contains(_1)){var _5=this.members.indexOf(_1);if(_5<_2)_4=true;this.removeMember(_1,true)}else{var _6=_1.$32;if(_6!=null){var _7=this.getMemberNumber(_6)
if((_7>=0)&&(_7<_2)){_4=true}
_6.parentElement.$33(_1)}
}
var _8=_2-(_4?1:0);if(!this.animateMembers||(_1.dragAppearance!="target"&&_1.dragAppearance!="outline")){this.addMember(_1,_8);delete _1.dropSucceeded;return}
var _9=this.$30(_1,"$35");this.addMember(_9,_2);this.reflowNow();this.$36=_1;var _10=this,_11=_9.getPageLeft(),_12=_9.getPageTop();if(_4){var _13=this.membersMargin+this.getMemberGap(_1);if(this.vertical)_12-=(_1.getVisibleHeight()+_13);else _11-=(_1.getVisibleWidth()+_13)}
if(_9==this.members.last()&&this.members.length>1){var _14=(this.members[this.members.length-2].$22||0);if(this.vertical)_12-=_14;else _11-=_14}
_1.animateMove(_11,_12,function(){_10.$36=null;var _15=_10.instantRelayout;_10.instantRelayout=false;_9.destroy();_1.dropSucceeded=null;_10.addMember(_1,_8,true);_10.instantRelayout=_15;if(_15)_10.reflowNow()},this.animateMemberTime
)}
,isc.A.$33=function isc_Layout__cleanUpPlaceHolder(_1){var _2=_1.$32;if(this.hasMember(_2)){_1.$32=null;this.removePlaceHolder(_2)
}}
,isc.A.$3q=function isc_Layout__finishDropAnimation(){if(this.$36!=null){this.$36.finishAnimation("move")}}
,isc.A.getDropPosition=function isc_Layout_getDropPosition(){var _1=this.vertical?this.getOffsetY():this.getOffsetX();if(_1<0)return 0;var _2=this.vertical?this.$td:this.$tb;for(var i=0;i<this.memberSizes.length;i++){var _4=this.memberSizes[i],_5=this.members[i];if(!_5)continue;if(_1<(_2+(_4/2))){if(_5.canDropBefore===false)return false;return i}
_2+=_4+this.membersMargin+this.getMemberGap(_5)}
return this.members.length}
,isc.A.$37=function isc_Layout__getChildInset(_1){return(_1?this.getTopMargin()+this.getTopBorderSize():this.getLeftMargin()+this.getLeftBorderSize())}
,isc.A.getPositionOffset=function isc_Layout_getPositionOffset(_1){if(this.members.length==0){return this.vertical?this.getPageTop()+this.$37(true)+this.$td:this.getPageLeft()+this.$37()+this.$tb}
if(_1<this.members.length){var _2=this.members[_1];return(this.vertical?_2.getPageTop():_2.getPageLeft())}else{var _2=this.members[_1-1];return(this.vertical?_2.getPageBottom():_2.getPageRight())}}
,isc.A.showDropLine=function isc_Layout_showDropLine(){if(this.$88z)return;if(this.showDropLines==false){return}
var _1=this.getDropPosition();if(!isc.isA.Number(_1)){this.hideDropLine();return}
if(_1<0)return;if(this.$3n)this.reflowNow();if(!this._dropLine)this._dropLine=this.makeDropLine();var _2=this.dropLineThickness,_3=this.getPositionOffset(_1);var _4;if(this.$tb==null)this.setLayoutMargin();if(_1==0){_4=this.vertical?this.$td:this.$tb}else if(_1==this.members.length){_4=-(this.vertical?this.$te:this.$tc)}else{_4=this.membersMargin}
_3=_3-Math.round((_4+_2)/2);var _5=this.vertical?this.$tb+this.$37():this.$td+this.$37(true);var _6=this.vertical?this.getVisibleWidth()-this.getVMarginBorder()-this.$2u():this.getVisibleHeight()-this.getHMarginBorder()-this.$2v();this._dropLine.setPageRect((this.vertical?this.getPageLeft()+_5:_3),(this.vertical?_3:this.getPageTop()+_5),(this.vertical?_6:_2),(this.vertical?_2:_6)
);var _7=this.topElement||this;if(this._dropLine.getZIndex()<_7.getZIndex())this._dropLine.moveAbove(_7);this._dropLine.show()}
,isc.A.hideDropLine=function isc_Layout_hideDropLine(){if(this._dropLine)this._dropLine.hide()}
,isc.A.makeDropLine=function isc_Layout_makeDropLine(){var _1=this.createAutoChild("dropLine",null,isc.Canvas);_1.dropTarget=this;return _1}
,isc.A.createResizeBar=function isc_Layout_createResizeBar(_1,_2,_3,_4){var _5=this.createAutoChild("resizeBar",{target:_1,targetAfter:_3,hideTarget:_4,layout:this,vertical:!this.vertical,dragScrollDirection:this.vertical?isc.Canvas.VERTICAL:isc.Canvas.HORIZONTAL
},this.resizeBarClass);return isc.SGWTFactory.extractFromConfigBlock(_5)}
,isc.A.makeResizeBar=function isc_Layout_makeResizeBar(_1,_2,_3,_4){var _5=_1.$3f;var _6=this.getMember(this.getMemberNumber(_1)+1)||_1;if(_5==null){var _7=_1,_8,_9;if(_1.resizeBarTarget=="next"){_7=_6;_8=true}
if(_1.resizeBarHideTarget!=null){if(_1.resizeBarHideTarget=="next")_9=_6;else _9=_1}else{_9=_7}
_5=this.createResizeBar(_7,_3,_8,_9);_1.$3f=_5}
if(this.vertical){_5.setRect(_2,_3,_4,this.resizeBarSize)}else{if(this.isRTL())_3-=this.resizeBarSize;_5.setRect(_3,_2,this.resizeBarSize,_4)}
if(this.membersAreChildren){this.addChild(_5)}else{this.addPeer(_5)}
if(!_5.isDrawn())_5.draw();if(!_5.isVisible())_5.show();if(_6!=_1&&_6.getZIndex()>_1.getZIndex()){_5.moveAbove(_6)}else{_5.moveAbove(_1)}
return _5}
,isc.A.propertyChanged=function isc_Layout_propertyChanged(_1,_2){this.invokeSuper(isc.Layout,"propertyChanged",_1,_2);if(this.$127h[_1]){if(_1=="minMemberSize"||_1=="minMemberLength"||_1=="minMemberBreadth"||_1=="hPolicy"||_1=="vPolicy")
{this.$2s=true}
this.reflow("Reflow for change to "+_1)}else if(isc.endsWith(_1,"Margin"))this.setLayoutMargin()}
,isc.A.getLengthAxis=function isc_Layout_getLengthAxis(){return this.vertical?"height":"width"}
,isc.A.$42g=function isc_Layout__reportResize(_1,_2,_3,_4){var _5=this.vertical?_2:_3,_6=this.vertical?_3:_2,_7=_1.getDelta("width",_5,_1.getWidth()),_8=_1.getDelta("height",_6,_1.getHeight());if((_7!=null&&_7!=0)||(_8!=null&&_8!=0)){var _9=_4?_4.$2695:1;if(_9==null){_9=1}
this.logDebug("resizing "+_1+(_1.isDrawn()?" (drawn): ":": ")+(_2!=null?_2+(this.vertical?"w ":"h "):"")+(_3!=null?_3+(this.vertical?"h":"w"):"")+(_9!=1?" ("+_9+" resizes due to sibling overflow)":""),"layout"
)}}
,isc.A.reportSizes=function isc_Layout_reportSizes(_1,_2){if(!this.logIsInfoEnabled(this.$2g))return;var _3="layoutChildren (reason: "+_2+"):\nlayout specified size: "+this.getWidth()+"w x "+this.getHeight()+"h\ndrawn size: "+this.getVisibleWidth(true)+"w x "+this.getVisibleHeight(true)+"h\navailable size: "+this.getInnerWidth()+(!this.vertical?"w (length) x ":"w x ")+this.getInnerHeight()+(this.vertical?"h (length)\n":"h\n");for(var i=0;i<_1.length;i++){var _5=_1[i];_3+="   "+this.members[i]+"\n";_3+="      "+_5.$3g+" drawn length"+(_5.$3d?" (resizeLength: "+_5.$3d+")":"")+" (policyLength: "+_5.$27+") ("+_5.$28+")\n";_3+="      "+_5.$3c+" drawn breadth ("+_5.$3b+")\n"}
if(_1.length==0)_3+="[No members]";this.logInfo(_3,"layout")}
);isc.B._maxIndex=isc.C+155;isc.defineClass("HLayout","Layout");isc.A=isc.HLayout.getPrototype();isc.A.orientation="horizontal";isc.defineClass("VLayout","Layout");isc.A=isc.VLayout.getPrototype();isc.A.orientation="vertical";isc.defineClass("HStack","Layout");isc.A=isc.HStack.getPrototype();isc.A.orientation="horizontal";isc.A.hPolicy=isc.Layout.NONE;isc.A.defaultWidth=20;isc.defineClass("VStack","Layout");isc.A=isc.VStack.getPrototype();isc.A.orientation="vertical";isc.A.vPolicy=isc.Layout.NONE;isc.A.defaultHeight=20;isc.defineClass("LayoutSpacer","Canvas");isc.A=isc.LayoutSpacer.getPrototype();isc.A.overflow="hidden";isc.A.draw=isc.Canvas.NO_OP;isc.A.redraw=isc.Canvas.NO_OP;isc.A.$59d=true;isc.defineClass("FixedSpacer","LayoutSpacer");isc.A=isc.FixedSpacer.getPrototype();isc.A.height=5;isc.defineClass("FlexSpacer","LayoutSpacer");isc.A=isc.FlexSpacer.getPrototype();isc.A.height=5;isc.Layout.registerDupProperties("members");isc.ClassFactory.defineClass("Button","StatefulCanvas");isc.defer("if (isc.Button.$b4.showFocused == null) isc.Button.addProperties({ showFocused: !isc.Browser.isTouch });");isc.A=isc.Button.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.title="Untitled Button";isc.A.clipTitle=true;isc.A.showClippedTitleOnHover=false;isc.A.$115g=true;isc.A.suppressClassName=true;isc.A.useEventParts=true;isc.A.autoFitDirection="horizontal";isc.A.baseStyle="button";isc.A.showDown=true;isc.A.showFocused=null;isc.A.showRollOver=true;isc.A.mozOutlineOffset="0px";isc.A.wrap=false;isc.A.height=20;isc.A.width=100;isc.A.overflow=isc.Canvas.HIDDEN;isc.A.redrawOnDisable=false;isc.A.redrawOnStateChange=false;isc.A.cursor=isc.Canvas.HAND;isc.A.className=null;isc.A.canFocus=true;isc.B.push(isc.A.setAutoFit=function isc_Button_setAutoFit(){var _1=this.isDrawn(),_2=this.shouldPushTableBorderStyleToDiv();this.Super("setAutoFit",arguments);this.$238i=!!this.autoFit;if(_1){var _3=this.shouldPushTableBorderStyleToDiv();if(_2!=_3){this.$220j(_3)}
}
}
,isc.A.$220j=function isc_Button__pushTableBorderToDivChanged(_1){if(!this.isDrawn())return;var _2=_1?this.$4v:this.border;if(_2!=null)this.setBorder(_2);var _3=_1?this.$4x:this.backgroundColor;this.setBackgroundColor(_3)}
);isc.B._maxIndex=isc.C+2;isc.A=isc.Button.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.shouldRedrawOnResize=(isc.Browser.isIPhone?function(_1,_2){return(this!==this.ns.EH.dragTarget)}:isc.Button.getSuperClass().$b4.shouldRedrawOnResize);isc.A.$114x="titleClipper";isc.A.$2728="<table role='presentation' cellspacing='0' cellpadding='0'";isc.A.$160f=['<table cellspacing="0" cellpadding="0"><tbody><tr><td ',null,'class="',null,'" style="',null,'">',null,"</td></tr></tbody></table>"];isc.A.$38="px;";isc.A.$39=";";isc.A.$4a="border:";isc.A.$4b="padding-top:0px;padding-bottom:0px;";isc.A.$4c="padding:";isc.A.$115k="padding-right:";isc.A.$115l="padding-left:";isc.A.$4d="background-color:";isc.A.$4e="margin:0px;";isc.A.$987="filter:none;";isc.A.$115f=isc.Browser.$114w+":ellipsis;overflow:hidden;";isc.A.$4f=["' style='",,,,,,,,,,,,,,,,null];isc.A.$4g="</td></tr></tbody></table>";isc.A.$4h="<table role='presentation' cellspacing='0' cellpadding='0'><tbody><tr><td ";isc.A.$4i="<table role='presentation' width='100%' cellspacing='0' cellpadding='0'><tbody><tr><td ";isc.A.$1153="<table role='presentation' width='100%' cellspacing='0' cellpadding='0' style='table-layout:fixed'><tbody><tr><td ";isc.A.$4j="font-size:"+(isc.Browser.isFirefox&&isc.Browser.isStrict?0:1)+"px;padding-right:";isc.A.$4k="font-size:"+(isc.Browser.isFirefox&&isc.Browser.isStrict?0:1)+"px;padding-left:";isc.A.$4l="px'>";isc.A.$4m="</td><td ";isc.A.$4n="class='";isc.A.$4p="'>";isc.A.$4q="' nowrap='true'>";isc.A.$4r="</td></tr></tbody></table>";isc.A.$o1="right";isc.A.$4s={align:"absmiddle"};isc.A.$116h="icon";isc.A.$141s="vertical-align:middle";isc.A.$209z=" eventpart='icon'";isc.A.$132u="RTL";isc.A.adaptWidthShowIconOnly=true;isc.A.$34w="TABLE";isc.B.push(isc.A.$217e=function isc_Button__aboutToDraw(){this.Super("$217e",arguments);var _1=this.shouldPushTableBorderStyleToDiv();if(this.border!=null&&!_1){this.$4v=this.border;this.$240l()}
if(this.padding!=null){this.$4w=this.padding;this.padding=null}
if(_1){this.$4x=null}else{if(this.backgroundColor!=null){this.$4x=this.backgroundColor;this.backgroundColor=null}
}
this.forceHandleOverflowHidden=_1}
,isc.A.$118i=function isc_Button__assignRectToHandle(_1,_2,_3,_4,_5){this.invokeSuper(isc.Button,"$118i",_1,_2,_3,_4,_5);if(this.redrawOnResize&&!this.isPrinting&&this.$118j())return;var _6=this.$11o();if(_6!=null){if(_3!=null&&isc.isA.Number(_3)&&(this.overflow!==isc.Canvas.VISIBLE||(!this.$118j()&&this.redrawOnResize!=false)))
{var _7=_3;if(this.isBorderBox)_7-=this.getHBorderPad();this.$u9(_6,this.$o6,_7)}
if(_4!=null&&isc.isA.Number(_4)){var _8=_4;if(this.isBorderBox)_8-=this.getVBorderPad();this.$u9(_6,this.$o5,_8)}
}}
,isc.A.getCanHover=function isc_Button_getCanHover(_1,_2,_3){return this.$115g||this.invokeSuper(isc.Button,"getCanHover",_1,_2,_3)}
,isc.A.shouldClipTitle=function isc_Button_shouldClipTitle(){return this.getOverflow()==isc.Canvas.HIDDEN&&!!this.clipTitle}
,isc.A.$1140=function isc_Button__getTitleClipperID(){return this.$qs(this.$114x)}
,isc.A.titleClipped=function isc_Button_titleClipped(_1){var _2=this.getDocument().getElementById(this.$1140());if(_2==null)return false;if(this.getScrollHeight()>this.getViewportHeight()){return true}
if(isc.Browser.isChrome||(isc.Browser.isMoz&&isc.Browser.version>=7))
{var _3=this.getDocument().createRange();_3.selectNodeContents(_2);if(_1&&_2.contains(_1)){_3.setStartAfter(_1)}
var _4=_3.getBoundingClientRect();var _5=_2.getBoundingClientRect();return _5.width<_4.width&&(_4.width-_5.width>1)}else{return(isc.Element.getClientWidth(_2)<_2.scrollWidth)}}
,isc.A.defaultTitleHoverHTML=function isc_Button_defaultTitleHoverHTML(){return this.getTitleHTML()}
,isc.A.hiddenTitleHoverHTML=function isc_Button_hiddenTitleHoverHTML(){var _1=this.getTitle(true);return this.formatTitle(this,_1)}
,isc.A.titleHoverHTML=function isc_Button_titleHoverHTML(_1){return _1}
,isc.A.handleHover=function isc_Button_handleHover(_1,_2,_3){if(this.canHover==false)return;if(this.canHover==null&&this.prompt)return this.invokeSuper(isc.Button,"handleHover",_1,_2,_3);if(!this.$238j&&(!this.showClippedTitleOnHover||!this.titleClipped())){if(this.canHover)return this.invokeSuper(isc.Button,"handleHover",_1,_2,_3);else return}
if(this.titleHover&&this.titleHover()==false)return;var _4=this.$169z?this.hiddenTitleHoverHTML():this.defaultTitleHoverHTML();var _5=this.titleHoverHTML(_4);if(_5!=null&&!isc.isAn.emptyString(_5)){var _6=this.$wc();isc.Hover.show(_5,_6,null,this)}}
,isc.A.$158o=function isc_Button__getLogicalIconOrientation(){var _1=this.isRTL(),_2=((!_1&&this.iconOrientation==isc.Canvas.RIGHT)||(_1&&((this.ignoreRTL&&this.iconOrientation==isc.Canvas.LEFT)||(!this.ignoreRTL&&this.iconOrientation==isc.Canvas.RIGHT))));return(_1||_2)&&!(_1&&_2)?isc.Canvas.RIGHT:isc.Canvas.LEFT}
,isc.A.$118j=function isc_Button__explicitlySizeTable(_1,_2){if(_1==null)_1=this.$5b();if(_2==null)_2=this.shouldClipTitle();return!(_1||!_2||(isc.Browser.isIE&&((!isc.Browser.isStrict&&isc.Browser.version<10)||isc.Browser.version<=7))
)}
,isc.A.$168e=function isc_Button__usesSubtable(_1){var _2=this.$5b(),_3=this.shouldClipTitle(),_4=!_2&&_3;return(((!_1&&this.isPrinting)||!this.$118j(_2,_3))&&this.icon&&!_4&&!this.noIconSubtable)}
,isc.A.$167v=function isc_Button__getTextAlign(_1){var _2=this.align;if(_2==null){return isc.Canvas.CENTER}else if(!_1||this.ignoreRTL){return _2}else{return isc.StatefulCanvas.$1333[_2]}}
,isc.A.getInnerHTML=function isc_Button_getInnerHTML(){var _1=this.$5b(),_2=this.shouldClipTitle(),_3=this.isRTL();if(this.isPrinting||!this.$118j(_1,_2)){var _4=isc.Button;if(!_4.$4y){_4._100Size=" width='100%' height='100%";_4._100Width=" width='100%";_4.$xf="width='";_4.$xg="' height='";_4.$4z="' style='table-layout:fixed;overflow:hidden;";var _5=_4.$115m=[];_4.$115n=">";_4.$115o=" nowrap='true'";_4.$115p=" class='";_4.$115q="<col width='";_4.$1151="px'/>";_4.$115s="<col/>";_5[0]="'><colgroup>";_5[5]="</colgroup><tbody><tr><td";_4.$40="'><tbody><tr><td class='";_4.$41="'><tbody><tr><td nowrap='true' class='";_4.$2728="<table role='presentation' cellspacing='0' cellpadding='0'";var _6=_4.$4y=[];_6[9]="' align='";_4.$145t="' valign='middle";_4.$43="' valign='top";_4.$44="' valign='bottom";_4.$151="' id='";_4.$45="' "+(isc.Browser.isChrome?"":"tabindex='-1'")
+" onfocus='";_4.$46=".$47()'>";_4.$48="'>"}
var _6=_4.$4y;_6[0]=this.$2728+(this.tableStyle?" class='"+this.tableStyle+"'":"");if(this.isPrinting||this.redrawOnResize==false){_6[1]=(this.isPrinting?_4._100Width:_4._100Size);_6[2]=null;_6[3]=null;_6[4]=null}else{_6[1]=_4.$xf;var _7=this.$1316()
_6[2]=this.getInnerWidth();_6[3]=_4.$xg;_6[4]=this.getInnerHeight()}
if(this.overflow==isc.Canvas.VISIBLE){_6[5]=null}else{_6[5]=_4.$4z}
var _8;if(isc.Browser.isIE&&!isc.Browser.isStrict&&isc.Browser.version<10&&this.$1240&&(_8=this.$115j==null?null:this.$115j())>0)
{var _5=_4.$115m;_5[1]=_4.$115s;_5[2]=_4.$115q;_5[3]=_8;_5[4]=_4.$1151;_5[6]=(this.wrap?null:_4.$115o);_5[7]=_4.$115p;_6[6]=_5.join(isc.emptyString)}else{_6[6]=(this.wrap?_4.$40:_4.$41)}
_6[7]=this.isPrinting?this.getPrintStyleName():this.getStateName();var _9=!_1&&_2;var _10=_9||this.cssText||this.$4v!=null||this.$4w!=null||this.$4x||this.margin!=null||this.$49()||this.shouldPushTableBorderStyleToDiv()||this.shouldPushTableShadowStyleToDiv()||(this.$115j!=null)||(this.$tt!=null);if(_10)_6[8]=this.$5a(null,_9);else _6[8]=null;_6[10]=_1?isc.Canvas.CENTER:this.$167v(_3);_6[11]=(this.valign==isc.Canvas.TOP?_4.$43:(this.valign==isc.Canvas.BOTTOM?_4.$44
:_4.$145t));if(_9){_6[12]=_4.$151;_6[13]=this.$1140()}else{_6[13]=_6[12]=null}
if(this.$kk()&&this._useNativeTabIndex){_6[14]=_4.$45;_6[15]=this.getID();_6[16]=_4.$46}else{_6[14]=_4.$48;_6[15]=_6[16]=null}
this.fillInCell(_6,17,_9);return _6.join(isc.emptyString)}else{var _11=isc.SB.create(),_12=(this.valign==isc.Canvas.TOP||this.valign==isc.Canvas.BOTTOM
?this.valign
:"middle");var _13=this.$167v(_3);var _14=this.$2728+(this.tableStyle?" class='"+this.tableStyle+"'":"");_11.append(_14,(this.overflow!==isc.Canvas.VISIBLE
?" width='"+this.getInnerWidth()+"' style='table-layout:fixed'":null)," height='",this.getInnerHeight(),"'><tbody><tr><td class='",this.getStateName(),"' style='",this.$5a([]),"text-align:",_13,";vertical-align:",_12,(!this.wrap?";white-space:nowrap":""),"'>");var _15=this.$1140(),_16=this.getIconSpacing(),_17=(this.iconWidth||this.iconSize),_18=_16+_17,_19=((!_3&&this.iconOrientation==isc.Canvas.RIGHT)||(_3&&((this.ignoreRTL&&this.iconOrientation==isc.Canvas.LEFT)||(!this.ignoreRTL&&this.iconOrientation==isc.Canvas.RIGHT)))),b=(_3||_19)&&!(_3&&_19);var _21=0,_8=0,_22=null;if(this.icon!=null&&!this.$2250){_21=_18;_22=this.$5d({align:"absmiddle",extraCSSText:(b?"margin-left:":"margin-right:")+_16+"px;vertical-align:middle",eventStuff:this.$209z
})}
_11.append((!_19?_22:null),"<div id='",_15,this.canSelectText?null:"' unselectable='on","' style='display:inline-block;",(this.icon&&!this.$2250?(b?"margin-right:":"margin-left:")+(-_18)+"px;":null),isc.Element.$1434,":border-box;max-width:100%;",(_21?((b?"padding-right:":"padding-left:")+_21+"px;"):null),(_8?((b?"padding-left:":"padding-right:")+_8+"px;"):null),"vertical-align:middle;overflow:hidden;",isc.Browser.$114w,":ellipsis'>",isc.Browser.isSafari?"<div></div>":"",this.getTitleHTML(),"</div>",(_19?_22:null));_11.append("</td></tr></tbody></table>");return _11.release(false)}}
,isc.A.$160g=function isc_Button__getSizeTestHTML(_1,_2){var _3=this.$160f;var _4=this.isRTL();var _5=this.$4w;var _6=this.$115j?this.$115j():_5;if(_5!=null||_6!=null){if(_5!=null){_3[5]=(_4?"padding-right:":"padding-left:")+_5+"px;"
}else{_3[5]=null}
if(_6!=null){var _7=(_4?"padding-left:":"padding-right:")
+_6+"px;";if(_3[5]==null){_3[5]=_7}else{_3[5]+=_7}
}
}else{_3[5]=null}
if(_2==null)_2=this.wrap;_3[1]=_2?null:'nowrap="true" ';_3[3]=(this.titleStyle
?this.getTitleStateName()
:this.getStateName(_1)
);var _8=this.icon;if(_8!=null){var _9=this.getIconSpacing(_1),_10=(this.iconWidth||this.iconSize),_11=_9+_10,_12=((!_4&&this.iconOrientation==isc.Canvas.RIGHT)||(_4&&((this.ignoreRTL&&this.iconOrientation==isc.Canvas.LEFT)||(!this.ignoreRTL&&this.iconOrientation==isc.Canvas.RIGHT)))),b=(_4||_12)&&!(_4&&_12);var _14=this.$5d({align:"absmiddle",extraCSSText:(b?"margin-left:":"margin-right:")+_9+"px;vertical-align:middle",eventStuff:this.$209z
});if(_12){_3[7]=_1==null?_14:_1+_14}else{_3[7]=_1==null?_14:_14+_1}
}else{_3[7]=_1}
return _3.join("")}
,isc.A.$11o=function isc_Button__getTableElement(){var _1=this.getHandle();return _1&&_1.firstChild}
,isc.A.$145n=function isc_Button__getCellElement(){var _1=this.$11o();if(_1==null)return null;return _1.rows[0].childNodes[0]}
,isc.A.redraw=function isc_Button_redraw(_1,_2,_3,_4){var _5=this.shouldPushTableBorderStyleToDiv();if(this.$1908!==_5){this.$tk=null;this.$1908=_5}
return this.invokeSuper(isc.Button,"redraw",_1,_2,_3,_4)}
,isc.A.setOverflow=function isc_Button_setOverflow(){var _1=this.isDirty(),_2=this.overflow;this.Super("setOverflow",arguments);if(!_1&&(_2!=this.overflow||(this.shouldPushTableShadowStyleToDiv())))
{this.redraw()}}
,isc.A.$ux=function isc_Button___adjustOverflow(_1){this.Super("$ux",arguments);if(isc.Browser.isSafari&&!isc.Browser.isChrome&&!isc.Browser.isEdge&&this.icon!=null&&!(this.isPrinting||!this.$118j()))
{var _2=this.isRTL(),_3=((!_2&&this.iconOrientation==isc.Canvas.RIGHT)||(_2&&((this.ignoreRTL&&this.iconOrientation==isc.Canvas.LEFT)||(!this.ignoreRTL&&this.iconOrientation==isc.Canvas.RIGHT))));if(!_3){var _4=this.$167v(_2),_5=this.getDocument().getElementById(this.$1140());if(!_5)return;var _6=_5.style,_7=this.getIconSpacing(),_8=(this.iconWidth||this.iconSize),_9=_7+_8;var _10=_9,_11=0;_6[_2?"paddingRight":"paddingLeft"]=_10+"px";_6[_2?"paddingLeft":"paddingRight"]="";if(this.titleClipped()){if(_4===isc.Canvas.CENTER){_10=((_10+_7)/2)<<0;_11=(_7/2)<<0}else if((!_2&&_4===isc.Canvas.RIGHT)||(_2&&_4===isc.Canvas.LEFT))
{_10-=(_10/2)<<0;_11=_8}
_6[_2?"paddingRight":"paddingLeft"]=_10+"px";_6[_2?"paddingLeft":"paddingRight"]=_11+"px"}
}
}}
,isc.A.getPrintTagStart=function isc_Button_getPrintTagStart(_1){var _2=this.currentPrintProperties,_3=_2.topLevelCanvas==this,_4=!_1&&!_3&&_2.inline;return[((this.wrap==false)?"<div style='white-space:nowrap' ":_4?"<span ":"<div "),this.getPrintTagStartAttributes(_1),">"].join(isc.emptyString)}
,isc.A.$5a=function isc_Button__getCellStyleHTML(_1,_2){_1=_1||this.$4f;_1[1]=(this.cssText?this.cssText:null);if(this.forceWrap){_1[1]=(_1[1]||"")+"word-break:break-word;"}
var _3=this.shouldPushTableBorderStyleToDiv(),_4=_3?"none;border-radius:inherit":this.$4v;if(!_3&&this.borderRadius!=null){_4=(_4!=null?_4:"none")+";border-radius:"+this.borderRadius}
if(_4!=null){_1[2]=this.$4a;_1[3]=_4;_1[4]=this.$39}else{_1[2]=null;_1[3]=null;_1[4]=null}
var _5=this.$4w;if(_5!=null){_1[5]=this.$4c;_1[6]=_5;_1[7]=this.$38}else{_1[5]=null;_1[6]=null;_1[7]=null}
var _6=this.$tt?"padding-top:"+this.$tt()+"px;padding-bottom:0px;":(this.$49()?this.$4b:null);if(_6){if(_1[7])_1[7]+=_6;else _1[7]=_6}
if(this.$4x!=null){_1[8]=this.$4d;_1[9]=this.$4x;_1[10]=this.$39}else{_1[8]=null;_1[9]=null;_1[10]=null}
if(this.margin!=null)_1[11]=this.$4e;else _1[11]=null;if(isc.Browser.useCSSFilters)_1[12]=null;else _1[12]=this.$987;if(_2)_1[13]=this.$115f;else _1[13]=null;var _7;if((!isc.Browser.isIE||isc.Browser.isStrict||isc.Browser.version>=10||!this.$1240)&&(_7=(this.$115j==null?null:this.$115j()))>0)
{_1[14]=(this.isRTL()?this.$115l:this.$115k);_1[15]=_7;_1[16]=this.$38}else{_1[16]=_1[15]=_1[14]=null}
if(isc.Browser.isChrome&&isc.Browser.version==61&&this.shouldPushTableShadowStyleToDiv())
{_1[17]="box-shadow:none;"}else _1[17]=null;if(this.backgroundImage!=null){_1[18]="background-image:none;"}else{_1[18]=null}
return _1.join(isc.emptyString)}
,isc.A.$49=function isc_Button__writeZeroVPadding(){return this.overflow==isc.Canvas.HIDDEN&&!this.rotateTitle&&!this.isAnimating()&&(isc.Browser.isMoz||isc.Browser.isSafari||isc.Browser.isIE)}
,isc.A.setBorder=function isc_Button_setBorder(_1){var _2=this.shouldPushTableBorderStyleToDiv(),_3=this.border,_4=this.$4v,_5=_2?_1:null,_6=_2?null:_1;if(_4!=_6){this.$4v=_6;this.markForRedraw("Button border changed")}
if(_3!=_5){this.Super("setBorder",[_5],arguments)}}
,isc.A.setPadding=function isc_Button_setPadding(_1){this.$4w=_1;this.markForRedraw()}
,isc.A.setBackgroundColor=function isc_Button_setBackgroundColor(_1){var _2=this.shouldPushTableBorderStyleToDiv(),_3=this.$4x,_4=this.backgroundColor,_5=_2?null:_1,_6=_2?_1:null;if(_3!=_5){this.$4x=_5;var _7;if(!this.destroyed)_7=this.$145n();if(_7!=null)_7.style.backgroundColor=(_5==null?"":_5)}
if(_4!=_6){return this.Super("setBackgroundColor",[_6],arguments)}}
,isc.A.$191r=function isc_Button__getHandleBackgroundColor(){if(this.backgroundColor==null&&this.shouldPushTableBorderStyleToDiv()){return isc.Button.$191s(this.isPrinting?this.getPrintStyleName()
:this.getStateName())}
return this.Super("$191r",arguments)}
,isc.A.$2334=function isc_Button__getHandleOpacity(){if(this.opacity==null&&this.shouldPushTableBorderStyleToDiv()){return isc.Button.$2335(this.isPrinting?this.getPrintStyleName()
:this.getStateName())}
return this.Super("$2334",arguments)}
,isc.A.$5c=function isc_Button__endTemplate(_1,_2){_1[_2]=this.$4g;_1.length=_2+1;return _1}
,isc.A.$5b=function isc_Button__iconAtEdge(){return this.icon!=null&&this.iconAlign!=null&&(this.iconAlign==this.iconOrientation)&&(this.iconAlign!=this.align)}
,isc.A.getIconSpacing=function isc_Button_getIconSpacing(_1){var _2;if(this.icon==null||this.$2250||(_1===_2?this.getTitle():_1)==null)return 0;return this.iconSpacing}
,isc.A.fillInCell=function isc_Button_fillInCell(_1,_2,_3){var _4=this.isRTL();var _5=this.getTitleHTML();if(!this.icon){if(isc.Browser.isMoz){var _6=this.reliableMinHeight;_1[_2]=(_6?"<div>":null);_1[_2+1]=_5;_1[_2+2]=(_6?"</div>":null);this.$5c(_1,_2+3)
}else{_1[_2]=_5;this.$5c(_1,_2+1)
}
return}
var _7=(!_4&&this.iconOrientation!=isc.Canvas.RIGHT)||(_4&&((this.ignoreRTL&&this.iconOrientation!=isc.Canvas.LEFT)||(!this.ignoreRTL&&this.iconOrientation!=isc.Canvas.RIGHT))),_8=this.$5d();if(_3||this.noIconSubtable){var _9=isc.Canvas.spacerHTML(this.getIconSpacing(),1);_1[_2]=(_7?isc.SB.concat(_8,_9,_5)
:isc.SB.concat(_5,_9,_8));this.$5c(_1,_2+1)
return}
var _10=this.$5b(),_11;if(_10){_11=(this.iconWidth?this.iconWidth:this.iconSize)+(isc.Browser.isBorderBox?this.getIconSpacing():0)
}
var _12=this.shouldClipTitle();_1[_2]=(_10
?(_12
?this.$1153
:this.$4i)
:this.$4h);var _13=this.isPrinting?this.getPrintStyleName():(this.titleStyle
?this.getTitleStateName()
:this.getStateName()
);var _14=this.$4o;if(!isc.Browser.useCSSFilters)_14+=this.$987;var _15=this.$167v(_4);if(_7){_1[++_2]=this.$4n;_1[++_2]=_13;_1[++_2]=_14;_1[++_2]=!_4?this.$4j:this.$4k;_1[++_2]=this.getIconSpacing();if(_10){_1[++_2]="px;width:";_1[++_2]=_11}
_1[++_2]=this.$4l;_1[++_2]=_8;_1[++_2]=this.$4m;_1[++_2]=this.$4n;_1[++_2]=_13;_1[++_2]=_14;if(_12)_1[++_2]=this.$115f;_1[++_2]="' align='";_1[++_2]=_15;if(_12){_1[++_2]=isc.Button.$151;_1[++_2]=this.$1140()}
_1[++_2]=(this.wrap?this.$4p:this.$4q)
_1[++_2]=_5}else{_1[++_2]=this.$4n;_1[++_2]=_13;_1[++_2]=_14;if(_12)_1[++_2]=this.$115f;_1[++_2]="' align='";_1[++_2]=_15;if(_12){_1[++_2]=isc.Button.$151;_1[++_2]=this.$1140()}
_1[++_2]=(this.wrap?this.$4p:this.$4q)
_1[++_2]=_5;_1[++_2]=this.$4m;_1[++_2]=this.$4n;_1[++_2]=_13;_1[++_2]=_14;_1[++_2]=!_4?this.$4k:this.$4j;_1[++_2]=this.getIconSpacing();if(_10){_1[++_2]="px;width:";_1[++_2]=_11}
_1[++_2]=this.$4l;_1[++_2]=_8}
_1[++_2]=this.$4r;this.$5c(_1,_2+1)}
,isc.A.$5d=function isc_Button__generateIconImgHTML(_1){var _2=this.isFontIconConfig(this.icon);if(_1==null){_1=this.$4s;_1.extraCSSText=this.$141s;_1.eventStuff=this.$209z;_1.extraStuff=null;_1.instance=this}
if(this.iconStyle!=null){var _3=true;var _4=isc.Canvas.$1861(this.icon);if(_4&&_4.cssClass)_3=false;if(_3){var _5=" class='"+this.iconStyle+this.$137r()+this.$ob;if(_1.extraStuff==null)_1.extraStuff=_5;else _1.extraStuff+=_5}
}
_1.name=this.$116h;_1.width=this.iconWidth||this.iconSize;_1.height=this.iconHeight||this.iconSize;_1.instance=this;if(_2)_1.src=this.$2250?null:this.icon;else _1.src=this.$5f();if(this.iconCursor!=null){var _6=this.$141r();var _7="cursor:"+_6;if(_1.extraCSSText==null){_1.extraCSSText=_7}else{_1.extraCSSText+=";"+_7}
}
return this.imgHTML(_1)}
,isc.A.$5f=function isc_Button__getIconURL(){var _1=this.Super("$5f",arguments);return this.$179m(_1)}
,isc.A.$179m=function isc_Button__getStatefulIconURL(_1){if(_1===isc.Canvas.$wz||_1==isc.Canvas.$5w)return _1;var _2=this.state,_3=this.selected,_4=this.getCustomState(),_5=isc.StatefulCanvas;if(_2==_5.STATE_DISABLED&&(!this.showDisabled||!this.showDisabledIcon))_2=null;else if(_2==_5.STATE_DOWN&&(!this.showDown||!this.showDownIcon))_2=null;else if(_2==_5.STATE_OVER&&(!this.showRollOver||!this.showRollOverIcon))_2=null;if(!this.showIconState){_2=null;_4=null}else if(this.showIconCustomState==false){_4=null}
if(_3&&!this.showSelectedIcon)_3=false;var _6=this.showFocusedIcon?this.getFocusedState():null;if(_6&&this.showFocusedAsOver){if(this.showRollOverIcon&&(!_2||_2==isc.StatefulCanvas.STATE_UP))
{_2=isc.StatefulCanvas.STATE_OVER}
_6=false}
var _7=isc.Media.getStockIconKeyForSrc(_1,this.skinImgDir,this);if(_7)_1=isc.Media.getStockIconSrc(_7);var _8=isc.Canvas.$1861(_1);if(_8){if(!_8.cssClass&&this.iconStyle)_8.cssClass=this.iconStyle;_1=isc.Canvas.$2166(_8)}
return isc.Img.urlForState(_1,_3,_6,_2,(this.showRTLIcon&&this.isRTL()?"rtl":null),_4)}
,isc.A.$137r=function isc_Button__getIconStyleSuffix(){var _1=this.state,_2=this.selected?isc.StatefulCanvas.SELECTED:null,_3=this.getCustomState(),_4=isc.StatefulCanvas;if(_1==_4.STATE_DISABLED&&!this.showDisabledIcon)_1=isc.emptyString;else if(_1==_4.STATE_DOWN&&!this.showDownIcon)_1=isc.emptyString;else if(_1==_4.STATE_OVER&&!this.showRollOverIcon)_1=isc.emptyString;if(!this.showIconState){_1=isc.emptyString;_3=null}else if(this.showIconCustomState==false){_3=null}
if(_2!=null&&!this.showSelectedIcon)_2=null;var _5=this.showFocusedIcon?(this.getFocusedState()?isc.StatefulCanvas.FOCUSED:null):null;if(_5&&this.showFocusedAsOver){_5=false;if(this.showRollOverIcon&&(!_1||_1==_4.STATE_UP))_1=_4.STATE_OVER}
var _6=this.$61l(_1,_2,_5,_3);if(this.showRTLIcon&&this.isRTL())_6+=this.$132u;return _6}
,isc.A.getTitleHTML=function isc_Button_getTitleHTML(_1,_2,_3,_4){var _5=this.invokeSuper(isc.Button,"getTitleHTML",_1,_2,_3,_4);if(!_1&&this.$169z)return null;if(!this.padTitle||this.align==isc.Canvas.CENTER)return _5;if(this.align==isc.Canvas.RIGHT)return _5+isc.nbsp;else if(this.align==isc.Canvas.LEFT)return isc.nbsp+_5}
,isc.A.setWrap=function isc_Button_setWrap(_1){if(this.wrap!=_1){this.wrap=_1;this.markForRedraw("wrapChanged")}}
,isc.A.getTitleCell=function isc_Button_getTitleCell(){if(!this.getHandle())return null;var _1=this.getHandle().firstChild,_2=_1&&_1.rows!=null?_1.rows[0]:null,_3=_2&&_2.cells!=null?_2.cells[0]:null;return _3}
,isc.A.getButtonMinHeight=function isc_Button_getButtonMinHeight(){var _1=this.getTitleCell();if(!isc.Browser.isMoz){return _1.scrollHeight+isc.Element.$ym(this.getStateName())}
return _1.firstChild.offsetHeight+isc.Element.$ym(this.getStateName())}
,isc.A.getPreferredWidth=function isc_Button_getPreferredWidth(){var _1=this.wrap,_2=this.overflow,_3=this.width;this.setWrap(false);this.overflow=isc.Canvas.VISIBLE;this.setWidth(1);this.redrawIfDirty("getPreferredWidth");var _4=this.getScrollWidth();this.setWrap(_1);this.overflow=_2;this.setWidth(_3);return _4}
,isc.A.$188g=function isc_Button__measureWidth(_1){var _2=isc.Button.$1690;if(_2==null||_2.destroyed){_2=isc.Button.$1690=isc.Canvas.create({autoDraw:false,top:-1000,width:1,overflow:"hidden",ariaState:{hidden:true
}
})}
var _3=this.$160g(_1);if(_1!=null){if(this.$188h&&this.$188h==_3)return this.$188i}else{if(this.$188j&&this.$188j==_3)return this.$188k}
_2.setContents(_3);if(!_2.isDrawn())_2.draw();else _2.redrawIfDirty("measuring button width");if(_1!=null){this.$188h=_3;return this.$188i=_2.getScrollWidth()}else{this.$188j=_3;return this.$188k=_2.getScrollWidth()}}
,isc.A.adaptWidthShouldHideTitle=function isc_Button_adaptWidthShouldHideTitle(){return this.adaptWidthShowIconOnly&&this.icon!=null}
,isc.A.adaptWidthBy=function isc_Button_adaptWidthBy(_1,_2,_3,_4){var _5=this.adaptWidthShouldHideTitle(),_6=(this.minWidth!=null)&&(this.$238i||this.autoFit);if(!_5&&!_6){return 0}
var _7=_6||(this.overflow!=isc.Canvas.HIDDEN&&this.overflow!=isc.Canvas.CLIP_H);var _8=this.$238j;if((_1>0&&_8)||(_1<0&&!_8))
{_8=!_8}else{if(_4||!_3)return 0}
var _9;if(!_8&&!_7&&isc.isA.Number(this.$pn)){_9=this.$pn}else{if(_8){_9=this.minWidth||1;if(_5)_9=Math.max(_9,this.$188g(null))}else{_9=this.$188g(this.getTitleHTML(true))}
}
if(_8){if(_9<_2){this.$238j=true;this.$169z=_5;if(_6){this.setAutoFit(false);this.$238i=true}
this.markForRedraw();return _9-_2}
}else{var _10=_2+_1;if(_9<=_10){this.$238j=false;this.$169z=false;if(_6){this.setAutoFit(true)}
this.markForRedraw();return _9-_2}
}
return 0}
,isc.A.getTitle=function isc_Button_getTitle(_1){if(!_1&&this.$169z)return null;if(this.useContents)return this.getContents();return this.title}
,isc.A.getStateName=function isc_Button_getStateName(_1){var _2,_3=this.getStateSuffix(),_4=_1!==_2?!_1:this.$169z,_5=_4&&this.iconOnlyBaseStyle||this.baseStyle;return _3?_5+_3:_5}
,isc.A.stateChanged=function isc_Button_stateChanged(){var _1,_2,_3,_4,_5,_6;if(this.icon){if(isc.isA.String(this.icon)){var _7=isc.Media.getStockIconKeyForSrc(this.icon,this.skinImgDir,this);if(_7){_1=isc.Media.getStockIconSrc(_7)}
}
if(!_1)_1=this.$5f();_4=isc.Canvas.$1861(_1);_3=_4!=null;if(!_3){_5=isc.Media.isFontIconConfig(_1);if(_5)_6=isc.Media.getFontIconConfig(_1)}
}
if(_1){var _2=_1;if(_4)_2=_4.svg||_4.src;_2=isc.Page.getImgURL(_2,this.skinImgDir,this);var _7=isc.Media.getStockIconKeyForSrc(_2,null,this);if(_7&&_1){_1=isc.Media.getStockIconSrc(_7);_4=isc.Canvas.$1861(_1);_3=_4!=null;if(!_3){_5=isc.Media.isFontIconConfig(_1);if(_5)_6=isc.Media.getFontIconConfig(_1)}
}
}
if(this.$179l()||!this.isDrawn()||this.icon&&!this.$195i(this.$116h,_1,_3))
{return this.invokeSuper(isc.Button,"stateChanged",true)}else{var _8=this.isPrinting?this.getPrintStyleName():this.getStateName();if(this.shouldPushTableBorderStyleToDiv()){this.$95v(_8);var _9=this.getStyleHandle();if(_9!=null){var _10=this.$191r();_9.backgroundColor=_10;var _11=this.$2334();_9.opacity=_11}
}
if(this.shouldPushTableShadowStyleToDiv()){this.$1320(_8)}
if(!this.suppressClassName)this.setClassName(this.getStyleList(_8));else this.setTableClassName(_8);if(_1&&!this.$2250&&this.getImage(this.$116h,_3)){this.setImage(this.$116h,_1,null,_3);if(this.iconStyle!=null){this.getImage(this.$116h).className=this.iconStyle+this.$137r()}else if(_6&&_6.cssClass){}
}
var _12;if(this.titleStyle&&(_12=this.getTitleCell())!=null){var _13=_12.firstChild;if(_13!=null&&_13.tagName==this.$34w){var _14=this.isPrinting?this.getPrintStyleName():this.getTitleStateName();var _15=_13.rows[0].childNodes;for(var i=0;i<_15.length;i++){_15[i].className=_14}
}
}
}}
,isc.A.setTableClassName=function isc_Button_setTableClassName(_1){if(this.shouldPushTableBorderStyleToDiv()){this.$tk=null}
var _2=this.getTitleCell();if(!_2)return;if(this.pendingMarkerVisible){var _3=this.getStyleList(_1);_2.className=_3}else{if(_2.className!=_1)_2.className=_1}
if(this.$168e(true)&&!this.titleStyle){var _4=_2.firstChild;if(_4!=null&&_4.tagName==this.$34w){var _5=_4.rows[0].children;if(_5!=null){for(var i=0;i<_5.length;i++){if(_5[i]&&_5[i].className!=_1)_5[i].className=_1}
}
}
}
if(this.overflow==isc.Canvas.VISIBLE){this.$t5=true;this.adjustOverflow("table style changed")}}
,isc.A.getScrollWidth=function isc_Button_getScrollWidth(_1,_2,_3,_4){var _5=this.invokeSuper(isc.Button,"getScrollWidth",_1,_2,_3,_4);if(!_1||!this.isDrawn())return _5;if(isc.Browser.isIE9&&this.$168e(true)){var _6=this.getDocument().getElementById(this.$1140());if(_6!=null){var _7;if(isc.Browser.isMoz){var _8=this.getDocument().createRange();_8.selectNodeContents(_6);var _9=_8.getBoundingClientRect();_7=_9.width}else{_7=_6.scrollWidth}
if(this.icon!=null){var _10=this.getIconSpacing(),_11=(this.iconWidth||this.iconSize),_12=_10+_11;_7+=_12}
_7+=isc.Element.$yp(this.getStateName());return Math.ceil(_7)}
}else if((isc.Browser.isMoz&&isc.Browser.isMac&&isc.Browser.version>=4)||isc.Browser.isIE9)
{var _13=this.$11o();var _14=_13.style.position;var _8=_13.ownerDocument.createRange();_8.selectNode(_13);var _9=_8.getBoundingClientRect();var _15;if(isc.Browser.isIE9&&!isc.Browser.isIE10){_15=(_9.width+1)<<0}else{_15=Math.ceil(_9.width)}
if(_15>_5){this.$su=_15;return _15}
}
return _5}
);isc.evalBoundary;isc.B.push(isc.A.setIcon=function isc_Button_setIcon(_1,_2){var _3=this.icon!=null;this.icon=_1;if(this.isDrawn()){var _4=this.$5f(),_5=this.$1889()
;if(_3&&(_1!=null)&&this.$195i(this.$116h,_4,_5)){this.setImage(this.$116h,_4,null,_5);if(_2)this.markForRedraw()}else{this.redraw()}
}}
,isc.A.setIconStyle=function isc_Button_setIconStyle(_1){this.iconStyle=_1;var _2=this.icon!=null;if(this.isDrawn()&&_2){var _3=this.getImage(this.$116h);if(_3!=null){_3.className=(_1==null?isc.emptyString
:_1+this.$137r())}
}}
,isc.A.$47=function isc_Button__cellFocus(){isc.EH.$h1("cFCS");this.focus();isc.EH.$h2()}
,isc.A.$ur=function isc_Button__updateCanFocus(){this.Super("$ur",arguments);if(this._useNativeTabIndex)this.markForRedraw()}
,isc.A.$132z=function isc_Button__getShadowCSSHTML(_1){var _2;if(this.showShadow&&this.shouldUseCSSShadow()){_2=this.$1781(true);if(_2==null)_2=""}else{var _2=isc.StatefulCanvas.$132z(_1);if(_2!=isc.emptyString)_2=";"+_2}
return _2}
,isc.A.$95e=function isc_Button__getBorderHTML(){if(this.shouldPushTableBorderStyleToDiv()){var _1=this.isPrinting?this.getPrintStyleName():this.getStateName();var _2=this.border!=null?";BORDER:"+this.border:"";_2+=isc.StatefulCanvas.$95s(this.border!=null,_1);if(this.shouldPushTableShadowStyleToDiv()){_2+=this.$132z(_1)}
return _2}
var _2=this.Super("$95e",arguments);if(this.shouldPushTableShadowStyleToDiv()){var _1=this.isPrinting?this.getPrintStyleName():this.getStateName(),_3=this.$132z(_1);if(_3!=isc.emptyString){_2=_2==null?_3:_2+_3}
}
return _2}
,isc.A.$95v=function isc_Button__applyBorderStyle(_1){var _2=this.getClipHandle().style,_3=isc.StatefulCanvas.$95q(this.border!=null,_1);if(!this.border)_2.border=isc.emptyString;_2.borderRadius=isc.emptyString;isc.addProperties(_2,_3);if(this.borderRadius!=null)_2.borderRadius=this.borderRadius}
,isc.A.$1320=function isc_Button__applyShadowStyle(_1){var _2=this.getClipHandle().style;if(this.showShadow&&this.shouldUseCSSShadow()){_2.boxShadow=this.$1781();return}
var _3=isc.StatefulCanvas.$132y(_1);_2.boxShadow=isc.emptyString;isc.addProperties(_2,_3);var _4=(isc.Browser.isChrome)?this.$11o():this.$145n();if(_4!=null){var _5=_4.style;_3=isc.StatefulCanvas.$132y(_1,null,true);_5.boxShadow=isc.emptyString;isc.addProperties(_5,_3)}}
,isc.A.$95g=function isc_Button__getBorderClassName(){if(this.shouldPushTableBorderStyleToDiv()){return this.getStateName()}
return this.Super("$95g",arguments)}
,isc.A.handleFocusIn=function isc_Button_handleFocusIn(_1,_2){if(isc.Browser.isIE&&this.$kk()&&isc.EH.leftButtonDown()){var _3=_1&&_1.nodeName;if(_3=="TD"){this.logWarn("Button: Intercepting native focus from mouseDown on table cell and resetting to handle.","nativeFocus");this.focus();return}
}
return this.Super("handleFocusIn",arguments)}
);isc.B._maxIndex=isc.C+60;isc.A=isc.Button;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$191t={};isc.A.$2336={};isc.B.push(isc.A.$191s=function isc_c_Button__getStateBackgroundColor(_1){var _2="**null**";if(this.$191t[_1]==null){var _3=isc.Element.$x5(_1,["backgroundColor"]);this.$191t[_1]=_3.backgroundColor==null?_2:_3.backgroundColor}
return this.$191t[_1]==_2?null:this.$191t[_1]}
,isc.A.$2335=function isc_c_Button__getStateOpacity(_1){var _2="**null**";if(this.$2336[_1]==null){var _3=isc.Element.$x5(_1,["opacity"]);this.$2336[_1]=_3.opacity==null?_2:_3.opacity}
return this.$2336[_1]==_2?null:this.$2336[_1]}
);isc.B._maxIndex=isc.C+2;isc.Button.registerStringMethods({getTitle:null});isc.ClassFactory.defineClass("AutoFitButton","Button");isc.A=isc.AutoFitButton.getPrototype();isc.A.autoFit=true;isc.Button.registerStringMethods({iconClick:"element,ID,event",titleHover:""});isc.addGlobal("IButton",isc.Button);isc.defineClass("SecondaryButton","IButton");isc.A=isc.SecondaryButton.getPrototype();isc.A.baseStyle="secondaryButton";isc.A.height=22;isc.A.showFocusedAsOver=false;isc.A.showFocusOutline=false;isc.defineClass("Img","StatefulCanvas");isc.A=isc.Img;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$5g=[];isc.A.preferModifiersToState=["Over","Down"
];isc.B.push(isc.A.urlForState=function isc_c_Img_urlForState(_1,_2,_3,_4,_5,_6){if(!_1)return _1;if(isc.isA.String(_1)){var _7=isc.Media.getStockIconKeyForSrc(_1,null,this);if(_7){_1=isc.Media.getStockIconSrc(_7)}
}
var _8;if(_1.isSprite)_8=_1;else _8=isc.Canvas.$1861(_1);if(_8!=null){var _9=_8.src,_10=_8.cssClass
;if(_9!=null){_8.src=this.urlForState(_9,_2,_3,_4,_5,_6)}
if(_8.svg!=null&&_8.statefulId){var _11=isc.StatefulCanvas.$61l(_4,_2,_3,_6)||"";_8.svg=_8.svg+(_11==""?"":"_"+_11)}
if(_10!=null){var _12=true;if(_8.statefulId&&!_8.statefulClass){_12=false}else{_12=_8.statefulClass!=false}
if(_12){var _13=isc.StatefulCanvas.$61l(_4,_2,_3,_6);if(_13&&_13.length>0&&!_8.cssClass.endsWith(_13)){_8.cssClass=_8.cssClass+_13}
}
}
return isc.Canvas.$2166(_8)}else if(isc.isA.String(_1)){}
if(isc.isAn.Object(_1)){if(_1._base==null){var _14=false,_15=null
;for(var _16 in _1){if(!_15&&!_16.contains("#"))_15=_16;if(isc.isA.String(_1[_16])&&_1[_16].contains("#")){_14=true;break}
}
if(_14){this.logWarn("Attempt to derive stateful URL for object:"+this.echo(_1)+" using the #modifier or #state prefixes when the object has no explicit '_base' attribute.  Setting _base to match the first valid key in the object to avoid downstrem issues.","StatefulImgConfig");_1._base=_1[_15]}
}
if(!_4&&!_5&&!_2&&!_3&&!_6){return this.$3303(_1._base)}
var _17=!(_4==null&&_5==null&&_6==null);if(_17&&(_2||_3)){if(_2&&_3){var _18=this.$207h(["Selected","Focused",_4,_5,_6
]);if(_1[_18]){return this.resolveStatefulImgConfigEntry(_18,_1)}
}
if(_2){var _18=this.$207h(["Selected",_4,_5,_6
]);if(_1[_18]){return this.resolveStatefulImgConfigEntry(_18,_1)}
}
if(_3){var _18=this.$207h(["Focused",_4,_5,_6
]);if(_1[_18]){return this.resolveStatefulImgConfigEntry(_18,_1)}
}
}
var _19;if(_2&&_3&&_1.SelectedFocused){_19="SelectedFocused"}
if(!_19&&_2&&_1.Selected){_19="Selected"}
if(!_19&&_3&&_1.Focused){_19="Focused"}
if(_19&&(!_17||this.preferModifiersToState[_4])){return this.resolveStatefulImgConfigEntry(_19,_1)}
if(_17){var _20=this.$207h([_4,_5,_6
]);if(_1[_20]){return this.resolveStatefulImgConfigEntry(_20,_1)}
}
if(_19){return this.resolveStatefulImgConfigEntry(_19,_1)}
return this.$3303(_1._base)}
if(!_4&&!_5&&!_2&&!_3&&!_6)return _1;var _21=_1.lastIndexOf(isc.dot),_22=_1.substring(0,_21),_23=_1.substring(_21),_24=this.$5g;_24.length=1;_24[0]=_22;if(_2){_24[1]=isc.$ag;_24[2]=isc.StatefulCanvas.SELECTED}
if(_3){_24[3]=isc.$ag;_24[4]=isc.StatefulCanvas.FOCUSED}
if(_4){_24[5]=isc.$ag;_24[6]=_4}
if(_6){_24[7]=isc.$ag;_24[8]=_6}
if(_5){_24[9]=isc.$ag;_24[10]=_5}
_24[11]=_23;var _25=_24.join(isc.$ad);return _25}
,isc.A.$207h=function isc_c_Img__getCombinedStatefulImgAttribute(_1){_1.removeEmpty();var _2;for(var i=0;i<_1.length;i++){if(_1[i]=="")continue;if(_2==null){_2=_1[i]}else{_2+=_1[i].substring(0,1).toUpperCase()+_1[i].substring(1)}
}
return _2}
,isc.A.$3303=function isc_c_Img__resolveStockIconValue(_1){if(_1&&isc.isA.String(_1)&&isc.Media){var _2=isc.Media.getStockIconKeyForSrc(_1);if(_2)return isc.Media.getStockIconSrc(_2)}
return _1}
,isc.A.resolveStatefulImgConfigEntry=function isc_c_Img_resolveStatefulImgConfigEntry(_1,_2,_3){var _4=_2[_1];if(_4==null)return null;if(_4.startsWith("#")){var _5=_4.split(":");switch(_5[0]){case"#modifier":var _6=_2._base,_7=_6.lastIndexOf(".");_6=_6.substring(0,_7)+_5[1]+_6.substring(_7);return _6;case"#state":if(_3!=null){if(_3.contains(_5[1])&&!_2.$207i)
{_2.$207i=true;this.logWarn("Stateful image Configuration contains a circular reference:"+this.echo(_2)+". Unable to resolve "+_3[0]+" to an image");return null}
_3.add(_1)}else{_3=[_1]}
return this.resolveStatefulImgConfigEntry(_5[1],_2,_3);default:this.logWarn("stateful image configuration value:"
+_1+" from configutation object:"+this.echo(_2)+" has hash prefix but does not conform to expected naming pattern for meta value. Returning as is.")}
}
return this.$3303(_4)}
,isc.A.measureImage=function isc_c_Img_measureImage(_1,_2,_3){var _4=isc.Page.getURL(isc.isAn.Img(_1)?_1.src:_1);var _5=new Image();_5.onload=function(){var _6={width:_5.width,height:_5.height};if(_3){var _7=isc.Img.scaleDimensions(_5.width,_5.height,_3.width,_3.height);_6.maxWidth=_3.width;_6.maxHeight=_3.height;_6.scaledWidth=_7.width;_6.scaledHeight=_7.height;_6.ratio=_7.ratio}
_2(_6)}
_5.src=_4}
,isc.A.scaleDimensions=function isc_c_Img_scaleDimensions(_1,_2,_3,_4){var _5=Math.min(_3/_1,_4/_2);return{width:_1*_5,height:_2*_5,ratio:_5}}
);isc.B._maxIndex=isc.C+6;isc.A=isc.Img.getPrototype();isc.A.name="main";isc.A.src="[SKINIMG]blank.gif";isc.A.imageType=isc.Img.STRETCH;isc.A.suppressClassName=false;isc.A.mozOutlineOffset="0px";isc.A.showTitle=false;isc.A.usePNGFix=true;isc.A=isc.Img.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.styleText="line-height:1px;";isc.A.$5h="<TABLE WIDTH=";isc.A.$5i=" HEIGHT=";isc.A.$5j=" BORDER=0 CELLSPACING=0 CELLPADDING=0><TR>";isc.A.$5k="<TD style='line-height:1px' VALIGN=center ALIGN=center>";isc.A.$5l="<TD BACKGROUND=";isc.A.$5m="</TD></TR></TABLE>";isc.A.sizeImageToFitOverflow=false;isc.B.push(isc.A.initWidget=function isc_Img_initWidget(){if(this.imageType=="scaled"){this.overflow="hidden"}
isc.StatefulCanvas.$b4.initWidget.call(this);this.redrawOnResize=(this.imageType!=isc.Img.STRETCH);this.$209a=this.getURL();if(this.shouldScaleImage()&&!this.$243p){this.measureImage(true)}}
,isc.A.draw=function isc_Img_draw(){if(this.shouldScaleImage()){if(!this.$243p){var _1=this;this.measureImage(true,function(){_1.draw()});return this}
}
return this.Super("draw",arguments)}
,isc.A.setImageType=function isc_Img_setImageType(_1){if(this.imageType==_1)return;this.imageType=_1;this.markForRedraw();this.redrawOnResize=(this.imageType!=isc.Img.STRETCH)}
,isc.A.getInnerHTML=function isc_Img_getInnerHTML(){var _1=this.sizeImageToFitOverflow?this.getOverflowedInnerWidth()
:this.getInnerWidth(),_2=this.sizeImageToFitOverflow?this.getOverflowedInnerHeight()
:this.getInnerHeight(),_3=this.imageType;if(this.shouldScaleImage()){if(!this.$243p){this.measureImage(true);return""}else this.rescaleImage()}
var _4=this.extraStuff,_5=this.eventStuff;if(this.imageStyle!=null){var _6=" class='"+this.imageStyle+this.getStateSuffix()+this.$ob;if(_4==null)_4=_6;else _4+=_6}
if(this.altText!=null){var _7=this.altText;_7=" alt='"+_7.replace("'","&apos;")+this.$ob;if(_4==null)_4=_7;else _4+=_7}
var _8=this.cssSpritePointerEvents;if(_3==isc.Img.STRETCH||_3==isc.Img.NORMAL){if(_3==isc.Img.NORMAL){_1=this.imageWidth;_2=this.imageHeight}
var _9={src:this.getURL(),width:_1,height:_2,name:this.name,extraStuff:_4,spritePEcss:_8,align:"top",activeAreaHTML:this.activeAreaHTML,eventStuff:_5
};return this.imgHTML(_9)}
var _10=isc.SB.create();_10.append(this.$5h,_1,this.$5i,_2,this.$5j);if(_3==isc.Img.TILE){_10.append(this.$5l,this.getImgURL(this.getURL()),this.$oa,isc.Canvas.spacerHTML(_1,_2))}else{_10.append(this.$5k,this.imgHTML(this.getURL(),this.imageWidth||this.imageSize,this.imageHeight||this.imageSize,this.name,_4,null,this.activeAreaHTML,null,_5,_8))}
_10.append(this.$5m);return _10.release(false)}
,isc.A.getOverflowedInnerWidth=function isc_Img_getOverflowedInnerWidth(){return this.getVisibleWidth()-this.getHMarginBorder()}
,isc.A.getOverflowedInnerHeight=function isc_Img_getOverflowedInnerHeight(){return this.getVisibleHeight()-this.getVMarginBorder()}
,isc.A.measureImage=function isc_Img_measureImage(_1,_2){var _3=this;isc.Img.measureImage(this.getURL(),function(_4){_3.$243p=isc.addProperties({},_4);if(_1)_3.rescaleImage();if(_2)_2()})}
,isc.A.shouldScaleImage=function isc_Img_shouldScaleImage(){return this.imageType=="scaled"&&this.src!="blank.gif"}
,isc.A.rescaleImage=function isc_Img_rescaleImage(){var _1=this.$243p,_2=this.getWidth(),_3=this.getHeight()
;var _4=isc.Img.scaleDimensions(_1.width,_1.height,_2,_3);this.imageWidth=_4.width;this.imageHeight=_4.height;this.markForRedraw("rescaling image with imageType 'scaled'")}
,isc.A.$ub=function isc_Img__handleResized(_1,_2){if(this.$243p){this.rescaleImage()}
if(this.redrawOnResize!=false||!this.isDrawn())return;var _3=this.getImage(this.name);var _4=_3&&_3.style;var _5=this.sizeImageToFitOverflow?this.getOverflowedInnerWidth():this.getInnerWidth(),_6=this.sizeImageToFitOverflow?this.getOverflowedInnerHeight():this.getInnerHeight();this.$u9(_4,this.$o6,_5);this.$u9(_4,this.$o5,_6)}
,isc.A.$10=function isc_Img__labelAdjustOverflow(){this.Super("$10",arguments);if(this.overflow!=isc.Canvas.VISIBLE||!this.sizeImageToFitOverflow)return;var _1=this.getImage(this.name),_2=_1?_1.style:null;if(_2==null)return;var _3=this.getOverflowedInnerWidth(),_4=this.getOverflowedInnerHeight();this.$u9(_2,this.$o6,_3);this.$u9(_2,this.$o5,_4)}
,isc.A.setSrc=function isc_Img_setSrc(_1,_2){if(_1==null||this.src==_1)return;this.src=_1;if(this.shouldScaleImage()){var _3=this;this.measureImage(true,function(){_3.resetSrc(_2)});return}else this.resetSrc(_2)}
,isc.A.resetSrc=function isc_Img_resetSrc(_1){if(!this.isDrawn())return;var _2=this.getURL();if(this.$209a==_2)return;this.$209a=_2;if(this.imageType=="scaled"){this.rescaleImage();this.markForRedraw("setSrc on scaled image")}else if(!isc.Media.isSVGDataURL(_2)){if(this.imageType!=isc.Img.TILE&&this.$195i(this.name,_2)){this.setImage(this.name,_2);this.adjustOverflow("setImage() called");if(_1)this.markForRedraw()}
}else{this.markForRedraw("setSrc on tiled image")}}
,isc.A.stateChanged=function isc_Img_stateChanged(_1){this.Super("stateChanged",arguments);if(!this.statelessImage)this.resetSrc()}
,isc.A.getHoverHTML=function isc_Img_getHoverHTML(){if(this.altText){if(isc.Browser.isIE)return null;if(this.prompt&&this.prompt!=this.altText){this.logWarn("Img component specified with altText:"+this.altText
+" and prompt:"+this.prompt
+". Value for 'prompt' attribute will be ignored in favor of 'altText' value.")}
return this.altText
}
return this.Super("getHoverHTML",arguments)}
,isc.A.fromCanvas=function isc_Img_fromCanvas(_1,_2){this.logWarn("This feature requires the Tools module.")}
);isc.B._maxIndex=isc.C+16;isc.ClassFactory.defineClass("StretchImg","StatefulCanvas");isc.A=isc.StretchImg.getPrototype();isc.A.vertical=true;isc.A.capSize=2;isc.A.overflow=isc.Canvas.HIDDEN;isc.A.imageType=isc.Img.STRETCH;isc.A.items=[{name:"start",width:"capSize",height:"capSize"},{name:"stretch",width:"*",height:"*"},{name:"end",width:"capSize",height:"capSize"}
];isc.A.ignoreRTL=true;isc.A.autoCalculateSizes=true;isc.A.cacheImageSizes=true;isc.A.suppressClassName=false;isc.A.mozOutlineOffset="0px";isc.A.showTitle=false;isc.A=isc.StretchImg.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$1276=[];isc.A.$5o="<NOBR>";isc.A.$5p="</NOBR>";isc.A.$5q="<BR>";isc.A.$133b="display:block";isc.A.$5h="<TABLE style='font-size:"+(isc.Browser.isFirefox&&isc.Browser.isStrict?0:1)
+"px;' CELLPADDING=0 CELLSPACING=0 BORDER=0>";isc.A.$5m="</TABLE>";isc.A.$5s="<TR><TD class='";isc.A.$5t="</TD></TR>";isc.A.$5u="<TD class='";isc.A.$61k="'>";isc.A.$5v="</TD>";isc.A.renderStretchImgInTable=isc.Browser.isMoz||isc.Browser.isIE8Strict;isc.A.oversizeStretchImg=isc.Browser.isMoz&&isc.Browser.isUnix;isc.A.$116b=/^blank[0-9]*$/;isc.B.push(isc.A.initWidget=function isc_StretchImg_initWidget(){isc.StatefulCanvas.$b4.initWidget.call(this);this.redrawOnResize=(this.imageType!=isc.Img.STRETCH)}
,isc.A.shouldShowLabel=function isc_StretchImg_shouldShowLabel(){if(this.showGrip)return true;return this.Super("shouldShowLabel",arguments)}
,isc.A.getPart=function isc_StretchImg_getPart(_1){for(var i=0,_3=this.items.length,_4;i<_3;i++){_4=this.items[i];if(_4.name==_1)return _4}
return null}
,isc.A.getPartNum=function isc_StretchImg_getPartNum(_1){for(var i=0,_3=this.items.length,_4;i<_3;i++){_4=this.items[i];if(_4.name==_1)return i}
return null}
,isc.A.getSize=function isc_StretchImg_getSize(_1){if(!this.$5x||this.$64y)this.resizeImages();return this.$5x[_1]}
,isc.A.sizeParts=function isc_StretchImg_sizeParts(){var _1=(this.vertical?this.$o5:this.$o6),_2=this.items,_3=_2.length,_4=this.$1276,_5=arguments.length;_4.length=_3+_5;var _6;var i=_3,_8=0,_9=true;for(var j=0;j<_5;++i,++j){_6=arguments[j];var _11=_4[i]=!_6?0:_6[_1];if(_11==null||isc.isAn.emptyString(_11)){_9=false}else if(isc.isA.Number(_11)){_8+=_11}else if(_11==isc.star||_11.indexOf(isc.Canvas.$o9)>=0){_9=false}else if(isc.isA.Number(this[_11])){_8+=_4[i]=this[_11]}else if(_11==="otherScrollbarSize"){_8+=_4[i]=this.getOtherScrollbarSize()}else{var _12=parseInt(_11);if(isc.isA.Number(_12)&&_12>=0){_8+=_12;_4[i]=_12}else{_9=false}
}
}
if(_9){_4.length=0;return _8}
for(i=0;i<_3;++i){_6=_2[i];if(!_6||!_6[_1])continue;_4[i]=_6[_1]}
isc.Canvas.applyStretchResizePolicy(_4,this.getImgLength(),1,true,this);_8=0;i=_3;for(var j=0;j<_5;++i,++j){_8+=_4[i]}
_4.length=0;return _8}
,isc.A.$10=function isc_StretchImg__labelAdjustOverflow(_1,_2,_3,_4){if(this.overflow==isc.Canvas.VISIBLE)this.$ub(null,null,true);this.invokeSuper(isc.StretchImg,"$10",_1,_2,_3,_4)}
,isc.A.setOverflow=function isc_StretchImg_setOverflow(_1,_2,_3,_4){var _5=false;if(this.overflow==isc.Canvas.VISIBLE&&((this.getScrollWidth()>this.getWidth())||(this.getScrollHeight()>this.getHeight())))
{_5=true}
this.invokeSuper(isc.StretchImg,"setOverflow",_1,_2,_3,_4);if(_5)this.$ub(null,null,true)}
,isc.A.$ub=function isc_StretchImg__handleResized(_1,_2,_3){if(this.redrawOnResize!=false||!this.isDrawn()){this.$64y=true;return}
if(this.$493)return;this.resizeImages();var _4=this.items,_5=_3||(isc.isA.Number(_1)&&_1!=0),_6=_3||(isc.isA.Number(_2)&&_2!=0),_7=(this.vertical&&_5)||(!this.vertical&&_6),_8=(this.vertical&&_6)||(!this.vertical&&_5);for(var i=0;i<_4.length;i++){var _10=this.getImage(_4[i].name);if(_10==null)continue;var _11=this.oversizeStretchImg&&(this.vertical?_4[i].height==isc.star
:_4[i].width==isc.star),_12=_11?_10.parentNode:null;if(_7){var _13=this.vertical?this.getWidth():this.getHeight();this.$u9(_10.style,this.vertical?this.$o6:this.$o5,_13);if(_11&&_12!=null){this.$u9(_12.style,this.vertical?this.$o6:this.$o5,_13)}
}
if(_8){var _13=this.$5x[i];if(_11&&_12!=null){this.$u9(_12.style,this.vertical?this.$o5:this.$o6,_13);_13+=2}
this.$u9(_10.style,this.vertical?this.$o5:this.$o6,_13)}
}}
,isc.A.resizeImages=function isc_StretchImg_resizeImages(){if(this.$493)return;var _1=(this.vertical?this.$o5:this.$o6),_2=this.items,_3=_2.length,_4=this.$5x;if(_4==null)_4=this.$5x=[];_4.length=_3;for(var i=0;i<_3;i++){var _6=_2[i];if(!_6||!_6[_1])continue;_4[i]=_6[_1]}
isc.Canvas.applyStretchResizePolicy(_4,this.getImgLength(),1,true,this)}
,isc.A.getInnerHTML=function isc_StretchImg_getInnerHTML(){var _1=this.items,_2=_1.length,_3=this.vertical;if(this.$64y||!this.$5x||(this.autoCalculateSizes&&!this.cacheImageSizes))this.resizeImages();delete this.$64y;var _4=this.$5x,_5=(_3?this.getImgBreadth():this.getImgLength()),_6=(_3?this.getImgLength():this.getImgBreadth()),_7=isc.SB.create();if(this.logIsDebugEnabled(this.$n3)){this.logDebug("drawing with imageType: '"+this.imageType+"' and sizes "+this.$5x,"drawing")}
var _8=!_3&&(this.ignoreRTL&&this.isRTL());if(this.imageType==isc.Img.TILE){_7.append("<TABLE CELLSPACING=0 CELLPADDING=0 BORDER=0 WIDTH=",_5," HEIGHT=",_6,"><TBODY>",(_3?"":"<TR>")
);for(var j=0;j<_2;j++){var i=_8?_2-j-1:j;var _11=_4[i];if(_11>0){var _12=_1[i],_13=this.getImgURL(this.$5z(_12));if(_3){_7.append("<TR><TD WIDTH=",_5," HEIGHT=",_11
,_12.name?(" NAME=\""+this.getCanvasName()+_12.name+"\""):null
," BACKGROUND=\"",_13,"\" class=\"",this.getItemStyleName(_12),"\">"
,isc.Canvas.spacerHTML(1,_11)
,"</TD></TR>"
)}else{_7.append("<TD WIDTH=",_11," HEIGHT=",_6,_12.name?(" NAME=\""+this.getCanvasName()+_12.name+"\""):null," BACKGROUND=\"",_13,"\" class=\"",this.getItemStyleName(_12),"\">"
,isc.Canvas.spacerHTML(_11,1)
,"</TD>"
)}
}
}
_7.append((_3?"":"</TR>"),"</TABLE>")}else if(this.imageType==isc.Img.CENTER){_7.append("<TABLE CELLSPACING=0 CELLPADDING=0 BORDER=0 WIDTH=",_5," HEIGHT=",_6,"><TBODY>",(_3?"":"<TR VALIGN=center>")
);for(var j=0;j<_2;j++){var i=_8?_2-j-1:j;var _11=_4[i];if(_11>0){var _12=_1[i],_13=this.$5z(_12);if(_3){_7.append("<TR VALIGN=center><TD WIDTH=",_5," HEIGHT=",_11," ALIGN=center"," class=\"",this.getItemStyleName(_12),"\">"
,this.imgHTML(_13,null,null,_12.name)
,"</TD></TR>"
)}else{_7.append("<TD WIDTH=",_11," HEIGHT=",_6," ALIGN=center"," class=\"",this.getItemStyleName(_12),"\">"
,this.imgHTML(_13,null,null,_12.name)
,"</TD>"
)}
}
}
_7.append((_3?"":"</TR>"),"</TABLE>")}else{var _14=this.renderStretchImgInTable;if(_14)_7.append(this.$5h);else if(!_3)_7.append(this.$5o);var _15=[" class='",null,"' "
];for(var j=0;j<_2;j++){var i=_8?_2-j-1:j;var _16=(j==0);var _17=(j==_2-1);var _11=_4[i];if(_11>0){var _12=_1[i],_13=this.$5z(_12),_18;var _18;if(!_14){var _19=this.getItemStyleName(_12);if(_19){_15[1]=_19;_18=_15.join(isc.emptyString)}else{_18=isc.emptyString}
}
if(!_3){if(_14){_7.append(_16?this.$5s:this.$5u);_7.append(this.getItemStyleName(_12));_7.append(this.$61k)}
var _20=_11,_21=(this.oversizeStretchImg&&(_12.width==isc.star));if(_21){_7.append("<div style='overflow:hidden;width:",_11,"px;height:",_6,"px;'>")
_20=_11+2}
_7.append(this.imgHTML({src:_13,width:_20,height:_6,name:_12.name,extraStuff:_18,extraCSSText:_12.extraCSSText
}));if(_21){_7.append("</div>")}
if(_14)_7.append(_17?this.$5t:this.$5v)}else{if(_14){_7.append(this.$5s);_7.append(this.getItemStyleName(_12));_7.append(this.$61k)}
var _22=_11,_21=(this.oversizeStretchImg&&(_12.width==isc.star));if(_21){_7.append("<div style='overflow:hidden;height:",_11,"px;width:",_5,"px;'>")
_22=_11+2}
var _23=isc.Browser.isDOM?this.$133b:null;if(isc.Browser.isMobileSafari&&_12.browserTouchCallout==false){_23=((_23==null?"":_23+";")+"-webkit-touch-callout:none")}
if(_12.extraCSSText){_23=((_23==null?"":_23+";")+_12.extraCSSText)}
_7.append(this.imgHTML({src:_13,width:_5,height:_22,name:_12.name,extraStuff:_18,extraCSSText:_23
}));if(_21){_7.append("</div>")}
if(_14)_7.append(this.$5t);else if(!isc.Browser.isDOM&&i<_2-1)_7.append(this.$5q)}
}
}
if(_14)_7.append(this.$5m)
else if(!_3)_7.append(this.$5p)}
return _7.release(false)}
,isc.A.getItemStyleName=function isc_StretchImg_getItemStyleName(_1){var _2;if(isc.isA.String(_1.baseStyleKey)&&isc.isAn.Object(_1.baseStyleMap)){_2=_1.baseStyleMap[this[_1.baseStyleKey]]}
if(_2==null)_2=_1.baseStyle||this.itemBaseStyle;if(!_2)return null;var _3=_1.state?_1.state:this.getState(),_4=this.$2087[_3];if(_3&&_4&&this[_4]===false){_3=""}
var _5=_1.selected!=null?_1.selected:this.selected,_6=this.showFocused&&!this.showFocusedAsOver&&!this.isDisabled()?(_1.focused!=null?_1.focused:this.focused):false;return _2+this.$61l(_3,_5?isc.StatefulCanvas.SELECTED:null,_6?isc.StatefulCanvas.FOCUSED:null)}
,isc.A.$5z=function isc_StretchImg__getItemURL(_1){if(this.vertical&&!_1.src&&_1.vSrc)return _1.vSrc;if(!this.vertical&&!_1.src&&_1.hSrc)return _1.hSrc;if(_1.src)return _1.src;if(this.$116b.test(_1.name))return isc.Canvas.$wz;return this.getURL(_1.name,(_1.state?_1.state:this.getState()),(_1.selected!=null?_1.selected:this.selected),(this.showFocused&&!this.showFocusedAsOver&&!this.isDisabled()?(_1.focused!=null?_1.focused:this.focused):false)
)}
,isc.A.setState=function isc_StretchImg_setState(_1,_2){if(_2==null){var _3=this.items.clearProperty("state"),_4=this.state!=_1;this.Super("setState",[_1],arguments);if(_3&&!_4)this.stateChanged()}else{var _5=this.getPart(_2);if(_5){if(_5.state==_1)return;_5.state=_1}
this.stateChanged()}}
,isc.A.stateChanged=function isc_StretchImg_stateChanged(_1){if(!this.isDrawn())return;if(this.isDirty())return;if(this.imageType==isc.Img.TILE||this.$5x==null){this.markForRedraw("setState (tiled images)")}else{if(isc.Browser.isWin2k&&isc.Browser.isIE){this.markForRedraw("Win2k IE image state change");return}
var _2=0;for(var i=0;i<this.items.length;i++){if(this.$5x[i]>0){var _4=this.items[i];if(!_1||_4.name==_1){if(!_4.src&&!this.$116b.test(_4.name)){this.setImage(_4.name,this.$5z(_4))}
var _5=this.getImage(_4.name);if(_5){if(this.renderStretchImgInTable){_5=_5.parentNode}
_5.className=this.getItemStyleName(_4)}
}
}else{_2++}
}
}}
,isc.A.setSrc=function isc_StretchImg_setSrc(_1){if(_1==null||this.src==_1)return;this.src=_1;this.markForRedraw()}
,isc.A.setItems=function isc_StretchImg_setItems(_1){this.items=_1==null?[]:_1.duplicate();this.markForRedraw()}
,isc.A.setIgnoreRTL=function isc_StretchImg_setIgnoreRTL(_1){this.ignoreRTL=!!_1;this.markForRedraw()}
,isc.A.inWhichPart=function isc_StretchImg_inWhichPart(){if(this.vertical){var _1=this.inWhichPosition(this.$5x,this.getOffsetY())}else{var _2=(this.ignoreRTL||!this.isRTL())?isc.Canvas.LTR:isc.Canvas.RTL;var _1=this.inWhichPosition(this.$5x,this.getOffsetX(),_2)}
var _3=this.items[_1];if(_3&&_3.name=="emptyButton")_3=this.items[_1+1];return(_3?_3.name:null)}
);isc.B._maxIndex=isc.C+19;isc.defineClass("Label","Button");isc.A=isc.Label.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.align=isc.Canvas.LEFT;isc.A.wrap=true;isc.A.showTitle=false;isc.A.height=null;isc.A.width=null;isc.A.overflow="visible";isc.A.canFocus=false;isc.A.styleName="normal";isc.A.baseStyle=null;isc.A.cursor="default";isc.A.showRollOver=false;isc.A.showFocus=false;isc.A.showDown=false;isc.A.showDisabled=false;isc.A.useContents=true;isc.B.push(isc.A.setStyleName=function isc_Label_setStyleName(_1){if(this.$300k){return this.Super("setStyleName",[_1])}
this.setBaseStyle(_1)}
);isc.B._maxIndex=isc.C+1;isc.ClassFactory.defineClass("Progressbar","StretchImg");isc.A=isc.Progressbar.getPrototype();isc.A.percentDone=0;isc.A.length=100;isc.A.breadth=20;isc.A.vertical=false;isc.A.skinImgDir="images/Progressbar/";isc.A.src="[SKIN]progressbar.gif";isc.A.cacheImageSizes=false;isc.A.valign="center";isc.A.backgroundColor="CCCCCC";isc.A.verticalItems=[{name:"v_empty_end",size:3},{name:"v_empty_stretch",size:0},{name:"v_empty_start",size:3},{name:"v_end",size:3},{name:"v_stretch",size:0},{name:"v_start",size:3}
];isc.A.horizontalItems=[{name:"h_start",size:3},{name:"h_stretch",size:0},{name:"h_end",size:3},{name:"h_empty_start",size:3},{name:"h_empty_stretch",size:0},{name:"h_empty_end",size:3}
];isc.A.useCssStyles=false;isc.A.baseStyle="progressbar";isc.A.progressStyle="progressbarProgress";isc.A=isc.Progressbar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.init=function isc_Progressbar_init(){if(this.vertical){this.width=this.breadth;this.height=this.length;this.items=this.verticalItems}else{this.width=this.length
this.height=this.breadth
this.items=this.horizontalItems}
if(this.useCssStyles){this.items=this.defaultItems?this.defaultItems.duplicate():[{name:"blank1",size:0,baseStyle:this.progressStyle},{name:"blank2",size:0,baseStyle:this.baseStyle}
]}
this.Super("init",arguments)}
,isc.A.resizeImages=function isc_Progressbar_resizeImages(){var _1=this.getLength(),_2=this.items,_3=this.$5x=[],_4=this.percentDone
;if(this.useCssStyles){_3[0]=Math.ceil(_1*_4/100);_3[1]=Math.floor(_1*(100-_4)/100)}else{if(this.vertical){_3[0]=(_4<100?_2[0].size:0);_3[2]=(_4<100?_2[2].size:0);_3[3]=(_4>0?_2[3].size:0);_3[5]=(_4>0?_2[5].size:0)}else{_3[0]=(_4>0?_2[0].size:0);_3[2]=(_4>0?_2[2].size:0);_3[3]=(_4<100?_2[3].size:0);_3[5]=(_4<100?_2[5].size:0)}
_1-=_3[0]+_3[2]+_3[3]+_3[5];if(this.vertical){_3[4]=Math.ceil(_1*_4/100);_3[1]=Math.floor(_1*(100-_4)/100)}else{_3[1]=Math.ceil(_1*_4/100);_3[4]=Math.floor(_1*(100-_4)/100)}
}}
,isc.A.setPercentDone=function isc_Progressbar_setPercentDone(_1){if(this.percentDone==_1)return;_1=Math.min(100,(Math.max(0,_1)));this.percentDone=_1;if(this.isDrawn()){if(isc.Canvas.ariaEnabled())this.setAriaState("valuenow",_1);this.markForRedraw("percentDone updated")}
this.percentChanged()}
,isc.A.percentChanged=function isc_Progressbar_percentChanged(){}
,isc.A.getLength=function isc_Progressbar_getLength(){return this.vertical?this.getHeight():this.getWidth()}
,isc.A.getBreadth=function isc_Progressbar_getBreadth(){return this.vertical?this.getWidth():this.getHeight()}
,isc.A.setLength=function isc_Progressbar_setLength(_1){this.length=_1;this.vertical?this.setHeight(_1):this.setWidth(_1)}
,isc.A.setBreadth=function isc_Progressbar_setBreadth(_1){this.breadth=_1;this.vertical?this.setWidth(_1):this.setHeight(_1)}
);isc.B._maxIndex=isc.C+8;isc.ClassFactory.defineClass("Rangebar","Progressbar");isc.A=isc.Rangebar.getPrototype();isc.A.value=0;isc.A.minValue=0;isc.A.maxValue=99;isc.A.title="";isc.A.vertical=true;isc.A.showTitle=true;isc.A.showRange=true;isc.A.showValue=true;isc.A.allLabelDefaults={width:50,height:20,spacing:5
};isc.A.titleLabelDefaults={width:100,className:"rangebarTitle"
};isc.A.rangeLabelDefaults={className:"rangebarRange"
};isc.A.valueLabelDefaults={className:"rangebarValue"
};isc.A.forceOverrides={$jo:false,autoDraw:false
};isc.A.flipValues=false;isc.A=isc.Rangebar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.initWidget=function isc_Rangebar_initWidget(){this.Super(this.$oc,arguments);this.titleLabelDefaults=isc.addProperties({},this.allLabelDefaults,this.titleLabelDefaults);this.valueLabelDefaults=isc.addProperties({},this.allLabelDefaults,this.valueLabelDefaults);this.rangeLabelDefaults=isc.addProperties({},this.allLabelDefaults,this.rangeLabelDefaults);if(this.showRange){this.$50=this.addPeer(this.$51("min"));this.$52=this.addPeer(this.$51("max"))}
if(this.showValue)this._valueLabel=this.addPeer(this.$53());if(this.showTitle)this._titleLabel=this.addPeer(this.$54());this.setValue(this.value)}
,isc.A.resized=function isc_Rangebar_resized(_1,_2){this.$55()}
,isc.A.$55=function isc_Rangebar__adjustPeerPositions(){if(this.showRange&&this.$50&&this.$52){var _1=this.$56("min");var _2=this.$56("max");this.$50.moveTo(_1.left,_1.top);this.$52.moveTo(_2.left,_2.top)}
if(this.showValue&&this._valueLabel){var _3=this.$57();this._valueLabel.moveTo(_3.left,_3.top)}
if(this.showTitle&&this._titleLabel){var _3=this.$58();this._titleLabel.moveTo(_3.left,_3.top)}}
,isc.A.$51=function isc_Rangebar__createRangeLabel(_1){var _2=this.$56(_1);return isc.Label.newInstance({ID:this.getID()+"_"+_1+"Label",contents:(_1=="min"?(this.minValueLabel?this.minValueLabel:this.minValue):(this.maxValueLabel?this.maxValueLabel:this.maxValue))
},this.rangeLabelDefaults,_2,this.forceOverrides)}
,isc.A.$56=function isc_Rangebar__computeRangeLabelProperties(_1){var _2={},_3=this.rangeLabelDefaults,_4=((_1=="min"&&!this.flipValues)||(_1="max"&&this.flipValues));if(this.vertical){_2.left=this.left+this.width+_3.spacing,_2.align=isc.Canvas.LEFT;if(_4){_2.top=this.getTop()+this.getHeight()-_3.height;_2.valign=isc.Canvas.BOTTOM}else{_2.top=this.getTop();_2.valign=isc.Canvas.TOP}
}else{_2.top=this.getTop()+this.getHeight()+_3.spacing,_2.valign=isc.Canvas.TOP;if(_4){_2.left=this.getLeft();_2.align=isc.Canvas.LEFT}else{_2.left=this.getLeft()+this.getWidth()-_3.width;_2.align=isc.Canvas.RIGHT}
}
return _2}
,isc.A.$54=function isc_Rangebar__createTitleLabel(){var _1=this.$58();return isc.Label.newInstance({ID:this.getID()+"_titleLabel",contents:this.title
},this.titleLabelDefaults,_1,this.forceOverrides)}
,isc.A.$58=function isc_Rangebar__computeTitleLabelProperties(){var _1={};var _2=this.titleLabelDefaults;if(this.vertical){_1.left=this.left+this.width/2-_2.width/2;_1.top=this.top-_2.height-_2.spacing;_1.align=isc.Canvas.CENTER}else{_1.left=this.left-_2.width-_2.spacing;_1.top=this.top+this.getHeight()/2-_2.height/2;_1.align=isc.Canvas.RIGHT}
return _1}
,isc.A.$53=function isc_Rangebar__createValueLabel(){var _1=this.$57();return isc.Label.newInstance({ID:this.getID()+"_valueLabel",contents:this.value,mouseUp:"return false;",observes:[{source:this,message:"valueChanged",action:"observer.setContents(this.getValue())"}]
},this.valueLabelDefaults,_1,this.forceOverrides)}
,isc.A.$57=function isc_Rangebar__computeValueLabelProperties(){var _1={};var _2=this.valueLabelDefaults;if(this.vertical){_1.left=this.left-_2.width-_2.spacing;_1.top=this.top+this.getHeight()/2-_2.height/2;_1.align=isc.Canvas.RIGHT;_1.valign=isc.Canvas.CENTER}else{_1.left=this.left+this.width/2-_2.width/2;_1.top=this.top-_2.height-_2.spacing;_1.align=isc.Canvas.CENTER;_1.valign=isc.Canvas.BOTTOM}
return _1}
,isc.A.getValue=function isc_Rangebar_getValue(){return this.value}
,isc.A.setValue=function isc_Rangebar_setValue(_1){if(this.value==_1)return;if(_1>this.maxValue)_1=this.maxValue;else if(_1<this.minValue)_1=this.minValue;this.value=_1;this.percentDone=100*(this.value-this.minValue)/(this.maxValue-this.minValue);this.markForRedraw();this.valueChanged()}
,isc.A.valueChanged=function isc_Rangebar_valueChanged(){}
);isc.B._maxIndex=isc.C+12;isc.ClassFactory.defineClass("Toolbar","Layout");isc.A=isc.Toolbar.getPrototype();isc.A.vertical=false;isc.A.overflow=isc.Canvas.HIDDEN;isc.A.height=20;isc.A.buttonConstructor="Button";isc.A.canReorderItems=false;isc.A.canResizeItems=false;isc.A.canRemoveItems=false;isc.A.reorderOnDrop=true;isc.A.tabWithinToolbar=true;isc.A.allowButtonReselect=false;isc.A.overrideDefaultButtonSizes=true;isc.A.buttonDefaults={click:function(){this.Super("click",arguments);this.parentElement.itemClick(this,this.parentElement.getButtonNumber(this))
},doubleClick:function(){this.Super("doubleClick",arguments);this.parentElement.itemDoubleClick(this,this.parentElement.getButtonNumber(this))
},setSelected:function(){var _1=this.isSelected();this.Super("setSelected",arguments);if(this.parentElement&&(this.parentElement.allowButtonReselect||_1!=this.isSelected()))
{if(this.isSelected())this.parentElement.buttonSelected(this);else this.parentElement.buttonDeselected(this)}
},dragAppearance:isc.EventHandler.NONE,setTabIndex:function(_1){this.Super("setTabIndex",arguments);this.$59=false},setAccessKey:function(_1,_2){if(!_2)this.$6a=null;this.Super("setAccessKey",[_1])},focusChanged:function(_1){if(this.parentElement==null){return}
if(this.hasFocus&&this.parentElement.$6b){this.parentElement.$6b(this)
}
}
};isc.A=isc.Toolbar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.initWidget=function isc_Toolbar_initWidget(){this.Super("initWidget",arguments);if(this.createButtonsOnInit)this.setButtons()}
,isc.A.draw=function isc_Toolbar_draw(_1,_2,_3,_4){if(isc.$cv)arguments.$cw=this;if(!this.readyToDraw())return this;if(!this.$6c)this.setButtons();this.invokeSuper(isc.Toolbar,"draw",_1,_2,_3,_4)}
,isc.A.keyPress=function isc_Toolbar_keyPress(){var _1=this.ns.EH.lastEvent.keyName;if(!this.tabWithinToolbar){if((this.vertical&&_1=="Arrow_Up")||(!this.vertical&&_1=="Arrow_Left")){this.$6d(false);return false}else if((this.vertical&&_1=="Arrow_Down")||(!this.vertical&&_1=="Arrow_Right")){this.$6d();return false}
}
return this.Super("keyPress",arguments)}
,isc.A.$6d=function isc_Toolbar__focusInNextButton(_1,_2){_1=(_1!=false);var _3=(_2!=null?_2:this.getFocusButtonIndex());if(_3==null)_3=(_1?-1:this.buttons.length);_3+=_1?1:-1;while(_3>=0&&_3<this.buttons.length){var _4=this.getMembers()[_3];if(_4.$kk()){_4.focus();return true}
_3+=_1?1:-1}
return false}
,isc.A.getFocusButtonIndex=function isc_Toolbar_getFocusButtonIndex(){var _1=this.getButtons(),_2;for(var i=0;i<_1.length;i++){if(_1[i].hasFocus){_2=i;break}
}
return _2}
,isc.A.setFocus=function isc_Toolbar_setFocus(_1){if(!this.$vl())return;var _2=this.getFocusButtonIndex();if(!_1){if(_2!=null&&this.members)this.members[_2].setFocus(false)}else{if(_2!=null)return;if(this.$6g)this.$6g.setFocus(true);else this.$6d()}}
,isc.A.setButtonTabIndex=function isc_Toolbar_setButtonTabIndex(_1,_2){_1.setTabIndex(_2);_1.$59=true}
,isc.A.$6f=function isc_Toolbar__setButtonAccessKey(_1,_2){_1.$6a=true;_1.setAccessKey(_2,true)}
,isc.A.setupButtonFocusProperties=function isc_Toolbar_setupButtonFocusProperties(){var _1=this.$6g;if((!_1||!isc.isA.Canvas(_1)||_1.visibility==isc.Canvas.HIDDEN)&&this.buttons.length>0)
{var _2;for(var i=0;i<this.members.length;i++){if(isc.isA.Canvas(this.members[i])&&this.members[i].visibility!=isc.Canvas.HIDDEN)
{_2=this.members[i];break}
}
this.$6b(_2)
_1=this.$6g}
var _4=this.getButtons();for(var i=0;i<_4.length;i++){var _5=_4[i];if(_5==_1)continue;if(!_5.$59)continue;if(!this.tabWithinToolbar){if(_5.$180j){this.setButtonTabIndex(_5,-1)}
}else{if(_5.tabIndex==-1)_5.clearExplicitTabIndex()}
}}
,isc.A.$6b=function isc_Toolbar__updateFocusButton(_1){if(!_1)return;if(this.$6g==_1){return}
if(_1.accessKey!=this.accessKey&&(_1.accessKey==null||_1.$6a))
{this.$6f(_1,this.accessKey)
}
if(_1.$59&&_1.tabIndex==-1){_1.clearExplicitTabIndex()}
var _2=this.$6g;if(_2!=null&&_2.$59){if(!this.tabWithinToolbar&&_2.$180j){this.setButtonTabIndex(_2,-1)}
if(_2.accessKey!=null&&_2.$6a)
{this.$6f(_2,null)
}
}
this.$6g=_1}
,isc.A.setAccessKey=function isc_Toolbar_setAccessKey(_1){this.Super("setAccessKey",arguments);var _2=this.$6g;if(_2!=null){this.$6g=null;this.$6b(_2)}}
,isc.A.getLength=function isc_Toolbar_getLength(_1,_2,_3,_4){if(this.innerWidth!=null)return this.innerWidth;return this.invokeSuper(isc.Toolbar,"getLength",_1,_2,_3,_4)}
,isc.A.setButtons=function isc_Toolbar_setButtons(_1){this.$6c=true;if(_1)this.buttons=_1;if(this.members==null)this.members=[];var _2=this.members.duplicate();for(var i=0;i<_2.length;i++){var _4=_2[i];if(!this.buttons.contains(_4)){_2[i].destroy()}
}
if(this.buttons==null)this.buttons=[];var _5=[];for(var i=0;i<this.buttons.length;i++){var _6=this.buttons[i];if(!isc.isA.Canvas(_6))_6=this.makeButton(_6);_5[_5.length]=_6;if(isc.isA.StatefulCanvas(_6)){var _7=_6.getActionType();if(_7==isc.StatefulCanvas.RADIO){if(_6.selected)this.lastSelectedButton=_6}
}
}
this.addMembers(_5,0);if(this.canResizeItems)this.setResizeRules();this.setupButtonFocusProperties()}
,isc.A.buttonShouldHiliteAccessKey=function isc_Toolbar_buttonShouldHiliteAccessKey(){if(this.$6a)return false;return this.hiliteAccessKey}
,isc.A.makeButton=function isc_Toolbar_makeButton(_1){var _2=this.overrideDefaultButtonSizes;if(_2||this.vertical)_1.width=_1.width||null;if(_2||!this.vertical)_1.height=_1.height||null;_1.canDrag=this.canReorderItems||this.canDragSelectItems||this.canRemoveItems;_1.canDragResize=(_1.canDragResize!=null?_1.canDragResize&&this.canResizeItems:this.canResizeItems);_1.canAcceptDrop=this.canAcceptDrop;_1.canDrop=this.canRemoveItems;_1.shouldHiliteAccessKey=this.buttonShouldHiliteAccessKey;if(this.tabIndex==-1)_1.tabIndex=-1;_1.$59=(_1.tabIndex==null);return this.$6h(_1,null)}
,isc.A.$6h=function isc_Toolbar__makeItem(_1,_2){var _3=(_1.buttonConstructor
?_1.buttonConstructor
:this.buttonConstructor
)
;_3=this.ns.ClassFactory.getClass(_3,true);var _4=_3.newInstance({autoDraw:false},this.buttonDefaults,this.buttonProperties,_1,_2
);if(!isc.isA.StatefulCanvas(_4))return _4;var _5;if((_4.getActionType()==isc.StatefulCanvas.RADIO&&_4.radioGroup===_5)
||_4.defaultRadioGroup!=null){var _6=_4.defaultRadioGroup!=null?_4.defaultRadioGroup:this.getID();_4.addToRadioGroup(_6)}
return _4}
,isc.A.addButtons=function isc_Toolbar_addButtons(_1,_2){if(_1==null)return;if(!isc.isAn.Array(_1))_1=[_1];if(!this.$6c)this.setButtons();_1.removeEvery(null);var _3;if(isc.isAn.Array(_2)){if(_2.length!=_1.length){this.logWarn("addButtons passed "+_1.length+" buttons with "+_2.length
+" discrete positions specified. Ignoring.");return}
var _4={};for(var i=0;i<_2.length;i++){_4[_2[i]]=_1[i]}
_2.sort(function(_14,_15){return _14-_15});_3=[];var _6={buttons:[],position:_2[0]},_7=0;for(var i=0;i<_2.length;i++){var _8=_2[i],_9=_4[_8];_6.buttons.add(_9);var _10=_2[i+1]
if(_10==null||_10!=_8+1){_3[_7]=_6;_7++
if(_10!=null)_6={buttons:[],position:_10}}
}
for(var i=0;i<_3.length;i++){this.buttons.addListAt(_3[i].buttons,_3[i].position)}
}else{this.buttons.addListAt(_1,_2)}
var _11=this.instantRelayout;this.instantRelayout=false;var _12;if(_3==null){_12=this.$82x(_1);this.addMembers(_12,_2)
}else{for(var i=0;i<_3.length;i++){var _13=this.$82x(_3[i].buttons);this.addMembers(_13,_3[i].position);if(_12==null)_12=_13;else _12.addList(_13)}
}
if(_11){this.instantRelayout=true;if(this.$3n)this.$3n=false;this.reflow("addButtons")}
if(this.canResizeItems)this.setResizeRules();_12.callMethod("show")}
,isc.A.$82x=function isc_Toolbar__createButtonInstances(_1){var _2=[];for(var i=0;i<_1.length;i++){var _4=_1[i],_5=isc.isA.Canvas(_4)?_4:this.makeButton(_4);_2[i]=_5}
return _2}
,isc.A.removeButtons=function isc_Toolbar_removeButtons(_1){if(_1==null)return;if(!isc.isAn.Array(_1))_1=[_1];var _2=[];for(var i=0;i<_1.length;i++){_1[i]=this.buttons[this.getButtonNumber(_1[i])];if(_1[i]==null){this.logWarn("removeButtons(): unable to find button for item number "+i+" in the array passed in.  Skipping this item.");_1.removeItem(i);i-=1;continue}
_2[i]=this.getButton(this.buttons.indexOf(_1[i]))
}
var _4=this.buttons;_4.removeList(_1);this.removeMembers(_2)}
,isc.A.getButton=function isc_Toolbar_getButton(_1){_1=this.getButtonNumber(_1);return this.getMember(_1)}
,isc.A.getButtonNumber=function isc_Toolbar_getButtonNumber(_1){if(isc.isAn.Object(_1)&&!isc.isA.Canvas(_1))return this.buttons.indexOf(_1);return this.getMemberNumber(_1)}
,isc.A.getButtons=function isc_Toolbar_getButtons(){return this.members}
,isc.A.setCanResizeItems=function isc_Toolbar_setCanResizeItems(_1){if(this.canResizeItems==_1)return;this.canResizeItems=_1;var _2=this.getButtons();if(!_2)return;for(var i=0;i<_2.length;i++){var _4=_2[i];if(!_4.origDragResize){_4.origDragResize=_4.canDragResize}
_4.canDragResize=_1&&(_4.origDragResize!=false)}
this.setResizeRules()}
,isc.A.setResizeRules=function isc_Toolbar_setResizeRules(){if(!this.members)return;var _1=this.isRTL();var _2,_3,_4;if(this.vertical){_2={"T":isc.Canvas.ROW_RESIZE,"B":isc.Canvas.ROW_RESIZE};_3=["T","B"];_4=["B"]}else{var _5=_1?isc.Canvas.RTL_COL_RESIZE:isc.Canvas.COL_RESIZE;_2={"L":_5,"R":_5};_3=["L","R"];if(!_1){_4=["R"]}else{_4=["L"]}
}
var _6=false;for(var i=0;i<this.members.length;i++){var _8=this.members[i];if(!_8.canDragResize){_8.resizeFrom=null;_8.edgeCursorMap={};_6=true}else{if(_6||i==0)
{_8.resizeFrom=_4}else{_8.resizeFrom=_3}
_8.edgeCursorMap=_2||{};_6=false}
}}
,isc.A.getSelectedButton=function isc_Toolbar_getSelectedButton(){return this.lastSelectedButton}
,isc.A.selectButton=function isc_Toolbar_selectButton(_1){if(!this.members)return;var _2=this.getButton(_1);if(_2&&isc.isA.StatefulCanvas(_2))_2.select()}
,isc.A.deselectButton=function isc_Toolbar_deselectButton(_1){var _2=this.getButton(_1);if(_2)_2.deselect()}
,isc.A.buttonSelected=function isc_Toolbar_buttonSelected(_1){if(_1.getActionType()==isc.Button.RADIO){this.lastSelectedButton=_1}}
,isc.A.buttonDeselected=function isc_Toolbar_buttonDeselected(_1){}
,isc.A.itemClick=function isc_Toolbar_itemClick(_1,_2){}
,isc.A.itemDoubleClick=function isc_Toolbar_itemDoubleClick(_1,_2){}
,isc.A.getMouseOverButtonIndex=function isc_Toolbar_getMouseOverButtonIndex(){var _1=this.vertical?this.getOffsetY():this.getOffsetX();if(this.isRTL()||this.align==isc.Canvas.RIGHT){var _2=this.getInnerWidth()-this.memberSizes.sum();if(_2>0)_1-=_2}
return this.inWhichPosition(this.memberSizes,_1,this.getTextDirection())}
,isc.A.prepareForDragging=function isc_Toolbar_prepareForDragging(){var _1=this.ns.EH;var _2=_1.lastEvent.target;while(_2.dragTarget){_2=_2.dragTarget}
var _3=_1.dragOperation;if(((this.canResizeItems&&_3=="dragResize")
||(this.canReorderItems&&_3=="drag")
)&&this.members.contains(_2))
{if(_3=="dragResize"){if((this.vertical&&["T","B"].contains(_1.resizeEdge))||(!this.vertical&&["L","R"].contains(_1.resizeEdge)))
{_1.dragOperation="dragResizeMember";return}
}else if(_3=="drag"){_1.dragOperation="dragReorder";return}
}
return this.Super("prepareForDragging",arguments)}
,isc.A.getDropPosition=function isc_Toolbar_getDropPosition(){var _1=this.getMouseOverButtonIndex();var _2=this.ns.EH,_3=(this.reorderStyle=="explorer"||(_2.dropTarget&&_2.dropTarget.parentElement==this));if(_3&&_1>=0){var _4=this.memberSizes[_1],_5=(this.vertical?this.getOffsetY():this.getOffsetX());_5-=this.memberSizes.slice(0,_1).sum();var _6=_1;if(_5>_4/2)_1++}
var _7=this.members.length,_8=(_3?_7:_7-1);var _9=this.dragStartPosition||0,_10=_2.dragTarget&&_2.dragTarget.parentElement==this;if(_1==-2&&this.containsEvent()){_1=_8}
if(_1<0||_1>_8)_1=_9;else if(_10&&this.members[_1]&&this.members[_1].canReorder==false&&(!this.$203u||!this.$203u(_1,_9)))
{_1=_9}
return _1}
,isc.A.dragReorderStart=function isc_Toolbar_dragReorderStart(){var _1=this.ns.EH,_2=_1.dragTarget
;if(_2.canReorder==false)return false;_2.setState(isc.StatefulCanvas.STATE_DOWN);this.dragStartPosition=this.getButtonNumber(_2);return _1.STOP_BUBBLING}
,isc.A.dragReorderMove=function isc_Toolbar_dragReorderMove(){var _1=this.ns.EH,_2=_1.dragTarget,_3=this.dragStartPosition,_4=Math.min(this.getDropPosition(),this.members.length-1);this.dragCurrentPosition=_4;var _5=this.members.duplicate();_5.slide(_3,_4);this.stackMembers(_5,null,false);return _1.STOP_BUBBLING}
,isc.A.dragReorderStop=function isc_Toolbar_dragReorderStop(){var _1=this.ns.EH,_2=_1.dragTarget,_3=this.dragStartPosition,_4=this.dragCurrentPosition;_2.setState(isc.StatefulCanvas.STATE_UP);if(_4==_3)return false;if(this.reorderOnDrop)this.reorderItem(_4,_3);if(this.itemDragReordered)this.itemDragReordered(_3,_4);return _1.STOP_BUBBLING}
,isc.A.dragStop=function isc_Toolbar_dragStop(){var _1=this.ns.EH,_2=_1.dragTarget,_3=this.dragStartPosition;_2.setState(isc.StatefulCanvas.STATE_UP);this.hideDropLine();return _1.STOP_BUBBLING}
,isc.A.reorderItem=function isc_Toolbar_reorderItem(_1,_2){this.reorderItems(_1,_1+1,_2)}
,isc.A.reorderItems=function isc_Toolbar_reorderItems(_1,_2,_3){this.buttons.slideRange(_1,_2,_3);this.reorderMembers(_1,_2,_3);this.setResizeRules()}
,isc.A.dragResizeMemberStart=function isc_Toolbar_dragResizeMemberStart(){var _1=this.ns.EH,_2=_1.dragTarget,_3=this.getButtonNumber(_2),_4=this.isRTL();var _5=false;if((!_4&&_1.resizeEdge=="L")||(_4&&_1.resizeEdge=="R")){_5=true;_3--;_1.resizeEdge=(_4?"L":"R")}else if(_1.resizeEdge=="T"){_5=true;_3--;_1.resizeEdge="B"}
if(_3<0||_3>=this.members.length||_2==null)return false;_1.dragTarget=_2=this.members[_3];_2.$6i=_2.canDrop;_2.canDrop=false;this.$6j=_3;_2.setState(isc.StatefulCanvas.STATE_DOWN);if(_5){var _6=this.members[_3+1];if(_6)_6.setState(isc.StatefulCanvas.STATE_UP)}
return _1.STOP_BUBBLING}
,isc.A.dragResizeMemberMove=function isc_Toolbar_dragResizeMemberMove(){var _1=this.ns.EH,_2=_1.dragTarget;_2.resizeToEvent();_2.redrawIfDirty("dragResize");return _1.STOP_BUBBLING}
,isc.A.dragResizeMemberStop=function isc_Toolbar_dragResizeMemberStop(){var _1=this.ns.EH,_2=_1.dragTarget;_2.canDrop=_2.$6i;_2.setState(isc.StatefulCanvas.STATE_UP);_2.resizeToEvent();var _3=(this.vertical?_2.getHeight():_2.getWidth());this.resizeItem(this.$6j,_3);if(this.itemDragResized)this.itemDragResized(this.$6j,_3);return _1.STOP_BUBBLING}
,isc.A.resizeItem=function isc_Toolbar_resizeItem(_1,_2){var _3=this.members[_1];if(this.vertical)_3.setHeight(_2);else _3.setWidth(_2)}
);isc.B._maxIndex=isc.C+44;isc.Toolbar.registerStringMethods({itemClick:"item,itemNum",itemDragResized:"itemNum,newSize",itemDragReordered:"itemNum,newPosition"});isc.defineClass("ImgButton","Img");isc.A=isc.ImgButton.getPrototype();isc.A.clipTitle=true;isc.A.showClippedTitleOnHover=false;isc.A.$115g=true;isc.A.baseStyle="imgButton";isc.A.showDown=true;isc.A.showFocused=true;isc.A.showRollOver=true;isc.A.showTitle=false;isc.A.cursor=isc.Button.$b4.cursor;isc.A.src="[SKIN]/ImgButton/button.png";isc.A.canFocus=true;isc.A.overflow=isc.Canvas.HIDDEN;isc.A=isc.ImgButton.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.getCanHover=function isc_ImgButton_getCanHover(_1,_2,_3){return this.$115g||this.invokeSuper(isc.ImgButton,"getCanHover",_1,_2,_3)}
,isc.A.titleClipped=function isc_ImgButton_titleClipped(){return(this.label==null?false:this.label.titleClipped())}
,isc.A.defaultTitleHoverHTML=function isc_ImgButton_defaultTitleHoverHTML(){return(this.label==null?null:this.label.defaultTitleHoverHTML())}
,isc.A.titleHoverHTML=function isc_ImgButton_titleHoverHTML(_1){return _1}
,isc.A.handleHover=function isc_ImgButton_handleHover(_1,_2,_3){if(this.canHover==null&&this.prompt)return this.invokeSuper(isc.ImgButton,"handleHover",_1,_2,_3);if(!this.showClippedTitleOnHover||!this.titleClipped()){if(this.canHover)return this.invokeSuper(isc.ImgButton,"handleHover",_1,_2,_3);else return}
if(this.titleHover&&this.titleHover()==false)return;var _4=this.titleHoverHTML(this.defaultTitleHoverHTML());if(_4!=null&&!isc.isAn.emptyString(_4)){var _5=this.$wc();isc.Hover.show(_4,_5,null,this)}}
);isc.B._maxIndex=isc.C+5;isc.ImgButton.registerStringMethods({titleHover:""});isc.defineClass("StretchImgButton","StretchImg");isc.A=isc.StretchImgButton.getPrototype();isc.A.clipTitle=true;isc.A.showClippedTitleOnHover=false;isc.A.$115g=true;isc.A.useEventParts=true;isc.A.baseStyle="stretchImgButton";isc.A.showDown=true;isc.A.showFocused=true;isc.A.showRollOver=true;isc.A.showTitle=true;isc.A.hiliteAccessKey=true;isc.A.src="[SKIN]/button/button.png";isc.A.vertical=false;isc.A.capSize=12;isc.A.autoFitDirection="horizontal";isc.A.cursor=isc.Button.$b4.cursor;isc.A.canFocus=true;isc.A=isc.StretchImgButton.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.getCanHover=function isc_StretchImgButton_getCanHover(_1,_2,_3){return this.$115g||this.invokeSuper(isc.StretchImgButton,"getCanHover",_1,_2,_3)}
,isc.A.titleClipped=function isc_StretchImgButton_titleClipped(){return(this.label==null?false:this.label.titleClipped())}
,isc.A.defaultTitleHoverHTML=function isc_StretchImgButton_defaultTitleHoverHTML(){return(this.label==null?null:this.label.defaultTitleHoverHTML())}
,isc.A.titleHoverHTML=function isc_StretchImgButton_titleHoverHTML(_1){return _1}
,isc.A.handleHover=function isc_StretchImgButton_handleHover(_1,_2,_3){if(this.canHover==null&&this.prompt)return this.invokeSuper(isc.StretchImgButton,"handleHover",_1,_2,_3);if(!this.showClippedTitleOnHover||!this.titleClipped()){if(this.canHover)return this.invokeSuper(isc.StretchImgButton,"handleHover",_1,_2,_3);else return}
if(this.titleHover&&this.titleHover()==false)return;var _4=this.titleHoverHTML(this.defaultTitleHoverHTML());if(_4!=null&&!isc.isAn.emptyString(_4)){var _5=this.$wc();isc.Hover.show(_4,_5,null,this)}}
);isc.B._maxIndex=isc.C+5;isc.StretchImgButton.registerStringMethods({iconClick:"",titleHover:""})
isc.A=isc.Notify;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$204o="message";isc.A.$204p="warn";isc.A.$204q="error";isc.A.settings={};isc.A.typeState={};isc.A.$204r=["multiMessageMode","stackDirection","maxStackSize","maxStackDismissMode","stackSpacing","repositionMethod"
];isc.B.push(isc.A.$204u=function isc_c_Notify__initializeSettings(){this.$2159=true;this.configureMessages(this.$204o,this.$207s(this.$204o));this.configureMessages(this.$204p,this.$207s(this.$204p));this.configureMessages(this.$204q,this.$207s(this.$204q))}
,isc.A.addMessage=function isc_c_Notify_addMessage(_1,_2,_3,_4){if(!_1&&!this.$204v(_2)){this.logWarn("addMessage(): you must either provide valid contents for the message, or at least one NotifyAction with a title","notify");return}
if(!_3)_3=this.$204o;var _5=this.settings[_3];if(!_5){this.configureMessages(_3);_5=this.settings[_3]}
_4=this.$204w(_4,_5);var _6=this.typeState[_3];if(!_6){_6=this.typeState[_3]={notifyType:_3,pendingQueue:[],liveMessages:[],dismissQueue:[],replaceQueue:[]
}}
var _7={contents:_1,actions:_2,settings:_4
};var _8=this.$204x(_6,_4);if(_8){this.$204y(_6,_7);if(this.logIsDebugEnabled("notify")){this.logDebug("addMessage(): showing message with notifyType: "+_3+" and contents: '"+_1+"'","notify")}
}else{_6.pendingQueue.add(_7);if(this.logIsInfoEnabled("notify")){this.logInfo("addMessage(): queuing message with notifyType: "+_3+" and contents: '"+_1+"'","notify")}
}
return{notifyType:_3,messageState:_7}}
,isc.A.$204y=function isc_c_Notify__addMessage(_1,_2){_1.liveMessages.add(_2);this.$204z(_1,_2);var _3,_4=_2.settings,_5=this.$2040(_1,_2)
;if(_4.multiMessageMode=="stack"){if(_1.stack==null){var _6=_4.stackDirection,_7=_6=="up"||_6=="down",_8=_7?isc.VStack:isc.HStack
;_1.stack=_8.create({left:_5[0],top:_5[1],width:1,height:1,$2485:"$2481",instantRelayout:true,autoDraw:true,membersMargin:_4.stackSpacing,$2041:function(_13,_14){this.setProperties({animateMembers:true,animateMemberTime:_14,animateMemberEffect:_13
})},$2042:function(){this.setProperty("animateMembers",false)}
});if(!_1.stack.isDrawn())_1.stack.draw();_1.stack.bringToFront();_1.placeholder=isc.Canvas.create({opacity:0,top:-1000,$2485:"$2481"
})}else{var _9=_1.stack;if(!_9.members.length){_9.moveTo(_5[0],_5[1])}
}
_3=this.$2043(_1,_2,false);_5=this.$2044(_1,_2,_3)}
var _9=_1.stack,_10=_2.label,_11=_1.liveMessages;var _12=_4.appearMethod;if(this.logIsDebugEnabled("notify")){this.logDebug("addMessage(): starting message animation: "+_12+" to/at coordinates: "+_5+" and stack slide to coordinates: "+_3+" for notifyType: "+_1.notifyType+" with contents: '"+_2.contents+"'","notify")}
switch(_12){case"fade":if(_11.length>1){this.$2045(_1,_2,_5,_3)}else{this.$2046(_1,_2,_5,_3)}
break;case"slide":this.$2047(_1,_2,_5,_3);break;case"instant":default:if(_9)this.$2048(_1,_2,_3);else _10.moveTo(_5[0],_5[1]);break}
if(_4.duration)this.$2049(_1,_2)}
,isc.A.$204w=function isc_c_Notify__filterCustomSettings(_1,_2){if(!_1)return _2;var _3,_4=this.$204r,_5=isc.addProperties({},_1)
;for(var i=0;i<_4.length;i++){var _7=_4[i];if(_7 in _5){delete _5[_7];_3=true}
}
if(_3){this.logWarn("addMessage(): you cannot change stack properties in a call to addMessage() - they can only be set through configureMessages()","notify")}
if(this.$2156(_5,_2)){var _8=_5.messagePriority,_9=this.$2157(_8);for(var _7 in this.$207v){if(!(_7 in _5))_5[_7]=_9[_7]}
}
return isc.addDefaults(_5,_2)}
,isc.A.$204v=function isc_c_Notify__hasTitledActions(_1){if(!_1)return false;for(var i=0;i<_1.length;i++){if(_1[i].title)return true}
return false}
,isc.A.dismissMessage=function isc_c_Notify_dismissMessage(_1){if(this.$205v(_1)){var _2=this.typeState[_1.notifyType];this.$204t(_2,_1.messageState)}else if(isc.isA.String(_1)){var _2=this.typeState[_1];if(_2){if(this.logIsInfoEnabled("notify")){this.logInfo("dismissMessage(): dismissing all messages for notifyType: "+_2.notifyType,"notify")}
var _3=_2.pendingQueue.duplicate();for(var i=0;i<_3.length;i++){this.$204t(_2,_3[i])}
var _5=_2.liveMessages.duplicate();for(var i=0;i<_5.length;i++){this.$204t(_2,_5[i])}
}
}else{this.logWarn("dismissMessage(): "+_1+" is neither a valid messageID nor a valid notifyType","notify")}
}
,isc.A.$204t=function isc_c_Notify__dismissMessage(_1,_2){var _3=_1.notifyType,_4=_1.pendingQueue,_5=_1.liveMessages,_6=_1.dismissQueue,_7=_2.contents
;if(!this.$205w(_1,_2)){this.logWarn("dismissMessage(): can't dismiss messageID with notifyType: "+_3+"and contents: ;"+_7+"' as it can't be found","notify");return}
if(_4.contains(_2)){if(this.logIsDebugEnabled("notify")){this.logDebug("dismissMessage(): removing message with notifyType: "+_3+" and contents: '"+_7+"' from the 'pending add' message queue","notify")}
_4.remove(_2);return true}
if(_6.contains(_2)||_1.opMessage==_2&&_2.dismissed)
{if(this.logIsInfoEnabled("notify")){this.logInfo("dismissMessage(): message with notifyType: "+_3+" and contents: '"+_7+"' has already been dismissed or queued for dismissal","notify")}
return false}
if(_1.op!=null){if(this.logIsInfoEnabled("notify")){this.logInfo("dismissMessage(): queuing message with notifyType: "+_3+" and contents: '"+_7+"' for dismissal","notify")}
_6.add(_2);return false}
if(_2.dismissEvent){isc.Timer.clear(_2.dismissEvent);_2.dismissEvent=null}
_2.dismissed=true;var _8,_9=_1.stack,_10=_2.label,_11=_2.settings
;if(_9)_8=this.$2043(_1,_2,true);var _12=_11.disappearMethod;if(this.logIsDebugEnabled("notify")){var _13=[_10.getPageLeft(),_10.getPageTop()];this.logDebug("dismissMessage(): starting message animation: "+_12+" from/at coordinates: "+_13+" and stack slide to coordinates: "+_8+" for notifyType: "+_3+" with contents: '"+_7+"'","notify")}
switch(_12){case"fade":this.$205q(_1,_2,_8);return false;case"slide":this.$205o(_1,_2,_8);return false;case"instant":default:_1.liveMessages.remove(_2);if(_9){_9.moveTo(_8[0],_8[1]);_9.removeMember(_10)}
if(_10)_10.destroy();return true}
}
,isc.A.$2049=function isc_c_Notify__scheduleMessageDismissal(_1,_2){var _3=_2.settings,_4=_3.duration
;if(_3.stackPersistence=="reset"){var _5=_1.liveMessages,_6=_1.dismissQueue,_7=isc.timeStamp()+_4
;for(var i=0;i<_5.length-1;i++){var _9=_5[i].dismissEvent;if(_9&&!_6.contains(_5[i])&&isc.Timer.getTimeoutFireTime(_9)<_7)
{isc.Timer.clear(_9);var _10=_5[i];_10.dismissEvent=isc.Timer.setTimeout(function(){isc.Notify.$204t(_1,_10)},_4-_5.length+i+1,null,null,true
);if(this.logIsInfoEnabled("notify")){this.logInfo("addMessage(): reset message with notifyType: "+_1.notifyType+" and contents: '"+_10.contents+"' to auto-dismiss after "+_4+"ms to match new message's duration","notify")}
}
}
}
_2.dismissEvent=isc.Timer.setTimeout(function(){isc.Notify.$204t(_1,_2)},_4,null,null,true)}
,isc.A.$205v=function isc_c_Notify__isValidMessageID(_1){if(_1==null)return false;var _2=_1.notifyType;return _2!=null&&this.typeState[_2]&&_1.messageState}
,isc.A.canDismissMessage=function isc_c_Notify_canDismissMessage(_1){if(this.$205v(_1)){var _2=this.typeState[_1.notifyType];return this.$205w(_2,_1.messageState)}
isc.logWarn("canDismissMessage(): "+_1+" isn't a valid messageID","notify");return false}
,isc.A.$205w=function isc_c_Notify__canDismissMessage(_1,_2){return _1.pendingQueue.contains(_2)||_1.liveMessages.contains(_2)||_1.dismissQueue.contains(_2)}
,isc.A.$205x=function isc_c_Notify__destroyMessages(_1){var _2=this.settings[_1],_3=this.typeState[_1];var _4=_3.liveMessages;for(var i=0;i<_4.length;i++){var _6=_4[i],_7=_6.label;if(_7)_7.destroy();var _8=_6.dismissEvent;if(_8)isc.Timer.clear(_8)}
var _9=_3.stack;if(_9)_9.destroy();delete this.typeState[_1]}
,isc.A.$2575=function isc_c_Notify__destroyAllMessages(){for(var _1 in this.typeState){this.$205x(_1)}
}
,isc.A.configureMessages=function isc_c_Notify_configureMessages(_1,_2){if(!this.$2159)this.$204u();if(!_1)_1=this.$204o;if(this.typeState[_1]){if(this.logIsInfoEnabled("notify")){this.logInfo("configureMessages(): destroying all state and widgets associated with the current configuration of notifyType: "+_1,"notify")}
this.$205x(_1)}
var _3=this.settings[_1];if(_3)isc.addProperties(_3,_2);else this.settings[_1]=this.$207s(_1,_2);this.logInfo("configureMessages(): Changed settings for NotifyType: "+_1,"notify")}
,isc.A.configureDefaultSettings=function isc_c_Notify_configureDefaultSettings(_1){var _2=this.commonDefaults,_3=this.$207v;for(var _4 in _1){var _5=_4 in _3?_3:_2;_5[_4]=_1[_4]}
this.logInfo("configureDefaultSettings(): Changed global defaults for new NotifyTypes","notify")}
,isc.A.setMessageContents=function isc_c_Notify_setMessageContents(_1,_2,_3){if(!this.$205v(_1)){this.logWarn("setMessageContents(): can't set contents - invalid messageID","notify");return}
var _4=_1.messageState,_5=this.typeState[_1.notifyType]
;if(!this.$205w(_5,_4)){this.logInfo("setMessageContents(): that message was dismissed - nothing to do","notify");return}
var _6;if(_2==null)_2=_4.contents;if(_3===_6)_3=_4.actions;if(!_2&!this.$204v(_3)){this.logWarn("setMessageContents(): you must either provide valid contents for the message, or at least one NotifyAction with a title","notify");return}
_4.contents=_2;_4.actions=_3;if(this.logIsDebugEnabled("notify")){this.logDebug("setMessageContents(): updating message with notifyType: "+_1.notifyType+" to have contents: '"+_2+"'","notify")}
if(!_4.label){if(this.logIsDebugEnabled("notify")){this.logDebug("setMessageContents(): no label found - skipping widget update","notify")}
return}
if(_3&&_3.length){var _7=this.$205d(_4);if(_7)_2=_2?_2+_7:_7}
if(_5.op!=null){var _8=_5.replaceQueue;if(!_8.contains(_4)){_8.add(_4)}
_4.$216m=_2;return}
this.$216n(_5,_4,_2)}
,isc.A.$216n=function isc_c_Notify__setMessageContents(_1,_2,_3){if(!this.$205w(_1,_2)){this.logInfo("setMessageContents(): that message was dismissed - nothing to do","notify");return}
var _4=_2.label,_5=_2.settings;var _6=this.$216o(_5);if(_6){this.$216p=isc.Page.getScrollWidth();this.$216q=isc.Page.getScrollHeight()}
_4.setContents(_3);this.$2158(_5,_4);_4.redraw("contents changed");_2.width=_4.getVisibleWidth();_2.height=_4.getVisibleHeight();this.$216r(_1,_6||_2.$216m);if(_6)delete this.$216p,delete this.$216q}
,isc.A.$216s=function isc_c_Notify__applyContentsToMessages(_1){var _2=_1.replaceQueue;for(var i=0;i<_2.length;i++){var _4=_2[i];this.$216n(_1,_4,_4.$216m);delete _4.$216m}
_2.length=0}
,isc.A.$216o=function isc_c_Notify__hasViewportDependentAlignment(_1){if(_1.positionCanvas)return false;var _2=_1.position;return _2?_2.indexOf("B")>=0||_2.indexOf("R")>=0:false}
,isc.A.setMessageActions=function isc_c_Notify_setMessageActions(_1,_2){this.setMessageContents(_1,null,_2)}
,isc.A.messageHasActions=function isc_c_Notify_messageHasActions(_1){if(this.$205v(_1)){var _2=_1.messageState,_3=_2?_2.actions:null;return _3&&_3.length>0}
}
,isc.A.$204x=function isc_c_Notify__prepareForNewMessage(_1,_2){var _3=_1.liveMessages;if(_3.length==0||_2.multiMessageMode=="stack"&&_3.length<_2.maxStackSize)
{return _1.op==null}
var _4=_1.opMessage,_5=_1.dismissQueue
;if(_5.length>0||_4&&_4.dismissed)return false;var _6=this.$2064(_1,_2);return this.$204t(_1,_6)}
,isc.A.$2064=function isc_c_Notify__getLeastImportantMessage(_1,_2){var _3=_1.liveMessages;if(_3.length==1)return _3[0];var _4=0;for(var i=0;i<_3.length;i++){var _6=_3[i].settings;if(_4<_6.messagePriority){_4=_6.messagePriority}
}
_3=_3.filter(function(_11){return _11.settings.messagePriority==_4});if(_2.maxStackDismissMode=="countdown"&&_3.length>1){var _7,_8;for(var i=_3.length-1;i>=0;i--){var _9=_3[i].dismissEvent;if(!_9)continue;var _10=isc.Timer.getTimeoutFireTime(_9);if(_7==null||_10<_7){_7=_10;_8=i}
}
if(_8!=null)return _3[_8]}
return _3[0]}
,isc.A.$205b=function isc_c_Notify__processMessageQueue(_1){var _2=_1.dismissQueue;while(_2.length>0&&_1.op==null){this.$204t(_1,_2.removeAt(0))}
var _3=_1.pendingQueue;while(_3.length>0&&this.$204x(_1,_3[0].settings))
{this.$204y(_1,_3.removeAt(0))}
}
,isc.A.$205c=function isc_c_Notify__completeMessageHandling(_1,_2,_3,_4){if(_4){var _5=_1.stack,_6=_2.label,_7=_1.liveMessages
;if(_6)_6.destroy();_7.remove(_2);if(_5&&!_7.length){}
}
this.$205b(_1)}
,isc.A.$204z=function isc_c_Notify__createMessageLabel(_1,_2){var _3=_2.actions,_4=_2.settings,_5=_2.contents,_6=_1.notifyType
;var _7=_4.styleName,_8=_4.messageIcon,_9=_4.messageIconOrientation
;var _10=_2.label=isc.NotifyLabel.create(_4.labelProperties,{contents:_5,notifyType:_6,messageState:_2,styleName:_7,animateShowTime:_4.fadeInDuration,animateHideTime:_4.fadeOutDuration
},_4.zIndex?{zIndex:_4.zIndex}:null,_8?{icon:_8}:null,_9?{iconAlign:_9,iconOrientation:_9}:null,_4.messageIconSpacing?{iconSpacing:_4.messageIconSpacing}:null,_4.messageIconWidth?{iconWidth:_4.messageIconWidth}:null,_4.messageIconHeight?{iconHeight:_4.messageIconHeight}:null);if(_3&&_3.length){var _11=this.$205d(_2);if(_11)_5=_5?_5+_11:_11;_10.setContents(_5)}
_10.bringToFront();_10.$35z=_10.getWidth();this.$2158(_4,_10);_10.draw();_2.width=_10.getVisibleWidth();_2.height=_10.getVisibleHeight()}
,isc.A.$2158=function isc_c_Notify__autoFitMessageContents(_1,_2){if(!_1.autoFitWidth)return;if(_2.wrap==false){this.logWarn("addMessage(): autoFitWidth:true specified in conjunction with wrap:false.  These settings are usually not intended to be used in conjunction as autoFitWidth is specifically intended to allow text to wrap when autoFitMaxWidth would otherwise be exceeded.","notify")}
var _3=_2.contents,_4=_2.$35z,_5=isc.Hover.$2053(_1,_2,_3)
;if(_5>_4){if(this.logIsDebugEnabled("notify")){this.logDebug("addMessage(): message shown with autoFitWidth enabled. It will expand from specified width:"+_4+" to content width:"+_5,"notify")}
_2.setWidth(_5)}
}
,isc.A.$205d=function isc_c_Notify__getActionHTML(_1){var _2=_1.label,_3=_1.actions,_4=_1.settings,_5=!!_1.contents,_6=_4.actionStyleName
;var _7=isc.StringBuffer.create();for(var i=0;i<_3.length;i++){var _9=_3[i],_10=_9.title;if(_10){if(_5)_7.append(_9.separator||_4.actionSeparator);if(_9.wholeMessage)_7.append(_10);else{_7.append("<span eventpart='action' id='",_2.getID(),"_action_",i,"' class='",_6,"'>",_10,"</span>")}
_5=true}
}
return _7.toString()}
,isc.A.$2040=function isc_c_Notify__getMessageCoords(_1,_2){var _3=_2.settings;if(_3.x!=null&&_3.y!=null)return[_3.x,_3.y];var _4=_2.label,_5=_3.positionCanvas
;var _6=_3.position;if(!_6){if(_5)_6="C";else{_6=_3.slideInOrigin||_3.slideOutOrigin;if(!_6||!_6.match(/[TBRLC]/))_6="L"}
}
return this.$205e(_1,_2,_6,_5)}
,isc.A.$2043=function isc_c_Notify__getStackCoords(_1,_2,_3){var _4=_1.liveMessages.last(),_5=_4.settings;if(_5.x!=null&&_5.y!=null){return[_5.x,_5.y]}
var _6=_5.positionCanvas;var _7=_5.position;if(!_7){if(_6)_7="C";else{var _8=_2.settings;_7=_8.slideInOrigin||_8.slideOutOrigin;if(!_7||!_7.match(/[TBRLC]/))_7="L"}
}
return this.$205e(_1,_2,_7,_6,_3)}
,isc.A.$205f=function isc_c_Notify__getSlideOriginCoords(_1,_2,_3,_4){var _5=_2.label,_6=_2.settings,_7=_4?_6.slideInOrigin:_6.slideOutOrigin
;var _8=_3?_3[0]:_5.getPageLeft(),_9=_3?_3[1]:_5.getPageTop()
;var _10=_2.nearest||this.$205g(_1,_2,_8,_9)
;if(!_7||!_7.match(/[TBRL]/)){if(_4&&!_6.defaultSlideOutToNearest){_2.nearest=_10}
_7=_10}
return this.$205e(_1,_2,_7,null,null,_8,_9)}
,isc.A.$205e=function isc_c_Notify__getPositionCoords(_1,_2,_3,_4,_5,_6,_7){var _8,_9,_10,_11
;if(_4){_8=_4.getPageLeft();_9=_4.getPageTop();_10=_4.getVisibleWidth();_11=_4.getVisibleHeight()}else{_8=_9=0;_10=this.$216p||isc.Page.getScrollWidth();_11=this.$216q||isc.Page.getScrollHeight()}
var _12=_5!=null,_13=_6!=null&&_7!=null
;var _14=_5?_1.liveMessages.last():_2,_15=_14.settings,_16=_14.width,_17=_14.height,_18=0,_19=0
;if(_12){var _20=this.$205h(_1,_5?_2:null);switch(_15.stackDirection){case"down":case"right":switch(_3){case"BR":_17=_20[1];_16=_20[0];case"B":case"BL":_17=_20[1];break;case"R":case"TR":_16=_20[0];break;default:case"T":case"L":case"C":case"TL":break}
break;case"up":switch(_3){case"R":case"BR":_16=_20[0];case"B":case"L":case"C":case"BL":_19=_17-_20[1];break;case"TR":_16=_20[0];case"T":case"TL":_17=_20[1];break}
break;case"left":switch(_3){case"B":case"BR":_17=_20[1];case"R":case"C":case"T":case"TR":_18=_16-_20[0];break;case"BL":_17=_20[1];case"L":case"TL":_16=_20[0];break}
break}
}
switch(_3){case"L":case"TL":case"BL":_6=_8;if(_13)_6-=_16;break;case"R":case"TR":case"BR":_6=_8+_10;if(!_13)_6-=_16;break;default:if(!_13)_6=Math.floor(_8+_10/2-_16/2);break}
switch(_3){case"T":case"TL":case"TR":_7=_9;if(_13)_7-=_17;break;case"B":case"BL":case"BR":_7=_9+_11;if(!_13)_7-=_17;break;default:if(!_13)_7=Math.floor(_9+_11/2-_17/2);break}
if(_15.leftOffset!=null)_18+=_15.leftOffset;if(_15.topOffset!=null)_19+=_15.topOffset;return[_6+_18,_7+_19]}
,isc.A.$205g=function isc_c_Notify__getNearestEdge(_1,_2,_3,_4){var _5=isc.Page.getScrollWidth(),_6=isc.Page.getScrollHeight()
;var _7=_5-_3-_2.width,_8=_6-_4-_2.height
;if(_2.width===_5){if(_2.settings.position==='TL')return'L';else if(_2.settings.position==='TR')return'R';else if(_2.settings.position==='BL')return'L';else if(_2.settings.position==='BR')return'R';if(_4===0)return"T";if(_8===0)return"B";if(_3===0&&_2.settings.position==='L')return"L";if(_7===0&&_2.settings.position==='R')return"R"}else if(_3<=_7){if(_4<=_8)return _3<=_4?"L":"T";else return _3<=_8?"L":"B"}else{if(_4<=_8)return _7<=_4?"R":"T";else return _7<=_8?"R":"B"}
}
,isc.A.$2044=function isc_c_Notify__getStackedMessageCoords(_1,_2,_3){var _4=_2.settings.stackDirection,_5=_3[0],_6=_3[1];if(_4=="up"||_4=="left"){var _7=this.$205h(_1);if(_4=="up")_6+=_7[1]-_2.height;else _5+=_7[0]-_2.width}
return[_5,_6]}
,isc.A.$205h=function isc_c_Notify__getPostEffectsStackSize(_1,_2){var _3=_1.liveMessages;if(!_3.length)return[1,1];var _4=0,_5=0,_6=_1.stack,_7=_6.vertical
;for(var i=0;i<_3.length;i++){var _9=_3[i];if(_9==_2)continue;var _10=_9.width,_11=_9.height
;if(_7){if(_5>0)_5+=_6.membersMargin;if(_10>_4)_4=_10;_5+=_11}else{if(_4>0)_4+=_6.membersMargin;if(_11>_5)_5=_11;_4+=_10}}
return[_4,_5]}
,isc.A.$205a=function isc_c_Notify__getSlideDuration(_1,_2,_3,_4,_5){if(_5<1)_5=1;var _6=_3-_1,_7=_4-_2,_8=Math.sqrt(_6*_6+_7*_7)
;return Math.ceil(1000*_8/_5)}
,isc.A.$2048=function isc_c_Notify__addLabelToStack(_1,_2,_3,_4){var _5=_1.stack,_6=_2.label,_7=_2.settings.stackDirection,_8=_7=="down"||_7=="right"
;_5.addMember(_6,_8?0:null,null,_4);if(_3)_5.moveTo(_3[0],_3[1])}
,isc.A.$205i=function isc_c_Notify__moveStackForDismiss(_1,_2,_3,_4,_5){var _6=0,_7=_1.stack;if(_7.getLeft()!=_3[0]||_7.getTop()!=_3[1]){var _8=_1.liveMessages,_9=_1.pendingQueue;if(_8.length>1&&_9.length==0){_7.animateMove(_3[0],_3[1],_4,_5);_6++}
}
return _6}
,isc.A.$205j=function isc_c_Notify__moveStackForAdd(_1,_2,_3,_4,_5){var _6=0,_7=_1.stack,_8=_3[0],_9=_3[1],_10=_2.settings,_11=_7.membersMargin
;switch(_10.stackDirection){case"right":_8+=_2.width+_11;break;case"down":_9+=_2.height+_11;break}
if(_7.getLeft()!=_8||_7.getTop()!=_9){_7.animateMove(_8,_9,_4,_5);_6++}
return _6}
,isc.A.$205k=function isc_c_Notify__completeAnimation(_1,_2,_3,_4){delete _1.op;delete _1.opCount;delete _1.opMessage;if(_1.stack){_1.stack.$2042()}
if(_1.replaceQueue.length>0)this.$216s(_1);this.$205c(_1,_2,_3,_4)}
,isc.A.$216r=function isc_c_Notify__fixStackOrMessagePosition(_1,_2){var _3=_1.stack,_4=_1.liveMessages,_5=_4[0];if(!_5)return;var _6,_7;if(_3){_7=_4.find("label",_3.getMember(0));_6=_3}else{_7=_5;_6=_5.label}
if(!_7)return;var _8=_3?this.$2043(_1,_7,false):this.$2040(_1,_7);var _9=_7.settings,_10=_9.repositionMethod,_11=_6.left,_12=_6.top;if(_10=="instant"||_8[0]==_11&&_8[1]==_12||_2){_6.moveTo(_8[0],_8[1]);return}
var _13=this.$205a(_11,_12,_8[0],_8[1],_9.slideSpeed);_6.animateMove(_8[0],_8[1],null,_13)}
,isc.A.$2047=function isc_c_Notify__slideInMessage(_1,_2,_3,_4){var _5=this,_6=_1.stack,_7=_2.label,_8=_2.settings,_9=function(){_5.$205l(_1,_2,_4)},_10=this.$205f(_1,_2,_3,true)
;_7.moveTo(_10[0],_10[1]);var _11=1,_12=this.$205a(_10[0],_10[1],_3[0],_3[1],_8.slideSpeed)
;_7.animateMove(_3[0],_3[1],_9,_12);if(_6){_11+=this.$205j(_1,_2,_4,_9,_12)}
_1.op="slideIn";_1.opCount=_11;_1.opMessage=_2}
,isc.A.$205l=function isc_c_Notify__slideInComplete(_1,_2,_3){if(--_1.opCount>0)return;if(_1.stack){this.$2048(_1,_2,_3)}
this.$205k(_1,_2)}
,isc.A.$2045=function isc_c_Notify__prepSlideStack(_1,_2,_3,_4){var _5=_1.stack,_6=_5.vertical,_7=_2.label,_8=_2.settings,_9=_8.fadeInDuration
;var _10=this.$205j(_1,_2,_4,function(){isc.Notify.$205m(_1,_2,_3,_4)},_9);if(_10){_1.op="slideStack";_1.opMessage=_2}else{this.$2046(_1,_2,_3,_4)}
}
,isc.A.$205m=function isc_c_Notify__prepSlideComplete(_1,_2,_3,_4){delete _1.op;delete _1.opMessage;this.$2046(_1,_2,_3,_4)}
,isc.A.$2046=function isc_c_Notify__fadeInMessage(_1,_2,_3,_4){var _5=this,_6=_1.stack,_7=_2.label,_8=_2.settings,_9=function(){_5.$205n(_1,_2)}
;if(_6){var _10=_8.fadeInDuration;_6.$2041("fade",_10);this.$2048(_1,_2,_4,_9)}else{_7.hide();_7.moveTo(_3[0],_3[1]);_7.animateShow(null,_9)}
_1.op="fadeIn";_1.opMessage=_2}
,isc.A.$205n=function isc_c_Notify__fadeInComplete(_1,_2){if(--_1.opCount>0)return;this.$205k(_1,_2)}
,isc.A.$205o=function isc_c_Notify__slideOutMessage(_1,_2,_3){var _4=this,_5=_1.stack,_6=_2.label,_7=_2.settings,_8=_6.getPageLeft(),_9=_6.getPageTop()
;var _10=1,_11=function(){_4.$205p(_1,_2,_3)},_12=this.$205f(_1,_2),_13=this.$205a(_8,_9,_12[0],_12[1],_7.slideSpeed)
;if(_5){var _14=_1.placeholder;_14.resizeTo(_6.getVisibleWidth(),_6.getVisibleHeight());_14.show();_5.$2097(_6,_14);_6.moveTo(_8,_9);_6.moveAbove(_5);_6.draw();_5.$2041("slide",_13);_5.removeMember(_14,null,_11);_10++;_10+=this.$205i(_1,_2,_3,_11,_13)}
_6.animateMove(_12[0],_12[1],_11,_13,_13);_1.op="slideOut";_1.opCount=_10;_1.opMessage=_2}
,isc.A.$205p=function isc_c_Notify__slideOutComplete(_1,_2,_3){if(--_1.opCount>0)return;this.$205k(_1,_2,_3,true)}
,isc.A.$205q=function isc_c_Notify__fadeOutMessage(_1,_2,_3){var _4=this,_5=1,_6=_1.stack,_7=_2.label,_8=_2.settings,_9=function(){_4.$205r(_1,_2,_3,_11)}
;if(_6){var _10=_8.fadeOutDuration,_11=_6.members.last()!=_2.label
;if(_11){_7.animateFade(0,_9,_10)}else{_6.$2041("fade",_10);_6.removeMember(_7,null,_9);_5+=this.$205i(_1,_2,_3,_9,_10)}
}else{_7.animateHide(null,_9)}
_1.op="fadeOut";_1.opCount=_5;_1.opMessage=_2}
,isc.A.$205r=function isc_c_Notify__fadeOutComplete(_1,_2,_3,_4){if(--_1.opCount>0)return;delete _1.op;delete _1.opCount;delete _1.opMessage;if(_4){this.$205s(_1,_2,_3)}else{this.$205k(_1,_2,_3,true)}
}
,isc.A.$205s=function isc_c_Notify__slideClosedStack(_1,_2,_3){var _4=1,_5=_1.stack,_6=_5.vertical,_7=_2.label,_8=_2.settings,_9=_8.fadeOutDuration,_10=function(){isc.Notify.$205t(_1,_2,_3)};;if(this.$205u(_1,_2,_3)){_5.removeMember(_7);_5.moveTo(_3[0],_3[1]);this.$205c(_1,_2,_3,true);return}
_5.$2041("slide",_9);_5.removeMember(_7,null,_10);_4+=this.$205i(_1,_2,_3,_10,_9);_1.op="slideClosed";_1.opCount=_4;_1.opMessage=_2}
,isc.A.$205t=function isc_c_Notify__slideClosedComplete(_1,_2,_3){if(--_1.opCount>0)return;this.$205k(_1,_2,_3,true)}
,isc.A.$205u=function isc_c_Notify__canUpdateStackInstantly(_1,_2,_3){var _4=_2.settings,_5=_4.stackDirection,_6=_1.pendingQueue,_7=_1.liveMessages
;if(_7.length<2||_6.length||_5=="down"||_5=="right")
{return}
var _8=_1.stack,_9=_2.label;if(_9!=_8.members.first())return;var _10=_8.members[1];if(_10.getPageLeft()==_3[0]&&_10.getPageTop()==_3[1])
{return true}
return false}
);isc.B._maxIndex=isc.C+54;isc.defineClass("NotifyLabel","Label");isc.A=isc.NotifyLabel.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.width=1;isc.A.height=1;isc.A.animateHideEffect="fade";isc.A.animateShowEffect="fade";isc.A.left=0;isc.A.top=-1000;isc.A.autoDraw=false;isc.A.$2485="$2481";isc.A.ID=null;isc.A.closeButtonConstructor="ImgButton";isc.A.closeButtonDefaults={snapTo:isc.Page.isRTL()?"L":"R",snapOffsetLeft:isc.Page.isRTL()?8:-8,imageType:"center",padding:0,showDown:false,showRollOver:false,src:"[SKINIMG]/Notify/close.png",click:function(){var _1=this.creator,_2=isc.Notify.typeState[_1.notifyType];isc.Notify.$204t(_2,_1.messageState)}
};isc.A.closeButtonSize=12;isc.A.iconWidth=17;isc.A.iconHeight=17;isc.B.push(isc.A.$115j=function isc_NotifyLabel__getAfterPadding(){return this.$217x?this.$217x:null}
,isc.A.initWidget=function isc_NotifyLabel_initWidget(){this.Super("initWidget",arguments);var _1=this.closeButtonSize,_2=this.messageState.settings,_3=_2.canDismiss;if(_3||_3!=false&&!_2.duration){this.addAutoChild("closeButton",{size:_1,imageWidth:_1,imageHeight:_1,baseStyle:this.baseStyle
});var _4=_2.messageControlPadding;if(_4)this.$217x=_4}
}
,isc.A.click=function isc_NotifyLabel_click(){var _1=this.messageState,_2=_1.actions;if(!_2)return;for(var i=0;i<_2.length;i++){var _4=_2[i];if(_4.wholeMessage){this.fireAction(_4)}
}
}
,isc.A.actionClick=function isc_NotifyLabel_actionClick(_1,_2,_3){var _4=this.messageState,_5=_4.actions[_2];if(_5){this.fireAction(_5);return false}
}
,isc.A.fireAction=function isc_NotifyLabel_fireAction(_1){if(_1.target&&_1.methodName||_1.method){isc.Class.fireCallback(_1)}
if(_1.dismissMessage){var _2=isc.Notify.typeState[this.notifyType];isc.Notify.$204t(_2,this.messageState)}
}
);isc.B._maxIndex=isc.C+5;isc.A=isc.Notify;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.commonDefaults={duration:5000,appearMethod:"slide",disappearMethod:"fade",repositionMethod:"slide",slideSpeed:300,fadeInDuration:500,fadeOutDuration:500,multiMessageMode:"stack",stackDirection:"down",stackSpacing:2,maxStackSize:3,stackPersistence:"none",maxStackDismissMode:"oldest",actionSeparator:" ",messageIconSpacing:20,messagePriority:isc.Notify.MESSAGE,applyPriorityToAppearance:true,messageIconOrientation:isc.Page.isRTL()?"right":"left",autoFitWidth:true,autoFitMaxWidth:300
};isc.A.$207t={messageIcon:"[SKIN]/Notify/error.png",actionStyleName:"notifyErrorActionLink",styleName:isc.Page.isRTL()?"notifyErrorRTL":"notifyError"
};isc.A.$207u={messageIcon:"[SKIN]/Notify/warning.png",actionStyleName:"notifyWarnActionLink",styleName:isc.Page.isRTL()?"notifyWarnRTL":"notifyWarn"
};isc.A.$207v={messageIcon:"[SKIN]/Notify/checkmark.png",actionStyleName:"notifyMessageActionLink",styleName:isc.Page.isRTL()?"notifyMessageRTL":"notifyMessage",messageControlPadding:null
};isc.B.push(isc.A.$207w=function isc_c_Notify__getDefaultPriority(_1){switch(_1){case this.$204q:return isc.Notify.ERROR;case this.$204p:return isc.Notify.WARN;case this.$204o:default:return isc.Notify.MESSAGE}
}
,isc.A.$207s=function isc_c_Notify__initNotifySettings(_1,_2){_2=isc.addProperties({},_2);var _3=this.$207w(_1);if(_3<isc.Notify.MESSAGE)isc.addDefaults(_2,{applyPriorityToAppearance:false,messagePriority:_3
});_2.$207x=_3;isc.addDefaults(_2,this.$207y(_3));isc.addDefaults(_2,this.commonDefaults);return _2}
,isc.A.$207y=function isc_c_Notify__getPriorityRelatedDefaults(_1){switch(_1){case isc.Notify.ERROR:return this.$207t;case isc.Notify.WARN:return this.$207u;default:case isc.Notify.MESSAGE:return this.$207v}
}
,isc.A.$2157=function isc_c_Notify__getConfigSettingsByPriority(_1){var _2=this.settings;switch(_1){case isc.Notify.ERROR:return _2[this.$204q];case isc.Notify.WARN:return _2[this.$204p];default:case isc.Notify.MESSAGE:return _2[this.$204o]}
}
,isc.A.$2156=function isc_c_Notify__shouldApplyPriorityToAppearance(_1,_2){if(_1.messagePriority==null)return false;return _1.applyPriorityToAppearance!=null?_1.applyPriorityToAppearance:_2.applyPriorityToAppearance}
);isc.B._maxIndex=isc.C+5;isc.addGlobal("notify",function(_1,_2,_3,_4){return isc.Notify.addMessage(_1,_2,_3,_4)});isc.defineClass("ToolStrip","Layout");isc.A=isc.ToolStrip.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.height=20;isc.A.defaultWidth=250;isc.A.styleName="toolStrip";isc.A.vertical=false;isc.A.resizeBarClass="ToolStripResizer";isc.A.resizeBarSize=14;isc.A.separatorClass="ToolStripSeparator";isc.A.separatorSize=8;isc.A.separatorBreadth=22;isc.A.formWrapperConstructor="DynamicForm";isc.A.formWrapperDefaults={numCols:2,overflow:"visible",width:1,height:1
};isc.B.push(isc.A.init=function isc_ToolStrip_init(){if(!isc.isA.Number(this.width))this.reflowOnDraw=true;return this.Super("init",arguments)}
,isc.A.initWidget=function isc_ToolStrip_initWidget(_1,_2,_3,_4,_5,_6){this.members=this.$62r(this.members);this.invokeSuper(isc.ToolStrip,this.$oc,_1,_2,_3,_4,_5,_6);if(this.vertical&&this.verticalStyleName!=null){this.setStyleName(this.verticalStyleName)}
}
,isc.A.draw=function isc_ToolStrip_draw(){var _1=this.Super("draw",arguments);if(this.reflowOnDraw)this.reflow(true);return _1}
,isc.A.$62r=function isc_ToolStrip__convertMembers(_1){if(_1==null)return null;var _2=isc.ClassFactory.getClass(this.separatorClass,true),_3=[];for(var i=0;i<_1.length;i++){var m=_1[i];if(m=="separator"){var _6=_2.createRaw();_6.autoDraw=false;_6.vertical=!this.vertical;if(this.vertical){_6.height=this.separatorSize;_6.width=this.separatorBreadth}else{_6.width=this.separatorSize;_6.height=this.separatorBreadth}
_6.completeCreation();_3.add(isc.SGWTFactory.extractFromConfigBlock(_6))}else if(m=="resizer"&&i>0){_1[i-1].showResizeBar=true}else if(m=="starSpacer"){var _7=(this.vertical?{height:"*"}:{width:"*"});_3.add(isc.LayoutSpacer.create(_7))}else if(isc.isA.ToolStripResizer(m)&&i>0){_1[i-1].showResizeBar=true;m.destroy()}else{if(!isc.isA.ToolStripSeparator(m)&&!isc.isA.ToolStripSpacer(m)&&!isc.isA.RibbonGroup(m)){m=this.createCanvas(m)}
if(isc.isA.ToolStripSeparator(m)){var _6=m;_6.vertical=!this.vertical;_6.setSrc(this.vertical?_6.hSrc:_6.vSrc);if(this.vertical){_6.setHeight(this.separatorSize);_6.setWidth(this.separatorBreadth)}else{_6.setWidth(this.separatorSize);_6.setHeight(this.separatorBreadth)}
_6.markForRedraw()}else if(isc.isA.ToolStripSpacer(m)){var _8=m.space>>0||"*";if(this.vertical){m.height=_8;m.setHeight(_8)}else{m.width=_8;m.setWidth(_8)}
}else if(isc.isA.RibbonGroup(m)){if(!m.showTitle)m.setShowTitle(this.showGroupTitle);if(!m.titleAlign)m.setTitleAlign(this.groupTitleAlign);if(!m.titleOrientation)m.setTitleOrientation(this.groupTitleOrientation)}
_3.add(m)}
}
return _3}
,isc.A.addMembers=function isc_ToolStrip_addMembers(_1,_2,_3,_4,_5){if(!_1)return;if(!isc.isAn.Array(_1))_1=[_1];var _6=_1[0],_7=isc.isA.ToolStripResizer(_6);if(_6=="resizer"||_7){if(_2==null)_2=this.members.length;var _8=Math.min(_2,this.members.length)-1;if(_8>=0){var _9=this.getMember(_8);if(_9!=null){_9.showResizeBar=true;this.reflow()}
}
var _10=_1.shift();if(_7)_10.destroy()}
_1=this.$62r(_1);return this.invokeSuper(isc.ToolStrip,"addMembers",_1,_2,_3,_4,_5)}
,isc.A.addFormItem=function isc_ToolStrip_addFormItem(_1,_2,_3){if(isc.isA.Canvas(_1)){this.addMember(_1,_3);return _1}
var _4=this.createAutoChild("formWrapper",_2);_4.setItems([_1]);this.addMember(_4,_3);return _4}
);isc.B._maxIndex=isc.C+6;isc.defineClass("ToolStripSeparator","Img");isc.A=isc.ToolStripSeparator.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.skinImgDir="images/ToolStrip/";isc.A.vSrc="[SKIN]separator.png";isc.A.hSrc="[SKIN]hseparator.png";isc.A.layoutAlign="center";isc.A.imageType="center";isc.A.$1767="separator";isc.A._generated=true;isc.B.push(isc.A.initWidget=function isc_ToolStripSeparator_initWidget(){if(isc.isA.Img(this))this.src=this.vertical?this.vSrc:this.hSrc;this.Super("initWidget",arguments)}
,isc.A.updateEditNode=function isc_ToolStripSeparator_updateEditNode(_1,_2){_1.removeNodeProperties(_2,["autoDraw","ID","autoID","title"])}
);isc.B._maxIndex=isc.C+2;isc.defineClass("ToolStripSpacer","LayoutSpacer");isc.A=isc.ToolStripSpacer.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$1767="starSpacer";isc.A._generated=true;isc.B.push(isc.A.propertyChanged=function isc_ToolStripSpacer_propertyChanged(_1,_2){if(_1=="space"){var _3=this.space>>0||"*";if(this.parentElement.vertical){this.setHeight(_3)}else{this.setWidth(_3)}
}
}
,isc.A.updateEditNode=function isc_ToolStripSpacer_updateEditNode(_1,_2){_1.removeNodeProperties(_2,["autoDraw","ID","autoID","title"])}
);isc.B._maxIndex=isc.C+2;isc.defineClass("ToolStripButton","Button");isc.A=isc.ToolStripButton.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.showRollOver=true;isc.A.showDown=true;isc.A.labelHPad=6;isc.A.labelVPad=0;isc.A.autoFit=true;isc.A.src="[SKIN]/ToolStrip/button/button.png";isc.A.capSize=3;isc.A.height=22;isc.B.push(isc.A.initWidget=function isc_ToolStripButton_initWidget(){if(!this.title)this.iconSpacing=0;this.Super("initWidget",arguments)}
,isc.A.setTitle=function isc_ToolStripButton_setTitle(_1){if(!_1){this.iconSpacing=0;if(this.label)this.label.iconSpacing=0}
this.Super("setTitle",arguments)}
);isc.B._maxIndex=isc.C+2;isc.defineClass("Header","ToolStrip");isc.A=isc.Header.getPrototype();isc.A.styleName="headerItem";isc.A.titleLabelDefaults={_constructor:"Label",$1661:true,baseStyle:"headerItem",padding:2,autoFit:true,wrap:false
};isc.A=isc.Header.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.initWidget=function isc_Header_initWidget(){if(this.title){if(!this.members||this.members.length==0){this.members=[this.createTitleLabel(this.title)]}else if(this.members&&!this.members[0].$1661){this.members.addAt(this.createTitleLabel(this.title),0)}
}
this.Super(this.$oc)}
,isc.A.addMembers=function isc_Header_addMembers(_1,_2,_3,_4,_5){_2=(_2!=null?_2+1:null);return this.Super("addMembers",[_1,_2,_3,_4,_5])}
,isc.A.createTitleLabel=function isc_Header_createTitleLabel(_1){this._titleLabel=this.createAutoChild("titleLabel",{contents:_1});return this._titleLabel}
,isc.A.setTitle=function isc_Header_setTitle(_1){this.title=_1;if(this.$116x!=null&&this.$116x==_1){return}else{this.$116x=_1}
if(!this._titleLabel){this.addMember(this.createTitleLabel(this.title))}
this._titleLabel.setContents(_1)}
);isc.B._maxIndex=isc.C+4;isc.defineClass("RibbonBar","ToolStrip");isc.A=isc.RibbonBar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.showGroupTitle=true;isc.A.groupTitleAlign="center";isc.A.groupTitleOrientation="top";isc.A.membersMargin=2;isc.A.layoutMargin=2;isc.A.groupConstructor="RibbonGroup";isc.B.push(isc.A.addGroup=function isc_RibbonBar_addGroup(_1,_2){if(!_1)return null;if(!isc.isA.Class(_1)){var _3=this.groupConstructor;if(isc.isA.String(_3)){_3=isc.ClassFactory.getClass(this.groupConstructor,true)}
_1=_3.create(_1)}
if(!_1||!isc.isA.RibbonGroup(_1))return null;if(_1.showTitle==null)_1.setShowTitle(this.showGroupTitle);if(!_1.titleAlign)_1.setTitleAlign(this.groupTitleAlign);if(!_1.titleOrientation)_1.setTitleOrientation(this.groupTitleOrientation);this.addMember(_1,_2);return _1}
,isc.A.destroy=function isc_RibbonBar_destroy(){if(this.members){for(var i=0;i<this.members.length;i++){var m=this.members[i];if(m&&!m.destroying&&!m.destroyed)m.destroy();this.members[i]=null;m=null}
}
return this.Super("destroy",arguments)}
,isc.A.releaseReifySizeLock=function isc_RibbonBar_releaseReifySizeLock(_1){_1=_1||this;if(!_1.editingOn||_1.$257z)return false;if(_1.editContext.isEditNodeSelected(_1.editNode)){_1.$257z=true;_1.editProxy.showSelectedAppearance(false)
return true}
return false}
,isc.A.restoreReifySizeLock=function isc_RibbonBar_restoreReifySizeLock(_1){_1=_1||this;if(!_1.editingOn||!_1.$257z)return false;if(_1!=this)this.redraw();delete _1.$257z;_1.editProxy.showSelectedAppearance(true)
return true}
);isc.B._maxIndex=isc.C+4;isc.defineClass("RibbonGroup","VLayout");isc.A=isc.RibbonGroup.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.newControlConstructor="RibbonButton";isc.A.newControlDefaults={};isc.A.groupConstructor="RibbonGroup";isc.A.styleName="ribbonGroup";isc.A.canAcceptDrop=true;isc.A.canDropComponents=false;isc.A.membersMargin=1;isc.A.layoutAlign="top";isc.A.autoDraw=false;isc.A.height=1;isc.A.width=1;isc.A.overflow="visible";isc.A.labelLayoutDefaults={_constructor:"HLayout",width:"100%",autoDraw:false,height:22
};isc.A.labelConstructor="Label";isc.A.labelDefaults={width:"100%",height:18,autoDraw:false,wrap:false,overflow:"visible",canAcceptDrop:false
};isc.A.titleAlign="center";isc.A.titleStyle="ribbonGroupTitle";isc.A.autoSizeToTitle=true;isc.A.titleOrientation="top";isc.A.titleHeight=18;isc.A.bodyConstructor="HLayout";isc.A.bodyDefaults={width:"100%",height:"*",overflow:"visible",membersMargin:2,autoDraw:false,canAcceptDrop:false
};isc.A.columnLayoutMembersMargin=2;isc.A.columnLayoutDefaults={_constructor:"VLayout",width:1,height:"100%",overflow:"visible",autoDraw:false,numRows:0,canAcceptDrop:false,setActive:function(_1){if(_1==null)_1=true;this.active=_1;if(this.active&&!this.isDrawn()&&this.parentElement&&this.parentElement.isDrawn&&this.parentElement.isDrawn())this.draw();if(!_1&&this.isDrawn())this.clear()},addMember:function(_1,_2){this.Super("addMember",arguments);if(_1.rowSpan==null)_1.rowSpan=1;var _3=_1.rowSpan*this.creator.rowHeight+((_1.rowSpan-1)*this.membersMargin);if(_1.vertical){_3=(this.maxRows*this.creator.rowHeight)+((this.maxRows-1)*this.membersMargin);this.numRows=this.maxRows}else{this.numRows+=_1.rowSpan}
var _4=this.creator.getRibbon();var _5=_4?_4.releaseReifySizeLock(_1):false;_1.setHeight(_3);if(_1.editingOn&&_1.editNode&&_1.editNode.liveObject){_1.editNode.liveObject.setHeight(_3)}
var _6=_4?_4.restoreReifySizeLock(_1):false;this.reflow();this.setActive(true)},removeMember:function(_1){this.Super("removeMember",arguments);delete _1.$225v;if(_1.$32)return;if(_1.rowSpan==null)_1.rowSpan=1;this.numRows-=_1.rowSpan;if(this.numRows<0)this.numRows=0;if(this.numRows==0)this.setActive(false)}
};isc.A.numRows=1;isc.A.rowHeight=26;isc.A.defaultColWidth="*";isc.A.autoFillColumns=false;isc.A.recreateChildLayouts=false;isc.A.autoHideOnLastRemove=false;isc.A.$257y={};isc.B.push(isc.A.createControl=function isc_RibbonGroup_createControl(_1,_2){var _3=this.createAutoChild("newControl",_1);return this.addControl(_3,_2)}
,isc.A.drop=function isc_RibbonGroup_drop(_1,_2){var _3=isc.EventHandler.getDragTarget();if(_3){this.addControl(_3)}
return false}
,isc.A.setNumRows=function isc_RibbonGroup_setNumRows(_1){this.numRows=_1;this.delayCall("delayedUpdateControls")}
,isc.A.delayedUpdateControls=function isc_RibbonGroup_delayedUpdateControls(){this.resizeTo(1,1);this.getRibbon()&&this.getRibbon().releaseReifySizeLock(this);this.$225s(true);this.getRibbon()&&this.getRibbon().restoreReifySizeLock(this)}
,isc.A.initWidget=function isc_RibbonGroup_initWidget(){this.columnLayouts=[];this.$1i=this.width;this.Super("initWidget",arguments);var _1=this.showTitle!=false&&this.showLabel!=false;if(_1){this.addAutoChild("labelLayout",{height:this.titleHeight});var _2=isc.addProperties({},this.titleProperties||{},{styleName:this.titleStyle,height:this.titleHeight,maxHeight:this.titleHeight,align:this.titleAlign,contents:this.title,autoDraw:false,eventProxy:this
});if(this.autoSizeToTitle==false)_2.overflow="hidden";this.addAutoChild("label",_2);this.labelLayout.addMember(this.label);if(this.showTitle==false)this.labelLayout.hide();this.addMember(this.labelLayout)}
this.addAutoChild("body",{_constructor:this.bodyConstructor,height:this.numRows*this.rowHeight,parentResized:function(){var _3=this.getVisibleWidth(),_4=this.parentElement,_5=_4.$1i;if(isc.isA.Number(_5)&&_5>1){_3=Math.max(_3,_5)}
if(_4.label)_4.label.setWidth(_3)}
});this.addMember(this.body,_1?(this.titleOrientation=="bottom"?0:1):0);this.observe(this.body,"resized","observer.bodyResized(observed);");this.addColumn();var _6=this.controls||[];this.controls=[];if(!this.editingOn&&_6.length>0){this.setControls(_6)}
}
,isc.A.bodyResized=function isc_RibbonGroup_bodyResized(_1){var _2=this.body.getVisibleWidth(),_3=this.$1i;if(isc.isA.Number(_3)&&_3>1){_2=Math.max(_2,_3)}
if(Math.abs(this.getVisibleWidth()-_2)>5){this.$312n=true;this.setWidth(_2);delete this.$312n}
if(this.labelLayout)this.labelLayout.setWidth(_2)}
,isc.A.destroy=function isc_RibbonGroup_destroy(){this.ignore(this.body,"resized");for(var i=0;i<this.controls.length;i++){this.ignoreControl(this.controls[i]);this.controls[i].destroy();this.controls[i]=null}
if(this.members){for(var i=0;i<this.members.length;i++){var m=this.members[i];if(m&&!m.destroying&&!m.destroyed)m.destroy();this.members[i]=null;m=null
}
}
return this.Super("destroy",arguments)}
,isc.A.setTitle=function isc_RibbonGroup_setTitle(_1){this.title=_1;if(this.label)this.label.setContents(this.title);this.getRibbon()&&this.getRibbon().releaseReifySizeLock(this);this.resizeTo(1,1);this.$225s(true);this.getRibbon()&&this.getRibbon().restoreReifySizeLock(this)}
,isc.A.setShowTitle=function isc_RibbonGroup_setShowTitle(_1){this.showTitle=_1;if(!_1&&this.labelLayout&&this.labelLayout.isVisible())this.labelLayout.hide();else if(_1&&this.labelLayout&&!this.labelLayout.isVisible())this.labelLayout.show()}
,isc.A.setTitleAlign=function isc_RibbonGroup_setTitleAlign(_1){this.titleAlign=_1;if(this.label)this.label.setAlign(this.titleAlign)}
,isc.A.setTitleStyle=function isc_RibbonGroup_setTitleStyle(_1){this.titleStyle=_1;if(this.label){this.label.setStyleName(this.titleStyle);if(this.label.isDrawn())this.label.redraw()}
}
,isc.A.setTitleOrientation=function isc_RibbonGroup_setTitleOrientation(_1){this.titleOrientation=_1;if(this.label&&this.labelLayout){if(this.titleOrientation=="top"){this.removeMember(this.labelLayout);this.addMember(this.labelLayout,0)}else if(this.titleOrientation=="bottom"){this.removeMember(this.labelLayout);this.addMember(this.labelLayout,1)}
}
}
,isc.A.setTitleHeight=function isc_RibbonGroup_setTitleHeight(_1){this.titleHeight=_1;if(this.label)this.label.setHeight(this.titleHeight)}
,isc.A.addColumn=function isc_RibbonGroup_addColumn(_1,_2){if(!_1&&_1!=0)_1=this.columnLayouts.length;var _3=this.defaultColWidth;if(this.colWidths&&this.colWidths[_1]!=null)_3=this.colWidths[_1];var _4={maxRows:this.numRows,numRows:0,width:_3,height:this.body.getInnerHeight()
};_4.membersMargin=this.columnLayoutMembersMargin;var _5=this.createAutoChild("columnLayout",_4);this.columnLayouts.add(_5);this.body.addMember(_5,_1);if(_2)_5.addMembers(_2);return _5}
,isc.A.getAvailableColumn=function isc_RibbonGroup_getAvailableColumn(_1,_2){var _3=this.columnLayouts||[];if(_2.vertical){for(var i=0;i<_3.length;i++){if(_3[i].active){if(_3[i].numRows==0){return _3[i]}
}else{_3[i].setActive(true);return _3[i]}
}
}else if(_3&&_3.length>0){for(var i=0;i<_3.length;i++){var _5=_3[i];if(_5.active){var _6=_5.maxRows-_5.numRows;if(_6>0&&_6>=_2.rowSpan){if(i==_3.length-1||(!_3[i+1]||!_3[i+1].active)){return _5}else if(this.autoFillColumns){return _5}
}
}else{_5.setActive(true);return _5}
}
}
if(_1!=false){var _7=this.addColumn();_7.setActive(true);return _7}
return null}
,isc.A.getControlColumn=function isc_RibbonGroup_getControlColumn(_1){var _2=this.body.members;if(_2&&_2.length>0){for(var i=_2.length-1;i>=0;i--){if(_2[i].members.contains(_1))return _2[i]}
}
return null}
,isc.A.setControls=function isc_RibbonGroup_setControls(_1,_2){this.$225r=true;if(this.controls){if(this.isDrawn())this.removeAllControls()}
this.controls=_1;this.$225s();for(var i=0;i<this.controls.length;i++){this.observeControl(this.controls[i])}
delete this.$225r}
,isc.A.reflowControls=function isc_RibbonGroup_reflowControls(){this.$225s()}
,isc.A.addControls=function isc_RibbonGroup_addControls(_1,_2){if(!_1)return;if(!isc.isAn.Array(_1))_1=[_1];for(var i=0;i<_1.length;i++){this.addControl(_1[i],null,_2)}
}
,isc.A.addControl=function isc_RibbonGroup_addControl(_1,_2,_3){if(!_1)return null;if(this.controls.contains(_1))this.controls.remove(_1);if(_2==null)_2=this.controls.length;_1.$225u=this;this.observeControl(_1);this.controls.addAt(_1,_2);if(!_3)this.$225s()}
,isc.A.$225t=function isc_RibbonGroup__addControl(_1){if(_1.rowSpan==null)_1.rowSpan=1;var _2=this.getAvailableColumn(true,_1);_1.$225u=this;_1.$225v=_2.getID();if(this.isDrawn()&&!_2.isDrawn())_2.draw();if(!_2.isVisible())_2.show();_2.addMember(_1);_2.reflowNow()}
,isc.A.$225s=function isc_RibbonGroup__updateControls(_1){this.$229t=true;if(!_1&&this.getRibbon())this.getRibbon().releaseReifySizeLock(this);for(var i=0;i<this.controls.length;i++){var _3=this.controls[i];if(_3.$225v){var _4=isc.Canvas.getById(_3.$225v);if(_4&&!_4.destroyed)_4.removeMember(_3)}
_3.clear();this.addChild(_3,null,false);delete _3.$225v}
var _5=this;this.columnLayouts.map(function(_6){_6.numRows=0;_6.maxRows=_5.numRows;_6.active=false});if(this.recreateChildLayouts){this.body.members.callMethod("destroy");this.body.members.clear()}
this.body.resizeTo(1,1);if(!this.isDrawn()&&this.parentElement&&this.parentElement.isDrawn())this.draw();for(var i=0;i<this.controls.length;i++){var _3=this.controls[i];if(!_3.isVisible())continue;this.$225t(_3)}
this.layoutChildren();this.redraw();if(!_1&&this.getRibbon())this.getRibbon().restoreReifySizeLock(this);delete this.$229t}
,isc.A.removeControl=function isc_RibbonGroup_removeControl(_1){_1=isc.isAn.Object(_1)?_1:this.getMember(_1);if(!_1)return null;if(this.controls.contains(_1))this.controls.remove(_1);this.getControlColumn(_1).removeMember(_1);_1.$225u=null;this.ignoreControl(_1);this.$225s();if(this.body.members.length==0&&this.autoHideOnLastRemove){this.hide()}
}
,isc.A.observeControl=function isc_RibbonGroup_observeControl(_1){if(!this.isObserving(_1,"$807")){this.observe(_1,"$807","observer.controlVisibilityChanged(observed);")}
}
,isc.A.ignoreControl=function isc_RibbonGroup_ignoreControl(_1){if(this.isObserving(_1,"$807")){this.ignore(_1,"$807")}
}
,isc.A.controlVisibilityChanged=function isc_RibbonGroup_controlVisibilityChanged(_1){if(this.$225r||this.$229t){return}
if(!this.isDrawn()){this.logInfo("Delaying $225s() until draw()");this.$251h=true;return}
this.logInfo(_1.ID+" - visibility changed - Updating controls");this.$225s()}
,isc.A.removeAllControls=function isc_RibbonGroup_removeAllControls(){if(!this.controls||this.controls.length==0)return null;for(var i=0;i<this.controls.length;i++){var _2=this.controls[i];_2.hide();if(_2.$225v){var _3=isc.Canvas.getById(_2.$225v);if(_3&&!_3.destroyed&&_3.members.contains(_2)){_3.removeMember(_2)}
}
this.controls[i]=null}
this.controls=[];this.$225s();this.body.height=1;this.height=1}
,isc.A.setWidth=function isc_RibbonGroup_setWidth(_1){if(!this.$312n)this.$1i=_1;return this.Super("setWidth",arguments)}
,isc.A.resized=function isc_RibbonGroup_resized(){if(this.destroyed||this.destroying)return;this.$87v()}
,isc.A.draw=function isc_RibbonGroup_draw(){if(this.destroyed||this.destroying)return;this.Super("draw",arguments);this.$87v();if(this.$251h){delete this.$251h;this.$225s()}
}
,isc.A.redraw=function isc_RibbonGroup_redraw(){if(this.destroyed||this.destroying)return;this.Super("redraw",arguments);this.$87v()}
,isc.A.$87v=function isc_RibbonGroup__updateLabel(){var _1=this.getInnerWidth(),_2=_1
;if(_2<0){_2=this.body?this.body.getVisibleWidth():this.getVisibleWidth()}
if(this.label)this.label.setWidth(_2)}
,isc.A.getRibbon=function isc_RibbonGroup_getRibbon(){if(isc.isA.RibbonBar(this.parentElement))return this.parentElement;return null}
,isc.A.propertyChanged=function isc_RibbonGroup_propertyChanged(_1,_2){this.invokeSuper(isc.RibbonGroup,"propertyChanged",_1,_2);if(this.$257y[_1]){this.getRibbon()&&this.getRibbon().releaseReifySizeLock(this);this.resizeTo(1,1);this.$225s(true);this.getRibbon()&&this.getRibbon().restoreReifySizeLock(this)}
if(this.editingOn&&this.editProxy){}}
);isc.B._maxIndex=isc.C+34;isc.defineClass("RibbonButton","Button");isc.A=isc.RibbonButton.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$2250=true;isc.A.width=1;isc.A.overflow="visible";isc.A.height=1;isc.A.autoDraw=false;isc.A.usePartEvents=true;isc.A.orientation="vertical";isc.A.vertical=false;isc.A.rowSpan=1;isc.A.baseStyle="ribbonButton";isc.A.showMenuIcon=null;isc.A.menuIconSrc="[SKINIMG]/Menu/submenu_down.png";isc.A.menuIconWidth=14;isc.A.menuIconHeight=13;isc.A.menuConstructor=isc.Menu;isc.A.align=null;isc.A.valign=null;isc.A.showButtonTitle=true;isc.A.icon="[SKINIMG]actions/edit.png";isc.A.iconSize=16;isc.A.largeIconSize=32;isc.A.titleSeparator="&nbsp;";isc.A.showMenuOnClick=false;isc.A.showMenuIconOver=true;isc.A.showMenuIconDown=false;isc.A.showMenuIconDisabled=true;isc.A.menu=null;isc.A.showMenuBelow=true;isc.A.$257y={};isc.B.push(isc.A.getRibbon=function isc_RibbonButton_getRibbon(){return this.$225u&&this.$225u.getRibbon()}
,isc.A.getRibbonGroup=function isc_RibbonButton_getRibbonGroup(){return this.$225u}
,isc.A.setVertical=function isc_RibbonButton_setVertical(_1){this.getRibbon()&&this.getRibbon().releaseReifySizeLock(this);if(this.vertical!=_1){this.vertical=_1}
var _2=this.getRibbonGroup();if(_2){var _3;if(this.vertical){_3=(this.maxRows*_2.rowHeight)+((this.maxRows-1)*_2.columnLayoutMembersMargin)}else{_3=this.rowSpan*_2.rowHeight+((this.rowSpan-1)*_2.columnLayoutMembersMargin)}
this.setHeight(_3)}
this.setTitle(this.title);this.redraw();this.getRibbon()&&this.getRibbon().restoreReifySizeLock(this);this.markForRedraw();this.forceGroupUpdate()}
,isc.A.setRowSpan=function isc_RibbonButton_setRowSpan(_1){this.getRibbon()&&this.getRibbon().releaseReifySizeLock(this);if(!_1||_1<1)_1=1;var _2=this.getRibbonGroup();if(_2){var _3=_2.numRows;if(_1>_3){this.logWarn("setRowSpan() passed "+_1+" but RibbonGroup.numRows is only "+_3+".  Reducing to "+_3+".");_1=_2.numRows}
this.setHeight(_1*_2.rowHeight)}
this.rowSpan=_1;this.redraw();this.getRibbon()&&this.getRibbon().restoreReifySizeLock(this);this.forceGroupUpdate()}
,isc.A.forceGroupUpdate=function isc_RibbonButton_forceGroupUpdate(){if(!this.$225u)return;this.getRibbon()&&this.getRibbon().releaseReifySizeLock(this);this.$225u.$225s(true);this.getRibbon()&&this.getRibbon().restoreReifySizeLock(this)}
,isc.A.init=function isc_RibbonButton_init(){if(this.vertical==null){this.vertical=this.orientation=="vertical"?true:false}
if(this.vertical){this.align=this.align||"center";this.valign=this.valign||"top"}else{this.align=this.align||"left";this.valign=this.valign||"center"}
this.$1089=this.align;this.$109a=this.valign;if(this.showMenuIcon!=false&&this.menu)this.showMenuIcon=true;return this.Super("init",arguments)}
,isc.A.initWidget=function isc_RibbonButton_initWidget(){this.Super("initWidget",arguments)}
,isc.A.setIcon=function isc_RibbonButton_setIcon(_1){this.icon=_1;this.setTitle(this.title)}
,isc.A.getIcon=function isc_RibbonButton_getIcon(){return this.icon}
,isc.A.stateChanged=function isc_RibbonButton_stateChanged(){if(this.destroyed||this.destroying)return;var _1=this.Super("stateChanged",arguments);return _1}
,isc.A.setLargeIcon=function isc_RibbonButton_setLargeIcon(_1){this.largeIcon=_1;this.setTitle(this.title)}
,isc.A.setTitle=function isc_RibbonButton_setTitle(_1){this.title=_1;this.align=this.$1089;this.valign=this.$109a;this.Super("setTitle",arguments)}
,isc.A.getTitle=function isc_RibbonButton_getTitle(){return this.title}
,isc.A.getTitleHTML=function isc_RibbonButton_getTitleHTML(){var _1=this.vertical,_2=this.showIcon==false?null:(_1?this.largeIcon||this.icon:this.icon),_3=(_1?this.largeIconSize:this.iconSize),_4=this.showButtonTitle?this.title:""
;if(_2=="")_2=null;_2=this.$179m(_2);var _5=_2?this.imgHTML({src:_2,width:_3,height:_3,eventStuff:" eventpart='icon'",cssClass:this.iconStyle||(_1?this.baseStyle+"VIcon":this.baseStyle+"HIcon")
}):null
;var _6=null;if(this.showMenuIcon){var _7=this.$1117();_6=this.menuIcon=this.imgHTML({src:_7,width:this.menuIconWidth,height:this.menuIconHeight,name:"menuIcon",eventStuff:" eventpart='menuIcon'",cssClass:this.menuIconStyle||(this.baseStyle+(_1?"VMenuIcon":"HMenuIcon"))
})}
var _8=_4;_4=_5||"";if(this.vertical){if(this.showButtonTitle){if(_4!="")_4+="<br>";_4+=_8}
if(this.showMenuIcon&&_6){_4+="<br>";_4+=_6}
}else{var _9=this.titleSeparator;if(isc.Browser.isChrome&&isc.Browser.version==78&&_9=="&nbsp;"){_9=" "}
this.valign="center";if(this.showButtonTitle){if(_4!=""){_4+=_9}
_4+="<span style='vertical-align:middle;align-content:center;'>"+_8+"</span>"}
if(this.showMenuIcon&&_6){if(_4!="")_4+=_9;_4+=_6}
}
return _4}
,isc.A.$1117=function isc_RibbonButton__getMenuIconURL(){var _1=this.state,_2=this.selected,_3=this.getCustomState(),_4=isc.StatefulCanvas
;if(_1==_4.STATE_DOWN&&!this.showMenuIconDown)_1=null;else if(_1==_4.STATE_DISABLED&&!this.showMenuIconDisabled)_1=null;else if(_1==_4.STATE_OVER&&(!this.showMenuIconOver||!this.showingMenuButtonOver))
_1=null;var _5=null;var _6=this.menuIconSrc;return isc.Img.urlForState(_6,_2,_5,_1,null,_3)}
,isc.A.setHandleDisabled=function isc_RibbonButton_setHandleDisabled(){this.Super("setHandleDisabled",arguments);if(this.isDrawn())this.setTitle(this.title)}
,isc.A.mouseOut=function isc_RibbonButton_mouseOut(){this.Super("mouseOut",arguments);if(this.showingMenuButtonOver)this.menuIconMouseOut()}
,isc.A.menuIconClick=function isc_RibbonButton_menuIconClick(){this.showMenu();return false}
,isc.A.iconClick=function isc_RibbonButton_iconClick(){return true}
,isc.A.click=function isc_RibbonButton_click(){if(this.showMenuOnClick&&this.showMenu)this.showMenu()}
,isc.A.menuIconMouseMove=function isc_RibbonButton_menuIconMouseMove(){if(!this.showMenuIconOver||this.showingMenuButtonOver)return;var _1=this.getImage("menuIcon");if(_1){this.showingMenuButtonOver=true;this.setTitle(this.title)}}
,isc.A.menuIconMouseOut=function isc_RibbonButton_menuIconMouseOut(){if(!this.showMenuIconOver)return;var _1=this.getImage("menuIcon");if(_1){this.showingMenuButtonOver=false;this.setTitle(this.title)}}
,isc.A.$179l=function isc_RibbonButton__shouldRedrawOnStateChange(){if(this.Super("$179l",arguments))return true;var _1=this.showIcon!=false?(this.vertical?this.largeIcon||this.icon:this.icon):null;if(_1===isc.Canvas.$wz)return _1;if(_1&&this.showIconState&&(this.showDisabledIcon||this.showSelectedIcon||this.showRollOverIcon||this.showFocusedIcon||this.showDownIcon))return true;return false}
,isc.A.setMenu=function isc_RibbonButton_setMenu(_1){this.menu=_1;this.showMenuIcon=(this.menu!=null);this.markForRedraw()}
,isc.A.getMenu=function isc_RibbonButton_getMenu(){return this.menu}
,isc.A.showMenu=function isc_RibbonButton_showMenu(){if(isc.isA.String(this.menu))this.menu=window[this.menu];if(!isc.isA.Menu(this.menu))this.$36d(this.menu);if(!isc.isA.Menu(this.menu))return false;var _1=this.menu;_1.$8h();this.positionMenu(_1);_1.show(this.menuAnimationEffect)}
,isc.A.positionMenu=function isc_RibbonButton_positionMenu(_1){if(!_1)return;var _2=this.getPageLeft();if(this.menuAlign==isc.Canvas.CENTER){_2=_2-((_1.getVisibleWidth()-this.getVisibleWidth())/2)}else if(this.menuAlign==isc.Canvas.RIGHT){_2-=(_1.getVisibleWidth()-this.getVisibleWidth())}
var _3=this.showMenuBelow?this.getPageTop()+this.getVisibleHeight()+1:this.getPageTop()-_1.getVisibleHeight()+2;_1.placeNear(_2,_3)}
,isc.A.$36d=function isc_RibbonButton__createMenu(_1){if(!_1)return;_1.autoDraw=false;var _2=this.menuConstructor||isc.Menu;this.menu=_2.create(_1)}
,isc.A.propertyChanged=function isc_RibbonButton_propertyChanged(_1,_2){this.invokeSuper(isc.RibbonButton,"propertyChanged",_1,_2);if(this.$257y[_1]){this.getRibbon()&&this.getRibbon().releaseReifySizeLock(this);if(this.$225u){this.$225u.resizeTo(1,1);this.$225u.$225s()}
this.getRibbon()&&this.getRibbon().restoreReifySizeLock(this)}
if(this.editingOn&&this.editProxy){}}
);isc.B._maxIndex=isc.C+29;isc.defineClass("RibbonMenuButton","RibbonButton");isc.A=isc.RibbonMenuButton.getPrototype();isc.A.usePartEvents=true;isc.A.showMenuIcon=true;isc.defineClass("ToolStripGroup","RibbonGroup");isc.defineClass("IconButton","RibbonButton");isc.A=isc.IconButton.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.orientation="horizontal";isc.A.vertical=false;isc.B.push(isc.A.init=function isc_IconButton_init(){var _1=this.Super("init",arguments);if(!window.sessionStorage.iscSkipIconButtonWarning){window.sessionStorage.iscSkipIconButtonWarning=true;this.logWarn("Note that IconButton is deprecated and will be removed in the next major release.  Use RibbonButton instead,")}
return _1}
);isc.B._maxIndex=isc.C+1;isc.defineClass("IconMenuButton","RibbonMenuButton");isc.A=isc.IconMenuButton.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.orientation="horizontal";isc.A.vertical=false;isc.B.push(isc.A.init=function isc_IconMenuButton_init(){var _1=this.Super("init",arguments);if(!window.sessionStorage.iscSkipIconMenuButtonWarning){window.sessionStorage.iscSkipIconMenuButtonWarning=true;this.logWarn("Note that IconMenuButton is deprecated and will be removed in the next major release.  Use RibbonMenuButton instead,")}
return _1}
);isc.B._maxIndex=isc.C+1;isc.defineClass("SectionStack","VLayout");isc.addGlobal("ListBar",isc.SectionStack);isc.A=isc.SectionStack.getPrototype();isc.A.overflow="hidden";isc.A.styleName="sectionStack";isc.A.sectionHeaderClass="SectionHeader";isc.A.headerHeight=20;isc.A.printHeaderStyleName="printHeader";isc.A.tabPanelDefaults={_constructor:"Canvas",overflow:"hidden",visibility:"hidden",hideUsingDisplayNone:true
};isc.A.canResizeSections=true;isc.A.canResizeStack=true;isc.A.canReorderSections=false;isc.A.scrollSectionIntoView=true;isc.A.useGlobalSectionIDs=false;isc.A.animateMemberEffect="wipe";isc.A.visibilityMode="mutex";isc.A.canCollapseAll=true;isc.A.forceFill=true;isc.A.itemIndent=0;isc.A.showExpandControls=true;isc.A=isc.SectionStack.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.canCloseSections=false;isc.A.closeSectionIcon="[SKIN]/actions/close.png";isc.A.closeSectionIconSize=16;isc.A.closeSectionButtonConstructor="Img";isc.A.closeSectionButtonDefaults={click:function(){this.creator.closeSection(this.section)}
};isc.A.sectionNameIndex=0;isc.A.$254k=isc.SectionStack.$254j(["canCloseSections","canCollapseAll","canReorderSections"
]);isc.A.$254p=["name","title","canClose","canReorder","canCollapse","canDropBefore"
];isc.B.push(isc.A.initWidget=function isc_SectionStack_initWidget(){this.Super(this.$oc,arguments);if(this.canReorderSections)this.canAcceptDrop=true;if(this.animateSections!=null)this.animateMembers=this.animateSections;if(this.groups!=null&&this.sections==null)this.sections=this.groups;var _1=this.sections;this.sections=[];this.addSections(_1,null,true)}
,isc.A.setAnimateSections=function isc_SectionStack_setAnimateSections(_1){this.animateSections=this.animateMembers=_1}
,isc.A.setVisibilityMode=function isc_SectionStack_setVisibilityMode(_1){this.visibilityMode=_1;if(_1=="mutex"){var _2=this.getExpandedSections();if(_2!=null&&_2.length>=2){this.collapseSection(_2.slice(1))}
}
if(isc.Canvas.ariaEnabled()){this.updateAriaState();var _3=(_1!="mutex");this.setAriaState("multiselectable",_3);var _4=this.sections;if(_4!=null){for(var i=0,_6=_4.length;i<_6;++i){var _7=_4[i];_7.setAriaState((_3?"expanded":"selected"),!!_7.expanded)}
}
}
}
,isc.A.setShowExpandControls=function isc_SectionStack_setShowExpandControls(_1){this.showExpandControls=_1;for(var i=0;i<this.sections.length;i++){var _3=this.getSectionHeader(this.sections[i]);_3.markForRedraw("setShowExpandControls")}
}
,isc.A.$95u=function isc_SectionStack__doPopOutDragMember(_1,_2){var _3=this.sectionForItem(_2);if(_3){var _4=this.getMemberNumber(_2)-(this.getMemberNumber(_3)+1);this.addItem(_3,_1,_4)}else{this.addMember(_1,this.getMemberNumber(_2),true)}
}
,isc.A.$2097=function isc_SectionStack__replaceMember(_1,_2){var _3=this.getMemberNumber(_1),_4=this.sectionForItem(_1)
;if(!_4){return this.Super("$2097",arguments)}
var _5=this.instantRelayout;this.instantRelayout=false;this.$3q();var _6=this.getMemberNumber(_4);this.removeItem(_4,_1);this.addItem(_4,_2,(_3-_6)-1);this.instantRelayout=_5;if(_5)this.reflowNow()}
,isc.A.$735=function isc_SectionStack__dragIsSectionReorder(){if(this.canReorderSections){var _1=this.ns.EH.dragTarget;return(this.sections!=null&&this.sections.contains(_1))}
return false}
,isc.A.willAcceptDrop=function isc_SectionStack_willAcceptDrop(){if(this.$735()){var _1=this.ns.EH.dragTarget;return(_1.canReorder!=false)}
return this.Super("willAcceptDrop",arguments)}
,isc.A.getStackDropPosition=function isc_SectionStack_getStackDropPosition(){var _1=this.vertical?this.getOffsetY():this.getOffsetX();if(_1<0)return 0;var _2=this.vertical?this.$td:this.$tb,_3=0
;for(var i=0;i<this.members.length;i++){var _5=this.members[i];if(!_5)continue;var _6=_5.isSectionHeader?_5:this.sectionForItem(_5),_7=this.sectionIsExpanded(_6),_8=_5.isVisible()&&_7
;if(_8||(_5==_6)){if(_1<(_2+(_9/2))){if(_5.canDropBefore===false)return false;return i}
var _9=this.memberSizes[_3];_2+=_9+this.membersMargin+this.getMemberGap(_5);_3++}
}
return this.members.length}
,isc.A.getDropPosition=function isc_SectionStack_getDropPosition(_1,_2){if(!this.$735()){if(this.editingOn&&this.editProxy){return this.editProxy.getDropPosition(_1)}else{return this.getStackDropPosition()}
}
var _3=this.vertical?this.getOffsetY():this.getOffsetX();if(_3<0)return 0;var _4=this.vertical?this.$td:this.$tb,_5=this.sections[0],_6=0,_7=0,_8=0;while(_8<this.members.length){var _9=0,_10=this.members[_8],_11=0
;while(_10!=null&&(_10==_5||(_5.items&&_5.items.contains(_10)))){if(_10.isVisible()){_9+=this.memberSizes[_7];_11=this.membersMargin+this.getMemberGap(_10);_9+=_11;_7++}
_8+=1;_10=this.members[_8]}
if(_3<(_4+((_9-_11)/2))){if(_5&&_5.canDropBefore===false)return false;return this.members.indexOf(_5)}
_4+=_9;_6+=1;_5=this.sections[_6]}
return this.members.length}
,isc.A.drop=function isc_SectionStack_drop(){if(!this.willAcceptDrop())return;var _1=this.getDropPosition(),_2=this.getDropComponent(isc.EventHandler.getDragTarget(),_1),_3=this.sections&&this.sections.contains(_2),_4=_2
;if(!_3){if(this.canDropComponents){_4=this.sectionForMemberIndex(_1);var _5=_1-(this.getMemberNumber(_4)+1);this.addItem(_4,_2,_5)}else{this.addMember(_2,_1)}
}else if(_3&&this.canReorderSections){var _6=this.sections.indexOf(_4),_7;var _8=this.members[_1];if(_8==null){_7=this.sections.length}else{for(var i=0;i<this.sections.length;i++){if(_8==this.sections[i]||(this.sections[i].items&&this.sections[i].items.contains(_8)))
{_7=i}
}
}
var _10=_7>_6;if(_10){_7-=1}
if(_7==_6){return}
this.sections.slide(_6,_7);var _11=this.members.indexOf(_4),_12=_11+1,_13=_4.items||[];for(var i=0;i<_13.length;i++){if(this.members.contains(_13[i]))_12+=1}
if(_10)_1-=(_12-_11);this.logInfo("Drag reorder of sections - section:"+_4+" moved to:"+_7+" - reordering members from "+_11+" to "+_12+" target position:"+_1);this.reorderMembers(_11,_12,_1)}
}
,isc.A.shouldCreateCanvas=function isc_SectionStack_shouldCreateCanvas(_1){if(isc.isA.String(_1)&&isc.startsWith(_1,this.$ou)){var _2=_1.substring(this.$ou.length);var _3=this.$226h(_2);if(_3)return _3.shouldCreateChild(_2)};return true}
,isc.A.addItem=function isc_SectionStack_addItem(_1,_2,_3){if(!this.shouldCreateCanvas(_2))return;var _4=this.createCanvas(_2);if(!isc.isA.Canvas(_4)){this.logWarn("addItem passed:"+this.echo(_2)+" cannot be resolved to a Canvas - ignoring");return}
var _5=this.getSection(_1);if(_3==null)_3=0;if(_3>=_5.items.length)_3=_5.items.length;if(_4.resizeable==null){if(!this.canResizeSections)_4.resizeable=false;else if(_1.resizeable!=null){_4.resizeable=_1.resizeable}
}
_5.items.addAt(_4,_3);if(this.isDrawn()&&this.sectionIsExpanded(_5)){var _6=1+this.members.indexOf(_5)+_3;this.addMember(_4,_6);if(isc.Canvas.ariaEnabled()){_1=this.getSectionHeader(_1);if(isc.isA.Canvas(_1)){var _7=_1.items.callMethod("getAriaHandleID");_1.$159g.setAriaState("owns",_7.join(" "))}
}
}else if(_4.isDrawn()){_4.clear();_4.deparent()}
}
,isc.A.removeItem=function isc_SectionStack_removeItem(_1,_2){if(_1==null)_1=this.sectionForItem(_2);if(_1==null)return;var _3=this.getSection(_1);_3.items.remove(_2);if(this.members.contains(_2))this.removeMember(_2,_2.$3v);if(isc.Canvas.ariaEnabled()){_1=this.getSectionHeader(_1);if(isc.isA.Canvas(_1)){var _4=_1.items.callMethod("getAriaHandleID");_1.$159g.setAriaState("owns",_4.join(" "))}
}
}
,isc.A.setItems=function isc_SectionStack_setItems(_1,_2){if(_1==null)return;var _3=this.instantRelayout;this.instantRelayout=false;var _4=this.getSection(_1);while(_4.items.length>0){this.removeItem(_1,_4.items.last())}
if(!isc.isAn.Array(_2))_2=[_2];for(var i=0;i<_2.length;i++){this.addItem(_1,_2[i],i)}
this.instantRelayout=_3;if(_3)this.reflowNow()}
,isc.A.setSectionProperties=function isc_SectionStack_setSectionProperties(_1,_2){var _1=this.getSection(_1);if(_1!=null){if(isc.isA.Canvas(_1)){_1.setProperties(_2)}else{isc.addProperties(_1,_2)}
}
}
,isc.A.removeChild=function isc_SectionStack_removeChild(_1,_2){isc.Layout.$b4.removeChild.call(this,_1,_2);var _3=this.sections;if(_3){for(var i=0;i<_3.length;i++){var _5=_3[i];if(_1==_5){this.removeSection(_1);break}else if(_5.items&&_5.items.contains(_1)){this.removeItem(_5,_1);break}
}
}
}
,isc.A.closeSection=function isc_SectionStack_closeSection(_1){this.removeSection(_1)}
,isc.A.createCloseSectionButton=function isc_SectionStack_createCloseSectionButton(_1){var _2=_1.closeIcon||this.closeSectionIcon,_3=_1.closeIconSize||this.closeSectionIconSize,_4=_3;return this.createAutoChild("closeSectionButton",{section:_1,src:_2,width:_3,height:_4})}
,isc.A.createSectionControls=function isc_SectionStack_createSectionControls(_1){var _2=_1.controls||[];if(!isc.isAn.Array(_2))_2=[_2];var _3=_1.canClose;if(_3==null)_3=this.canCloseSections;if(_3){var _4=this.createCloseSectionButton(_1),_5=_2.indexOf("closeButton");if(_5==-1)_5=_2.length;_2[_5]=_4}
if(_2.length>0){var _6=this.createCanvii(_2);_6.removeEmpty();return _6}
}
,isc.A.addSections=function isc_SectionStack_addSections(_1,_2,_3){if(_1==null)return;if(!isc.isAn.Array(_1))_1=[_1];if(_2==null||_2>this.sections.length){_2=this.sections.length}
var _4=isc.Canvas.ariaEnabled();for(var i=0;i<_1.length;i++){var _6=_1[i];if(!_6)continue;if(_6.showHeader==null)_6.showHeader=true;if(_6.canHide==null)_6.canHide=true;if(_6.canClose==null)_6.canClose=this.canCloseSections;var _7=_6.expanded!=null?_6.expanded:_6.autoShow||_6.showHeader==false;if(_6.hidden==null)_6.hidden=false;if(_6.items==null)_6.items=[];else if(!isc.isA.Array(_6.items))_6.items=[_6.items];else _6.items=_6.items.duplicate();_6.locatorParent=this;for(var j=0;j<_6.items.length;j++){if(isc.isAn.Object(_6.items[j])){isc.Canvas.setCanvasPanelContainer(_6.items[j],this)}
};var _9=isc.ClassFactory.getClass(this.sectionHeaderClass,true),_10=_9.createRaw();if(this.sectionHeaderAriaRole!=null)_10.ariaRole=this.sectionHeaderAriaRole;_10.autoDraw=false;_10._generated=true;_10.expanded=_7;_10.isSectionHeader=true;_10.visibility=(_6.hidden||_6.showHeader==false)?isc.Canvas.HIDDEN:isc.Canvas.INHERIT;_10.dragScrollType="parentsOnly";_10.dragScrollDirection=this.vertical?isc.Canvas.VERTICAL:isc.Canvas.HORIZONTAL;_10.layout=this;if(this.vertical)_10.height=this.headerHeight;else _10.width=this.headerHeight;var _11=null,_12=null,_13=null,_14;if(_6.name!=null)_11=_6.name;if(_6.ID!=null||_6.autoID!=null){if(_11==null)_11=_6.ID||_6.autoID;if(!this.useGlobalSectionIDs){_12=_6.ID;_13=_6.autoID;if(isc.Browser.isSGWT){delete _6.ID;delete _6.autoID;delete _6._autoAssignedID}else{_6.ID=_14;_6.autoID=_14;_6._autoAssignedID=_14}
}else{var _15=window[_6.ID||_6.autoID];if(_15!=null){this.logWarn("Note: Section Stack Section has ID specified as '"+(_6.ID||_6.autoID)+"'. This collides with an existing "+(isc.isA.Canvas(_15)?"SmartClient component ID.":"object reference.")+" The existing object will be replaced by the generated header for this section. To avoid applying section IDs to their corresponding section headers, you can set sectionStack.useGlobalSectionIDs to false")}
}
}
if(_11==null){_11="section"+this.sectionNameIndex++}
var _16=_11,_17=this.sections.find("name",_11);while(_17!=_6&&_17!=null){_11="section"+this.sectionNameIndex++;_17=this.sections.find("name",_11)}
if(_16!=_11){this.logWarn("Specified name for section:"+_16+" collided with name for existing section in this stack. Replacing with auto-generated name:"+_11)}
_6.name=_11;isc.addProperties(_10,_6,this.sectionHeaderProperties,_6.headerProperties);_10.__ref=null;delete _10.__module;_10.$75q=_6;if(this.canReorderSections&&_10.canReorder!=false){_10.canDragReposition=true;_10.canDrop=true}
_10.completeCreation();_10=isc.SGWTFactory.extractFromConfigBlock(_10);_6.$75r=_10;_10.getSectionConfig=function(){return this.$75q};_6.getSectionHeader=function(){return this.$75r};if(_12!=null)_6.ID=_12;if(_13!=null)_6.autoID=_13;_6=_10;this.sections.addAt(_6,_2+i);if(_4){var _18=_6.$159g=this.createAutoChild("tabPanel",{$159h:_6
});this.addChild(_18)}
this.addMember(_6,this.$6k(_6),true);if(_7&&!_6.hidden){this.expandSection(_6)}else{for(var _19=0;_19<_6.items.length;_19++){var _20=_6.items[_19];if(_20.parentElement&&_20.parentElement!=this)_20.deparent();if(isc.isA.Canvas(_20)&&_20.isDrawn())_20.clear()}
}
if(_6.items){if(!this.canResizeSections)_6.items.setProperty("resizeable",false);else if(_6.resizeable!=null){_6.items.setProperty("resizeable",_6.resizeable)}
}
}
if(_3&&this.$6l==null){var _21=_1.first();if(_21&&!(_21.expanded==false)){var _22=this.sections.first();this.expandSection(_22)}
}
}
,isc.A.addSection=function isc_SectionStack_addSection(_1,_2){this.addSections(_1,_2)}
,isc.A.removeSection=function isc_SectionStack_removeSection(_1){if(!isc.isAn.Array(_1))_1=[_1];for(var i=0;i<_1.length;i++){var _3=this.getSectionHeader(_1[i]);if(_3!=null){this.sections.remove(_3);if(_3.$159g!=null){_3.$159g.destroy();_3.$159g=null}
var _4=_3.destroyOnRemove;for(var _5=_3.items.length-1;_5>=0;_5--){var _6=_3.items[_5];if(this.members.contains(_6))this.removeMember(_6);if(_4&&_6&&!_6.destroying&&!_6.destroyed){_6.destroy()}
}
if(!_3.destroying&&!_3.destroyed)_3.destroy()}
}
}
,isc.A.getSectionNames=function isc_SectionStack_getSectionNames(){return this.sections.getProperty("name")}
,isc.A.getSections=function isc_SectionStack_getSections(){return this.getSectionNames()}
,isc.A.reorderSection=function isc_SectionStack_reorderSection(_1,_2){this.moveSection(_1,_2)}
,isc.A.moveSection=function isc_SectionStack_moveSection(_1,_2){if(_2==null)return;if(!isc.isAn.Array(_1))_1=[_1];for(var i=0;i<_1.length;i++){var _4=this.getSectionHeader(_1[i]);if(_4==null){this.logInfo("moveSection(): Unable to find header for specified section:"+_1[i]+", skipping");i--;_1.removeAt(i)}else{_1[i]=_4;this.sections[this.sections.indexOf(_4)]=null}
}
this.sections.removeEmpty();this.sections.addListAt(_1,_2);var _5=0;for(var i=0;i<this.sections.length;i++){var _6=this.getSectionHeader(i),_7=this.members.indexOf(_6),_8=_7+1;var _9=_6.items;if(_9!=null&&_9.length!=0&&this.members.contains(_9[0])){if(_7==-1){_7=this.members.indexOf(_9[0]);_8=_7}
_8+=_9.length}
if(_7==-1)continue;this.members.slideRange(_7,_8,_5);_5+=(_8-_7)}
this.$87o("moveSection() called")}
,isc.A.showSection=function isc_SectionStack_showSection(_1,_2){this.$6m(_1,true,false,_2)}
,isc.A.expandSection=function isc_SectionStack_expandSection(_1,_2){if(!isc.isAn.Array(_1))_1=[_1];if(this.visibilityMode=="mutex"){if(_1.length>1){this.logWarn("expandSection(): only one section can be expanded in 'mutex' visibility mode. Dropping all but the last.");_1=[_1[_1.length-1]]}
var _3=this.$6l,_4=this.getSectionHeader(_1[0]);if(_3&&_3!=_4)this.collapseSection(_3)}
this.$6m(_1,false,true,_2)}
,isc.A.$6m=function isc_SectionStack__showSection(_1,_2,_3,_4){if(_1==null)return;if(!isc.isAn.Array(_1))_1=[_1];var _5=isc.Canvas.ariaEnabled();var _6=[];for(var i=0;i<_1.length;i++){var _8=this.getSectionHeader(_1[i]);if(_8==null){this.logWarn("showSection(): no such section ["+i+"]: "+this.echo(_1[i]));continue}
if(_8.showHeader&&_8.hidden&&(_2||_3)){_6.add(_8);_8.hidden=false;if(_5)_8.$159g.setAriaState("hidden",_8.hidden||!_8.expanded)}
if(_3||_8.expanded){if(_8.setExpanded&&!_8.setOpen)_8.setExpanded(true);else if(_8.setOpen)_8.setOpen(true);this.$6l=_8;if(_8.items!=null&&_8.items.length>0){for(var _9=_8.items.length-1;_9>=0;_9--){if(!this.shouldCreateCanvas(_8.items[_9])){_8.items.removeAt(_9);continue}
var _10=this.createCanvas(_8.items[_9]);if(!isc.isA.Canvas(_10)){this.logWarn("Section with title:"+_8.title+" contains invalid item:"+_8.items[_9]+" - ignoring this item.");_8.items.removeAt(_9);continue}
_8.items[_9]=_10}
var _11=this.$6k(_8)+1;this.addMembers(_8.items,_11,true);_6.addList(_8.items);if(_5){var _12=_8.items.callMethod("getAriaHandleID");_8.$159g.setAriaState("owns",_12.join(" "))}
}
}
}
var _13=this;this.showMembers(_6,function(){_13.$6n(_1,_4)}
)}
,isc.A.$6n=function isc_SectionStack__completeShowOrExpandSection(_1,_2){if(_1.length==0)return;if(this.isDrawn()&&this.scrollSectionIntoView&&(this.overflow==isc.Canvas.SCROLL||this.overflow==isc.Canvas.AUTO))
{var _3=this.getSectionHeader(_1[0]);this.delayCall("$216c",[_3],0)}
if(_2!=null)this.fireCallback(_2)}
,isc.A.$216c=function isc_SectionStack__scrollSectionIntoView(_1){if(!this.vscrollOn||!this.sectionIsVisible(_1))return;var _2=_1.showHeader?_1:_1.items.first();var _3=_2,_4=_1.items;for(var i=0;i<_4.length;i++){if(_4[i].isDrawn()&&_4[i].isVisible())_3=_4[i]}
var _6=_2.getTop();this.scrollIntoView(_2.getLeft(),_6,_2.getVisibleWidth(),_3.getTop()-_6+_3.getVisibleHeight(),"left","top")}
,isc.A.sectionForItem=function isc_SectionStack_sectionForItem(_1){if(this.sections){for(var i=0;i<this.sections.length;i++){var _3=this.sections[i];if(_3){for(var j=0;j<_3.items.length;j++){if(_3.items[j]==_1){return _3}
}
}
}
}
}
,isc.A.sectionForMemberIndex=function isc_SectionStack_sectionForMemberIndex(_1){var _2=-1;if(this.sections){for(var i=this.sections.length-1;i>=0;i--){var _4=this.sections[i];_2=this.getMemberNumber(_4);if(_2<_1)return _4}
}
}
,isc.A.revealChild=function isc_SectionStack_revealChild(_1){if(isc.isA.String(_1))_1=window[_1];var _2=this.sectionForItem(_1);if(_2)this.expandSection(_2)}
,isc.A.hideSection=function isc_SectionStack_hideSection(_1,_2){this.$6o(_1,true,false,_2)}
,isc.A.collapseSection=function isc_SectionStack_collapseSection(_1,_2){this.$6o(_1,false,true,_2)}
,isc.A.$6o=function isc_SectionStack__hideSection(_1,_2,_3,_4){if(_1==null)return;if(!isc.isAn.Array(_1))_1=[_1];var _5=isc.Canvas.ariaEnabled();var _6=[];for(var i=0;i<_1.length;i++){var _8=this.getSectionHeader(_1[i]);if(_8==null){this.logWarn("hideSection(): no such section ["+i+"]: "+this.echo(_1[i]));continue}
if(_2&&!_8.hidden){_8.hidden=true;if(_5)_8.$159g.setAriaState("hidden",_8.hidden||!_8.expanded);_6.add(_8)}
if(_3||_8.expanded){if(_3){if(_8.setExpanded&&!_8.setOpen)_8.setExpanded(false);else if(_8.setOpen)_8.setOpen(false)}
if(this.$6l==_8)this.$6l=null;if(_8.items){for(var j=0;j<_8.items.length;j++){if(this.members.contains(_8.items[j]))_6.add(_8.items[j])}
}
}
}
if(this.forceFill&&this.getVisibleHeight()<=this.getHeight()){var _10=this.getMemberNumber(this.getSectionHeader(_1[0]));var _11;var _12=false;for(var i=_10-1;i>=0;i--){var _13=this.members[i];if(_6.contains(_13))continue;if(this.memberIsDragResizeable(_13)){if(this.memberHasAutoResizeableHeight(_13)){_12=true;break}else if(_11==null){_11=_13}
}
}
if(!_12){for(var i=_10+1;i<this.members.length;i++){var _13=this.members[i];if(_6.contains(_13))continue;if(this.memberIsDragResizeable(_13)){if(this.memberHasAutoResizeableHeight(_13)){_12=true;break}else if(_11==null){_11=_13}
}
}
}
if(!_12&&_11!=null){_11.updateUserSize(null,this.$o5)}
}
this.hideMembers(_6,_4)}
,isc.A.sectionIsVisible=function isc_SectionStack_sectionIsVisible(_1){_1=this.getSectionHeader(_1);if(!_1)return false;if(_1.showHeader&&_1.isVisible())return true;var _2=_1.items.first();if(_2==null||!isc.isA.Canvas(_2)||!_2.isDrawn()||_2.visibility==isc.Canvas.HIDDEN)return false;return true}
,isc.A.getVisibleSections=function isc_SectionStack_getVisibleSections(){var _1=[];for(var i=0;i<this.sections.length;i++)
if(this.sectionIsVisible(this.sections[i]))_1.add(this.sections[i].name);return _1}
,isc.A.sectionIsExpanded=function isc_SectionStack_sectionIsExpanded(_1){return this.getSectionHeader(_1).expanded}
,isc.A.getExpandedSections=function isc_SectionStack_getExpandedSections(){var _1=this.sections.findAll("expanded",true);return _1==null?[]:_1.getProperty("name")}
,isc.A.setSectionTitle=function isc_SectionStack_setSectionTitle(_1,_2){var _3=this.getSectionHeader(_1);if(_3)_3.setTitle(_2)}
,isc.A.getSectionHeader=function isc_SectionStack_getSectionHeader(_1){return isc.Class.getArrayItem(_1,this.sections,"name")}
,isc.A.getSection=function isc_SectionStack_getSection(_1){return this.getSectionHeader(_1)}
,isc.A.getSectionConfig=function isc_SectionStack_getSectionConfig(_1){var _2=this.getSectionHeader(_1);if(!isc.isA.Canvas(_2))return _2;return _2.$75q}
,isc.A.getSectionNumber=function isc_SectionStack_getSectionNumber(_1){if(isc.isA.String(_1)){return this.sections.findIndex("name",_1)}else{return this.sections.indexOf(_1)}
}
,isc.A.$6k=function isc_SectionStack__getSectionPosition(_1){var _2=this.getMemberNumber(_1);if(_2!=-1)return _2;var _3=this.sections.indexOf(_1);if(_3<=0)return _3;var _4=this.sections[_3-1],_5=_4.items?_4.items.last():null;if(this.hasMember(_5)){return this.getMemberNumber(_5)+1}else{return this.getMemberNumber(_4)+1}
}
,isc.A.sectionHeaderClick=function isc_SectionStack_sectionHeaderClick(_1){if(this.onSectionHeaderClick&&(this.onSectionHeaderClick(_1)==false)){return false}
if(this.visibilityMode=="mutex"){if(this.sectionIsExpanded(_1)){this.collapseSection(_1);if(!this.canCollapseAll){var _2=this.sections.indexOf(_1);if(_2==this.sections.getLength()-1)_2=0;else _2+=1;var _3=this.sections[_2];this.expandSection(_3)}
return false}
this.expandSection(_1)}else{if(!this.sectionIsExpanded(_1)){this.expandSection(_1)}else{this.collapseSection(_1)}
}
return false}
,isc.A.getSectionCursor=function isc_SectionStack_getSectionCursor(_1){var _2;var _3=this.getSectionConfig(_1);if(_3==null)_2=isc.Canvas.DEFAULT;else if(_3.cursor)_2=_3.cursor;else{if(_3.canCollapse!=false){_2=isc.Canvas.HAND}else if(this.canRorderSections&&_3.canReorder!=false){_2="move"}else{_2=isc.Canvas.DEFAULT}
}
return _2}
,isc.A.getDragResizeTarget=function isc_SectionStack_getDragResizeTarget(_1){var _2=this.getMemberNumber(_1);var _3;this.$6p=0;for(var i=_2-1;i>=0;i--){var _1=this.getMember(i);if(this.memberIsDragResizeable(_1)){_3=_1;break}
if((_1.isSectionHeader&&this.sectionIsVisible(_1))||(!_1.resizeable&&_1.isVisible()))
{this.$6p+=_1.getVisibleHeight()}
}
if(!_3)return null;if(this.canResizeStack)return _3;var _5=this.getMembers().length;for(var i=_2+1;i<_5;i++){var _1=this.getMember(i);if(this.memberIsDragResizeable(_1))return _3}
return null}
,isc.A.memberIsDragResizeable=function isc_SectionStack_memberIsDragResizeable(_1){if(!_1.isSectionHeader
&&_1.resizeable!==false
&&_1.isVisible()
&&(!this.memberHasInherentLength(_1)||_1.resizeable)
)return true}
,isc.A.memberHasAutoResizeableHeight=function isc_SectionStack_memberHasAutoResizeableHeight(_1){var _2=_1.$po;return _2==null||(isc.isA.String(_2)&&(_2=="*"||isc.endsWith(_2,"%")))}
,isc.A.getMemberDefaultBreadth=function isc_SectionStack_getMemberDefaultBreadth(_1,_2){var _3=_2;if(!_1.isSectionHeader){if(this.itemStartIndent!=null||this.itemEndIndent!=null)
_3-=(this.itemStartIndent==null?0:this.itemStartIndent)+(this.itemEndIndent==null?0:this.itemEndIndent);else _3-=this.itemIndent}
return _3}
,isc.A.getMemberOffset=function isc_SectionStack_getMemberOffset(_1,_2,_3){var _4=this.itemIndent;if(_1.isSectionHeader)return _2;if(this.itemStartIndent!=null)_4=this.itemStartIndent;if(_3==isc.Canvas.RIGHT||_3==isc.Canvas.BOTTOM)
_4*=-1;return _2+_4}
,isc.A.getUISummary=function isc_SectionStack_getUISummary(_1,_2){var _3=this.Super("getUISummary",arguments);var _4=this.sections;if(_4){var _5=[];for(var i=0;i<_4.length;i++){var _7=_4[i];if(this.sectionIsVisible(_7)){var _8=this.$254q(_7,_1);if(_3.members&&_8.items){var _9=_8.items;for(var j=0;j<_9.length;j++){_3.members.removeWhere("id",_9[j].id)}
}
_5.add(_8)}
}
_3.sections=_5}
if(_3.members&&!_3.members.length){delete _3.members}
return _3}
,isc.A.$254q=function isc_SectionStack__getSectionUISummary(_1,_2){var _3={};var _4,_5=this.$254p;for(var i=0;i<_5.length;i++){var _7=_5[i];if(_1.hasOwnProperty(_7)&&_1[_7]!==_4){_3[_7]=_1[_7]}
}
var _8=_1.items,_9=[];for(var i=0;i<_8.length;i++){var _10=_8[i];if(isc.isA.Canvas(_10)&&_10.isVisible()&&!_10._generated){_9.add(_10.getUISummary(_2))}
}
if(_9.length){_3.items=_9}
return _3}
);isc.B._maxIndex=isc.C+57;isc.$6q={icon:"[SKIN]SectionHeader/opener.gif",overflow:"hidden",baseStyle:"sectionHeader",showDisabled:true,expanded:false,setOpen:function(_1){this.setExpanded(_1)},getCustomState:function(){return this.expanded?"opened":"closed"}};isc.$6r={overflow:"hidden",clipTitle:true,showClippedTitleOnHover:true,wrap:false,height:20,expanded:false,canCollapse:true,getSectionStack:function(){var _1=this.layout;if(_1)return isc.isA.String(_1)?window[_1]:_1;else return null},redraw:function(){if(this.shouldShowExpandIcon()){if(!this.icon)this.icon=this.$4u;this.showIconState=true}else{if(!this.$4u)this.$4u=this.icon;this.icon=null;this.showIconState=false}
this.Super("redraw",arguments)},shouldShowExpandIcon:function(){return!(!this.canCollapse||(this.$71i()&&this.getSectionStack()&&this.getSectionStack().showExpandControls==false))},keyPress:function(){var _1=this.getSectionStack();if(_1==null)return;var _2=isc.EH.getKey();if(_2=="Enter"||_2=="Space"){if(this.canCollapse)return _1.sectionHeaderClick(this)}else if(_2=="Arrow_Up"||_2=="Arrow_Down"){var _3=_1.getDragResizeTarget(this);if(_3==null)return false;var _4=(_2=="Arrow_Up"?-5:5);this.bringToFront();this.resizeTarget(_3,true,this.resizeInRealTime,0,0,(this.getPageTop()+_4));this.$6s=_3}
},keyUp:function(){if(this.$6s){var _1=isc.EH.getKey();if(_1=="Arrow_Up"||_1=="Arrow_Down"){this.finishTargetResize(this.$6s,true,this.resizeInRealTime);this.$6s=null}
}
},$kk:function(){if(this.canTabToHeader!=null)return this.canTabToHeader;var _1=this.getSectionStack();if(_1){if(_1.canTabToHeaders!=null)return _1.canTabToHeaders;if(_1.canTabToHeader!=null)return _1.canTabToHeader;if(isc.SectionItem&&isc.isA.SectionItem(_1)){var _2=_1.form;if(_2&&_2.canTabToSectionHeaders!=null)return _2.canTabToSectionHeaders}
return!!isc.screenReader}
else return true},$71i:function(){var _1=this.getSectionStack();return _1?true:false},schemaName:"SectionStackSection",addItem:function(_1,_2){if(!this.$71i())return;var _3=this.getSectionStack();_3.addItem(this,_1,_2);if(this.editingOn||this.expanded)_3.expandSection(this)},removeItem:function(_1){if(!this.$71i())return;this.getSectionStack().removeItem(this,_1)},addControl:function(_1,_2){if(!this.controls)this.controls=[];if(this.controlsLayout){this.controlsLayout.addMembers(this.parentElement.createCanvii([_1]),_2)}else{this.controls.addAt(_1,_2);this.addControls()}
},removeControl:function(_1){if(!this.controls||!this.controlsLayout)return;this.controlsLayout.removeMember(_1)},canDrag:true,dragAppearance:"none",isSectionHeader:true,dragStart:function(){if(!this.$71i())return;var _1=this.getSectionStack().getDragResizeTarget(this);this.$6t=_1;if(_1==null)return false;this.bringToFront()},dragMove:function(){if(!this.$71i())return;var _1=this.getSectionStack().$6p;var _2=0-isc.EH.dragOffsetY;this.resizeTarget(this.$6t,true,this.resizeInRealTime,_2,_1)},dragStop:function(){if(!this.$71i())return;this.finishTargetResize(this.$6t,true,this.resizeInRealTime)},destroy:function(){if(!this.expanded&&this.items){var _1=this.items;for(var i=0;i<_1.length;i++){if(isc.isA.Canvas(_1[i])&&_1[i].parentElement!=this.parentElement){_1[i].destroy()}
}
}
var _3=this.controls,_4=this.controlsLayout;if(_3){if(!isc.isAn.Array(_3))_3=[_3];for(var _5=0;_5<_3.length;_5++){if(_3[_5].destroy&&!_3[_5].destroyed&&(_4==null||_3[_5].parentElement!=_4))
{_3[_5].destroy()}
}
}
return this.Super("destroy",arguments)},controlsLayoutDefaults:{_constructor:isc.HStack,defaultLayoutAlign:"center",membersMargin:5,layoutEndMargin:5,addAsChild:true
},$115j:function(){return(this.controlsLayout==null?null:this.controlsLayout.getVisibleWidth())},getControlsSnapTo:function(){var _1=this.isRTL();return _1?"L":"R"},addControls:function(){var _1=this.getSectionStack();var _2;if(_1==null||!isc.isA.SectionStack(_1)){_2=this.controls;if(_2){if(!isc.isAn.Array(_2))_2=[_2];var _3=this.parentElement||this;if(_2.length>0){_2=this.parentElement.createCanvii(_2);_2.removeEmpty()}
}
}else{_2=_1.createSectionControls(this)}
if(_2==null||_2.length==0)return;var _4=this.isRTL();var _5=this.getControlsSnapTo();this.addAutoChild("controlsLayout",{height:this.getInnerHeight(),align:_4?"left":"right",snapTo:_5,members:_2,resized:function(){var _6=this.creator,_7=this.creator.background;if(_7!=null)_6=_7.label;_6.markForRedraw()}
});this.allowContentAndChildren=true},getPrintStyleName:function(){var _1=this.parentElement;if(_1&&_1.printHeaderStyleName!=null){this.printStyleName=_1.printHeaderStyleName}
return this.Super("getPrintStyleName",arguments)},shouldPrint:true};isc.defineClass("SectionHeader","Label");isc.A=isc.SectionHeader.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.useContents=false;isc.A.noDoubleClicks=true;isc.B.push(isc.A.setExpanded=function isc_SectionHeader_setExpanded(_1){this.expanded=_1;if(isc.Canvas.ariaEnabled()){if(this.$159g!=null)this.$159g.setAriaState("hidden",this.hidden||!_1);var _2=this.layout;if(isc.isA.SectionStack(_2)){var _3=(_2.visibilityMode!="mutex");if(_3){this.setAriaState("expanded",!!_1)}else{this.setAriaState("selected",!!_1)}
}
}
this.stateChanged()}
,isc.A.click=function isc_SectionHeader_click(){if(this.contains(isc.EH.lastTarget))return;if(!this.canCollapse||!this.$71i())return;if(this.contains(isc.EH.mouseDownTarget()))return false;this.$203s();if(((this.parentElement&&this.parentElement.editingOn)||this.editingOn)&&!this.noDoubleClicks){this.$203t=this.getSectionStack().delayCall("sectionHeaderClick",[this],isc.EH.DOUBLE_CLICK_DELAY);return}
return this.getSectionStack().sectionHeaderClick(this)}
,isc.A.$203s=function isc_SectionHeader__clearPendingClickTimer(){if(this.$203t){isc.Timer.clear(this.$203t);delete this.$203t}
}
,isc.A.draw=function isc_SectionHeader_draw(_1,_2,_3,_4){if(isc.$cv)arguments.$cw=this;if(!this.readyToDraw())return;if(!this.shouldShowExpandIcon()){if(this.icon)this.$4u=this.icon;this.icon=null;this.showIconState=false}
this.setCursor(this.getCurrentCursor());this.invokeSuper(isc.SectionHeader,"draw",_1,_2,_3,_4);this.addControls();if(this.headerControls!=null){this.headerLayout=isc.HLayout.create({autoDraw:false,width:this.getInnerWidth(),height:this.getInnerHeight(),members:this.headerControls
});this.addChild(this.headerLayout);this.allowContentAndChildren=true}
}
,isc.A.getCurrentCursor=function isc_SectionHeader_getCurrentCursor(){var _1=this.cursor;if(this.getSectionStack()&&this.getSectionStack().getSectionCursor!=null){_1=this.getSectionStack().getSectionCursor(this)}
return _1}
);isc.B._maxIndex=isc.C+5;isc.SectionHeader.addMethods(isc.$6r,isc.$6q);isc.defineClass("ImgSectionHeader","HLayout");isc.A=isc.ImgSectionHeader.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$115g=true;isc.A.noDoubleClicks=true;isc.A.backgroundDefaults=isc.addProperties({titleStyle:"sectionHeaderTitle",src:"[SKIN]SectionStack/header.gif",backgroundColor:"#a0a0a0",setExpanded:function(_1){this.expanded=_1;this.stateChanged()},click:function(){if(this.parentElement&&this.parentElement.editingOn){return this.Super("click",arguments)}
if(this.parentElement.canCollapse){if(this.parentElement.getSectionStack())
return this.parentElement.getSectionStack().sectionHeaderClick(this.parentElement)}
},width:"100%",height:"100%",addAsChild:true,getFocusedAsOverState:function(){if(!this.showFocused||!this.showFocusedAsOver||this.isDisabled())return false;return this.creator.hasFocus},getFocusedState:function(){if(!this.showFocused||this.showFocusedAsOver||this.isDisabled())return false;return this.creator.hasFocus},getPrintStyleName:function(){if(this.parentElement)return this.parentElement.getPrintStyleName();return this.Super("getPrintStyleName",arguments)}
},isc.$6q);isc.B.push(isc.A.getCanHover=function isc_ImgSectionHeader_getCanHover(_1,_2,_3){return this.$115g||this.invokeSuper(isc.ImgSectionHeader,"getCanHover",_1,_2,_3)}
,isc.A.$lf=function isc_ImgSectionHeader__focusChanged(_1,_2,_3,_4){var _5=this.invokeSuper(isc.StatefulCanvas,"$lf",_1,_2,_3,_4);var _6=this.background;if(_6!=null&&_6.showFocused){_6.updateStateForFocus(_1)}
return _5}
,isc.A.setExpanded=function isc_ImgSectionHeader_setExpanded(_1){this.expanded=_1;if(isc.Canvas.ariaEnabled()){if(this.$159g!=null)this.$159g.setAriaState("hidden",this.hidden||!_1);var _2=this.layout;if(isc.isA.SectionStack(_2)){var _3=(_2.visibilityMode!="mutex");if(_3){this.setAriaState("expanded",!!_1)}else{this.setAriaState("selected",!!_1)}
}
}
if(this.background!=null)this.background.setExpanded(_1)}
,isc.A.setOpen=function isc_ImgSectionHeader_setOpen(_1){this.setExpanded(_1)}
,isc.A.setTitle=function isc_ImgSectionHeader_setTitle(_1){this.title=_1;if(this.background)this.background.setTitle(_1)}
,isc.A.setIcon=function isc_ImgSectionHeader_setIcon(_1){this.icon=_1;if(this.background)this.background.setIcon(_1)}
,isc.A.setIconOrientation=function isc_ImgSectionHeader_setIconOrientation(_1){this.orientation=_1;if(this.background)this.background.setIconOrientation(_1)}
,isc.A.setAlign=function isc_ImgSectionHeader_setAlign(_1){this.align=_1;if(this.background)this.background.setAlign(_1)}
,isc.A.setPrompt=function isc_ImgSectionHeader_setPrompt(_1){this.prompt=_1;if(this.background)this.background.setPrompt(_1)}
,isc.A.draw=function isc_ImgSectionHeader_draw(_1,_2,_3,_4){if(isc.$cv)arguments.$cw=this;if(!this.readyToDraw())return;this.setupBackground();this.addControls();this.addAutoChildren(this.headerControls);this.background.sendToBack();this.invokeSuper(isc.ImgSectionHeader,"draw",_1,_2,_3,_4)}
,isc.A.setupBackground=function isc_ImgSectionHeader_setupBackground(){var _1={title:this.title,clipTitle:this.clipTitle,showClippedTitleOnHover:false,$115g:false,expanded:this.expanded,canFocus:false
};if(this.align){_1.align=this.align}else{var _2=isc.SectionHeader.getInstanceProperty("align");if(_2!=null){_1.align=_2}
}
if(this.prompt)_1.prompt=this.prompt;if(this.icon)_1.icon=this.icon;if(this.iconSize)_1.iconSize=this.iconSize;if(this.iconHeight)_1.iconHeight=this.iconHeight;if(this.iconWidth)_1.iconWidth=this.iconWidth;if(this.iconAlign)_1.iconAlign=this.iconAlign;if(this.iconOrientation)_1.iconOrientation=this.iconOrientation;if(!this.shouldShowExpandIcon()){_1.icon=null;_1.showIconState=false}
_1.canDragReposition=this.canDragReposition;_1.canDrop=this.canDrop;_1.dragTarget=this;var _3=this.getCurrentCursor();this.setCursor(_3);_1.cursor=_3;_1.$115j=function(){var _4=this.creator.controlsLayout;return(_4==null?null:_4.getVisibleWidth())};if(this.background==null){this.addAutoChild("background",_1,isc.StretchImgButton)}else{this.background.setProperties(_1)}
}
,isc.A.getCurrentCursor=function isc_ImgSectionHeader_getCurrentCursor(){var _1=this.cursor;if(this.getSectionStack()&&this.getSectionStack().getSectionCursor!=null){_1=this.getSectionStack().getSectionCursor(this)}
return _1}
,isc.A.getPrintHTML=function isc_ImgSectionHeader_getPrintHTML(_1){if(this.background==null)this.setupBackground();return this.background.getPrintHTML(_1)}
,isc.A.titleClipped=function isc_ImgSectionHeader_titleClipped(){return(this.background==null?false:this.background.titleClipped())}
,isc.A.defaultTitleHoverHTML=function isc_ImgSectionHeader_defaultTitleHoverHTML(){return(this.background==null?null:this.background.defaultTitleHoverHTML())}
,isc.A.titleHoverHTML=function isc_ImgSectionHeader_titleHoverHTML(_1){return _1}
,isc.A.handleHover=function isc_ImgSectionHeader_handleHover(_1,_2,_3){if(this.canHover==null&&this.prompt)return this.invokeSuper(isc.ImgSectionHeader,"handleHover",_1,_2,_3);if(!this.showClippedTitleOnHover||!this.titleClipped()){if(this.canHover)return this.invokeSuper(isc.ImgSectionHeader,"handleHover",_1,_2,_3);else return}
if(this.titleHover&&this.titleHover()==false)return;var _4=this.titleHoverHTML(this.defaultTitleHoverHTML());if(_4!=null&&!isc.isAn.emptyString(_4)){var _5=this.$wc();isc.Hover.show(_4,_5,null,this)}
}
);isc.B._maxIndex=isc.C+17;isc.ImgSectionHeader.addMethods(isc.$6r)
isc.ImgSectionHeader.registerStringMethods({titleHover:""});isc.SectionStack.registerStringMethods({onSectionHeaderClick:"sectionHeader"});isc.SectionStack.registerDupProperties("sections",["items","controls"]);isc.defineClass("SectionHeaderLayout",isc.HLayout);isc.SectionHeaderLayout.addProperties(isc.$6q,isc.$6r)
isc.A=isc.SectionHeaderLayout.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.titleLabelConstructor=isc.SectionHeader;isc.A.titleLabelDefaults={isSectionHeader:false,width:"*",height:"*",border:"0px",backgroundColor:"transparent",backgroundImage:isc.Canvas.$wz,shouldShowExpandIcon:function(){return this.creator.shouldShowExpandIcon()},getCurrentCursor:function(){return this.creator.getCurrentCursor()},$kk:function(){return false},stateChanged:function(){this.Super("stateChanged",arguments);this.creator.updateStateStyling()}
};isc.A.expanded=false;isc.A.canCollapse=true;isc.A.layoutMargin=0;isc.A.defaultLayoutAlign="center";isc.B.push(isc.A.initWidget=function isc_SectionHeaderLayout_initWidget(){this.addAutoChild("titleLabel",{title:this.title,expanded:this.expanded
}
)}
,isc.A.getControlsSnapTo=function isc_SectionHeaderLayout_getControlsSnapTo(){return null}
,isc.A.setTitle=function isc_SectionHeaderLayout_setTitle(_1){this.title=_1;if(this.titleLabel)this.titleLabel.setTitle(_1)}
,isc.A.updateStateStyling=function isc_SectionHeaderLayout_updateStateStyling(){if(this.titleLabel)return this.setStyleName(this.titleLabel.getStateName())}
,isc.A.draw=function isc_SectionHeaderLayout_draw(_1,_2,_3,_4){if(isc.$cv)arguments.$cw=this;if(!this.readyToDraw())return;this.updateStateStyling();this.addControls();this.invokeSuper(isc.SectionHeaderLayout,"draw",_1,_2,_3,_4)}
,isc.A.setExpanded=function isc_SectionHeaderLayout_setExpanded(_1){this.expanded=_1;this.titleLabel.setExpanded(_1)}
,isc.A.click=function isc_SectionHeaderLayout_click(){if(!this.canCollapse||!this.$71i())return;var _1=isc.EH.mouseDownTarget();if(_1!=this&&_1!=this.titleLabel&&_1!=this.controlsLayout)return;this.$203s();if(((this.titleLabel&&this.titleLabel.editingOn)||this.editingOn)&&!this.noDoubleClicks){this.$203t=this.getSectionStack().delayCall("sectionHeaderClick",[this],isc.EH.DOUBLE_CLICK_DELAY);return}
return this.getSectionStack().sectionHeaderClick(this)}
,isc.A.$203s=function isc_SectionHeaderLayout__clearPendingClickTimer(){if(this.$203t){isc.Timer.clear(this.$203t);delete this.$203t}
}
);isc.B._maxIndex=isc.C+8;isc.SectionHeaderLayout.changeDefaults("controlsLayoutDefaults",{addAsChild:null,snapTo:null,width:1
});isc.$225q={vertical:true,setScrollTarget:function(_1){var _2=this.scrollTarget;if(this.$u3&&this.scrollTarget!=null&&this.isObserving(this.scrollTarget,"scrollTo"))
{this.ignore(this.scrollTarget,"scrollTo");this.ignore(this.scrollTarget,"$ut")}
if(this.scrollTarget&&this.scrollTarget.receiveScrollbarEvents){this.$192o()}
if(_1!=null)this.scrollTarget=_1;if(this.scrollTarget==null)this.scrollTarget=this;var _3=this.scrollTarget;if(this.$u3&&_3!=this){this.observe(_3,"scrollTo","observer.setThumb()");this.observe(_3,"$ut","observer.setThumb()");this.$169y(_3)}
if(_3.receiveScrollbarEvents)this.$192o(_3);this.scrollTargetChanged(_2,_3)},$169y:function(_1){var _2;if(this.vertical){_1.$169v=this;_2=_1.$169u}else{_1.$169u=this;_2=_1.$169v}
},$192o:function(_1){},scrollTargetChanged:function(_1,_2){this.setThumb()},scrollTargetMouseMove:function(){},setThumb:function(){},setShowCorner:function(_1){this.showCorner=_1},$u3:true,$192q:function(_1){return false}}
isc.ClassFactory.defineClass("Scrollbar","StretchImg");isc.Scrollbar.addProperties(isc.$225q)
isc.$89p={autoDraw:false,_generated:true,$131p:true,$jp:false,$jo:false,_redrawWithParent:false,containedPeer:true,triggerAreaTop:0,triggerAreaRight:0,triggerAreaBottom:0,triggerAreaLeft:0,$194y:function(_1){var _2=this.scrollbar.vertical,_3=isc.Browser.isTouch?8:0,_4=isc.Browser.minDualInputThumbLength
;if(_2){var _5=_1==null?isc.Page.isRTL():_1.isRTL();this.setTriggerAreaLeft(!_5?_3:0);this.setTriggerAreaRight(_5?_3:0);if(_4!=null&&isc.Browser.hasDualInput){var _6=this.getVisibleHeight();_3=_6<_4?Math.ceil((_4-_6)/2):0;this.setTriggerAreaTop(_3);this.setTriggerAreaBottom(_3)}
}else{this.setTriggerAreaTop(_3);this.setTriggerAreaBottom(0);if(_4!=null&&isc.Browser.hasDualInput){var _7=this.getVisibleWidth();_3=_7<_4?Math.ceil((_4-_7)/2):0;this.setTriggerAreaLeft(_3);this.setTriggerAreaRight(_3)}
}
},enableTouchSupport:function(){this.Super("enableTouchSupport",arguments);if(this.triggerArea)this.$194y()},showDisabled:false,skinImgDir:"images/Scrollbar/",canDrag:true,dragAppearance:isc.EventHandler.NONE,dragStartDistance:0,dragScrollType:"parentsOnly",click:isc.EventHandler.stopBubbling,doubleClick:isc.EventHandler.stopBubbling,mouseMove:isc.EventHandler.stopBubbling,showContextMenu:function(){if(this.ns.EH.$129k())return false},mouseOver:function(){return this.scrollbar.thumbOver()},mouseOut:function(_1){return this.scrollbar.thumbOut(_1)},mouseDown:function(){return this.scrollbar.thumbDown()},dragStart:function(){return this.scrollbar.thumbDragStart()},dragMove:function(){return this.scrollbar.thumbMove()},dragStop:function(){return this.scrollbar.thumbDragStop()},mouseUp:function(){return this.scrollbar.thumbUp()},keyPress:function(){return this.ns.EH.bubbleEvent(this.scrollbar,this.ns.EH.eventTypes.KEY_PRESS)},keyDown:function(){return this.ns.EH.bubbleEvent(this.scrollbar,this.ns.EH.eventTypes.KEY_DOWN)},keyUp:function(){return this.ns.EH.bubbleEvent(this.scrollbar,this.ns.EH.eventTypes.KEY_UP)},mouseWheel:function(){return this.ns.EH.bubbleEvent(this.scrollbar,this.ns.EH.eventTypes.MOUSE_WHEEL)},masterMoved:function(){var _1=this.masterElement;if(_1&&_1.$ss)return;this.Super("masterMoved",arguments)}};if(isc.Browser.minDualInputThumbLength!=null){isc.$89p.triggerAreaDefaults=isc.addProperties({},isc.StatefulCanvas.getPrototype().triggerAreaDefaults,{$1515:function(){var _1=this.masterElement;_1.$194y();this.setRect(_1.$1516())}
})}
isc.defineClass("ScrollThumb","StretchImg").addProperties(isc.$89p)
isc.A=isc.ScrollThumb.getPrototype();isc.A.hSrc="[SKIN]hthumb.gif";isc.A.vSrc="[SKIN]vthumb.gif";isc.A.backgroundColor="#EEEEEE";isc.A.textDirection="ltr";isc.A.capSize=2;isc.defineClass("HScrollThumb",isc.ScrollThumb);isc.A=isc.HScrollThumb.getPrototype();isc.A.vertical=false;isc.defineClass("VScrollThumb",isc.ScrollThumb);isc.A=isc.VScrollThumb.getPrototype();isc.A.vertical=true;isc.defineClass("SimpleScrollThumb","Img").addProperties(isc.$89p)
isc.A=isc.SimpleScrollThumb.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.title="&nbsp;";isc.A.titleStyle="normal";isc.A.overflow="hidden";isc.A.vBaseStyle="vScrollThumb";isc.A.hBaseStyle="hScrollThumb";isc.A.imageType="center";isc.A.hSrc="[SKIN]hthumb_grip.gif";isc.A.vSrc="[SKIN]vthumb_grip.gif";isc.A.showRollOver=true;isc.A.statelessImage=true;isc.B.push(isc.A.initWidget=function isc_SimpleScrollThumb_initWidget(){if(this.vertical){this.src=this.vSrc||this.src;this.baseStyle=this.vBaseStyle||this.baseStyle}else{this.src=this.hSrc||this.src;this.baseStyle=this.hBaseStyle||this.baseStyle}
this.Super("initWidget",arguments)}
);isc.B._maxIndex=isc.C+1;isc.defineClass("HSimpleScrollThumb",isc.SimpleScrollThumb);isc.A=isc.HSimpleScrollThumb.getPrototype();isc.A.vertical=false;isc.defineClass("VSimpleScrollThumb",isc.SimpleScrollThumb);isc.A=isc.VSimpleScrollThumb.getPrototype();isc.A.vertical=true;isc.A=isc.Scrollbar.getPrototype();isc.A.state=isc.StatefulCanvas.STATE_UP;isc.A.autoEnable=true;isc.A.allowThumbDownState=false;isc.A.allowThumbOverState=false;isc.A.showTrackEnds=false;isc.A.showTrackButtons=true;isc.A.thumbMinSize=12;isc.A.trackEndWidth=12;isc.A.trackEndHeight=12;isc.A.thumbOverlap=1;isc.A.thumbInset=0;isc.A.overflow=isc.Canvas.HIDDEN;isc.A.skinImgDir="images/Scrollbar/";isc.A.cornerSrc="[SKIN]corner.gif";isc.A.hSrc="[SKIN]hscroll.gif";isc.A.vSrc="[SKIN]vscroll.gif";isc.A.hThumbClass=isc.HScrollThumb;isc.A.vThumbClass=isc.VScrollThumb;isc.A.startImg={name:"start",width:"btnSize",height:"btnSize",browserTouchCallout:false};isc.A.trackStartImg={name:"track_start",width:"trackStartSize",height:"trackStartSize",browserTouchCallout:false};isc.A.trackImg={name:"track",width:"*",height:"*",browserTouchCallout:false};isc.A.trackEndImg={name:"track_end",width:"trackEndSize",height:"trackEndSize",browserTouchCallout:false};isc.A.endImg={name:"end",width:"btnSize",height:"btnSize",browserTouchCallout:false};isc.A.cornerImg={name:"corner",browserTouchCallout:false};isc.A.textDirection="ltr";isc.A.showThumb=true;isc.A=isc.Scrollbar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$52l="thumb";isc.A.trackMinSize=1;isc.A.autoApplyDownState=false;isc.A.autoApplyOverState=false;isc.A.click=isc.EventHandler.stopBubbling;isc.A.handleMouseOver=isc.EH.stopBubbling;isc.B.push(isc.A.initWidget=function isc_Scrollbar_initWidget(){this.invokeSuper(isc.Scrollbar,"initWidget");var _1=this.cornerSize||"otherScrollbarSize";this.$6x=isc.addProperties({},this.cornerImg,{width:_1,height:_1});if(null==this.startThumbOverlap)this.startThumbOverlap=this.thumbOverlap;if(null==this.endThumbOverlap)this.endThumbOverlap=this.thumbOverlap;this.setItems();var _2=this.btnSize=this.btnSize||this.scrollbarSize;this.setBreadth(_2)
this.makeThumb();this.addPeer(this.thumb);this.setScrollTarget(this.scrollTarget)}
,isc.A.getBreadth=function isc_Scrollbar_getBreadth(){return this.vertical?this.getWidth():this.getHeight()}
,isc.A.setBreadth=function isc_Scrollbar_setBreadth(_1){if(this.vertical)this.setWidth(_1);else this.setHeight(_1)}
,isc.A.getOtherScrollbarSize=function isc_Scrollbar_getOtherScrollbarSize(){var _1=this.scrollTarget;if(this.$u3&&_1!=null){var _2=this.vertical?_1.$169u:_1.$169v;if(_2)return _2.getBreadth()}
return this.getBreadth()}
,isc.A.setItems=function isc_Scrollbar_setItems(){var _1=this.items=[];if(this.showTrackButtons==true)_1.add(this.startImg);if(this.showTrackEnds==true)_1.add(this.trackStartImg);_1.add(this.trackImg);if(this.showTrackEnds==true)_1.add(this.trackEndImg);if(this.showTrackButtons==true)_1.add(this.endImg);if(this.showCorner)this.items.add(this.$6x)}
,isc.A.$169w=function isc_Scrollbar__resizeItems(_1){this.setItems();this.resizeImages();this.setThumb();this.markForRedraw(_1||"resizeItems")}
,isc.A.setShowCorner=function isc_Scrollbar_setShowCorner(_1){_1=_1!=false;if(this.showCorner!=_1){this.showCorner=_1;this.$169w("showCorner")}
return _1}
,isc.A.$169x=function isc_Scrollbar__getCornerSize(){var _1=this.getPartNum(this.cornerImg.name);return _1!=null?this.getSize(_1):null}
,isc.A.$169y=function isc_Scrollbar__setScrollbarOnTarget(_1){var _2;if(this.vertical){_1.$169v=this;_2=_1.$169u}else{_1.$169u=this;_2=_1.$169v}
if(_2){var _3=_2.$169x();if(isc.isA.Number(_3)&&_3!=this.getBreadth()){_2.$169w("scrollbarDependency")}
}}
,isc.A.scrollTargetChanged=function isc_Scrollbar_scrollTargetChanged(_1,_2){if(this.$u3){var _3=this.vertical?"$169v":"$169u",_4=_1&&(_1[_3]==this),_5=_4&&(_1==_2);if(!_5){if(_4)delete _1[_3];this.$169y(_2)}
}
if(this.thumb!=null)this.thumb.$194y(_2);this.setThumb()}
,isc.A.setHandleDisabled=function isc_Scrollbar_setHandleDisabled(_1){this.Super("setHandleDisabled",arguments);if(this.thumb){if(this.scrollTarget&&this.scrollTarget.$61c){if(_1)this.thumb.delayCall("setVisibility",[isc.Canvas.HIDDEN]);else this.thumb.delayCall("setVisibility",[this.visibility])}else{if(_1)this.thumb.setVisibility(isc.Canvas.HIDDEN);else this.thumb.setVisibility(this.visibility)}
this.thumb.$jq=!_1}
if(_1==(this.state==isc.StatefulCanvas.STATE_UP)){this.setState(_1?isc.StatefulCanvas.STATE_DISABLED:isc.StatefulCanvas.STATE_UP)}}
,isc.A.setVisibility=function isc_Scrollbar_setVisibility(_1,_2,_3,_4){this.invokeSuper(isc.Scrollbar,"setVisibility",_1,_2,_3,_4);if(this.isVisible())this.setThumb()}
,isc.A.parentVisibilityChanged=function isc_Scrollbar_parentVisibilityChanged(_1,_2,_3,_4){this.invokeSuper(isc.Scrollbar,"parentVisibilityChanged",_1,_2,_3,_4);if(this.isVisible())this.setThumb()}
,isc.A.drawPeers=function isc_Scrollbar_drawPeers(_1,_2,_3,_4){this.setThumb();this.invokeSuper(isc.Scrollbar,"drawPeers",_1,_2,_3,_4)}
,isc.A.resizePeersBy=function isc_Scrollbar_resizePeersBy(_1,_2){this.setThumb()}
,isc.A.makeThumb=function isc_Scrollbar_makeThumb(){if(!this.showThumb)return;var _1=this.scrollTarget==null?isc.Page.isRTL():this.scrollTarget.isRTL(),_2=isc.Browser.isTouch?8:0
;var _3=this.vertical?this.vThumbClass:this.hThumbClass;this.thumb=_3.create({ID:this.getID()+"_thumb",scrollbar:this,state:this.state,visibility:this.visibility,autoApplyDownState:false,autoApplyOverState:false,width:this.vertical?this.getWidth():1,height:!this.vertical?this.getHeight():1,showTriggerArea:!!this.showThumbTriggerArea,triggerAreaLeft:this.vertical&&!_1?_2:0,triggerAreaRight:this.vertical&&_1?_2:0,triggerAreaTop:!this.vertical?_2:0,dragScrollDirection:this.vertical?isc.Canvas.VERTICAL:isc.Canvas.HORIZONTAL
});if(this.thumb.showRollOver){this.allowThumbOverState=true
}
if(this.thumb.showDown){this.allowThumbDownState=true}}
,isc.A.updateButtonsOnEdges=function isc_Scrollbar_updateButtonsOnEdges(){if(this.disableButtonsOnEdges){var _1=this.scrollTarget.getScrollRatio(this.vertical);var _2=this.scrollTarget.getViewportRatio(this.vertical);if(_1==0){this.setState(isc.StatefulCanvas.STATE_DISABLED,this.startImg.name)}else{this.setState(isc.StatefulCanvas.STATE_UP,this.startImg.name)}
if(_1==1||_2>=1){this.setState(isc.StatefulCanvas.STATE_DISABLED,this.endImg.name)}else{this.setState(isc.StatefulCanvas.STATE_UP,this.endImg.name)}
}}
,isc.A.setThumb=function isc_Scrollbar_setThumb(){this.updateButtonsOnEdges();if(this.thumb==null||this.$494)return;this.$189g();var _1=this.thumb,_2=this.trackSize();if(this.isDrawn()&&_1.isDrawn())_1.moveAbove(this);var _3=Math.round(this.scrollTarget.getViewportRatio(this.vertical)*_2);if(!isc.isA.Number(_3)||_3<this.thumbMinSize)_3=this.thumbMinSize;if(_3>_2)_3=_2;var _4=Math.max(1,(this.vertical?this.getWidth():this.getHeight())
-(2*this.thumbInset));this.vertical?_1.resizeTo(_4,_3):_1.resizeTo(_3,_4);this.moveThumb()}
,isc.A.$192q=function isc_Scrollbar__hasScrollTargetEventParent(_1){if(this.disabled)return false;return _1==this||_1&&_1==this.thumb}
,isc.A.setZIndex=function isc_Scrollbar_setZIndex(_1){this.Super("setZIndex",arguments);if(this.thumb)this.thumb.moveAbove(this)}
,isc.A.moveThumbTo=function isc_Scrollbar_moveThumbTo(_1){if(!this.thumb)return;if(this.vertical)
return this.thumb.moveTo(this.getLeft()+this.thumbInset,_1);else
return this.thumb.moveTo(_1,this.getTop()+this.thumbInset)}
,isc.A.thumbSize=function isc_Scrollbar_thumbSize(){if(!this.thumb)return;return(this.vertical?this.thumb.getHeight():this.thumb.getWidth())}
,isc.A.moveThumb=function isc_Scrollbar_moveThumb(){var _1=(this.$u3||this.scrollTarget.canScroll(this.vertical));if(!_1){if(this.autoEnable)this.disable();this.moveThumbTo(this.trackStart());return}
if(this.autoEnable&&!this.scrollTarget.isDisabled())this.enable();var _2=this.scrollTarget.getScrollRatio(this.vertical),_3=this.trackSize()-this.thumbSize(),_4=Math.round(_2*_3);this.moveThumbTo(_4+this.trackStart());var _5=isc.EH;if(_5.mouseIsDown()&&(_5.mouseDownTarget()==this)&&this.thumb.containsEvent())
this.doneTrackScrolling()}
,isc.A.$189g=function isc_Scrollbar__adjustThumbOverlap(){this.$189h=this.startThumbOverlap;this.$189i=this.endThumbOverlap;var _1=this.trackMinSize-this.trackSize();if(_1<=0)return;var _2=this.$189h-this.$189i;if(_2>0){var _3=Math.min(_1,_2);_1-=_3,this.$189i+=_3}else if(_2<0){var _3=Math.min(_1,-_2);_1-=_3,this.$189h+=_3}
if(_1<=0)return;var _4=_1>>1,_5=_1-_4;this.$189h+=_4;this.$189i+=_5}
,isc.A.trackSize=function isc_Scrollbar_trackSize(){return this.getSize(this.getPartNum(this.trackImg.name))+(this.showTrackEnds!=false?(this.getSize(this.getPartNum(this.trackStartImg.name))+this.getSize(this.getPartNum(this.trackEndImg.name)))
:0)+this.$189h+this.$189i}
,isc.A.trackStart=function isc_Scrollbar_trackStart(){return(this.vertical?this.getTop():this.getLeft())+(this.showTrackButtons==true?this.getSize(this.getPartNum(this.startImg.name)):0)-this.$189h}
,isc.A.directionRelativeToThumb=function isc_Scrollbar_directionRelativeToThumb(){if(!this.thumb){if(this.clickPart==this.startImg.name)return-1;else return 1}
var _1,_2=this.thumb,_3,_4;if(this.vertical){_1=isc.EH.getY();_3=_2.getPageTop();_4=_2.getHeight()}else{_1=isc.EH.getX();_3=_2.getPageLeft();_4=_2.getWidth()}
if(_1<_3)return-1;else if(_1>_3+_4)return 1;return 0}
,isc.A.mouseDown=function isc_Scrollbar_mouseDown(){this.clickPart=this.inWhichPart();if(this.clickPart==this.cornerImg.name){this.clickPart=null}else{this.$615(isc.StatefulCanvas.STATE_DOWN,this.clickPart)}
this.startDirection=this.directionRelativeToThumb();return isc.EH.STOP_BUBBLING}
,isc.A.mouseStillDown=function isc_Scrollbar_mouseStillDown(){if(this.clickPart==this.trackImg.name||this.showTrackEnds==true&&(this.clickPart==this.trackStartImg.name||this.clickPart==this.trackEndImg.name)){var _1=this.directionRelativeToThumb();if(_1!=0&&_1==this.startDirection){if(this.$50y){delete this.$50y;this.$50o=true}else if(!this.$50o)
this.$50y=true;this.scrollTarget.scrollByPage(this.vertical,this.startDirection,"trackClick")}
}else{this.scrollTarget.scrollByDelta(this.vertical,this.startDirection,"trackButtonClick")}
return true}
,isc.A.doubleClick=function isc_Scrollbar_doubleClick(){if(isc.Browser.isIE)return this.mouseStillDown();return isc.EH.STOP_BUBBLING}
,isc.A.handleShowContextMenu=function isc_Scrollbar_handleShowContextMenu(){if(this.ns.EH.$129k())return false}
,isc.A.$615=function isc_Scrollbar__updateItemStates(_1,_2){if(_2==null)return this.setState(_1);var _3=isc.StatefulCanvas.STATE_UP,_4=(_2==this.trackImg.name||_2==this.trackStartImg.name||_2==this.trackEndImg.name),_5=!_4&&_2==this.startImg.name,_6=!_4&&!_5&&_2==this.endImg.name,_7=!_4&&!_5&&!_6,_8=_4?_1:_3;this.setState(_5?_1:_3,this.startImg.name);this.setState(_8,this.trackImg.name);if(this.showTrackEnds)this.setState(_8,this.trackStartImg.name);if(this.showTrackEnds)this.setState(_8,this.trackEndImg.name);this.setState(_6?_1:_3,this.endImg.name);if(this.showCorner)this.setState(_7?_1:_3,this.cornerImg.name)}
,isc.A.mouseUp=function isc_Scrollbar_mouseUp(){if(this.clickPart){var _1=this.showRollOver?isc.StatefulCanvas.STATE_OVER:isc.StatefulCanvas.STATE_UP;this.$615(_1,this.clickPart)}
this.clickPart=null;this.doneTrackScrolling();this.updateButtonsOnEdges();return isc.EventHandler.STOP_BUBBLING}
,isc.A.handleMouseMove=function isc_Scrollbar_handleMouseMove(){if(this.ns.EH.mouseIsDown()&&this.clickPart){}else if(this.showRollOver){this.$615(isc.StatefulCanvas.STATE_OVER,this.inWhichPart())}
return isc.EH.STOP_BUBBLING}
,isc.A.handleMouseOut=function isc_Scrollbar_handleMouseOut(_1){if(this.ns.EH.mouseIsDown())return isc.EH.STOP_BUBBLING;if(this.showRollOver){this.setState(isc.StatefulCanvas.STATE_UP)}
if(this.$192p(_1)){return isc.EH.STOP_BUBBLING}}
,isc.A.prepareForDragging=function isc_Scrollbar_prepareForDragging(){return false}
,isc.A.isDragScrolling=function isc_Scrollbar_isDragScrolling(){return this.$50p}
,isc.A.isRepeatTrackScrolling=function isc_Scrollbar_isRepeatTrackScrolling(){return this.$50o}
,isc.A.doneTrackScrolling=function isc_Scrollbar_doneTrackScrolling(){delete this.$50y;if(this.isRepeatTrackScrolling()){delete this.$50o;if(this.scrollTarget&&this.scrollTarget.doneFastScrolling)this.scrollTarget.doneFastScrolling()}}
,isc.A.thumbOver=function isc_Scrollbar_thumbOver(){if(this.allowThumbOverState){this.thumb.setState(isc.StatefulCanvas.STATE_OVER)}}
,isc.A.thumbOut=function isc_Scrollbar_thumbOut(_1){if(!isc.EH.mouseIsDown()){this.thumb.setState(isc.StatefulCanvas.STATE_UP)}
if(this.$192p(_1)){return isc.EH.STOP_BUBBLING}}
,isc.A.thumbDown=function isc_Scrollbar_thumbDown(){this.clickPart=this.$52l;if(this.allowThumbDownState){this.thumb.setState(isc.StatefulCanvas.STATE_DOWN)}
return isc.EventHandler.STOP_BUBBLING}
,isc.A.thumbDragStart=function isc_Scrollbar_thumbDragStart(){var _1=isc.EH;_1.setDragOffset(this.thumb.getOffsetX(_1.mouseDownEvent),this.thumb.getOffsetY(_1.mouseDownEvent));this.$50p=true;return _1.STOP_BUBBLING}
,isc.A.getEventCoord=function isc_Scrollbar_getEventCoord(){var _1=isc.EH;return(this.vertical?_1.getY()-this.getPageTop()-_1.dragOffsetY:_1.getX()-this.getPageLeft()-_1.dragOffsetX)+this.$189h-
(this.showTrackButtons==true?this.getSize(this.getPartNum(this.startImg.name)):0)}
,isc.A.masterMoved=function isc_Scrollbar_masterMoved(_1,_2,_3,_4,_5,_6){if(this.masterElement.$ss)return;return this.invokeSuper(isc.Scrollbar,"masterMoved",_1,_2,_3,_4,_5,_6)}
,isc.A.thumbMove=function isc_Scrollbar_thumbMove(){var _1=this.trackSize()-this.thumbSize(),_2=this.getEventCoord(),_3=_1!=0?_2/_1:_2;_3=Math.max(0,Math.min(_3,1));this.scrollTarget.scrollToRatio(this.vertical,_3,"thumbMove");return isc.EventHandler.STOP_BUBBLING}
,isc.A.thumbUp=function isc_Scrollbar_thumbUp(){if(this.clickPart!=this.$52l)
return this.mouseUp();var _1=(this.allowThumbOverState&&this.thumb.containsEvent()&&!isc.EH.$129k()
?isc.StatefulCanvas.STATE_OVER
:isc.StatefulCanvas.STATE_UP);this.thumb.setState(_1);return isc.EventHandler.STOP_BUBBLING}
,isc.A.thumbDragStop=function isc_Scrollbar_thumbDragStop(){delete this.$50p;if(this.scrollTarget&&this.scrollTarget.doneFastScrolling)this.scrollTarget.doneFastScrolling();return this.thumbUp()}
,isc.A.keyPress=function isc_Scrollbar_keyPress(){return this.ns.EH.bubbleEvent(this.scrollTarget,this.ns.EH.eventTypes.KEY_PRESS)}
,isc.A.keyDown=function isc_Scrollbar_keyDown(){return this.ns.EH.bubbleEvent(this.scrollTarget,this.ns.EH.eventTypes.KEY_DOWN)}
,isc.A.keyUp=function isc_Scrollbar_keyUp(){return this.ns.EH.bubbleEvent(this.scrollTarget,this.ns.EH.eventTypes.KEY_UP)}
,isc.A.mouseWheel=function isc_Scrollbar_mouseWheel(){return this.ns.EH.bubbleEvent(this.scrollTarget,this.ns.EH.eventTypes.MOUSE_WHEEL)}
,isc.A.hide=function isc_Scrollbar_hide(_1,_2,_3,_4){this.invokeSuper(isc.Scrollbar,"hide",_1,_2,_3,_4);if(!this.$u3&&this.scrollTarget!=null){this.moveTo(this.scrollTarget.getLeft(),this.scrollTarget.getTop());this.resizeTo(1,1)}}
,isc.A.$192o=function isc_Scrollbar__redirectEvents(_1){var _2=this.thumb;if(!_1)_1=null;this.eventParent=_1;if(_2!=null)_2.eventParent=_1}
,isc.A.$192p=function isc_Scrollbar__shouldSuppressMouseOut(_1){var _2=_1.target;return _2&&_2==this.scrollTarget&&_2.receiveScrollbarEvents}
,isc.A.enableTouchSupport=function isc_Scrollbar_enableTouchSupport(){this.Super("enableTouchSupport",arguments);if(isc.Browser.isChrome&&this.thumb)this.thumb.$1992()}
);isc.B._maxIndex=isc.C+56;isc.defineClass("SpritedScrollThumb","ScrollThumb");isc.defineClass("SpritedHScrollThumb","SpritedScrollThumb");isc.A=isc.SpritedHScrollThumb.getPrototype();isc.A.vertical=false;isc.defineClass("SpritedVScrollThumb","SpritedScrollThumb");isc.A=isc.SpritedVScrollThumb.getPrototype();isc.A.vertical=true;isc.defineClass("SpritedSimpleScrollThumb","HSimpleScrollThumb");isc.defineClass("SpritedHSimpleScrollThumb","SpritedSimpleScrollThumb");isc.A=isc.SpritedHSimpleScrollThumb.getPrototype();isc.A.vertical=false;isc.defineClass("SpritedVSimpleScrollThumb","SpritedSimpleScrollThumb");isc.A=isc.SpritedVSimpleScrollThumb.getPrototype();isc.A.vertical=true;isc.defineClass("SpritedScrollbar","Scrollbar");isc.A=isc.SpritedScrollbar.getPrototype();isc.A.hThumbClass=isc.SpritedHScrollThumb;isc.A.vThumbClass=isc.SpritedVScrollThumb;isc.ClassFactory.defineClass("MinimalScrollbar","Canvas");isc.MinimalScrollbar.addProperties(isc.$225q)
isc.defineClass("MinimalScrollbarThumb","Canvas");isc.A=isc.MinimalScrollbarThumb.getPrototype();isc.A.overflow="hidden";isc.MinimalScrollbarThumb.addProperties(isc.$89p);isc.A=isc.MinimalScrollbar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.overflow="hidden";isc.A.contrastSuffix="Dark";isc.A.trackBaseStyle="minimalScrollTrack";isc.A.thumbBaseStyle="minimalScrollThumb";isc.A.thumbConstructor="MinimalScrollbarThumb";isc.A.thumbDefaults={};isc.A.showOnTargetMouseMove=true;isc.A.thumbMinSize=12;isc.A.activeThumbWidth=8;isc.A.inactiveThumbWidth=2;isc.A.thumbInset=2;isc.A.endSpace=0;isc.A.interactive=false;isc.A.scrollbarSize=12;isc.A.interactiveScrollbarSize=15;isc.A.setInteractiveOnMouseOver=true;isc.A.autoShow=true;isc.A.autoHideDelay=1000;isc.B.push(isc.A.getTrackStyleName=function isc_MinimalScrollbar_getTrackStyleName(){var _1=this.trackBaseStyle+this.contrastSuffix;return this.interactive?_1+"Interactive":_1}
,isc.A.getThumbStyleName=function isc_MinimalScrollbar_getThumbStyleName(){var _1=this.thumbBaseStyle+this.contrastSuffix;return this.interactive?_1+"Interactive":_1}
,isc.A.initWidget=function isc_MinimalScrollbar_initWidget(){if(this.vertical)this.setWidth(this.getBreadth());else this.setHeight(this.getBreadth());this.setStyleName(this.getTrackStyleName());this.addAutoChild("thumb",{scrollbar:this,styleName:this.getThumbStyleName()
});if(this.scrollTarget)this.setScrollTarget(this.scrollTarget);this.setThumb();return this.Super("initWidget",arguments)}
,isc.A.scrollTargetChanged=function isc_MinimalScrollbar_scrollTargetChanged(_1,_2){var _3=this.vertical?"$169v":"$169u",_4=_1&&(_1[_3]==this),_5=_4&&(_1==_2);if(!_5){if(_4)delete _1[_3];this.$169y(_2)}
this.setThumb()}
,isc.A.$169y=function isc_MinimalScrollbar__setScrollbarOnTarget(_1){if(this.vertical){_1.$169v=this}else{_1.$169u=this}
}
,isc.A.scrollTargetMouseMove=function isc_MinimalScrollbar_scrollTargetMouseMove(){if(this.autoShow&&this.showOnTargetMouseMove){var _1=(this.$u3||this.scrollTarget.canScroll(this.vertical));if(_1){this.$256j()}
}
}
,isc.A.thumbOver=function isc_MinimalScrollbar_thumbOver(){}
,isc.A.thumbOut=function isc_MinimalScrollbar_thumbOut(_1){}
,isc.A.thumbDown=function isc_MinimalScrollbar_thumbDown(){return isc.EventHandler.STOP_BUBBLING}
,isc.A.thumbUp=function isc_MinimalScrollbar_thumbUp(){return isc.EventHandler.STOP_BUBBLING}
,isc.A.thumbDragStart=function isc_MinimalScrollbar_thumbDragStart(){var _1=isc.EH;_1.setDragOffset(this.thumb.getOffsetX(_1.mouseDownEvent),this.thumb.getOffsetY(_1.mouseDownEvent));this.$50p=true;return _1.STOP_BUBBLING}
,isc.A.thumbMove=function isc_MinimalScrollbar_thumbMove(){var _1=this.trackSize()-this.thumbSize(),_2=this.getEventCoord(),_3=_1!=0?_2/_1:_2;_3=Math.max(0,Math.min(_3,1));this.scrollTarget.scrollToRatio(this.vertical,_3,"thumbMove");return isc.EventHandler.STOP_BUBBLING}
,isc.A.thumbDragStop=function isc_MinimalScrollbar_thumbDragStop(){delete this.$50p;if(this.scrollTarget&&this.scrollTarget.doneFastScrolling)this.scrollTarget.doneFastScrolling();return this.thumbUp()}
,isc.A.getEventCoord=function isc_MinimalScrollbar_getEventCoord(){var _1=isc.EH;return(this.vertical?_1.getY()-this.getPageTop()-_1.dragOffsetY:_1.getX()-this.getPageLeft()-_1.dragOffsetX)}
,isc.A.trackSize=function isc_MinimalScrollbar_trackSize(){var _1=this.vertical?this.getHeight():this.getWidth();_1-=this.trackStart()*2;if(this.scrollTarget.hscrollOn&&this.scrollTarget.vscrollOn)_1-=this.getBreadth();return _1}
,isc.A.thumbSize=function isc_MinimalScrollbar_thumbSize(){if(!this.thumb)return;return(this.vertical?this.thumb.getHeight():this.thumb.getWidth())}
,isc.A.$192o=function isc_MinimalScrollbar__redirectEvents(_1){var _2=this.thumb;if(!_1)_1=null;this.eventParent=_1;if(_2!=null)_2.eventParent=_1}
,isc.A.setThumb=function isc_MinimalScrollbar_setThumb(){if(this.thumb==null||this.$494||!this.scrollTarget){return}
var _1=this.thumb,_2=this.trackSize();var _3=Math.round(this.scrollTarget.getViewportRatio(this.vertical)*_2);if(!isc.isA.Number(_3)||_3<this.thumbMinSize)_3=this.thumbMinSize;if(_3>_2)_3=_2;var _4=this.getThumbThickness();this.vertical?_1.resizeTo(_4,_3):_1.resizeTo(_3,_4);this.moveThumb()}
,isc.A.getThumbThickness=function isc_MinimalScrollbar_getThumbThickness(){var _1=this.inactiveThumbWidth;if(this.interactive){if(this.activeThumbWidth!=null)_1=this.activeThumbWidth;else{_1=Math.max(1,(this.vertical?this.getWidth():this.getHeight())
-(2*this.thumbInset))}
}
return _1}
,isc.A.resized=function isc_MinimalScrollbar_resized(){this.setThumb()}
,isc.A.moveThumb=function isc_MinimalScrollbar_moveThumb(){var _1=(this.$u3||this.scrollTarget.canScroll(this.vertical));if(!_1){if(this.autoEnable)this.disable();this.moveThumbTo(this.trackStart());return}
if(this.autoEnable&&!this.scrollTarget.isDisabled())this.enable();var _2=this.scrollTarget.getScrollRatio(this.vertical),_3=this.trackSize()-this.thumbSize(),_4=Math.round(_2*_3);this.moveThumbTo(_4+this.trackStart());var _5=isc.EH;if(this.autoShow){this.$256j()}
}
,isc.A.$256j=function isc_MinimalScrollbar__performAutoShow(){if(!this.isVisible()){this.show();var _1=this.$225w();if(_1)_1.show()}
this.$225x()}
,isc.A.trackStart=function isc_MinimalScrollbar_trackStart(){return this.endSpace}
,isc.A.moveThumbTo=function isc_MinimalScrollbar_moveThumbTo(_1){if(!this.thumb)return;var _2=Math.round((this.getInnerBreadth()-this.getThumbThickness())/2);if(this.vertical)
return this.thumb.moveTo(_2,_1);else
return this.thumb.moveTo(_1,_2)}
,isc.A.getBreadth=function isc_MinimalScrollbar_getBreadth(){if(this.interactive&&this.interactiveScrollbarSize!=null){return this.interactiveScrollbarSize}
return this.scrollbarSize}
,isc.A.getInnerBreadth=function isc_MinimalScrollbar_getInnerBreadth(){var _1=this.getBreadth();if(this.vertical)_1-=this.getHBorderPad();else _1-=this.getVBorderPad();return _1}
,isc.A.updateBreadth=function isc_MinimalScrollbar_updateBreadth(){var _1=this.getBreadth(),_2=this.vertical?this.getWidth():this.getHeight();if(_2==_1)return;if(this.vertical){this.setWidth(_1);this.moveBy(_2-_1)}else{this.setHeight(this.getBreadth());if(!this.isRTL()){this.moveBy(null,_2-_1)}
}
}
,isc.A.show=function isc_MinimalScrollbar_show(){this.updateBreadth();return this.Super("show",arguments)}
,isc.A.setInteractive=function isc_MinimalScrollbar_setInteractive(_1){if(this.interactive==_1)return;this.interactive=_1;this.setStyleName(this.getTrackStyleName());if(this.thumb)this.thumb.setStyleName(this.getThumbStyleName());this.updateBreadth();if(_1){var _2=this.$225w();if(_2)_2.setInteractive(false)}
}
,isc.A.mouseDown=function isc_MinimalScrollbar_mouseDown(){return isc.EH.STOP_BUBBLING}
,isc.A.mouseMove=function isc_MinimalScrollbar_mouseMove(){if(this.setInteractiveOnMouseOver&&!this.interactive){this.setInteractive(true)}
if(this.setInteractiveOnMouseOver)this.$225x();return isc.EH.STOP_BUBBLING}
,isc.A.mouseOut=function isc_MinimalScrollbar_mouseOut(){if(this.setInteractiveOnMouseOver&&this.interactive&&!this.autoShow){this.setInteractive(false)}
return isc.EH.STOP_BUBBLING}
,isc.A.click=function isc_MinimalScrollbar_click(){this.thumbMove();return isc.EH.STOP_BUBBLING}
,isc.A.$225x=function isc_MinimalScrollbar__resetAutoHideTimer(){this.$225y=this.fireOnPause("autoHideOnPauseTimer",{target:this,methodName:"autoHideOnPause"},this.autoHideDelay)}
,isc.A.$225w=function isc_MinimalScrollbar__getOtherScrollbar(){if(this.scrollTarget){var _1=this.vertical?"$169u":"$169v";return this.scrollTarget[_1]}
}
,isc.A.autoHideOnPause=function isc_MinimalScrollbar_autoHideOnPause(_1){delete this.$225y;var _2=_1?null:this.$225w();if(_2&&_2.$225y){return}
if(this.autoShow)this.hide();if(this.setInteractiveOnMouseOver&&this.interactive){this.setInteractive(false)}
if(_2){_2.autoHideOnPause(true)}
}
);isc.B._maxIndex=isc.C+36;isc.ClassFactory.defineClass("NativeScrollbar","Canvas");isc.NativeScrollbar.addProperties(isc.$225q)
isc.A=isc.NativeScrollbar;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.getScrollbarSize=function isc_c_NativeScrollbar_getScrollbarSize(){var _1=isc.Element.getNativeScrollbarSize();if(_1!=0)return _1;return 16}
);isc.B._maxIndex=isc.C+1;isc.A=isc.NativeScrollbar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.showCustomScrollbars=false;isc.A.overflow="hidden";isc.A.autoEnable=true;isc.A.scrollbarCanvasDefaults={overflow:"scroll",showCustomScrollbars:false,canFocus:false,mouseOut:function(_1){if(this.creator.autoHide)this.creator.setInactiveOnPause();if(this.creator.$192p(_1)){return isc.EH.STOP_BUBBLING}
},$lh:function(_1,_2){this.Super("$lh",arguments);if(isc.Browser.isMoz&&!_1&&(_2||isc.Browser.geckoVersion<20030312))
{return}
if(this.$u7)return;this.creator.scrollbarCanvasScrolled()},parentResized:function(){this.creator.sizeScrollbarCanvas();this.creator.adjustOverflow()},getScrollWidth:function(_1,_2,_3,_4,_5){if(this.isDirty())this.redraw("Immediate redraw to get scroll width");return this.Super("getScrollWidth",arguments)},getScrollHeight:function(_1,_2,_3,_4,_5){if(this.isDirty())this.redraw("Immediate redraw to get scroll height");return this.Super("getScrollHeight",arguments)},$rw:function(){if(isc.Element.getNativeScrollbarSize()!=0){return this.Super("$rw",arguments)}else{var _1=!this.creator.vertical||this.creator.showCorner,_2=this.creator.vertical||this.creator.showCorner;return[(_1?"scroll":"hidden"),(_2?"scroll":"hidden")
]}
}
};isc.A.scrollbarCanvasThickness=100;isc.A.autoHideDelay=1000;isc.B.push(isc.A.initWidget=function isc_NativeScrollbar_initWidget(){this.autoHide=isc.Element.getNativeScrollbarSize()==0;if(this.autoHide&&this.showOnTargetMouseMove==null){this.showOnTargetMouseMove=isc.Browser.isWin}
var _1=isc.NativeScrollbar.getScrollbarSize();if(this.vertical){this.setWidth(_1)}else{this.setHeight(_1)}
this.setOverflow(isc.Canvas.HIDDEN);this.addAutoChild("scrollbarCanvas");this.sizeScrollbarCanvas();this.setScrollTarget();this.setThumb()}
,isc.A.scrollTargetMouseMove=function isc_NativeScrollbar_scrollTargetMouseMove(){if(this.autoHide&&this.showOnTargetMouseMove){this.setScrollbarActive(true)}
}
,isc.A.sizeScrollbarCanvas=function isc_NativeScrollbar_sizeScrollbarCanvas(_1){if(!this.scrollbarCanvas)return;var _2=isc.Element.getNativeScrollbarSize();if(_1&&_2==0){var _3=this.scrollbarCanvas;var _4=_3.$rw();var _5=_3.getClipHandle();if(_5!=null){if(isc.isAn.Array(_4)){_5.style.overflowX=_4[0];_5.style.overflowY=_4[1]}else{_5.overflow=_4}
}
}
var _6=this.vertical?this.scrollbarCanvasThickness
:this.getInnerWidth()+(this.showCorner?0:_2),_7=!this.vertical?this.scrollbarCanvasThickness
:this.getInnerHeight()+(this.showCorner?0:_2);this.scrollbarCanvas.resizeTo(_6,_7)}
,isc.A.$ut=function isc_NativeScrollbar__adjustOverflow(){this.Super("$ut",arguments);this.$280d()}
,isc.A.$280d=function isc_NativeScrollbar__fixScrollbarCanvasClipping(){if(this.vertical){this.scrollToTop();this.scrollToRight()}else{this.scrollToLeft();this.scrollToBottom()}
}
,isc.A.$256k=function isc_NativeScrollbar__forceThumb(){if(this.$256l)return;var _1=this.scrollbarCanvas;this.$256l=true;_1.setContents(isc.Canvas.spacerHTML(1,1));_1.spacerLength=1;this.delayCall("$256m")}
,isc.A.$256m=function isc_NativeScrollbar__resetThumb(){this.setThumb();this.$256l=false}
,isc.A.setThumb=function isc_NativeScrollbar_setThumb(){if(this.$494)return;var _1=this.scrollbarCanvas,_2=(this.$u3||this.scrollTarget.canScroll(this.vertical)),_3=1,_4=1;if(_2){var _5=this.scrollTarget.getViewportRatio(this.vertical);var _6=(this.vertical?_1.getViewportHeight():_1.getViewportWidth()),_7=_5==0?0:Math.round(_6/_5);if(this.vertical)_4=_7;else _3=_7}
if(this.autoHide){if(_2){this.setScrollbarActive()}else{this.setScrollbarInactive()}
}
if(_1.spacerLength!=_7){_1.setContents(isc.Canvas.spacerHTML(_3,_4));_1.spacerLength=_7}
this.moveThumb();this.$280d()}
,isc.A.setVisibility=function isc_NativeScrollbar_setVisibility(_1,_2,_3,_4){this.invokeSuper(isc.Scrollbar,"setVisibility",_1,_2,_3,_4);if(this.isVisible())this.setThumb()}
,isc.A.parentVisibilityChanged=function isc_NativeScrollbar_parentVisibilityChanged(_1,_2,_3,_4){this.invokeSuper(isc.Scrollbar,"parentVisibilityChanged",_1,_2,_3,_4);if(this.isVisible())this.setThumb()}
,isc.A.moveThumb=function isc_NativeScrollbar_moveThumb(){var _1=this.scrollTarget.getScrollRatio(this.vertical);var _2=this.scrollbarCanvas;var _3=this.vertical?_2.getScrollHeight()-_2.getViewportHeight()
:_2.getScrollWidth()-_2.getViewportWidth(),_4=Math.round(_1*_3);_2.scrollTo(this.vertical?0:_4,this.vertical?_4:0)}
,isc.A.scrollbarCanvasScrolled=function isc_NativeScrollbar_scrollbarCanvasScrolled(){if(this.$256l)return;if(this.scrollTarget.scrollAnimation)return;const _1=this.scrollbarCanvas,_2=this.vertical?_1.getScrollHeight()-_1.getViewportHeight()
:_1.getScrollWidth()-_1.getViewportWidth(),_3=_2<=0?0
:(this.vertical?_1.getScrollTop():_1.getScrollLeft())/_2;this.scrollTarget.scrollToRatio(this.vertical,_3)}
,isc.A.setShowCorner=function isc_NativeScrollbar_setShowCorner(_1){if(this.showCorner==_1||!this.scrollbarCanvas)return;this.showCorner=_1;this.sizeScrollbarCanvas(true)}
,isc.A.handleMouseOut=function isc_NativeScrollbar_handleMouseOut(_1){if(this.autoHide)this.setInactiveOnPause();if(this.$192p(_1))return isc.EH.STOP_BUBBLING}
,isc.A.$192o=function isc_NativeScrollbar__redirectEvents(_1){if(!_1)_1=null;this.eventParent=_1;var _2=this.scrollbarCanvas;if(_2!=null){_2.eventParent=_1}
}
,isc.A.$192p=function isc_NativeScrollbar__shouldSuppressMouseOut(_1){var _2=_1.target;return _2&&_2==this.scrollTarget&&_2.receiveScrollbarEvents}
,isc.A.$192q=function isc_NativeScrollbar__hasScrollTargetEventParent(_1){if(this.disabled)return false;return _1==this||_1&&_1==this.scrollbarCanvas}
,isc.A.setScrollbarActive=function isc_NativeScrollbar_setScrollbarActive(_1){if(!this.autoHide)return;if(!this.active){this.active=true;if(!this.isVisible())this.show();if(_1)this.$256k()}
if(!this.containsEvent()){this.setInactiveOnPause()}
}
,isc.A.setInactiveOnPause=function isc_NativeScrollbar_setInactiveOnPause(){this.$232t=this.fireOnPause("setScrollbarInactive",{target:this,methodName:"setScrollbarInactive"},this.autoHideDelay)}
,isc.A.setScrollbarInactive=function isc_NativeScrollbar_setScrollbarInactive(){if(!this.autoHide)return;if(this.containsEvent()){return}
this.active=false;if(this.isVisible())this.hide();delete this.$232t}
);isc.B._maxIndex=isc.C+20;isc.$6y={invertClosedGripIfTargetAfter:true,canDrag:true,dragAppearance:"none",dragStartDistance:1,canCollapse:true,canCollapseOnTap:true,cursor:"hand",vResizeCursor:"row-resize",hResizeCursor:"col-resize",resizeInRealTime:false,$jp:false,$jo:false,overflow:"hidden",isMouseTransparent:true};isc.$6z={initWidget:function(){this.setVertical(this.vertical);this.Super("initWidget",arguments);if(isc.Browser.isMoz)this.bringToFront()},setVertical:function(_1,_2){this.vertical=_1;if(_2){this.setSrc(_1?this.vSrc:this.hSrc);if(this.showGrip)this.$207g()}
if(_1){this.setProperties({cursor:this.hResizeCursor,defaultWidth:this.defaultWidth||10,baseStyle:this.vBaseStyle||this.baseStyle
})}else{this.setProperties({cursor:this.vResizeCursor,defaultHeight:this.defaultHeight||10,baseStyle:this.hBaseStyle||this.baseStyle
})}
},prepareForDragging:function(){if(this.$91z==null){this.$91z=this.canDrag}
if(this.$1056==null){this.$1056=false}
if(this.target){if(this.target.visibility==isc.Canvas.HIDDEN){this.canDrag=this.$1056}else{this.canDrag=this.$91z}
}else{this.canDrag=false}
return this.Super("prepareForDragging",arguments)},makeLabel:function(){this.Super("makeLabel",arguments);this.label.addMethods({getCustomState:function(){var _1=this.masterElement;if(!_1.showClosedGrip)return;var _2=_1.target,_3=_2&&_2.visibility==isc.Canvas.HIDDEN,_4=_1.targetAfter&&_1.invertClosedGripIfTargetAfter;if((!_4&&_3)||(_4&&!_3)){return"closed"}
}
})},dragStart:function(){this.setState("Down");this.bringToFront()},dragMove:function(){var _1=this.vertical?(0-isc.EH.dragOffsetX):(0-isc.EH.dragOffsetY);this.resizeTarget(this.target,!this.vertical,this.resizeInRealTime,_1,null,null,this.targetAfter)},dragStop:function(){this.setState("");this.finishTargetResize(this.target,!this.vertical,this.resizeInRealTime)},click:function(){if(this.canCollapse!=true)return;if(this.ns.EH.$129k()&&this.canCollapseOnTap!=true)return;var _1=this.hideTarget||this.target;if(!this.target)return;if(_1.visibility=='hidden'){if(isc.isA.Layout(_1.parentElement))_1.parentElement.showMember(_1);else _1.show()}else{if(isc.isA.Layout(_1.parentElement))_1.parentElement.hideMember(_1);else _1.hide()}
this.setState("")}};isc.defineClass("Splitbar","StretchImg");isc.A=isc.Splitbar.getPrototype();isc.A.skinImgDir="images/Splitbar/";isc.A.imageType="stretch";isc.A.capSize=3;isc.A.vSrc="[SKIN]vsplit.gif";isc.A.hSrc="[SKIN]hsplit.gif";isc.Splitbar.addMethods(isc.$6y,isc.$6z)
isc.defineClass("ImgSplitbar","Img");isc.A=isc.ImgSplitbar.getPrototype();isc.A.skinImgDir="images/Splitbar/";isc.A.imageType="center";isc.A.src=null;isc.A.hSrc="[SKIN]hgrip.png";isc.A.vSrc="[SKIN]vgrip.png";isc.A.styleName="splitbar";isc.A.showDown=true;isc.ImgSplitbar.addMethods(isc.$6y,isc.$6z)
isc.addGlobal("StretchImgSplitbar",isc.Splitbar);isc.defineClass("HSplitbar","Splitbar");isc.A=isc.HSplitbar.getPrototype();isc.A.vertical=false;isc.defineClass("VSplitbar","Splitbar");isc.defineClass("Stretchbar","Splitbar");isc.A=isc.Stretchbar.getPrototype();isc.A.canResize=false;isc.A.skinImgDir="images/Stretchbar/";isc.A.showRollOver=true;isc.defineClass("HStretchbar","Stretchbar");isc.A=isc.HStretchbar.getPrototype();isc.A.vertical=false;isc.A.src="[SKIN]hsplit.gif";isc.A.defaultHeight=10;isc.defineClass("VStretchbar","Stretchbar");isc.A=isc.VStretchbar.getPrototype();isc.A.src="[SKIN]vsplit.gif";isc.A.defaultWidth=10;isc.defineClass("Snapbar","Splitbar");isc.A=isc.Snapbar.getPrototype();isc.A.showRollOver=true;isc.A.showDown=true;isc.A.showGrip=true;isc.A.showDownGrip=true;isc.A.showRollOverGrip=true;isc.A.showClosedGrip=true;isc.A.gripImgSuffix="snap";isc.LayoutResizeBarProperties={dragScrollType:"parentsOnly",showResizeBar:false,initWidget:function(){if(this.layout){this.resizeDirection=this.targetAfter?isc.Splitbar.AFTER:isc.Splitbar.BEFORE}else{if(this.resizeDirection==isc.Splitbar.AFTER)this.targetAfter=true}
this.Super("initWidget",arguments)},resizeDirection:"before",setResizeDirection:function(_1,_2){if(this.resizeDirection==_1)return;var _3=this.layout;var _4=this.target;if(!_3||!_4){this.resizeDirection=_1;this.targetAfter=(_1==isc.Splitbar.AFTER);this.target=this.hideTarget=null;return}
var _5=this.creator==this.layout;if(_5){var _6=this.layout.getMemberNumber(_4);var _7=(_1==isc.Splitbar.AFTER);var _8=this.layout.getMember(_6+(_7?1:-1));if(_8==null){this.logWarn("Set Resize Direction - unable to find member on specified side to resize");return}
this.resizeDirection=_1;this.targetAfter=_7;this.hideTarget=this.target=_8}else{var _6=this.layout.getMemberNumber(this);this.resizeDirection=_1;this.targetAfter=(_1==isc.Splitbar.AFTER);this.$2052(_2)}
},$2052:function(_1){var _2=this.layout;if(_1==null){_1=_2.getMemberNumber(this)}
var _3=this.targetAfter,_4=_2.getMember(_1+1),_5=_2.getMember(_1-1),_6=_3?(_4||_5):(_5||_4)
;var _7=this.target&&this.target.destroying;if(!_7){if(!_6){this.logWarn("no members available for the resizeBar to target")}else if(this.hasOwnProperty("resizeDirection")&&(_3?_6!=_4:_6!=_5))
{this.logWarn("couldn't comply with targetAfter property for the resizeBar at index "+_1+" - no such member")}
}
this.target=_6},setShowResizeBar:function(){this.logWarn("setShowResizeBar(); showResizeBar is always false for a LayoutResizeBar")}};isc.defineClass("LayoutResizeBar","Splitbar").addProperties(isc.LayoutResizeBarProperties)
isc.defineClass("LayoutResizeSnapbar","Snapbar").addProperties(isc.LayoutResizeBarProperties)
isc.defineClass("ToolStripResizer","ImgSplitbar");isc.A=isc.ToolStripResizer.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.skinImgDir="images/ToolStrip/";isc.A.vSrc="[SKIN]resizer.png";isc.A.hSrc="[SKIN]hresizer.png";isc.A.layoutAlign="center";isc.A.resizeInRealTime=true;isc.A.showDown=false;isc.A.imageLength=20;isc.A.imageBreadth=14;isc.A.imageType="center";isc.A.$1767="resizer";isc.A._generated=true;isc.B.push(isc.A.initWidget=function isc_ToolStripResizer_initWidget(){this.imageWidth=this.vertical?this.imageBreadth:this.imageLength;this.imageHeight=this.vertical?this.imageLength:this.imageBreadth;this.Super("initWidget",arguments)}
,isc.A.updateEditNode=function isc_ToolStripResizer_updateEditNode(_1,_2){_1.removeNodeProperties(_2,["autoDraw","ID","autoID","title"])}
);isc.B._maxIndex=isc.C+2;isc.A=isc.Splitbar;isc.A.BEFORE="before";isc.A.AFTER="after";isc.defineClass("IconImgButton","ImgButton");isc.A=isc.IconImgButton.getPrototype();isc.A.width=16;isc.A.height=16;isc.A.showMenuOnClick=true;isc.A.src={_base:"[SKIN]/actions/edit.png"};isc.A.showFocusedAsOver=false;isc.A=isc.IconImgButton;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.init=function isc_c_IconImgButton_init(_1,_2,_3){this.invokeSuper(isc.IconImgButton,"init",_1,_2,_3);if(this!=isc.IconImgButton)return;if(!isc.Window){this.logWarn("isc.Window not loaded, failed to pick up Window.headerIconDefaults");return}
var _4=isc.Window.getInstanceProperty("headerIconDefaults");this.addProperties({width:_4.width,height:_4.height
})}
);isc.B._maxIndex=isc.C+1;isc.A=isc.Canvas;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$o9="%";isc.A.$60="listPolicy";isc.B.push(isc.A.$166a=function isc_c_Canvas__calculateStaticSize(_1,_2,_3,_4,_5){var _6=0,_7=0,_8=0,_9=0;for(var i=0;i<_1.length;i++){var _11=_1[i];if(_11==null||isc.is.emptyString(_11))_1[i]=_11=isc.star;if(isc.isA.Number(_11)){_2[i]=_11}else{if(_11==isc.star){_6++;_11=0}else if(_11.indexOf(this.$o9)>=0){if(_4!=null&&_4.fixedPercents){var _12=parseInt(_11);_11=_2[i]=Math.round((_12/100)*_3)}else{_8+=parseInt(_11);_7++;_11=0}
}else{if(_4!=null&&isc.isA.Number(_4[_11])){_11=_2[i]=_4[_11]}else if(_4!=null&&_11==="otherScrollbarSize"){_11=_2[i]=_4.getOtherScrollbarSize()}else{var _13=parseInt(_11);if(isc.isA.Number(_13)&&_13>=0){_2[i]=_11=_13}else{try{_11=isc.eval(_11)}catch(e){var _14=_4&&_4.logWarn
?_4:this;_14.logWarn("StretchResizePolicy:  unable to convert size:"+_11+" to a valid size - reported error: '"+e+"'\n Complete set of sizes:"+_1);_11=null}
if(!isc.isA.Number(_11)||_11<0)_11=0;_2[i]=_11}
}
}
}
_11=Math.max(_11,0);_9+=_11}
return{starCount:_6,percentCount:_7,percentTotal:_8,staticSize:_9
}}
,isc.A.isStretchResizePolicy=function isc_c_Canvas_isStretchResizePolicy(_1){if(!isc.isA.String(_1))return false;return _1==isc.star||_1.indexOf(this.$o9)>=0}
,isc.A.applyStretchResizePolicy=function isc_c_Canvas_applyStretchResizePolicy(_1,_2,_3,_4,_5){if(!_1)return;if(_3==null||_3<=0)_3=1;var _6=_4?_1:[],_7=this.logIsDebugEnabled(this.$60);if(_7&&_4)_1=_1.duplicate();var _8=this.$166a(_1,_6,_2,_5),_9=_8.starCount,_10=_8.percentTotal,_11=_8.staticSize;var _12=0;if(_9){if(_10>=100){_11+=_9*_3}else{_12=(100-_10)/_9;_10=100}
}
if(_10>0){var _13=_2-_11,_14=Math.max(0,_13/_10),_15=null;for(var i=0;i<_1.length;i++){var _17=_1[i];if(isc.isA.String(_17)){var _18;if(_17==isc.star){_18=_12*_14}else if(_17.indexOf(this.$o9)>=0){_18=parseInt(_17)*_14}else{continue}
_18=Math.max(Math.floor(_18),_3);_13-=_18;_15=i;_6[i]=_18}
}
if(_13>0)_6[_15]+=_13}
if(_7){this.logDebug("stretchResize"+(_5?" for "+_5.ID:"")+" with totalSize: "+_2+",  desired sizes: "+_1+",  calculated sizes: "+_6,"listPolicy")}
return _6}
,isc.A.applyNewStretchResizePolicy=function isc_c_Canvas_applyNewStretchResizePolicy(_1,_2,_3,_4,_5,_6,_7){if(!_1)return;if(!_3||_3<0)_3=1;var _8=_4?_1:[],_9=this.logIsDebugEnabled(this.$60),_10=_6!=null
;var _11;if(_9){_11="stretchResize"+(_5?" for "+_5.ID:"")+" with totalSize: "+_2+",  desired sizes: "+_1}
var _12=[],_13=[];if(_7==null)_7=[];if(isc.isA.Layout(_5)){var _14,_15;if(_10){_14=_5.fields||[];_15=false}else{_14=_5.members,_15=_5.vertical}
if(!_5.ignoreStretchResizeForCanAdaptMembers&&!_10){_6=[];for(var i=0;i<_14.length;i++){var _17=_14[i];if(!_5.$188d(_17))continue;var _18=_5.$2m(_17);if(isc.Canvas.$186q(_18)&&isc.isA.Number(_1[i])){if(_5.$2n(_17)){if(!_5.$188l){_5.$188l=true;_5.logWarn("applyNewStretchResizePolicy(): Adaptive-length members cannot support stretch sizing unless overflow is hidden - member "+_17.ID)}
continue}
_6[i]=_1[i];_1[i]=_18}
}
}
if(!_5.ignoreStretchResizeMemberSizeLimits){for(var i=0;i<_14.length;i++){var _17=_14[i];if(_15){_12[i]=_17.minHeight;_13[i]=_17.maxHeight}else{_12[i]=_17.minWidth;_13[i]=_17.maxWidth}
if(_12[i]==null||_12[i]<_3){_12[i]=_3}
}
if(_6){for(var i=0;i<_14.length;i++){var _19=_6[i];if(_10&&_13[i]!=null&&_19>_13[i]){_19=_13[i]}
if(_19>_12[i])_12[i]=_19}
}
}
}
if(_4)_1=_1.duplicate();else{var _20,_21=[];for(var i=0;i<_1.length;i++){_21[_21.length]=_8[i]!==_20?_8[i]:_1[i]}
_1=_21}
if(_7!=null){for(var i=0;i<_1.length;i++){var _22=_1[i];if(isc.isA.Number(_22)&&_7[i]!=null&&_7[i]>_22)
{_1[i]=_7[i]}
}
}
var _23=this.$166a(_1,_8,_2,_5,_10),_24=_23.starCount,_25=_23.percentCount,_26=_23.percentTotal,_27=_23.staticSize
;var _28=1e-9,_29=[],_30=0;while(_24+_25>0){var _31=0,_32=[];var _33=_26;var _34=0,_35=0;if(_24){if(_33>=100){for(var i=0;i<_1.length;i++){if(!_29[i]&&_1[i]==isc.star){_35+=_12[i]!=null?_12[i]:_3}
}
}else{_34=(100-_33)/_24;_33=100}
}
if(_33>0){_30=_2-_27-_35;var _36=Math.max(0,_30/_33);for(var i=0;i<_1.length;i++){if(_29[i])continue;var _37=_1[i];if(isc.isA.String(_37)){var _38;if(_37==isc.star){_38=_34*_36}else if(_37.indexOf(this.$o9)>=0){_38=parseInt(_37)*_36}else{continue}
_38=Math.floor(_38+_28);var _39=_12[i]!=null?_12[i]:_3;if(_7[i]!=null&&_7[i]>_39){_39=_7[i]}
if(_38<_39){_31+=_32[i]=_39-_38;_38=_39}
if(_13[i]!=null){var _40=Math.max(_13[i],_39);if(_38>_40){_31+=_32[i]=_40-_38;_38=_40}
}
_30-=_8[i]=_38}
}
}
if(_31!=0){for(var i=0;i<_1.length;i++){if(_32[i]==null)continue;if(_31>0&&_32[i]<=0||_31<0&&_32[i]>=0)continue;var _37=_1[i];if(_37==isc.star){_24--}else{_25--;_26-=parseInt(_37)}
_27+=_8[i];_29[i]=true}
}else break}
if(_30>0){for(var i=_1.length-1;i>=0;i--){if(!this.isStretchResizePolicy(_1[i]))continue;if(_13[i]==null||_13[i]>=_8[i]+_30){_8[i]+=_30;break}
}
if(i<0){this.logInfo("stretchResize"+(_5?" for "+_5.ID:"")+" with totalSize: "+_2+" and calculated sizes: "+_8+"; cannot assign remainingSpace: "+_30+" due to member max size limits","listPolicy")}
}
if(_9){this.logDebug(_11+",  calculated sizes: "+_8,"listPolicy")}
return _8}
);isc.B._maxIndex=isc.C+4;isc.A=isc.Canvas.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.applyStretchResizePolicy=function isc_Canvas_applyStretchResizePolicy(_1,_2,_3,_4,_5,_6){var _7=this.getClass(),_8=this.useOriginalStretchResizePolicy?_7.applyStretchResizePolicy:_7.applyNewStretchResizePolicy;return _8.call(_7,_1,_2,_3,_4,this,_6,_5)}
);isc.B._maxIndex=isc.C+1;isc.ClassFactory.defineClass("GroupingMessages");
isc.A=isc.GroupingMessages;
isc.A.upcomingBeforeTitle="Before";
isc.A.upcomingTodayTitle="Today";
isc.A.upcomingTomorrowTitle="Tomorrow";
isc.A.upcomingThisWeekTitle="This Week";
isc.A.upcomingNextWeekTitle="Next Week";
isc.A.upcomingThisMonthTitle="This Month";
isc.A.upcomingNextMonthTitle="Next Month";
isc.A.upcomingThisYearTitle="This Year";
isc.A.upcomingNextYearTitle="Next Year";
isc.A.upcomingLaterTitle="Later";
isc.A.byDayTitle="by Day";
isc.A.byWeekTitle="by Week";
isc.A.byMonthTitle="by Month";
isc.A.byQuarterTitle="by Quarter";
isc.A.byYearTitle="by Year";
isc.A.byDayOfMonthTitle="by Day of Month";
isc.A.byUpcomingTitle="by Upcoming";
isc.A.byDateTitle="by Date";
isc.A.byWeekAndYearTitle="by Week and Year";
isc.A.byMonthAndYearTitle="by Month and Year";
isc.A.byQuarterAndYearTitle="by Quarter and Year";
isc.A.byDayOfWeekAndYearTitle="by Day of specific Week";
isc.A.byDayOfMonthAndYearTitle="by Day of specific Month";
isc.A.byHoursTitle="by Hours";
isc.A.byMinutesTitle="by Minutes";
isc.A.bySecondsTitle="by Seconds";
isc.A.byMillisecondsTitle="by Milliseconds";
isc.A.weekNumberTitle="Week #";
isc.A.timezoneMinutesSuffix="minutes";
isc.A.timezoneSecondsSuffix="seconds"
;
isc.builtinTypes=
{
text:{validators:{type:"isString",typeCastValidator:true},
defaultOperator:"iContains"
},
"boolean":{validators:{type:"isBoolean",typeCastValidator:true},
defaultOperator:"equals"
},
integer:{validators:{type:"isInteger",typeCastValidator:true},
defaultOperator:"equals",
normalDisplayFormatter:function(_1,_2){
if(isc.isA.Number(_1))return _1.toFormattedString();
return _1},
getGroupValue:function(_1,_2,_3,_4,_5){
var g=_3.groupGranularity;
return g?Math.ceil(_1/g):_1},
getGroupTitle:function(_1,_2,_3,_4,_5){
var g=_3.groupGranularity;
return g?((_1-1)*g)+" - "+(_1*g):_1},
parseInput:function(_1){
var _2=_1;
if(isc.isA.String(_1))_1=_1.trim();
var _3=isc.NumberUtil.parseInt(_1,true);
if((_1!=_3)||isNaN(_3)){
return _1}else{
return _3}
}
},
"float":{validators:{type:"isFloat",typeCastValidator:true},
defaultOperator:"equals",
normalDisplayFormatter:function(_1,_2){
if(isc.isA.Number(_1))return _1.toFormattedString();
return _1},
getGroupValue:function(_1,_2,_3,_4,_5){
_3.groupPrecision=parseInt(_3.groupPrecision);
if(_3.groupPrecision<0)_3.groupPrecision=_3.groupPrecision*-1;
var p=_3.groupPrecision?Math.pow(10,_3.groupPrecision):null;
return p?Math.floor(_1*p)/p:_1},
getGroupTitle:function(_1,_2,_3,_4,_5){
return _3.groupPrecision?_1+"*":_1},
parseInput:function(_1){
var _2=isc.NumberUtil.parseFloat(_1,true);
if(isNaN(_2)){
return _1}else{
return _2}
}
},
date:{validators:{type:"isDate",typeCastValidator:true},
defaultOperator:"equals",
normalDisplayFormatter:function(_1,_2){
if(isc.isA.Date(_1))return _1.toNormalDate();
return _1},
getGroupingModes:function(){
return{
day:isc.GroupingMessages.byDayTitle,
week:isc.GroupingMessages.byWeekTitle,
month:isc.GroupingMessages.byMonthTitle,
quarter:isc.GroupingMessages.byQuarterTitle,
year:isc.GroupingMessages.byYearTitle,
dayOfMonth:isc.GroupingMessages.byDayOfMonthTitle,
upcoming:isc.GroupingMessages.byUpcomingTitle,
date:isc.GroupingMessages.byDateTitle,
weekAndYear:isc.GroupingMessages.byWeekAndYearTitle,
monthAndYear:isc.GroupingMessages.byMonthAndYearTitle,
quarterAndYear:isc.GroupingMessages.byQuarterAndYearTitle,
dayOfWeekAndYear:isc.GroupingMessages.byDayOfWeekAndYearTitle,
dayOfMonthAndYear:isc.GroupingMessages.byDayOfMonthAndYearTitle
}},
defaultGroupingMode:"date",
getGroupValue:function(_1,_2,_3,_4,_5){
var _6=_1;
var _7=_3.groupingMode=
(_3.groupingMode||_3.$62.defaultGroupingMode||null);
if(isc.isA.Date(_1)&&_7){
switch(_7){
case"year":
_6=_1.getFullYear();
break;
case"quarter":
_6=Math.floor(_1.getMonth()/3)+1;
break;
case"month":
_6=_1.getMonth();
break;
case"week":
_6=_1.getWeek();
break;
case"day":
case"dayOfWeek":
_6=_1.getDay();
break;
case"dayOfMonth":
_6=_1.getDate();
break;
case"quarterAndYear":
_6=_1.getFullYear()+"_"+(Math.floor(_1.getMonth()/3)+1);
break;
case"monthAndYear":
var _8=_1.getMonth();
_8=""+(_8<10?"0":"")+_8;
_6=_1.getFullYear()+"_"+_8;
break;
case"weekAndYear":
_6=_1.getFullYear()+"_"+
isc.DateUtil.format(_1,"ww");
break;
case"date":
var _8=_1.getMonth();
_8=""+(_8<10?"0":"")+_8;
_6=_1.getFullYear()+"_"+
_8+"_"+
isc.DateUtil.format(_1,"dd");
break;
case"dayOfWeekAndYear":
var _9=isc.DateUtil.getWeekNumber(_1);
_6=_9[0]+"_"+
isc.NumberUtil.stringify(_1.getMonth(),2)+"_"+
isc.NumberUtil.stringify(_1.getDate(),2)+"_"+
isc.NumberUtil.stringify(_9[1],2)+"_"+
isc.NumberUtil.stringify(_1.getDay(),2);
break;
case"dayOfMonthAndYear":
var _8=_1.getMonth();
_8=""+(_8<10?"0":"")+_8;
_6=_1.getFullYear()+"_"+
_8+"_"+
isc.DateUtil.format(_1,"dd")+"_"+
_1.getDay();
break;
case"timezoneHours":
_6=_1.getTimezoneOffset()/60;
break;
case"timezoneMinutes":
_6=_1.getTimezoneOffset();
break;
case"timezoneSeconds":
_6=_1.getTimezoneOffset()*60;
break;
case"upcoming":
var _10=new Date();
if(_10.isBeforeToday(_1))return 1;
else if(_10.isToday(_1))return 2;
else if(_10.isTomorrow(_1))return 3;
else if(_10.isThisWeek(_1))return 4;
else if(_10.isNextWeek(_1))return 5;
else if(_10.isThisMonth(_1))return 6;
else if(_10.isNextMonth(_1))return 7;
else if(_10.getFullYear()==_1.getFullYear())return 8;
else if(_10.getFullYear()+1==_1.getFullYear())return 9;
else return 10;
break}
}
return _6},
getGroupTitle:function(_1,_2,_3,_4,_5){
var _6=_1;
var _7=_3.groupingMode=
(_3.groupingMode||_3.$62.defaultGroupingMode||null);
if(_7&&_1!="-none-"&&_1!=null&&_2.groupValue!=null){
switch(_7){
case"quarter":
_6="Q"+_2.groupValue;
break;
case"month":
_6=isc.DateUtil.getShortMonthNames()[_1];
break;
case"week":
_6=isc.GroupingMessages.weekNumberTitle+_2.groupValue;
break;
case"day":
case"dayOfWeek":
_6=isc.DateUtil.getShortDayNames()[_1];
break;
case"dayOfMonth":
_6=_1;
break;
case"quarterAndYear":
var _8=_2.groupValue.split("_");
_6="Q"+_8[1]+" "+_8[0];
break;
case"monthAndYear":
var _8=_2.groupValue.split("_");
var _9=new Number(_8[1]);
_6=isc.DateUtil.getMonthNames()[_9]+" "+_8[0];
break;
case"weekAndYear":
var _8=_2.groupValue.split("_");
_6=isc.GroupingMessages.weekNumberTitle+_8[1]+" "+_8[0];
break;
case"date":
var _8=_2.groupValue.split("_");
var _9=new Number(_8[1]);
var _10=isc.DateUtil.createLogicalDate(_8[0],_9,_8[2]);
_6=_10.toShortDate();
break;
case"dayOfWeekAndYear":
var _8=_2.groupValue.split("_");
_6=isc.GroupingMessages.weekNumberTitle+_8[3]+" "+
_8[0]+", "+isc.DateUtil.getDayNames()[parseInt(_8[4])];
break;
case"dayOfMonthAndYear":
var _8=_2.groupValue.split("_");
var _9=new Number(_8[1]);
_6=isc.DateUtil.getShortMonthNames()[_9]+" "+_8[0]+
", "+isc.DateUtil.getDayNames()[_8[3]]+" "+_8[2];
break;
case"timezoneHours":
_6="GMT+"+_1;
break;
case"timezoneMinutes":
_6="GMT+"+_1+" "+isc.GroupingMessages.timezoneMinutesSuffix;
break;
case"timezoneSeconds":
_6="GMT+"+_1+" "+isc.GroupingMessages.timezoneSecondsSuffix;
break;
case"upcoming":
var _11=new Date();
if(_1==1)return isc.GroupingMessages.upcomingBeforeTitle;
else if(_1==2)return isc.GroupingMessages.upcomingTodayTitle;
else if(_1==3)return isc.GroupingMessages.upcomingTomorrowTitle;
else if(_1==4)return isc.GroupingMessages.upcomingThisWeekTitle;
else if(_1==5)return isc.GroupingMessages.upcomingNextWeekTitle;
else if(_1==6)return isc.GroupingMessages.upcomingThisMonthTitle;
else if(_1==7)return isc.GroupingMessages.upcomingNextMonthTitle;
else if(_1==8)return isc.GroupingMessages.upcomingThisYearTitle;
else if(_1==9)return isc.GroupingMessages.upcomingNextYearTitle;
else return isc.GroupingMessages.upcomingLaterTitle;
break}
}
return _6}
},
time:{validators:{type:"isTime",typeCastValidator:true},
defaultOperator:"equals",
normalDisplayFormatter:function(_1,_2){
if(isc.isA.Date(_1))return isc.Time.toTime(_1,null,true);
return _1},
getGroupingModes:function(){
return{
hours:isc.GroupingMessages.byHoursTitle,
minutes:isc.GroupingMessages.byMinutesTitle,
seconds:isc.GroupingMessages.bySecondsTitle,
milliseconds:isc.GroupingMessages.byMillisecondsTitle
}
},
defaultGroupingMode:"hours",
getGroupValue:function(_1,_2,_3,_4,_5){
var _6=_1;
var _7=_3.groupingMode=
(_3.groupingMode||_3.$62.defaultGroupingMode||null);
if(isc.isA.Date(_1)&&_7){
switch(_7){
case"hours":
_6=_1.getHours();
break;
case"minutes":
_6=_1.getMinutes();
break;
case"seconds":
_6=_1.getSeconds();
break;
case"milliseconds":
_6=_1.getMilliseconds();
break}
}
return _6},
getGroupTitle:function(_1,_2,_3,_4,_5){
var _6=_1;
var _7=_3.groupingMode||_3.$62.defaultGroupingMode||null;
if(_7&&_1!="-none-"){
switch(_7){
case"hours":
case"minutes":
case"seconds":
case"milliseconds":
_6=_1;
break}
}
return _6}
},
string:{inheritsFrom:"text"},
ntext:{inheritsFrom:"text"},
"int":{inheritsFrom:"integer"},
"long":{inheritsFrom:"integer"},
number:{inheritsFrom:"integer"},
decimal:{inheritsFrom:"float"},
"double":{inheritsFrom:"float"},
datetime:{
validators:{type:"isDate",typeCastValidator:true},
defaultOperator:"equals",
normalDisplayFormatter:function(_1,_2){
if(isc.isA.Date(_1))return _1.toShortDateTime(null,true);
return _1},
getGroupingModes:function(){
return{
day:isc.GroupingMessages.byDayTitle,
week:isc.GroupingMessages.byWeekTitle,
month:isc.GroupingMessages.byMonthTitle,
quarter:isc.GroupingMessages.byQuarterTitle,
year:isc.GroupingMessages.byYearTitle,
dayOfMonth:isc.GroupingMessages.byDayOfMonthTitle,
upcoming:isc.GroupingMessages.byUpcomingTitle,
date:isc.GroupingMessages.byDateTitle,
weekAndYear:isc.GroupingMessages.byWeekAndYearTitle,
monthAndYear:isc.GroupingMessages.byMonthAndYearTitle,
quarterAndYear:isc.GroupingMessages.byQuarterAndYearTitle,
dayOfWeekAndYear:isc.GroupingMessages.byDayOfWeekAndYearTitle,
dayOfMonthAndYear:isc.GroupingMessages.byDayOfMonthAndYearTitle
}},
defaultGroupingMode:"date",
getGroupValue:function(_1,_2,_3,_4,_5){
var _6=_1;
var _7=_3.groupingMode=
(_3.groupingMode||_3.$62.defaultGroupingMode||null);
if(isc.isA.Date(_1)&&_7){
switch(_7){
case"year":
_6=_1.getFullYear();
break;
case"quarter":
_6=Math.floor(_1.getMonth()/3)+1;
break;
case"month":
_6=_1.getMonth();
break;
case"week":
_6=_1.getWeek();
break;
case"day":
case"dayOfWeek":
_6=_1.getDay();
break;
case"dayOfMonth":
_6=_1.getDate();
break;
case"quarterAndYear":
_6=_1.getFullYear()+"_"+(Math.floor(_1.getMonth()/3)+1);
break;
case"monthAndYear":
var _8=_1.getMonth();
_8=""+(_8<10?"0":"")+_8;
_6=_1.getFullYear()+"_"+_8;
break;
case"weekAndYear":
_6=_1.getFullYear()+"_"+
isc.DateUtil.format(_1,"ww");
break;
case"date":
var _8=_1.getMonth();
_8=""+(_8<10?"0":"")+_8;
_6=_1.getFullYear()+"_"+
_8+"_"+
isc.DateUtil.format(_1,"dd");
break;
case"dayOfWeekAndYear":
var _9=isc.DateUtil.getWeekNumber(_1);
_6=_9[0]+"_"+
isc.NumberUtil.stringify(_1.getMonth(),2)+"_"+
isc.NumberUtil.stringify(_1.getDate(),2)+"_"+
isc.NumberUtil.stringify(_9[1],2)+"_"+
isc.NumberUtil.stringify(_1.getDay(),2);
break;
case"dayOfMonthAndYear":
var _8=_1.getMonth();
_8=""+(_8<10?"0":"")+_8;
_6=_1.getFullYear()+"_"+
_8+"_"+
isc.DateUtil.format(_1,"dd")+"_"+
_1.getDay();
break;
case"timezoneHours":
_6=_1.getTimezoneOffset()/60;
break;
case"timezoneMinutes":
_6=_1.getTimezoneOffset();
break;
case"timezoneSeconds":
_6=_1.getTimezoneOffset()*60;
break;
case"upcoming":
var _10=new Date();
if(_10.isBeforeToday(_1))return 1;
else if(_10.isToday(_1))return 2;
else if(_10.isTomorrow(_1))return 3;
else if(_10.isThisWeek(_1))return 4;
else if(_10.isNextWeek(_1))return 5;
else if(_10.isThisMonth(_1))return 6;
else if(_10.isNextMonth(_1))return 7;
else if(_10.getFullYear()==_1.getFullYear())return 8;
else if(_10.getFullYear()+1==_1.getFullYear())return 9;
else return 10;
break}
}
return _6},
getGroupTitle:function(_1,_2,_3,_4,_5){
var _6=_1;
var _7=_3.groupingMode=
(_3.groupingMode||_3.$62.defaultGroupingMode||null);
if(_7&&_1!="-none-"&&_1!=null&&_2.groupValue!=null){
switch(_7){
case"quarter":
_6="Q"+_2.groupValue;
break;
case"month":
_6=isc.DateUtil.getShortMonthNames()[_1];
break;
case"week":
_6=isc.GroupingMessages.weekNumberTitle+_2.groupValue;
break;
case"day":
case"dayOfWeek":
_6=isc.DateUtil.getShortDayNames()[_1];
break;
case"dayOfMonth":
_6=_1;
break;
case"quarterAndYear":
var _8=_2.groupValue.split("_");
_6="Q"+_8[1]+" "+_8[0];
break;
case"monthAndYear":
var _8=_2.groupValue.split("_");
var _9=new Number(_8[1]);
_6=isc.DateUtil.getMonthNames()[_9]+" "+_8[0];
break;
case"weekAndYear":
var _8=_2.groupValue.split("_");
_6=isc.GroupingMessages.weekNumberTitle+_8[1]+" "+_8[0];
break;
case"date":
var _8=_2.groupValue.split("_");
var _9=new Number(_8[1]);
var _10=isc.DateUtil.createLogicalDate(_8[0],_9,_8[2]);
_6=_10.toShortDate();
break;
case"dayOfWeekAndYear":
var _8=_2.groupValue.split("_");
_6=isc.GroupingMessages.weekNumberTitle+_8[3]+" "+
_8[0]+", "+isc.DateUtil.getDayNames()[parseInt(_8[4])];
break;
case"dayOfMonthAndYear":
var _8=_2.groupValue.split("_");
var _9=new Number(_8[1]);
_6=isc.DateUtil.getShortMonthNames()[_9]+" "+_8[0]+
", "+isc.DateUtil.getDayNames()[_8[3]]+" "+_8[2];
break;
case"timezoneHours":
_6="GMT+"+_1;
break;
case"timezoneMinutes":
_6="GMT+"+_1+" "+isc.GroupingMessages.timezoneMinutesSuffix;
break;
case"timezoneSeconds":
_6="GMT+"+_1+" "+isc.GroupingMessages.timezoneSecondsSuffix;
break;
case"upcoming":
var _11=new Date();
if(_1==1)return isc.GroupingMessages.upcomingBeforeTitle;
else if(_1==2)return isc.GroupingMessages.upcomingTodayTitle;
else if(_1==3)return isc.GroupingMessages.upcomingTomorrowTitle;
else if(_1==4)return isc.GroupingMessages.upcomingThisWeekTitle;
else if(_1==5)return isc.GroupingMessages.upcomingNextWeekTitle;
else if(_1==6)return isc.GroupingMessages.upcomingThisMonthTitle;
else if(_1==7)return isc.GroupingMessages.upcomingNextMonthTitle;
else if(_1==8)return isc.GroupingMessages.upcomingThisYearTitle;
else if(_1==9)return isc.GroupingMessages.upcomingNextYearTitle;
else return isc.GroupingMessages.upcomingLaterTitle;
break}
}
return _6}
},
dateTime:{inheritsFrom:"datetime"},
positiveInteger:{
inheritsFrom:"integer",
validators:{type:"integerRange",min:0}
},
integerPercent:{
inheritsFrom:"integer",
validators:{type:"integerRange",min:0,max:100}
},
percent:{inheritsFrom:"integerPercent"},
sequence:{
inheritsFrom:"integer",
canEdit:false,
readOnlyDisplay:"static",
canFilter:true
},
"enum":{validators:"isOneOf",defaultOperator:"equals"},
"intEnum":{inheritsFrom:"integer",validators:"isOneOf"},
regexp:{inheritsFrom:"text",validators:"isRegexp"},
identifier:{inheritsFrom:"text",validators:"isIdentifier"},
URL:{inheritsFrom:"text"},
image:{inheritsFrom:"text"},
imageFile:{inheritsFrom:"binary"},
HTML:{inheritsFrom:"text"},
measure:{validators:"isMeasure",defaultOperator:"equals"},
measureOrIdentifier:{validators:"isMeasureOrIdentifier",defaultOperator:"equals"},
integerOrAuto:{validators:"integerOrAuto",defaultOperator:"equals"},
positiveIntegerOrAsterisk:{validators:"positiveIntegerOrAsterisk",defaultOperator:"equals"},
expression:{inheritsFrom:"text"},
method:{inheritsFrom:"text"},
"function":{inheritsFrom:"text"},
alignEnum:{
inheritsFrom:"enum",
valueMap:{left:"left",center:"center",right:"right"}
},
valignEnum:{
inheritsFrom:"enum",
valueMap:{top:"top",bottom:"bottom",center:"center"}
},
sideEnum:{
inheritsFrom:"enum",
valueMap:{left:"left",right:"right",top:"top",bottom:"bottom"}
},
color:{inheritsFrom:"string",validators:"isColor"},
modifier:{inheritsFrom:"text",hidden:true,canEdit:false},
modifierTimestamp:{inheritsFrom:"datetime",hidden:true,canEdit:false},
creator:{inheritsFrom:"text",hidden:true,canEdit:false},
creatorTimestamp:{inheritsFrom:"datetime",hidden:true,canEdit:false},
password:{
inheritsFrom:"text",
normalDisplayFormatter:function(_1,_2){
return new Array((_1&&_1.length>0?_1.length+1:0)).join("*")},
shortDisplayFormatter:function(_1,_2){
return new Array((_1&&_1.length>0?_1.length+1:0)).join("*")}
},
localeInt:{
inheritsFrom:"integer",
normalDisplayFormatter:function(_1,_2){
if(!isc.isA.Number(_1))_1=this.parseInput(_1);
if(!isc.isA.Number(_1))return _1;
return isc.NumberUtil.toLocalizedString(_1)},
shortDisplayFormatter:function(_1,_2){
if(!isc.isA.Number(_1))_1=this.parseInput(_1);
if(!isc.isA.Number(_1))return _1;
return isc.NumberUtil.toLocalizedString(_1)},
editFormatter:function(_1){
if(isc.isA.String(_1))return _1;
return isc.NumberUtil.toLocalizedString(_1)},
parseInput:function(_1){
var _2=isc.NumberUtil.parseLocaleInt(_1);
if(isNaN(_2)){
return _1}else{
return _2}
}
},
localeFloat:{
inheritsFrom:"float",
normalDisplayFormatter:function(_1,_2){
if(!isc.isA.Number(_1))_1=this.parseInput(_1);
if(!isc.isA.Number(_1))return _1;
return isc.NumberUtil.floatValueToLocalizedString(_1,_2.decimalPrecision,_2.decimalPad)},
shortDisplayFormatter:function(_1,_2){
if(!isc.isA.Number(_1))_1=this.parseInput(_1);
if(!isc.isA.Number(_1))return _1;
return isc.NumberUtil.floatValueToLocalizedString(_1,_2.decimalPrecision,_2.decimalPad)},
editFormatter:function(_1,_2){
var _3=isc.isA.String(_1)?_1:
isc.NumberUtil.floatValueToLocalizedString(_1,null,null,true);
return _3},
parseInput:function(_1){
var _2=isc.NumberUtil.parseLocaleFloat(_1);
if(isNaN(_2)){
return _1}else{
return _2}
},
compareValues:function(_1,_2,_3){
if(_1==_2){
var _4=isc.isA.Number(_1),
_5=isc.isA.Number(_2);
if(_4&&!_5)return-1;
if(!_4&&_5)return 1;
return 0}
if(_1>_2){
return-1}else{
return 1}
}
},
localeCurrency:{
inheritsFrom:"decimal",
normalDisplayFormatter:function(_1,_2){
if(!isc.isA.Number(_1))_1=this.parseInput(_1);
if(!isc.isA.Number(_1))return _1;
return isc.NumberUtil.toCurrencyString(_1)},
shortDisplayFormatter:function(_1,_2){
if(!isc.isA.Number(_1))_1=this.parseInput(_1);
if(!isc.isA.Number(_1))return _1;
return isc.NumberUtil.toCurrencyString(_1)},
editFormatter:function(_1){
if(isc.isA.String(_1))return _1;
return isc.NumberUtil.toCurrencyString(_1)},
parseInput:function(_1){
var _2=isc.NumberUtil.parseLocaleCurrency(_1);
if(isNaN(_2)){
return _1}else{
return _2}
},
compareValues:function(_1,_2,_3){
if(_1==_2){
var _4=isc.isA.Number(_1),
_5=isc.isA.Number(_2);
if(_4&&!_5)return-1;
if(!_4&&_5)return 1;
return 0}
if(_1>_2){
return-1}else{
return 1}
}
},
phoneNumber:{
inheritsFrom:"text",
browserInputType:"tel",
normalDisplayFormatter:function(_1,_2){
if(_1==null||_1=="")return _1;
return"<a href='tel:"+_1+"' class='sc_phoneNumber'>"+_1+"</a>"},
shortDisplayFormatter:function(_1,_2){
if(_1==null||_1=="")return _1;
return"<a href='tel:"+_1+"' class='sc_phoneNumber'>"+_1+"</a>"}
},
binary:{}
};
(function(){
for(var _1 in isc.builtinTypes){
isc.builtinTypes[_1].name=_1}
})();
isc.defineClass("SimpleType");
isc.SimpleType.addProperties({
})
isc.A=isc.SimpleType;
isc.B=isc._allFuncs;
isc.C=isc.B._maxIndex;
isc.D=isc._funcClasses;
isc.D[isc.C]=isc.A.Class;
isc.A.$7a="typeCastValidator";
isc.A.$71g={
title:function(_1,_2,_3){
if(_3==null)_3=isc.SimpleType.$141p();
if(_3.summaryValueTitle!=null)return _3.summaryValueTitle;
if(_2.summaryValueTitle!=null)return _2.summaryValueTitle;
return _2.title},
sum:function(_1,_2,_3,_4){
if(_3==null)_3=isc.SimpleType.$141p();
var _5=0;
for(var i=0;i<_1.length;i++){
var _7=isc.Canvas.$70o(null,_2,_1[i],_4,true,"formula"),
_8=parseFloat(_7)
;
if(_7==null||_7===isc.emptyString){
continue}
if(isc.isA.Number(_8)&&(_8==_7))_5+=_8;
else{
if((_2.userFormula||_2.userSummary)&&
_7==_3.badFormulaResultValue||
_7==_3.invalidSummaryValue)continue;
return null}
}
return _5},
avg:function(_1,_2,_3,_4){
if(_3==null)_3=isc.SimpleType.$141p();
var _5=0,_6=0;
for(var i=0;i<_1.length;i++){
var _8=isc.Canvas.$70o(null,_2,_1[i],_4,true,"formula"),
_9=parseFloat(_8)
;
if(_8==null||_8===isc.emptyString){
continue}
if(isc.isA.Number(_9)&&(_9==_8)){
_6+=1;
_5+=_9}else{
if((_2.userFormula||_2.userSummary)&&
_8==_3.badFormulaResultValue||
_8==_3.invalidSummaryValue)continue;
return null}
}
return _6>0?_5/_6:null},
max:function(_1,_2,_3,_4){
if(_3==null)_3=isc.SimpleType.$141p();
var _5=(_4&&_4.getDataSource&&_4.getDataSource())||_3.$213z;
if(_4&&_4.getDataSource)_5=_4.getDataSource()
else if(isc.isA.String(_3.dataSource))_5=isc.DS.get(_3.dataSource);
else _5=_3.dataSource;
var _6=(_2.type&&isc.SimpleType.getType(_2.type,_5))||isc.SimpleType.getType("text"),
_7;
for(var i=0;i<_1.length;i++){
var _9=isc.Canvas.$70o(null,_2,_1[i],_4,true,"formula");
if(_9==null){
continue}
if((_2.userFormula||_2.userSummary)&&
_9==_3.badFormulaResultValue||
_9==_3.invalidSummaryValue)
{
continue}
if(_7==null){
_7=_9}else{
var _10=isc.SimpleType.compareValues(_9,_7,_2,_6);
if(_10===false)continue;
if(_10<0)_7=_9}
}
return _7},
min:function(_1,_2,_3,_4){
if(_3==null)_3=isc.SimpleType.$141p();
var _5=(_4&&_4.getDataSource&&_4.getDataSource())||_3.$213z;
if(_4&&_4.getDataSource)_5=_4.getDataSource()
else if(isc.isA.String(_3.dataSource))_5=isc.DS.get(_3.dataSource);
else _5=_3.dataSource;
var _6=(_2.type&&isc.SimpleType.getType(_2.type,_5))||isc.SimpleType.getType("text"),
_7;
for(var i=0;i<_1.length;i++){
var _9=isc.Canvas.$70o(null,_2,_1[i],_4,true,"formula");
if(_9==null){
continue}
if((_2.userFormula||_2.userSummary)&&
_9==_3.badFormulaResultValue||
_9==_3.invalidSummaryValue)
{
continue}
if(_7==null){
_7=_9}else{
var _10=isc.SimpleType.compareValues(_9,_7,_2,_6);
if(_10===false)continue;
if(_10>0)_7=_9}
}
return _7},
multiplier:function(_1,_2,_3,_4){
if(_3==null)_3=isc.SimpleType.$141p();
var _5=0;
for(var i=0;i<_1.length;i++){
var _7=isc.Canvas.$70o(null,_2,_1[i],_4,true,"formula");
var _8=parseFloat(_7);
if(isc.isA.Number(_8)&&(_8==_7)){
if(i==0)_5=_8;
else _5=(_5*_8)}else{
if((_2.userFormula||_2.userSummary)&&
_7==_3.badFormulaResultValue||
_7==_3.invalidSummaryValue)continue;
return null}
}
return _5},
count:function(_1){
return _1.length},
first:function(_1,_2,_3,_4){
return isc.SimpleType.applySummaryFunction(_1,_2,"min",_3,
_4)},
concat:function(_1,_2,_3,_4){
if(_3==null)_3=isc.SimpleType.$141p();
var _5=[];
for(var i=0;i<_1.length;i++){
var _7=isc.Canvas.$70o(null,_2,_1[i],_4,true,"formula");
_5.add(_7)}
var _8=_3.joinPrefix||_2.jsonPrefix||'';
var _9=_3.joinSuffix||_2.jsonSuffix||'';
var _10=_3.joinString||_2.joinString||'';
var _11=_5.join(_10);
return _8.concat(_11,_9)},
array:function(_1,_2,_3,_4){
if(_3==null)_3=isc.SimpleType.$141p();
var _5=[];
for(var i=0;i<_1.length;i++){
var _7=isc.Canvas.$70o(null,_2,_1[i],_4,true,"formula");
_5.add(_7)}
return _5}
};
isc.A.serverSummaryFunctions=["sum","avg","max","min","count","first"];
isc.B.push(isc.A.getType=function isc_c_SimpleType_getType(_1,_2){
var _3;
if(_2){
_3=_2.getType(_1);
if(_3)return _3;
while(_2.inheritsFrom){
var _4=isc.DS.get(_2.inheritsFrom);
if(!_4)break;
_3=this.getType(_1,_4);
if(_3)return _3;
_2=_4}
}
_3=isc.builtinTypes[_1];
if(_3!=null&&!isc.isAn.Instance(_3)){
isc.builtinTypes[_1]=null;
_3.name=_1;
_3=isc.SimpleType.create(_3)}
return _3}
,isc.A.getBaseType=function isc_c_SimpleType_getBaseType(_1,_2){
if(isc.isA.String(_1))_1=this.getType(_1,_2);
if(_1==null)return null;
while(_1.inheritsFrom){
var _3=this.getType(_1.inheritsFrom,_2);
if(_3==null)return null;
_1=_3}
return _1.name}
,isc.A.inheritsFrom=function isc_c_SimpleType_inheritsFrom(_1,_2,_3){
if(_2==null){
this.logWarn("inheritsFrom passed null type");
return false}
if(isc.isA.String(_1))_1=this.getType(_1,_3);
if(_1==null)return false;
if(_1.name==_2)return true;
while(_1.inheritsFrom){
var _4=this.getType(_1.inheritsFrom,_3);
if(_4==null)return null;
if(_4.name==_2)return true;
_1=_4}
return false}
,isc.A.validateValue=function isc_c_SimpleType_validateValue(_1,_2,_3){
var _4={name:"$42j",type:_1};
isc.SimpleType.addTypeDefaults(_4);
var _3=_3||isc.DS.get("Object");
return _3.validateFieldValue(_4,_2)}
,isc.A.addTypeDefaults=function isc_c_SimpleType_addTypeDefaults(_1,_2){
if(_1==null||_1.$61)return;
_1.$61=true;
var _3=this.getType(_1.type,_2);
if(_3==null)return;
_1.$62=_3;
if(_1.valueMap==null){
var _4=this.getInheritedProperty(_3,"valueMap",_2);
if(_4!=null)_3.valueMap=_1.valueMap=_4}
if(_1.editorType==null){
var _5=this.getInheritedProperty(_3,"editorType",_2);
if(_5!=null)_3.editorType=_1.editorType=_5}
if(_1.readOnlyEditorType==null){
var _5=this.getInheritedProperty(_3,"readOnlyEditorType",_2);
if(_5!=null)_3.readOnlyEditorType=_1.readOnlyEditorType=_5}
if(_1.filterEditorType==null){
var _5=this.getInheritedProperty(_3,"filterEditorType",_2);
if(_5!=null)_3.filterEditorType=_1.filterEditorType=_5}
if(_1.browserInputType==null){
var _6=this.getInheritedProperty(_3,"browserInputType",_2);
if(_6!=null)_3.browserInputType=_1.browserInputType=_6}
if(_1.canEdit==null){
var _7=this.getInheritedProperty(_3,"canEdit",_2);
if(_7!=null){
_1.canEdit=_7}
}
if(_1.canFilter==null){
var _8=this.getInheritedProperty(_3,"canFilter",_2);
if(_8!=null){
_1.canFilter=_8}
}
this.setupInheritedProperties(_3,_2);
var _9=this.getInheritedProperty(_3,"editorProperties",_2);
if(_9!=null){
if(_1.editorProperties!=null){
_1.editorProperties=isc.addProperties({},_9,_1.editorProperties)}else{
_1.editorProperties=isc.addProperties({},_9)}
}
if(_1.readOnlyDisplay==null){
var _10=this.getInheritedProperty(_3,"readOnlyDisplay",_2);
if(_10!=null)_1.readOnlyDisplay=_10}
var _11=this.getInheritedProperty(_3,"readOnlyEditorProperties",_2);
if(_11!=null){
if(_1.readOnlyEditorProperties!=null){
isc.addProperties(_11,_1.readOnlyEditorProperties)}
_1.readOnlyEditorProperties=_11}
var _12=this.getInheritedProperty(_3,"filterEditorProperties",_2);
if(_12!=null){
_1.filterEditorProperties=isc.addProperties({},_12,
_1.filterEditorProperties)}
var _13=this.getInheritedProperty(_3,"shortDisplayFormatter",_2)
if(_13!=null)_3.shortDisplayFormatter=_13;
var _13=this.getInheritedProperty(_3,"normalDisplayFormatter",_2)
if(_13!=null)_3.normalDisplayFormatter=_13;
var _13=this.getInheritedProperty(_3,"editFormatter",_2)
if(_13!=null)_3.editFormatter=_13;
var _14=this.getInheritedProperty(_3,"parseInput",_2)
if(_14!=null)_3.parseInput=_14;
var _15=this.getValidators(_3,_2);
if(_15==null)return;
if(!_1.validators){
_1.validators=_15}else{
if(!isc.isAn.Array(_1.validators))_1.validators=[_1.validators];
_1.validators.addAsList(_15);
this.$67(_1.validators)}
}
,isc.A.setupInheritedProperties=function isc_c_SimpleType_setupInheritedProperties(_1,_2){
if(_1.getGroupTitle==null){
var _3=this.getInheritedProperty(_1,"getGroupTitle",_2);
if(_3!=null)_1.getGroupTitle=_3}
if(_1.getGroupValue==null){
var _4=this.getInheritedProperty(_1,"getGroupValue",_2);
if(_4!=null)_1.getGroupValue=_4}
if(_1.getGroupingModes==null){
var _5=this.getInheritedProperty(_1,"getGroupingModes",_2);
if(_5!=null)_1.getGroupingModes=_5}
}
,isc.A.getInheritedProperty=function isc_c_SimpleType_getInheritedProperty(_1,_2,_3){
while(_1!=null){
if(_1[_2]!=null)return _1[_2]
_1=this.getType(_1.inheritsFrom,_3)}
}
,isc.A.getValidators=function isc_c_SimpleType_getValidators(_1,_2){
if(isc.isA.String(_1))_1=this.getType(_1,_2);
if(_1.$68)return _1.validators;
var _3=_1.validators;
if(_3!=null){
if(!isc.isAn.Array(_3))_3=[_3];
var _4=[];
for(var i=0;i<_3.length;i++){
var _6=_3[i];
if(isc.isA.String(_6)){
_6={"type":_6}}else if(_6.type==null&&isc.isAn.emptyObject(_6)){
continue}
_6._generated=true;
_6.$174l=true;
_4.add(_6)}
_3=_4}
var _7=_1.inheritsFrom;
if(_7!=null){
var _8=this.getType(_7,_2);
if(_8!=null){
var _9=this.getValidators(_8,_2);
if(_9!=null){
_3=_3||[];
_3.addAsList(_9);
this.$67(_3)}
}
}
if(_3)_3.$69=true;
_1.validators=_3;
_1.$68=true;
return _3}
,isc.A.$67=function isc_c_SimpleType__reorderTypeValidator(_1){
var _2=_1.find(this.$7a,true);
if(_2){
var _3=_2.type;
for(var i=0;i<_1.length;i++){
if(_1[i].type==_3)break}
if(i!=0){
var _5=_1[i];
_1.splice(i,1);
_1.unshift(_5)}
_1[0].stopIfFalse=true}
}
,isc.A.compareValues=function isc_c_SimpleType_compareValues(_1,_2,_3,_4){
if(_4.compareValues)return _4.compareValues(_1,_2,_3);
if(isc.isA.Date(_1)&&isc.isA.Date(_2)){
if(this.inheritsFrom(_4,"date")){
return isc.DateUtil.compareLogicalDates(_1,_2)}
if(this.inheritsFrom(_4,"time")){
return isc.Time.compareLogicalTimes(_1,_2)}
return isc.DateUtil.compareDates(_1,_2)}
if(_1==_2)return 0;
if(_1>_2)return-1;
if(_1<_2)return 1;
return false}
,isc.A.$141p=function isc_c_SimpleType__getDefaultSummaryConfiguration(_1){
return{
invalidSummaryValue:isc.ListGrid==null?"&nbsp;":
isc.ListGrid.getInstanceProperty("invalidSummaryValue"),
badFormulaResultValue:isc.DataBoundComponent==null?".":
isc.Canvas.getInstanceProperty("badFormulaResultValue"),
dataSource:_1
}}
,isc.A.registerSummaryFunction=function isc_c_SimpleType_registerSummaryFunction(_1,_2){
if(!isc.isA.nonemptyString(_1)){
this.logError("`functionName` must be a non-empty string.");
return}
if(isc.isA.String(_2)){
_2=isc.Func.expressionToFunction(
"records,field,summaryConfig,displayComponent",
_1)}
if(this.$71g[_1]){
this.logWarn("Summary function '"+_1+"' is already registered. Replacing...")}
this.$71g[_1]=_2}
,isc.A.getRegisteredSummaryFunctions=function isc_c_SimpleType_getRegisteredSummaryFunctions(){
return isc.getKeys(this.$71g)}
,isc.A.setDefaultSummaryFunction=function isc_c_SimpleType_setDefaultSummaryFunction(_1,_2){
var _3=this.getType(_1);
if(_3)_3.$71h=_2}
,isc.A.getDefaultSummaryFunction=function isc_c_SimpleType_getDefaultSummaryFunction(_1){
var _2=this.getType(_1);
if(_2){
if(_2.$71h!=null){
return _2.$71h}
if(_2.inheritsFrom!=null&&_2.inheritsFrom!=_1){
return this.getDefaultSummaryFunction(_2.inheritsFrom)}
}
}
,isc.A.applySummaryFunction=function isc_c_SimpleType_applySummaryFunction(_1,_2,_3,_4,_5){
if(!_3||!_2||!_1)return;
if(isc.isA.String(_3)){
if(this.$71g[_3]){
_3=this.$71g[_3]}else{
_3=isc.Func.expressionToFunction(
"records,field,summaryConfig,displayComponent",
_3)}
}
if(isc.isA.Function(_3)){
return _3(_1,_2,_4,_5)}
}
,isc.A.getValidOperators=function isc_c_SimpleType_getValidOperators(_1){
_1=_1||"text";
var _2=this.getType(_1);
if(_2){
if(_2.validOperators!=null){
return _2.validOperators}
if(_2.inheritsFrom!=null&&_2.inheritsFrom!=_1){
return this.getValidOperators(_2.inheritsFrom)}
}
}
,isc.A.getDefaultOperator=function isc_c_SimpleType_getDefaultOperator(_1){
_1=_1||"text";
var _2=this.getType(_1);
if(_2){
if(_2.defaultOperator!=null){
return _2.defaultOperator}
if(_2.inheritsFrom!=null&&_2.inheritsFrom!=_1){
return this.getDefaultOperator(_2.inheritsFrom)}
}
}
);
isc.B._maxIndex=isc.C+18;
isc.A=isc.SimpleType.getPrototype();
isc.B=isc._allFuncs;
isc.C=isc.B._maxIndex;
isc.D=isc._funcClasses;
isc.D[isc.C]=isc.A.Class;
isc.B.push(isc.A.init=function isc_SimpleType_init(){
if(!this.name)this.name=isc.ClassFactory.getNextGlobalID(this);
if(isc.builtinTypes[this.name]!=null){
if(!this.xmlSource){
this.logWarn("SimpleType '"+this.name+"' defined twice: "+
this.getStackTrace());
isc.builtinTypes[this.name]=this}
}else{
isc.builtinTypes[this.name]=this}
if(this.validOperators!=null){
isc.DataSource.setTypeOperators(this.name,this.validOperators)}
}
);
isc.B._maxIndex=isc.C+1;
isc.SimpleType.setDefaultSummaryFunction("integer","sum");
isc.SimpleType.setDefaultSummaryFunction("float","sum");
isc.SimpleType.addProperties({
})
isc.SimpleType.getPrototype().toString=function(){
return"["+this.Class+" name="+this.name+
(this.inheritsFrom?" inheritsFrom="+this.inheritsFrom:"")+"]"};
isc.defineClass("NavigationButton","Button");isc.A=isc.NavigationButton.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.height="100%";isc.A.padding=5;isc.A.autoFit=true;isc.A.skinImgDir="images/NavigationBar/";isc.A.baseStyle="navButton";isc.A.backBaseStyle="navBackButton";isc.A.forwardBaseStyle="navForwardButton";isc.A.direction="none";isc.B.push(isc.A.initWidget=function isc_NavigationButton_initWidget(){this.Super("initWidget",arguments);this.setBaseStyle(this.getBaseStyleName())}
,isc.A.setNavigationDirection=function isc_NavigationButton_setNavigationDirection(_1){this.direction=_1;this.setBaseStyle(this.getBaseStyleName())}
,isc.A.getNavigationDirection=function isc_NavigationButton_getNavigationDirection(){return this.direction}
,isc.A.getBaseStyleName=function isc_NavigationButton_getBaseStyleName(){if(this.direction=="back"){return this.backBaseStyle}
if(this.direction=="forward"){return this.forwardBaseStyle}
return this.baseStyle}
,isc.A.$118j=function isc_NavigationButton__explicitlySizeTable(){return true}
);isc.B._maxIndex=isc.C+5;isc.defineClass("MiniNavControl","StretchImgButton");isc.A=isc.MiniNavControl.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.skinImgDir="images/NavigationBar/";isc.A.showDisabled=false;isc.A.showDown=false;isc.A.showRollOver=false;isc.A.showTitle=false;isc.A.upButtonSrc="[SKIN]/up.png";isc.A.upButtonWidth=20;isc.A.upButtonHeight=22;isc.A.downButtonSrc="[SKIN]/down.png";isc.A.downButtonWidth=20;isc.A.downButtonHeight=22;isc.A.height=22;isc.A.width=66;isc.A.$1447="blank0";isc.A.$74f="up";isc.A.$1448="blank1";isc.A.$1449="blank2";isc.A.$74g="down";isc.A.$145a="blank3";isc.B.push(isc.A.initWidget=function isc_MiniNavControl_initWidget(){this.Super("initWidget",arguments);this.items=[{name:this.$1447,width:5,height:5},{name:this.$74f,src:this.upButtonSrc,width:"upButtonWidth",height:"upButtonHeight"},{name:this.$1448,width:"*",height:"*"},{name:this.$1449,width:"*",height:"*"},{name:this.$74g,src:this.downButtonSrc,width:"downButtonWidth",height:"downButtonHeight"},{name:this.$145a,width:5,height:5}
]
}
,isc.A.click=function isc_MiniNavControl_click(){var _1=this.inWhichPart();if(_1==null)return;var _2=this.getPart(_1);if(_1===this.$1447||_1===this.$74f||this.partName===this.$1448){var _3=(_1===this.$74f?_2:this.getPart(this.$74f));if(_3.state!==isc.StatefulCanvas.STATE_DISABLED){if(this.upClick)this.upClick()}
}else{var _4=(_1===this.$74g?_2:this.getPart(this.$74g));if(_4.state!==isc.StatefulCanvas.STATE_DISABLED){if(this.downClick)this.downClick()}
}
}
);isc.B._maxIndex=isc.C+2;isc.MiniNavControl.registerStringMethods({upClick:"",downClick:""});isc.defineClass("NavigationBar","HLayout");isc.A=isc.NavigationBar.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.width="100%";isc.A.height=36;isc.A.overflow="hidden";isc.A.styleName="navToolbar";isc.A.skinImgDir="images/NavigationBar/";isc.A.animateStateChanges=false;isc.A.skinUsesCSSTransitions=false;isc.A.animateStateChangeTime=350;isc.A.addedFadeInStyleName="navBarAddedFadeIn";isc.A.removedFadeOutStyleName="navBarRemovedFadeOut";isc.A.fadeInStyleName="navBarFadeIn";isc.A.fadeOutStyleName="navBarFadeOut";isc.A.oldLeftButtonBackStyleName="navBarOldLeftButtonBack";isc.A.newLeftButtonBackStyleName="navBarNewLeftButtonBack";isc.A.oldLeftButtonForwardStyleName="navBarOldLeftButtonForward";isc.A.newLeftButtonForwardStyleName="navBarNewLeftButtonForward";isc.A.oldTitleBackStyleName="navBarOldTitleBack";isc.A.newTitleBackStyleName="navBarNewTitleBack";isc.A.oldTitleForwardStyleName="navBarOldTitleForward";isc.A.newTitleForwardStyleName="navBarNewTitleForward";isc.A.eventMaskPeerDefaults={$jq:false,ariaState:{hidden:true
}
};isc.A.shortLeftButtonTitle="Back";isc.A.alwaysShowLeftButtonTitle=false;isc.A.leftButtonIcon="[SKIN]back_arrow.png";isc.A.iconBaseStyle="icon";isc.A.leftButtonDefaults={_constructor:"NavigationButton",direction:"back",clipTitle:true,iconSize:16,click:function(){var _1=this.creator;if(!_1.$35v&&_1.navigationClick!=null){_1.navigationClick(this.direction)}
}
};isc.A.leftButtonSpacerDefaults={_constructor:"LayoutSpacer",height:1
};isc.A.maxCenterOffset=40;isc.A.titleLabelDefaults={_constructor:"Label",height:"100%",baseStyle:"navBarHeader",align:"center",valign:"center",clipTitle:true,wrap:false,overflow:"hidden"
};isc.A.titleLabelSpacerDefaults={_constructor:"LayoutSpacer",width:"*",height:1
};isc.A.rightButtonTitle="&nbsp;";isc.A.rightButtonDefaults={_constructor:"NavigationButton",direction:"forward",clipTitle:true,click:function(){var _1=this.creator;if(!_1.$35v&&_1.navigationClick!=null){_1.navigationClick(this.direction)}
}
};isc.A.showRightButton=false;isc.A.controls=["leftButton","titleLabel","rightButton"];isc.A.miniNavControlDefaults={_constructor:"MiniNavControl",layoutAlign:"center",upClick:function(){var _1=this.creator,_2=_1.upClick;if(_2!=null){return _2.apply(_1,arguments)}
},downClick:function(){var _1=this.creator,_2=_1.downClick;if(_2!=null){return _2.apply(_1,arguments)}
}
};isc.A.showMiniNavControl=false;isc.A.miniNavAlign="right";isc.A.blankImgSrc=isc.Canvas.$wz;isc.A.$1599="rightButton";isc.A.$27r="none";isc.A.$159a="back";isc.A.leftButtonIconFadeInDelayRatio=0.3;isc.A.leftButtonIconFadeOutDurationRatio=0.7;isc.A.titleFadeOutDurationRatio=0.4;isc.A.titleFadeInDelayRatio=0.3;isc.B.push(isc.A.setControls=function isc_NavigationBar_setControls(_1,_2){this.controls=_1;if(_2==null)_2=this.$158p(this);if(!_2.contains(this.leftButton)){this.showLeftButton=false;this.leftButton.setVisibility(isc.Canvas.HIDDEN)}
this.setMembers(_2);if(_2.contains(this.titleLabelSpacer)){this.titleLabel.moveBelow(this.titleLabelSpacer)}else if(_2.length>0){this.titleLabel.moveBelow(_2[0])}
}
,isc.A.$158p=function isc_NavigationBar__controlsToMembers(_1){var _2=_1.controls;if(_2==null)return[];var _3=this.titleLabel,_4=this.titleLabelSpacer,_5=[];for(var i=0,_7=_2.length;i<_7;++i){var _8=_2[i];if(_8==null)continue;if((_8==="miniNavControl"||_8===_1.miniNavControl)&&_1.showMiniNavControl==false)
{continue}
if(isc.isA.String(_8)){_8=this[_8];if(_8==null)continue}
if(_8===_3){_8=_4}
if(_5.contains(_8)){this.logWarn("The controls array contains "+isc.echo(_8)+" two or more times.");continue}
_5.add(_8)}
return _5}
,isc.A.initWidget=function isc_NavigationBar_initWidget(){this.Super("initWidget",arguments);var _1=this.isRTL();var _2=this.leftButtonMeasurer=this.createAutoChild("leftButton",{top:-9999,left:_1?9999:-9999,canFocus:false,iconSize:this.iconSize,iconStyle:this.iconBaseStyle,ariaRole:"presentation",ariaState:{hidden:true
}
});this.addChild(_2);var _3=this.titleLabel=this.createAutoChild("titleLabel",{baseStyle:this.navBarHeaderStyleName||"navBarHeader"
}
);this.addChild(_3);this.titleLabelSpacer=this.createAutoChild("titleLabelSpacer");var _4=this.titleLabelMeasurer=this.createAutoChild("titleLabel",{top:-9999,left:_1?9999:-9999,width:1,contents:this.title,overflow:"visible",ariaRole:"presentation",ariaState:{hidden:true
}
});this.addChild(_4);var _5={title:this.rightButtonTitle,icon:this.rightButtonIcon
}
if(this.iconSize!=null)_5.iconSize=this.iconSize;if(this.iconBaseStyle!=null)_5.iconStyle=this.iconBaseStyle;this.rightButton=this.createAutoChild(this.$1599,_5);var _6=this.showLeftButton;this.showLeftButton=true;var _7={autoParent:"none",title:this.leftButtonTitle,icon:this.leftButtonIcon,visibility:_6==false?isc.Canvas.HIDDEN:isc.Canvas.INHERIT
}
if(this.iconSize!=null)_7.iconSize=this.iconSize;if(this.iconBaseStyle!=null)_7.iconStyle=this.iconBaseStyle;var _8=this.addAutoChild("leftButton",_7);if(this.controls==null||(!this.controls.contains("leftButton")&&!this.controls.contains(_8)))
{_6=false}
this.showLeftButton=_6;this.setShowRightButton(this.showRightButton!=false);if(this.showMiniNavControl&&(this.controls==null||(!this.controls.contains("miniNavControl")&&(this.customNavControl==null||!this.controls.contains(this.customNavControl)))))
{var _9=this.controls;if(_9==null){_9=this.controls=[]}else{_9=this.controls=_9.duplicate()}
if(this.miniNavAlign=="left"){_9.addAt("miniNavControl",1)}else if(this.miniNavAlign=="center"){_9.addAt("miniNavControl",2)}else{_9.add("miniNavControl")}
}
if(this.customNavControl){this.miniNavControl=this.customNavControl}else{this.miniNavControl=this.createAutoChild("miniNavControl")}
this.miniNavControl.setVisibility(this.showMiniNavControl?isc.Canvas.INHERIT:isc.Canvas.HIDDEN);this.setControls(this.controls);if(this.animateStateChanges){this.leftButtonSpacer=this.createAutoChild("leftButtonSpacer");var _10=this.$158r=this.createAutoChild("leftButton",{icon:this.leftButtonIcon,iconSize:this.iconSize,iconStyle:this.iconBaseStyle,title:isc.emptyString,visibility:isc.Canvas.HIDDEN
});this.addChild(_10);var _11=this.$158x=this.createAutoChild("leftButton",{icon:this.blankImgSrc,iconSize:this.iconSize,iconStyle:this.iconBaseStyle,visibility:isc.Canvas.HIDDEN
});this.addChild(_11);var _12=this.$158y=this.createAutoChild("titleLabel",{visibility:isc.Canvas.HIDDEN
});this.addChild(_12)}
}
,isc.A.setTitle=function isc_NavigationBar_setTitle(_1){this.title=_1;this.$143r()}
,isc.A.setLeftButtonTitle=function isc_NavigationBar_setLeftButtonTitle(_1){this.leftButtonTitle=_1;if(this.leftButton!=null)this.leftButton.setTitle(_1)}
,isc.A.setShortLeftButtonTitle=function isc_NavigationBar_setShortLeftButtonTitle(_1){this.shortLeftButtonTitle=_1;this.$143r()}
,isc.A.setAlwaysShowLeftButtonTitle=function isc_NavigationBar_setAlwaysShowLeftButtonTitle(_1){this.alwaysShowLeftButtonTitle=_1;this.$143r()}
,isc.A.setLeftButtonIcon=function isc_NavigationBar_setLeftButtonIcon(_1){this.leftButtonIcon=_1;if(this.leftButton!=null&&!this.$35v){this.leftButton.setIcon(_1)}
}
,isc.A.setShowLeftButton=function isc_NavigationBar_setShowLeftButton(_1){if(_1==null)_1=true;if(!this.members.contains(this.leftButton))_1=false;this.showLeftButton=_1;this.leftButton.setVisibility(_1==false?isc.Canvas.HIDDEN:isc.Canvas.INHERIT)}
,isc.A.setRightButtonTitle=function isc_NavigationBar_setRightButtonTitle(_1){this.rightButtonTitle=_1;if(this.rightButton)this.rightButton.setTitle(_1);this.reflow()}
,isc.A.setRightButtonIcon=function isc_NavigationBar_setRightButtonIcon(_1){this.rightButtonIcon=_1;if(this.rightButton)this.rightButton.setIcon(_1)}
,isc.A.setShowRightButton=function isc_NavigationBar_setShowRightButton(_1){if(_1==null)_1=true;if(this.controls==null||(!this.controls.contains(this.$1599)&&!this.controls.contains(this.rightButton)))
{_1=false}
this.showRightButton=_1;this.rightButton.setVisibility(_1?isc.Canvas.INHERIT:isc.Canvas.HIDDEN)}
,isc.A.setCustomNavControl=function isc_NavigationBar_setCustomNavControl(_1){this.customNavControl=_1}
,isc.A.setViewState=function isc_NavigationBar_setViewState(_1,_2,_3){if(_1==null)return;if(this.$35v){if(!isc.Browser.$139c||!this.skinUsesCSSTransitions){isc.Animation.finishAnimation(this.$1580)}else{this.$1460(true)}
}
var _4,_5=false,_6=false,_7=false,_8=false,_9=false,_10=false,_11;if(_1.controls!==_11){_4=this.$158p(_1);_5=!_4.equals(this.members);if(!_4.contains(this.leftButton)){_1.showLeftButton=false}
}
if(_1.showLeftButton!==_11){_6=(this.showLeftButton!=false)!=(_1.showLeftButton!=false)}
if(_1.leftButtonTitle!==_11){_7=this.leftButtonTitle!=_1.leftButtonTitle}
if(_1.shortLeftButtonTitle!==_11){_8=this.shortLeftButtonTitle!=_1.shortLeftButtonTitle}
if(_1.alwaysShowLeftButtonTitle!==_11){_9=!!this.alwaysShowLeftButtonTitle!=!!_1.alwaysShowLeftButtonTitle}
if(_1.title!==_11){_10=this.title!=_1.title}
if(!(_5||_6||_7||_8||_9||_10))
{return}
if(_2==null||_2===this.$27r||!this.animateStateChanges||!this.isDrawn()||!this.isVisible())
{if(_5){this.setControls(_1.controls,_4)}
if(_6){this.setShowLeftButton(_1.showLeftButton)}
if(_7){this.leftButtonTitle=_1.leftButtonTitle}
if(_8){this.shortLeftButtonTitle=_1.shortLeftButtonTitle}
if(_9){this.alwaysShowLeftButtonTitle=!!_1.alwaysShowLeftButtonTitle}
if(_10){this.title=_1.title}
if(this.$3n)this.reflowNow();else this.$143r()}else{var _12=isc.Browser.$139c&&this.skinUsesCSSTransitions;var _13=this.eventMaskPeer;if(_13==null){_13=this.eventMaskPeer=this.createAutoChild("eventMaskPeer",{left:this.getLeft(),top:this.getTop(),width:this.getWidth(),height:this.getHeight()
});this.addPeer(_13)}else{_13.setRect(this.getLeft(),this.getTop(),this.getWidth(),this.getHeight())}
_13.moveAbove(this);_13.show();this.$35v=true;if(isc.Canvas.ariaEnabled())this.setAriaState("busy",true);var _14=this.$1371={direction:_2,showLeftButtonDifferent:_6,leftButtonTitleDifferent:_7,shortLeftButtonTitleDifferent:_8,alwaysShowLeftButtonTitleDifferent:_9,titleDifferent:_10,controlsDifferent:_5,oldViewState:null,oldMembers:null,oldAutoFitInfo:null,removedMembers:null,addedMembers:null,retainedMembers:null,newViewState:null,newMembers:null,newAutoFitInfo:null,leftButtonLogicalIconOrientation:this.leftButton.$158o(),leftIconButtonWidth:null
};var _15,_16=_14.oldViewState={members:null,leftButtonIcon:this.leftButtonIcon,leftButton:this.leftButton,maxCenterOffset:this.maxCenterOffset,titleLabelSpacer:this.titleLabelSpacer,showMiniNavControl:this.showMiniNavControl,miniNavControl:this.miniNavControl,showRightButton:this.showRightButton,rightButton:this.rightButton,showLeftButton:this.showLeftButton!=false,leftButtonTitle:this.leftButtonTitle,shortLeftButtonTitle:this.shortLeftButtonTitle,alwaysShowLeftButtonTitle:this.alwaysShowLeftButtonTitle,title:this.title,controls:this.controls
},_17=_16.showLeftButton,_18,_19=_14.newViewState=isc.addProperties({},_16,_1,{members:null,leftButtonIcon:this.leftButtonIcon,leftButton:this.leftButton,maxCenterOffset:this.maxCenterOffset,titleLabelSpacer:this.titleLabelSpacer,showMiniNavControl:this.showMiniNavControl,miniNavControl:this.miniNavControl,showRightButton:this.showRightButton,rightButton:this.rightButton
}),_20=_19.showLeftButton;if(_5){_15=this.members.duplicate();_18=_4;var _21=_14.addedMembers=[],_22=_14.retainedMembers=[];for(var i=0,_24=_18.length;i<_24;++i){var _25=_18[i];if(!_15.contains(_25)){_21.add(_25);_25.setOpacity(0)}else{_22.add(_25)}
_25.setVisibility(isc.Canvas.INHERIT)}
var _26=(_15.length-_22.length),_27=_14.removedMembers=[];for(var i=0,_24=_15.length;i<_24;++i){var _28=_15[i];if(!_18.contains(_28)){_27.add(_28);_28.setVisibility(isc.Canvas.INHERIT);if(_27.length==_26){break}
}
}
var _29=this.$3n;if(_29){this.reflowNow()}
_16.members=_15;_14.oldAutoFitInfo=this.$158s(_16);if(_29)this.$158w(_14.oldAutoFitInfo);_19.members=_18;if(_21.length>0){if(_20){this.leftButton.setTitle(_19.leftButtonTitle);this.leftButton.redrawIfDirty();this.leftButton.setVisibility(isc.Canvas.INHERIT)}else{this.leftButton.setVisibility(isc.Canvas.HIDDEN)}
this.setMembers(_18);if(this.$3n){this.reflowNow()}
_14.newAutoFitInfo=this.$158s(_19);this.setMembers(_15);if(this.$3n){this.reflowNow()}
this.$158w(_14.oldAutoFitInfo)}else{_14.newAutoFitInfo=this.$158s(_19)}
}else{_4=this.members.duplicate();if(!_16.showMiniNavControl&&this.miniNavControl!=null){_4.remove(this.miniNavControl)}
_18=_15=_4;var _29=this.$3n;if(_29){this.reflowNow()}
_16.members=_15;_14.oldAutoFitInfo=this.$158s(_16);if(_29)this.$158w(_14.oldAutoFitInfo);_19.members=_18;_29=false;if((!_17||_7)&&_20)
{this.leftButton.setTitle(_19.leftButtonTitle);this.leftButton.redrawIfDirty();this.leftButton.setVisibility(isc.Canvas.INHERIT);_29=this.$3n;if(_29)this.reflowNow()}else if(!_20){this.leftButton.setVisibility(isc.Canvas.HIDDEN);_29=this.$3n;if(_29)this.reflowNow()}
_14.newAutoFitInfo=this.$158s(_19);if(_29)this.$158w(_14.newAutoFitInfo)}
var _30=_14.oldAutoFitInfo,_31=_14.newAutoFitInfo;_14.oldMembers=_15;_14.newMembers=_18;if(_17||_20){if(_17){var _32=this.$158x;_32.moveTo(_30.$158u,this.leftButton.getTop());_32.setOpacity(null);_32.setTitle(_30.leftButtonTitle);_32.setVisibility(isc.Canvas.INHERIT);_32.redrawIfDirty()}
this.leftButton.setVisibility(isc.Canvas.INHERIT);if((_17&&!_20)||(_17&&_20))
{this.leftButton.setOpacity(null)}else{this.leftButton.setOpacity(0)}
if(this.leftButtonIcon){var _33=this.leftButtonMeasurer;_33.setProperties({icon:this.leftButtonIcon,title:isc.emptyString
});if(!_33.isDrawn())_33.draw();else _33.redrawIfDirty();_14.leftIconButtonWidth=_33.getVisibleWidth();_33.setTitle(isc.nbsp);var _34=this.$138d(_31);if(_34){_14.leftIconButtonWidth-=this.leftButton.getLeftPadding();_14.leftIconButtonWidth-=isc.Element.$tr(this.leftButton.getStateName())}else{_14.leftIconButtonWidth-=this.leftButton.getRightPadding();_14.leftIconButtonWidth-=isc.Element.$ts(this.leftButton.getStateName())}
_14.leftIconButtonWidth+=this.leftButton.iconSpacing;var _35=_14.leftIconButtonWidth;this.leftButton.setIcon(this.blankImgSrc);this.$158r.setIcon(this.leftButtonIcon);var _36=_14.leftButtonLogicalIconOrientation===isc.Canvas.LEFT;if((_17&&!_20)||(_17&&_20))
{var _30=_14.oldAutoFitInfo;this.$158r.moveTo(_30.$158u+(_36
?0
:(_30.$158v-_35)),this.leftButton.getTop());this.$158r.setOpacity(null)}else{var _31=_14.newAutoFitInfo;this.$158r.moveTo(_31.$158u+(_36
?0
:(_31.$158v-_35)),this.leftButton.getTop());this.$158r.setOpacity(0)}
this.$158r.setVisibility(isc.Canvas.INHERIT)}
if(_20){this.leftButton.setTitle(_31.leftButtonTitle);this.leftButton.redrawIfDirty()}
}else{this.leftButton.setVisibility(isc.Canvas.HIDDEN)}
if(_30.titleLabelVisible){var _37=this.$158y;_37.setOpacity(null);_37.setContents(_30.title);_37.setRightPadding(_30.titleLabelRightPadding);_37.setLeftPadding(_30.titleLabelLeftPadding);_37.setRect(_30.titleLabelRect);_37.setVisibility(isc.Canvas.INHERIT);_37.redrawIfDirty()}else{this.$158y.setVisibility(isc.Canvas.HIDDEN)}
if(_31.titleLabelVisible){var _38=this.titleLabel;_38.setOpacity(0);_38.setLeft(this.$138z(_14,0))}else{this.titleLabel.setVisibility(isc.Canvas.HIDDEN)}
if(!_12){var _39=_18.indexOf(this.leftButton);if(_39>=0){_18[_39]=this.leftButtonSpacer;if(!_19.showLeftButton)this.leftButtonSpacer.setVisibility(isc.Canvas.HIDDEN);else{this.leftButtonSpacer.setVisibility(isc.Canvas.INHERIT);this.leftButtonSpacer.setWidth(_14.newAutoFitInfo.$158v)}
}
}
this.setMembers(_18);if(this.$3n){this.reflowNow()}
this.$158w(_14.newAutoFitInfo);if(_19.showLeftButton){var _40=this.leftButton;_40.setVisibility(isc.Canvas.INHERIT);_40.setOpacity(0);this.addChild(_40)}else{this.leftButton.setVisibility(isc.Canvas.HIDDEN)}
var _27=_14.removedMembers;if(_27!=null){for(var i=0,_24=_27.length;i<_24;++i){var _41=_27[i];_41.setOpacity(null);this.addChild(_41);if(!_41.isDrawn())_41.draw()}
}
if(!_12){this.$1580=isc.Animation.registerAnimation(this.$1389,this.animateStateChangeTime,null,this)}else{var _42=_14.transitioningElements=[],_43=_14.direction===this.$159a,_34=this.$138d(_31);this.$158r.$139j=this.$158r.styleName;this.$158x.$139j=this.$158x.styleName;this.leftButton.$139j=this.leftButton.styleName;this.$158y.$139j=this.$158y.styleName;this.titleLabel.$139j=this.titleLabel.styleName;if(!_16.showLeftButton&&_19.showLeftButton){_42.add(this.$158r)}else if(_16.showLeftButton&&!_19.showLeftButton){_42.add(this.$158r)}
if(_16.showLeftButton){if((_43
?_14.newAutoFitInfo.titleLabelVisible
:_14.oldAutoFitInfo.titleLabelVisible)&&(_19.showLeftButton||_16.showLeftButton))
{isc.Element.$136r(this.$158x,"translateX(0px)",null,true)}
_42.add(this.$158x)}
if(_19.showLeftButton){if((_43
?_14.newAutoFitInfo.titleLabelVisible
:_14.oldAutoFitInfo.titleLabelVisible)&&_34==(_14.leftButtonLogicalIconOrientation===isc.Canvas.RIGHT))
{var _44=(this.$139m(_14,0)-
this.$139m(_14,1));isc.Element.$136r(this.leftButton,"translateX("+_44+"px)",null,true)}
_42.add(this.leftButton)}
if(_14.oldAutoFitInfo.titleLabelVisible){if(_14.newAutoFitInfo.$1581>=0||_14.oldAutoFitInfo.$1581>=0){isc.Element.$136r(this.$158y,"translateX(0px)",null,true);_42.add(this.$158y)}else if(_14.titleDifferent){_42.add(this.$158y)}
}
if(_14.newAutoFitInfo.titleLabelVisible){if(_14.newAutoFitInfo.$1581>=0||_14.oldAutoFitInfo.$1581>=0){var _44=(this.$138z(_14,0)-
this.$138z(_14,1));isc.Element.$136r(this.titleLabel,"translateX("+_44+"px)",null,true);_42.add(this.titleLabel)}else if(_14.titleDifferent){_42.add(this.titleLabel)}
}
var _27=_14.removedMembers;if(_27!=null){_27.map(function(_41){if(_41!==this.leftButton){_41.$139j=_41.styleName;_42.add(_41)}
},this)}
var _21=_14.addedMembers;if(_21!=null){_21.map(function(_45){if(_45!==this.leftButton){_45.$139j=_45.styleName;_42.add(_45)}
},this)}
if(_42.isEmpty()){this.$158r.$139j=null;this.$158x.$139j=null;this.leftButton.$139j=null;this.$158y.$139j=null;this.titleLabel.$139j=null;return}
if(this.$1409!=null){isc.Timer.clear(this.$1409);this.$1409=null}
if(!_3)this.$1409=this.delayCall("$141q");else this.$160a=true}
}
}
,isc.A.$141q=function isc_NavigationBar__animateStateChange(_1){this.$1409=null;if(_1){if(!this.$160a){return}
this.$160a=false}
this.$1392();var _2=this.$1371,_3=_2.oldViewState,_4=_2.oldAutoFitInfo,_5=_2.newViewState,_6=_2.newAutoFitInfo,_7=_2.direction===this.$159a,_8=this.$138d(_6),_9=isc.Canvas.$b4.setStyleName;if(!_3.showLeftButton&&_5.showLeftButton){_9.call(this.$158r,this.fadeInStyleName);this.$158r.setOpacity(null)}else if(_3.showLeftButton&&!_5.showLeftButton){_9.call(this.$158r,this.fadeOutStyleName);this.$158r.setOpacity(0)}
if(_3.showLeftButton){if((_7
?_6.titleLabelVisible
:_4.titleLabelVisible)&&(_5.showLeftButton||_3.showLeftButton))
{_9.call(this.$158x,_7
?this.oldLeftButtonBackStyleName
:this.oldLeftButtonForwardStyleName);var _10=(this.$142c(_2,1)-
_4.$158u);isc.Element.$136r(this.$158x,"translateX("+_10+"px)",null,true)}else{_9.call(this.$158x,this.fadeOutStyleName)}
this.$158x.setOpacity(0)}
if(_5.showLeftButton){if((_7
?_6.titleLabelVisible
:_4.titleLabelVisible)&&_8==(_2.leftButtonLogicalIconOrientation===isc.Canvas.RIGHT))
{_9.call(this.leftButton,_7
?this.newLeftButtonBackStyleName
:this.newLeftButtonForwardStyleName);isc.Element.$136r(this.leftButton,"translateX(0px)",null,true)}else{_9.call(this.leftButton,this.fadeInStyleName)}
this.leftButton.setOpacity(null)}
if(_4.titleLabelVisible){if(_6.$1581>=0||_4.$1581>=0){_9.call(this.$158y,_7
?this.oldTitleBackStyleName
:this.oldTitleForwardStyleName);var _10=(this.$142g(_2,1)-
_4.titleLabelRect[0]);isc.Element.$136r(this.$158y,"translateX("+_10+"px)",null,true);this.$158y.setOpacity(0)}else if(_2.titleDifferent){_9.call(this.$158y,this.removedFadeOutStyleName);this.$158y.setOpacity(0)}
}
if(_6.titleLabelVisible){if(_6.$1581>=0||_4.$1581>=0){_9.call(this.titleLabel,_7
?this.newTitleBackStyleName
:this.newTitleForwardStyleName);isc.Element.$136r(this.titleLabel,"translateX(0px)",null,true);this.titleLabel.setOpacity(null)}else if(_2.titleDifferent){_9.call(this.titleLabel,this.addedFadeInStyleName);this.titleLabel.setOpacity(null)}
}
var _11=_2.removedMembers;if(_11!=null){_11.map(function(_13){if(_13!==this.leftButton){_9.call(_13,this.removedFadeOutStyleName);_13.setOpacity(0)}
},this)}
var _12=_2.addedMembers;if(_12!=null){_12.map(function(_13){if(_13!==this.leftButton){_9.call(_13,this.addedFadeInStyleName);_13.setOpacity(null)}
},this)}
}
,isc.A.$1460=function isc_NavigationBar__transitionEnded(_1){if(this.$1409!=null){isc.Timer.clear(this.$1409);this.$1409=null}
this.$160a=false;var _2=this.$1371,_3=isc.Canvas.$b4.setStyleName,_4=[this.$158r,this.$158x,this.leftButton,this.$158y,this.titleLabel];for(var i=0,_6=_4.length;i<_6;++i){var _7=_4[i];_3.call(_7,_7.$139j);_7.$139j=null;if(_7.isDrawn())isc.Element.$136r(_7,null,null,true)}
var _8=_2.removedMembers;if(_8!=null){_8.map(function(_10){_3.call(_10,_10.$139j);_10.$139j=null},this)}
var _9=_2.addedMembers;if(_9!=null){_9.map(function(_10){_3.call(_10,_10.$139j)},this)}
this.$1393();this.$142i(_2)}
,isc.A.handleTransitionEnd=function isc_NavigationBar_handleTransitionEnd(_1,_2){if(isc.Browser.$139c&&this.skinUsesCSSTransitions&&this.$35v){var _3=this.$1371,_4=_3.transitioningElements;if(_2.propertyName==="opacity"){if(_4.remove(_2.target)){if(_4.length==0){this.$1460(false)}
}
}
}
}
,isc.A.transitionsRemoved=function isc_NavigationBar_transitionsRemoved(){if(isc.Browser.$139c&&this.skinUsesCSSTransitions&&this.$35v){this.$1460(true)}
}
,isc.A.$138d=function isc_NavigationBar__isSlidingRight(_1){return(_1.$1582>=0&&((this.reverseOrder&&(_1.$1581<0||_1.$158z))||(!this.reverseOrder&&_1.$1581>=0&&!_1.$158z)))||(_1.$1582<0&&this.reverseOrder)}
,isc.A.$142c=function isc_NavigationBar__calculateOldLeftButtonLeft(_1,_2){var _3=_1.oldAutoFitInfo,_4=_1.newAutoFitInfo,_5=_1.leftButtonLogicalIconOrientation;var _6=this.$138d(_4);var _7=this.$142x(_1,_3,_4,_5,_6);if(_1.direction===this.$159a){var _8=_6;if(_8){var _9=_3.$158u;return Math.round(_9-_2*_7)}else{var _10=_3.$158u;return Math.round(_10+_2*_7)}
}else{if(_6){var _10=(_4.$1581>=0?_4:_3).$158u;return Math.round(_10+_2*_7)}else{var _9=(_4.$1581>=0?_4:_3).$158u;return Math.round(_9-_2*_7)}
}
}
,isc.A.$139m=function isc_NavigationBar__calculateNewLeftButtonLeft(_1,_2){var _3=_1.oldAutoFitInfo,_4=_1.newAutoFitInfo,_5=_1.leftButtonLogicalIconOrientation;var _6=this.$138d(_4);var _7=this.$142x(_1,_3,_4,_5,_6);if(_1.direction===this.$159a){var _8=_6;if(_8){var _9=(_4.$1581>=0?_4:_3).$158u;return Math.round(_9+(1-_2)*_7)}else{var _10=(_4.$1581>=0?_4:_3).$158u;return Math.round(_10-(1-_2)*_7)}
}else{if(_6){var _10=_4.$158u;return Math.round(_10-(1-_2)*_7)}else{var _9=_4.$158u;return Math.round(_9+(1-_2)*_7)}
}
}
,isc.A.$142x=function isc_NavigationBar__calculateUW(_1,_2,_3,_4,_5){var _6;if(_1.direction===this.$159a){var _7=_5;if(_7){if(_3.$1581>=0){_6=_3.$158u+_3.$158v}else{_6=_2.$158u+_2.$158v}
_6-=_3.titleLabelRect[0]+_3.titleLabelRect[2]-_3.$159b}else{_6=(_3.titleLabelRect[0]+_3.$159c-
(_3.$1581>=0?_3:_2).$158u)}
}else{if(_5){if(_3.$1581>=0){_6=_3.$158u+_3.$158v}else{_6=_2.$158u+_2.$158v}
_6-=_2.titleLabelRect[0]+_2.titleLabelRect[2]-_2.$159b}else{_6=(_2.titleLabelRect[0]+_2.$159c-
(_3.$1581>=0?_3:_2).$158u)}
}
if(_4===(_5?isc.Canvas.RIGHT:isc.Canvas.LEFT)){_6-=_1.leftIconButtonWidth}else{_6-=(_3.$1581>=0?_3:_2).$158v}
return _6}
);isc.evalBoundary;isc.B.push(isc.A.$142g=function isc_NavigationBar__calculateOldTitleLabelLeft(_1,_2){var _3=_1.oldAutoFitInfo,_4=_1.newAutoFitInfo,_5=_1.leftButtonLogicalIconOrientation;var _6=this.$138d(_4);if(_1.direction===this.$159a){var _7=_6;if(_7){var _8=_3.titleLabelRect[0],_9=_3.titleLabelRect[2]-_3.$159b;return Math.round(_8-_2*_9)}else{var _10=_3.titleLabelRect[0],_9=_3.titleLabelRect[2]-_3.$159c;return Math.round(_10+_2*_9)}
}else{var _11=this.$142x(_1,_3,_4,_5,_6);if(_6){var _10=_3.titleLabelRect[0];return Math.round(_10+_2*_11)}else{var _8=_3.titleLabelRect[0];return Math.round(_8-_2*_11)}
}
}
,isc.A.$138z=function isc_NavigationBar__calculateNewTitleLabelLeft(_1,_2){var _3=_1.oldAutoFitInfo,_4=_1.newAutoFitInfo,_5=_1.leftButtonLogicalIconOrientation;var _6=this.$138d(_4);if(_1.direction===this.$159a){var _7=this.$142x(_1,_3,_4,_5,_6);if(_6){var _8=_4.titleLabelRect[0];return Math.round(_8+(1-_2)*_7)}else{var _9=_4.titleLabelRect[0];return Math.round(_9-(1-_2)*_7)}
}else{if(_6){var _9=_4.titleLabelRect[0],_10=_4.titleLabelRect[2]-_4.$159b;return Math.round(_9-(1-_2)*_10)}else{var _8=_4.titleLabelRect[0],_10=_4.titleLabelRect[2]-_4.$159c;return Math.round(_8+(1-_2)*_10)}
}
}
,isc.A.$1389=function isc_NavigationBar__fireAnimationStateChange(_1,_2,_3){var _4=this.$1371;var _5=_4.oldViewState,_6=_4.newViewState,_7=_4.direction===this.$159a;if(_1<1){if(!_5.showLeftButton&&_6.showLeftButton){var _8=this.leftButtonIconFadeInDelayRatio;if(_1>=_8){var _9=(_1-_8)/(1-_8);var _10=_9*100;this.$158r.setOpacity(_10)}
}else if(_5.showLeftButton&&!_6.showLeftButton){var _11=this.leftButtonIconFadeOutDurationRatio;if(_1<=_11){var _9=_1/_11;var _10=(1-_9)*100;this.$158r.setOpacity(_10)}else{this.$158r.setVisibility(isc.Canvas.HIDDEN)}
}
if(_5.showLeftButton){if((_7
?_4.newAutoFitInfo.titleLabelVisible
:_4.oldAutoFitInfo.titleLabelVisible)&&(_6.showLeftButton||_5.showLeftButton))
{var _12=(_7
?this.titleFadeOutDurationRatio
:this.leftButtonIconFadeOutDurationRatio);if(_1<=_12){var _9=_1/_12;var _10=(1-_9)*100;this.$158x.setOpacity(_10);var _13=this.$142c(_4,_1);this.$158x.setLeft(_13)}else{this.$158x.setVisibility(isc.Canvas.HIDDEN)}
}else{var _11=this.leftButtonIconFadeOutDurationRatio;if(_1<=_11){var _9=_1/_11;var _10=(1-_9)*100;this.$158x.setOpacity(_10)}else{this.$158x.setVisibility(isc.Canvas.HIDDEN)}
}
}
if(_6.showLeftButton){var _14=this.$138d(_4.newAutoFitInfo);if((_7
?_4.newAutoFitInfo.titleLabelVisible
:_4.oldAutoFitInfo.titleLabelVisible)&&_14==(_4.leftButtonLogicalIconOrientation===isc.Canvas.RIGHT))
{var _12=this.titleFadeOutDurationRatio;if(_1>_12){var _9=(_1-_12)/(1-_12);var _10=_9*100;this.leftButton.setOpacity(_10);var _13=this.$139m(_4,_1);this.leftButton.setLeft(_13)}
}else{var _8=this.leftButtonIconFadeInDelayRatio;if(_1>=_8){var _9=(_1-_8)/(1-_8);var _10=_9*100;this.leftButton.setOpacity(_10)}
}
}
if(_4.oldAutoFitInfo.titleLabelVisible){if(_4.newAutoFitInfo.$1581>=0||_4.oldAutoFitInfo.$1581>=0){var _12=(_4.newViewState.showLeftButton
?this.titleFadeOutDurationRatio
:this.leftButtonIconFadeOutDurationRatio);if(_1<=_12){var _9=_1/_12;var _10=(1-_9)*100;this.$158y.setOpacity(_10);var _13=this.$142g(_4,_1);this.$158y.setLeft(_13)}else{this.$158y.setVisibility(isc.Canvas.HIDDEN)}
}else if(_4.titleDifferent){if(_1<0.5){var _10=((0.5-_1)/0.5)*100;this.$158y.setOpacity(_10)}else{this.$158y.setVisibility(isc.Canvas.HIDDEN)}
}
}
if(_4.newAutoFitInfo.titleLabelVisible){if(_4.newAutoFitInfo.$1581>=0||_4.oldAutoFitInfo.$1581>=0){var _15=this.titleFadeInDelayRatio;if(_1>=_15){var _10=(_1-_15)/(1-_15)*100;this.titleLabel.setOpacity(_10);var _13=this.$138z(_4,_1);this.titleLabel.setLeft(_13)}
}else if(_4.titleDifferent){if(_1<0.5){this.titleLabel.setOpacity(0)}else{var _10=((_1-0.5)/0.5)*100;this.titleLabel.setOpacity(_10)}
}
}
if(_1<0.5){var _16=_4.removedMembers;if(_16!=null){var _10=((0.5-_1)/0.5)*100;for(var i=0,_18=_16.length;i<_18;++i){_16[i].setOpacity(_10)}
}
}else{var _19=_4.addedMembers,_20=_4.retainedMembers;if(_19!=null||_20!=null){var _10=((_1-0.5)/0.5)*100;for(var i=0,_18=(_19==null?0:_19.length);i<_18;++i){_19[i].setOpacity(_10)}
for(var i=0,_18=(_20==null?0:_20.length);i<_18;++i){_20[i].setOpacity(_10)}
}
}
}else{var _21=_4.newMembers,_22=_21.indexOf(this.leftButtonSpacer);if(_22>=0){_21[_22]=this.leftButton;this.setMembers(_21)}
this.$142i(_4)}
}
,isc.A.$142i=function isc_NavigationBar__cleanUpAfterAnimation(_1){var _2=_1.newViewState;this.showLeftButton=_2.showLeftButton;this.leftButtonTitle=_2.leftButtonTitle;this.shortLeftButtonTitle=_2.shortLeftButtonTitle;this.alwaysShowLeftButtonTitle=_2.alwaysShowLeftButtonTitle;this.title=_2.title;this.controls=_2.controls;var _3=_1.newAutoFitInfo;_1.oldViewState=null;_2=_1.newViewState=null;_1.oldAutoFitInfo=null;_1.newAutoFitInfo=null;if(this.leftButtonIcon)this.leftButton.setIcon(this.leftButtonIcon);this.leftButton.setOpacity(null);if(this.showLeftButton){this.leftButton.setOpacity(null);this.leftButton.setVisibility(isc.Canvas.INHERIT)}else{this.leftButton.setVisibility(isc.Canvas.HIDDEN);this.leftButton.setContents(isc.nbsp)}
if(_3.titleLabelVisible){this.titleLabel.setOpacity(null);this.titleLabel.setLeft(_3.titleLabelRect[0]);this.titleLabel.setVisibility(isc.Canvas.INHERIT)}else{this.titleLabel.setVisibility(isc.Canvas.HIDDEN);this.titleLabel.setContents(isc.nbsp)}
var _4=_1.removedMembers;if(_4!=null){for(var i=0,_6=_4.length;i<_6;++i){var _7=_4[i];_7.deparent();_7.setOpacity(null);_7.setVisibility(isc.Canvas.INHERIT)}
}
var _8=_1.addedMembers;if(_8!=null){for(var i=0,_6=_8.length;i<_6;++i){var _9=_8[i];_9.setOpacity(null);_9.setVisibility(isc.Canvas.INHERIT)}
}
this.$158r.setVisibility(isc.Canvas.HIDDEN);this.$158r.setOpacity(null);this.$158x.setVisibility(isc.Canvas.HIDDEN);this.$158x.setTitle(isc.nbsp);this.$158x.setOpacity(null);this.$158y.setVisibility(isc.Canvas.HIDDEN);this.$158y.setContents(isc.nbsp);this.$158y.setOpacity(null);this.$1580=null;this.$1371=null;this.$35v=false;if(isc.Canvas.ariaEnabled())this.setAriaState("busy",false);this.eventMaskPeer.hide()}
,isc.A.$158s=function isc_NavigationBar__calculateAutoFitInfo(_1){var _2;var _3={$158u:_2,$158v:_2,$1581:_2,$1582:_2,$158z:null,leftButtonTitle:_1.leftButtonTitle,titleLabelVisible:true,title:_1.title,titleLabelPrompt:null,titleLabelRightPadding:0,titleLabelLeftPadding:0,titleLabelRect:null,$159b:_2,$159c:_2
};var _4=this.getInnerWidth();var _5=0,_6=0,_7=0,_8=0,_9=0,_10=0,_11=0;if(this.layoutMargin){_5+=this.layoutMargin;_11+=this.layoutMargin}
var _12=_1.members;var _13=this.titleLabelMeasurer;_13.setContents(_1.title);if(!_13.isDrawn())_13.draw();else _13.redrawIfDirty();_8=_13.getVisibleWidth();if(isc.Browser.isFirefox&&isc.Browser.minorVersion>=78){_8+=1}
if(navigator.appVersion.contains("iPhone OS 10_"))_8++;_13.setContents(isc.nbsp);var _14=_12.length,i;var _16=_3.$1581=(this.$21(_1.leftButton)&&!(_1.showLeftButton&&!this.isIgnoringMember(_1.leftButton))
?-1:_12.indexOf(_1.leftButton)),_17=_16>=0;var _18=_3.$1582=_12.indexOf(_1.titleLabelSpacer);var _19=_18>=0&&!!_1.title;if(!_19){_3.titleLabelVisible=false;if(_17){if(_18>=0){_3.$158z=(_16<_18)}
_3.$158u=_1.leftButton.getLeft();var _20=this.leftButtonMeasurer;_20.setProperties({icon:_1.leftButtonIcon,title:_1.leftButtonTitle
});if(!_20.isDrawn())_20.draw();else _20.redrawIfDirty();_3.$158v=_20.getVisibleWidth();_20.setTitle(isc.nbsp)}
return _3}
var _21,_22;if(!_17){for(i=0;i<_18;++i){var _23=_12[i];if(!this.$21(_23)){_5+=_23.getVisibleWidth()}
}
for(i=_18+1;i<_14;++i){var _23=_12[i];if(!this.$21(_23)){_11+=_23.getVisibleWidth()}
}
_21=_5;_22=_11}else{_3.$158u=_1.leftButton.getLeft();var _20=this.leftButtonMeasurer;_20.setProperties({icon:_1.leftButtonIcon,title:_1.leftButtonTitle
});if(!_20.isDrawn())_20.draw();else _20.redrawIfDirty();var _24=_20.getVisibleWidth();_20.setTitle(isc.nbsp);if((_3.$158z=(_16<_18))){for(i=0;i<_16;++i){var _23=_12[i];if(!this.$21(_23)){_5+=_23.getVisibleWidth()}
}
for(i=_16+1;i<_18;++i){var _23=_12[i];if(!this.$21(_23)){_7+=_23.getVisibleWidth()}
}
for(i=_18+1;i<_14;++i){var _23=_12[i];if(!this.$21(_23)){_11+=_23.getVisibleWidth()}
}
_6=_24}else{for(i=0;i<_18;++i){var _23=_12[i];if(!this.$21(_23)){_5+=_23.getVisibleWidth()}
}
for(i=_18+1;i<_16;++i){var _23=_12[i];if(!this.$21(_23)){_9+=_23.getVisibleWidth()}
}
for(i=_16+1;i<_14;++i){var _23=_12[i];if(!this.$21(_23)){_11+=_23.getVisibleWidth()}
}
_10=_24}
_21=_5+_6+_7;_22=_9+_10+_11;var _25,_26;if(_21>_22){_25=_21-_22;_26=0}else{_25=0;_26=_22-_21}
var e=_25+_26;var _28=_21+_8+_22,r=_4-_28;if(r>=0&&!(_1.maxCenterOffset<(e-r)/2)){_3.leftButtonTitle=_1.leftButtonTitle}else{var _30=_24;var _31,d;if(_1.shortLeftButtonTitle){_20.setTitle(_1.shortLeftButtonTitle);_20.redrawIfDirty();_31=_20.getVisibleWidth();_20.setTitle(isc.nbsp);d=_31-_24;if(_16<_18){_21+=d}else{_22+=d}
if(_21>_22){_25=_21-_22;_26=0}else{_25=0;_26=_22-_21}
e=_25+_26;_28=_21+_8+_22;r=_4-_28}else{d=0}
if(_1.alwaysShowLeftButtonTitle||!_1.leftButtonIcon||(_31!=null&&(r>=0&&!(_1.maxCenterOffset<(e-r)/2))))
{if(_31==null){_3.leftButtonTitle=_1.leftButtonTitle}else{var _33=d<0;if(!_33){this.logWarn("The shortLeftButtonTitle:'"+_1.shortLeftButtonTitle+"' is not shorter than the normal leftButton title:'"+_1.leftButtonTitle+"'. The normal title will be used as it is shorter...");_3.leftButtonTitle=_1.leftButtonTitle
if(_16<_18){_21-=d}else{_22-=d}
}else{_3.leftButtonTitle=_1.shortLeftButtonTitle;_30=_31}
}
}else{_20.setTitle(null);_20.redrawIfDirty();var _34=_20.getVisibleWidth();_20.setTitle(isc.nbsp);d=_34-(_31!=null?_31:_24);if(_16<_18){_21+=d}else{_22+=d}
_3.leftButtonTitle=null;_30=_34}
if(_16<_18){_6=_30}else{_10=_30}
}
}
_3.$158v=_6;if(this.reverseOrder){var _35=_21;_21=_22;_22=_35}
var _25,_26;if(_21>_22){_25=_21-_22;_26=0}else{_25=0;_26=_22-_21}
var e=_25+_26;var _28=_21+_8+_22,r=_4-_28,_36=_4-_22-_21;if(_36<0){_3.titleLabelVisible=false}else{_3.title=_1.title;_3.titleLabelPrompt=null;if(r>=e){var _37=(r-e)/2;_3.$159b=_25+_37;_3.$159c=_26+_37;_3.titleLabelRightPadding=_25;_3.titleLabelLeftPadding=_26}else if(r>=0){var _38=e-r,_39=2*_1.maxCenterOffset;if(_39<_38){_3.titleLabelPrompt=_1.title}
if(_26==0){_3.$159b=r+Math.max(0,_38-_39);_3.$159c=0}else{_38=Math.min(_38,_39);_3.$159b=0;_3.$159c=Math.floor((_4-_8-_38)/2)-_21}
_3.titleLabelRightPadding=_3.$159b;_3.titleLabelLeftPadding=_3.$159c}else{_3.titleLabelPrompt=_1.title;_3.titleLabelRightPadding=_3.$159b=0;_3.titleLabelLeftPadding=_3.$159c=0}
_3.titleLabelRect=[_21,null,_36,null];_3.titleLabelVisible=true}
return _3}
,isc.A.$143r=function isc_NavigationBar__autoFitTitle(){if(this.$35v||this.getDrawnState()===isc.Canvas.UNDRAWN||!this.isVisible())return;var _1=this.$158s(this);this.$158w(_1)}
,isc.A.$807=function isc_NavigationBar__visibilityChanged(){if(this.isVisible()&&!this.$3n){this.$143r()}
return this.Super("$807",arguments)}
,isc.A.$158w=function isc_NavigationBar__applyAutoFitInfo(_1){var _2=this.leftButton;if(this.showLeftButton!=false&&_2!=null){_2.setTitle(_1.leftButtonTitle);_2.redrawIfDirty()}
var _3=this.titleLabel;if(!_1.titleLabelVisible){_3.setVisibility(isc.Canvas.HIDDEN)}else{_3.setContents(_1.title);_3.setPrompt(_1.titleLabelPrompt);_3.setRightPadding(_1.titleLabelRightPadding);_3.setLeftPadding(_1.titleLabelLeftPadding);_3.setRect(_1.titleLabelRect);_3.setVisibility(isc.Canvas.INHERIT);_3.redrawIfDirty()}
}
,isc.A.$3j=function isc_NavigationBar__layoutChildrenDone(){this.Super("$3j",arguments);this.$143r()}
,isc.A.push=function isc_NavigationBar_push(_1){if(this.$143z==null){this.$143z=[]}
this.$143z.add(_1)}
,isc.A.pop=function isc_NavigationBar_pop(){if(this.$143z==null){this.$143z=[]}
if(this.$143z.isEmpty()){return null}
var _1=this.$143z.last();this.$143z.setLength(this.$143z.getLength()-1);return _1}
,isc.A.setSinglePanel=function isc_NavigationBar_setSinglePanel(_1){this.$143z=[_1]}
);isc.B._maxIndex=isc.C+34;isc.NavigationBar.registerStringMethods({navigationClick:"direction",upClick:"",downClick:""});isc.defineClass("SplitPanePagedPanel","Canvas");isc.A=isc.SplitPanePagedPanel.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.overflow="hidden";isc.A.class="pageBackground";isc.A.animateTransitions=!isc.Browser.isMobileIE;isc.A.skinUsesCSSTransitions=false;isc.A.animateScrollDuration=350;isc.A.pagesContainerBaseStyle="splitPanePagedPanelPagesContainer";isc.A.pagesContainerDefaults={width:"100%",height:"100%",overflow:"visible",$2007:function(){var _1=this.creator;if(!_1.animateTransitions||!isc.Browser.$139c||!_1.skinUsesCSSTransitions)
{return null}else{var _2=_1.currentPage,_3;if(_2>=0){_3=-(_1.isRTL()?_1.pages.length-1-_2:_2)*_1.getInnerWidth()}else{_3=0}
return _3}
},getTransformCSS:function(){var _1=this.$2007();if(_1==null)return null;return";"+isc.Element.$159t+": translateX("+_1+"px);"},scrollIntoView:function(_1,_2){if(_1!=null){var _3=this.$2007();if(_3!=null)_1+=_3}
return this.Super("scrollIntoView",arguments)},$1460:function(_1){var _2=this.creator;if(!_1)delete _2.$35v;this.$1393();var _3=_2.pages,_4=_2.currentPage;for(var i=0,_6=_3.length;i<_6;++i){if(i!=_4)_3[i].setVisibility(isc.Canvas.HIDDEN)}
var _7=_2.$1461;if(_7!=null){delete _2.$1461;_2.fireCallback(_7)}
delete _2.$35v},handleTransitionEnd:function(_1,_2){if(_2.target===this){this.$1460(false)}
},transitionsRemoved:function(){var _1=this.creator;if(isc.Browser.$139c&&_1.skinUsesCSSTransitions&&_1.$35v){this.$1460(true)}
}
};isc.A.currentPage=-1;isc.A.autoChildren=["pagesContainer"];isc.B.push(isc.A.initWidget=function isc_SplitPanePagedPanel_initWidget(){this.Super("initWidget",arguments);this.addAutoChild("pagesContainer",{styleName:this.pagesContainerBaseStyle
});if(isc.Browser.isIPhone&&this.animateTransitions&&isc.Browser.$139c&&this.skinUsesCSSTransitions){this.$137k=isc.Page.setEvent("orientationChange",this)}
if(this.pages==null)this.pages=[];else this.$139d(this.pages);this.currentPage=Math.min(Math.max(0,this.currentPage),this.pages.length-1);this.$139e(-1)}
,isc.A.destroy=function isc_SplitPanePagedPanel_destroy(){if(this.$137k!=null){isc.Page.clearEvent("orientationChange",this.$137k);delete this.$137k}
this.Super("destroy",arguments)}
,isc.A.pageOrientationChange=function isc_SplitPanePagedPanel_pageOrientationChange(){if(isc.Browser.isIPhone&&this.animateTransitions&&isc.Browser.$139c&&this.skinUsesCSSTransitions){var _1=this.pagesContainer;if(_1.isDrawn()&&_1.isVisible()){_1.markForRedraw()}
}}
,isc.A.$145l=function isc_SplitPanePagedPanel__needHideUsingDisplayNone(){return(isc.Browser.isAndroid&&isc.Browser.isChrome)||this.Super("$145l",arguments)}
,isc.A.$139e=function isc_SplitPanePagedPanel__scrollToPage(_1,_2,_3){if(this.pagesContainer==null)return;_2=!this.animateTransitions||_2||_1<0||!this.isVisible();var _4=this.currentPage;var _5=this.pages;if(_4<0||_2){for(var i=0;i<_5.length;++i){if(i==_4)_5[i].setVisibility(isc.Canvas.INHERIT);else _5[i].setVisibility(isc.Canvas.HIDDEN)}
}else{var _7=Math.min(_4,_1),_8=Math.max(_4,_1);var i=0;for(;i<_7;++i){_5[i].setVisibility(isc.Canvas.HIDDEN)}
for(;i<=_8;++i){_5[i].setVisibility(isc.Canvas.INHERIT)}
for(;i<_5.length;++i){_5[i].setVisibility(isc.Canvas.HIDDEN)}
}
var _9;if(_4>=0){_9=-(this.isRTL()?this.pages.length-1-_4:_4)*this.getInnerWidth()}else{_9=0}
var _10=this.pagesContainer;if(!this.animateTransitions||!isc.Browser.$139c||!this.skinUsesCSSTransitions){if(_4>=0&&!_2){_10.animateMove(_9,0,{target:this,method:function(_16){if(!_16){delete this.$35v;var _5=this.pages,_4=this.currentPage;for(var i=0,_11=_5.length;i<_11;++i){if(i!=_4)_5[i].setVisibility(isc.Canvas.HIDDEN)}
}
if(_3!=null)this.fireCallback(_3);delete this.$35v}
},this.animateScrollDuration);this.$35v=true}else{if(this.moveAnimation!=null)this.finishAnimation(this.$0m);_10.setLeft(_9);if(_3!=null)this.fireCallback(_3)}
}else if(_10.isDrawn()){var _12=this.$1461;delete this.$1461;if(_12!=null)this.fireCallback(_12);if(_4>=0&&!_2){var _13=isc.Element.$137p(_10);if(_13!=_9){_10.$1392()}else{_10.$1393()}
_10.setStyleName(this.pagesContainerBaseStyle+"Animated");isc.Element.$136r(_10,"translateX("+_9+"px)");if(_13!=_9){this.$35v=true;this.$1461=_3}else{delete this.$35v;if(_3!=null)this.fireCallback(_3)}
}else{delete this.$35v;_10.$1393();isc.Element.$136r(_10,"translateX(0px)");_10.setStyleName(this.pagesContainerBaseStyle);isc.Element.$136r(_10,"translateX("+_9+"px)");if(_3!=null)this.fireCallback(_3)}
}else{if(_3!=null)this.fireCallback(_3)}
var _14=this.$160b;if(_14!=null&&_14.currentUIConfig!=null){var _15=_14.$160c();if(_15!=null&&isc.Browser.$139c&&_15.skinUsesCSSTransitions)
{_15.$141q(true)}
}}
,isc.A.setCurrentPage=function isc_SplitPanePagedPanel_setCurrentPage(_1,_2,_3){var _4=this.currentPage;_1=this.currentPage=Math.min(Math.max(0,_1),this.pages.length-1);this.$139e(_4,_2,_3)}
,isc.A.$1462=function isc_SplitPanePagedPanel__addPageToContainer(_1,_2,_3){this.pagesContainer.addChild(_1);_1.setRect(((this.isRTL()?_3-1-_2:_2)*100)+"%",0,"100%",null)}
,isc.A.$139d=function isc_SplitPanePagedPanel__addPagesToPagesContainer(_1){for(var i=0,_3=_1.length;i<_3;++i){this.$1462(_1[i],i,_3)}}
,isc.A.setPages=function isc_SplitPanePagedPanel_setPages(_1){if(_1==null){this.pages.callMethod("deparent");this.pages.setLength(0)}else{var _2,_3=this.pages;if(_3.equals(_1))return;if(isc.screenReader){_2=_3}else{_2=[];for(var i=0,_5=_3.length;i<_5;++i){var _6=_3[i];if(!_1.contains(_6))_2.add(_6)}
}
_2.callMethod("deparent");_3.setArray(_1);this.$139d(_1)}
this.setCurrentPage(this.currentPage,true)}
,isc.A.resized=function isc_SplitPanePagedPanel_resized(_1,_2){if(!!_1){this.$139e(this.currentPage,true)}}
);isc.B._maxIndex=isc.C+10;isc.defineClass("SplitPaneSidePanel","VLayout");isc.A=isc.SplitPaneSidePanel.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.width="42%";isc.A.height="100%";isc.A.overflow="hidden";isc.A.baseStyle="splitPaneSidePanel";isc.A.skinUsesCSSTransitions=false;isc.A.animate=!isc.Browser.isMobileIE;isc.A.animateShowTime=300;isc.A.animateShowEffectConfig={effect:"slide",startFrom:"L"
};isc.A.animateHideTime=250;isc.A.animateHideEffectConfig={effect:"slide",endAt:"L"
};isc.A.navigationBarDefaults={_constructor:"NavigationBar",width:"100%"
};isc.A.pagedPanelDefaults={_constructor:"SplitPanePagedPanel",width:"100%",height:"*"
};isc.A.onScreen=false;isc.A.autoChildren=["navigationBar"];isc.B.push(isc.A.initWidget=function isc_SplitPaneSidePanel_initWidget(){this.Super("initWidget",arguments);this.addAutoChildren(this.autoChildren);this.addAutoChild("pagedPanel",{$160b:this.$160b
});var _1=this.isRTL();this.$139f=this.baseStyle+(_1?"OffScreenRTL":"OffScreen");this.$139g=this.baseStyle+(_1?"OnScreenRTL":"OnScreen");this.hide();if(!this.animate){if(_1){this.$123w=isc.Page.setEvent("resize",this,null,"pageResized")}else{this.setLeft(0)}
this.setStyleName(_1?this.baseStyle+"RTL":this.baseStyle)}else{if(!isc.Browser.$139c||!this.skinUsesCSSTransitions){this.setStyleName(_1?this.baseStyle+"RTL":this.baseStyle)}else{if(_1)this.setLeft("100%");this.setStyleName(this.$139f)}
}
this.onScreen=false}
,isc.A.destroy=function isc_SplitPaneSidePanel_destroy(){if(this.$123w!=null){isc.Page.clearEvent("resize",this.$123w);delete this.$123w}
if(this.$146e!=null){isc.Timer.clear(this.$146e);delete this.$146e}
this.Super("destroy",arguments)}
,isc.A.setPagedPanel=function isc_SplitPaneSidePanel_setPagedPanel(_1){if(this.pagedPanel!==_1){if(this.pagedPanel!=null)this.removeMember(this.pagedPanel);this.pagedPanel=_1;if(_1!=null){this.addMember(_1)}
}}
,isc.A.getTransformCSS=function isc_SplitPaneSidePanel_getTransformCSS(){if(!this.animate||!isc.Browser.$139c||!this.skinUsesCSSTransitions){return null}else{var _1;if(this.onScreen){_1=this.isRTL()?"-100%":"0"}else{_1=this.isRTL()?"0":"-100%"}
return";"+isc.Element.$159t+": translateX("+_1+");"}}
,isc.A.slideIn=function isc_SplitPaneSidePanel_slideIn(){if(this.onScreen)return;if(!this.animate){this.show()}else{if(!isc.Browser.$139c||!this.skinUsesCSSTransitions){this.animateShow(this.animateShowEffectConfig)}else{this.setStyleName(this.$139g);this.show();if(this.$146e!=null){isc.Timer.clear(this.$146e);this.$146e=null}
if(this.isDrawn()){this.$146e=this.delayCall("$1n")}
}
}
this.onScreen=true;if(isc.Canvas.ariaEnabled())this.setAriaState("hidden",false)}
,isc.A.$1n=function isc_SplitPaneSidePanel__slideIn(){delete this.$146e;if(this.isDrawn()&&this.isVisible()){var _1=this.getClipHandle();var _2,_3;if(this.isRTL()){_2="-100%";_3=-_1.offsetWidth}else{_2="0";_3=0}
var _4=isc.Element.$137p(this);if(_4!=_3){this.$1392()}else{this.$1393()}
isc.Element.$136r(this,"translateX("+_2+")")}}
,isc.A.slideOut=function isc_SplitPaneSidePanel_slideOut(){if(!this.onScreen)return;if(!this.animate){this.hide()}else{if(!isc.Browser.$139c||!this.skinUsesCSSTransitions){this.animateHide(this.animateHideEffectConfig)}else{if(this.$146e!=null){isc.Timer.clear(this.$146e);delete this.$146e}
this.setStyleName(this.$139f);if(this.isDrawn()&&this.isVisible()){var _1=this.getClipHandle();var _2,_3;if(this.isRTL()){_2="0";_3=0}else{_2="-100%";_3=-_1.offsetWidth}
var _4=isc.Element.$137p(this);if(_4!=_3){this.$1392()}else{this.$1393()}
isc.Element.$136r(this,"translateX("+_2+")")}
}
}
this.onScreen=false;if(isc.Canvas.ariaEnabled())this.setAriaState("hidden",true)}
,isc.A.handleTransitionEnd=function isc_SplitPaneSidePanel_handleTransitionEnd(_1,_2){if(_2.target===this){this.$1393();if(!this.onScreen)this.hide()}}
,isc.A.onDraw=function isc_SplitPaneSidePanel_onDraw(){if(!this.animate&&this.isRTL()){this.setLeft(isc.Page.getWidth()-this.getVisibleWidth())}}
,isc.A.pageResized=function isc_SplitPaneSidePanel_pageResized(){if(this.isDrawn()&&!this.animate&&this.isRTL()){this.setLeft(isc.Page.getWidth()-this.getVisibleWidth())}}
,isc.A.resized=function isc_SplitPaneSidePanel_resized(_1,_2){if(this.isDrawn()&&!this.animate&&this.isRTL()){this.setLeft(isc.Page.getWidth()-this.getVisibleWidth())}}
);isc.B._maxIndex=isc.C+11;isc.defineClass("SplitPane","Layout");isc.A=isc.SplitPane.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.overflow="hidden";isc.A.vertical=true;isc.A.addHistoryEntries=false;isc.A.navigationPaneWidth=320;isc.A.portraitClickMaskDefaults={_constructor:"Canvas",width:"100%",height:"100%",overflow:"hidden",click:function(){this.creator.$148y()}
};isc.A.portraitSidePanelDefaults={_constructor:"SplitPaneSidePanel",navigationBar_autoMaker:function(_1){var _2=this.creator;_1=isc.addProperties({},_1,{animateStateChanges:_2.animateNavigationBarStateChanges,showLeftButton:_2.showBackButton,leftButtonConstructor:_2.backButtonConstructor,leftButtonDefaults:_2.backButtonDefaults,leftButtonProperties:_2.backButtonProperties
});return _2.createAutoChild("portraitSidePanelNavigationBar",_1)}
};isc.A.handsetPagedPanelDefaults={_constructor:"SplitPanePagedPanel",width:"100%",height:"*"
};isc.A.showSidePanelButtonDefaults={_constructor:"NavigationButton",click:function(){var _1=this.creator;var _2=this.creator.currentPane;if(_2==="list"||(_2==="detail"&&_1.$137t()))
{_1.showListPane(null,null,null,false,true)}else{_1.showNavigationPane(null,false,true)}
}
};isc.A.leftLayoutDefaults={_constructor:"VLayout",setWidth:function(_1){var _2=this.creator;if(_2.editingOn&&_2.editContext&&(!isc.isA.String(_1)||!_1.endsWith(this.$o9)))
{var _3=_2.getVisibleWidth(),_4=Math.round(_1/_3*100.0)+"%"
;_2.editContext.setNodeProperties(_2.editNode,{navigationPaneWidth:_4
})}
this.Super("setWidth",arguments)}
};isc.A.rightLayoutDefaults={_constructor:"VLayout",width:"*"
};isc.A.spacerDefaults={backgroundColor:"black",overflow:"hidden",width:1,height:"100%"
};isc.A.showResizeBars=true;isc.A.desktopNavigationBarHeight=30;isc.A.navigationBarDefaults={_constructor:"NavigationBar",autoParent:"none",rightPadding:5,leftPadding:5,defaultLayoutAlign:"center",leftButton_autoMaker:function(_1){if(this.showLeftButton==false)return null;return this.creator.createAutoChild("backButton",_1)},navigationClick:function(_1){var _2=this.creator;if(_2.navigationClick!=null)_2.navigationClick(_1)},upClick:function(){var _1=this.creator,_2=_1.upClick;if(_2!=null){return _2.apply(_1,arguments)}
},downClick:function(){var _1=this.creator,_2=_1.downClick;if(_2!=null){return _2.apply(_1,arguments)}
}
};isc.A.portraitSidePanelNavigationBarDefaults={_constructor:"NavigationBar",leftButton_autoMaker:function(_1){if(this.showLeftButton==false)return null;return this.creator.createAutoChild("backButton",_1)}
};isc.A.animateNavigationBarStateChanges=((isc.Browser.$139c&&!isc.Browser.isMobileIE)||isc.Browser.isMoz);isc.A.backButtonDefaults={_constructor:"NavigationButton",direction:"back",click:function(){if(this.parentElement.$35v)return;var _1=this.creator;if(_1.navigationClick!=null&&!_1.notifyAfterNavigationClick){if(_1.navigationClick(this.direction)==false)return false}
if(_1.currentPane==="detail"&&_1.$137t()&&_1.currentUIConfig!=="landscape")
{_1.showListPane(null,null,"back",null,false)}else{_1.showNavigationPane("back",null,false)}
if(_1.navigationClick!=null&&_1.notifyAfterNavigationClick){_1.navigationClick(this.direction)}
return false}
};isc.A.leftButtonDefaults={_constructor:"NavigationButton",direction:null,click:function(){if(this.parentElement.$35v)return;if(this.creator.navigationClick!=null){this.creator.navigationClick(this.direction)}
return false}
};isc.A.currentPane="navigation";isc.A.listTitleLabelDefaults={_constructor:"Label",align:"center",valign:"center",width:"*",height:"100%"
};isc.A.listToolStripDefaults={_constructor:"NavigationBar",rightPadding:5,leftPadding:5,defaultLayoutAlign:"center",overflow:"hidden",showLeftButton:false,showRightButton:false
};isc.A.detailTitleLabelDefaults={_constructor:"Label",height:"100%",align:"center",valign:"center",clipTitle:true,wrap:false,overflow:"hidden"
};isc.A.detailPaneContainerDefaults={_constructor:"VLayout",height:"100%"
};isc.A.detailToolStripDefaults={_constructor:"NavigationBar",rightPadding:5,leftPadding:5,leftButtonIcon:null,defaultLayoutAlign:"center"
};isc.A.autoChildren=["leftLayout","rightLayout","navigationBar","listToolStrip","detailToolStrip"];isc.A.showMiniNav=false;isc.A.$254r=["navigationPane","listPane","detailsPane"
];isc.A.$254k=isc.SplitPane.$254j(["autoNavigate"
]);isc.A.showLeftButton=false;isc.A.showRightButton=false;isc.A.listPaneTitleTemplate="${titleField}";isc.A.detailPaneTitleTemplate="${titleField}";isc.A.autoNavigate=true;isc.A.navigationId=0;isc.B.push(isc.A.setNavigationPaneWidth=function isc_SplitPane_setNavigationPaneWidth(_1){if(this.navigationPaneWidth==_1)return;this.navigationPaneWidth=_1;var _2=this.leftLayout;if(_2)_2.setWidth(_1)}
,isc.A.getDynamicDefaults=function isc_SplitPane_getDynamicDefaults(_1){if(_1=="leftLayout"){return{width:this.navigationPaneWidth}}
}
,isc.A.setShowNavigationBar=function isc_SplitPane_setShowNavigationBar(_1){if(this.showNavigationBar==_1)return;this.showNavigationBar=_1;var _2=this.$160c();if(_2==null){if(this.currentUIConfig==="portrait"){var _3=this.portraitSidePanel;_3.showNavigationBar=_1;_3.addAutoChild("navigationBar",null,null,_3,0)}else this.addAutoChild("navigationBar")}
this.updateUI(true)}
,isc.A.setShowListToolStrip=function isc_SplitPane_setShowListToolStrip(_1){if(this.showListToolStrip==_1)return;this.showListToolStrip=_1;if(this.listToolStrip==null)this.addAutoChild("listToolStrip");this.updateUI(true)}
,isc.A.setShowDetailToolStrip=function isc_SplitPane_setShowDetailToolStrip(_1){if(this.showDetailToolStrip==_1)return;this.showDetailToolStrip=_1;if(this.detailToolStrip==null)this.addAutoChild("detailToolStrip");this.updateUI(true)}
,isc.A.isHandset=function isc_SplitPane_isHandset(){return this.deviceMode==null?isc.Browser.isHandset:this.deviceMode==="handset"}
,isc.A.isTablet=function isc_SplitPane_isTablet(){return this.deviceMode==null?isc.Browser.isTablet:this.deviceMode==="tablet"}
,isc.A.getPageOrientation=function isc_SplitPane_getPageOrientation(){return this.pageOrientation||isc.Page.getOrientation()}
,isc.A.initWidget=function isc_SplitPane_initWidget(){this.Super("initWidget",arguments);this.addAutoChildren(this.autoChildren,"none");if(this.detailToolStrip!=null)this.detailTitleLabel=this.detailToolStrip.titleLabel;if(this.isTablet()){var _1=this.portraitClickMask=this.createAutoChild("portraitClickMask",{visibility:"hidden"
});this.addChild(_1);var _2=this.portraitSidePanel=this.createAutoChild("portraitSidePanel",{$160b:this,showNavigationBar:this.showNavigationBar
});this.$139h=_2.pagedPanel;this.addChild(_2)}else if(this.isHandset()){this.$139h=this.createAutoChild("handsetPagedPanel",{$160b:this
})}
if(this.navigationPane!=null){this.navigationPane.resizeTo("100%",this.navigationPane.$po!=null?null:"100%");this.navigationPane.splitPane=this;if(this.autoNavigate)this.$206q("navigation",this.navigationPane)}
if(this.listPane!=null){this.listPane.resizeTo("100%",this.listPane.$po!=null?null:"100%");this.listPane.splitPane=this;if(this.autoNavigate)this.$206q("list",this.listPane)}
if(this.detailPane!=null){this.detailPane.resizeTo("100%",this.detailPane.$po!=null?null:"100%");this.detailPane.splitPane=this}
if(this.pageOrientation==null){this.$137k=isc.Page.setEvent("orientationChange",this)}
this.$137l=this.getID()+"_";if(this.addHistoryEntries)this.$137m();this.pageOrientationChange()}
,isc.A.navigationBar_autoMaker=function isc_SplitPane_navigationBar_autoMaker(_1){_1=isc.addProperties({},_1,{animateStateChanges:this.animateNavigationBarStateChanges,showLeftButton:this.showBackButton,leftButtonConstructor:this.backButtonConstructor,leftButtonDefaults:this.backButtonDefaults,leftButtonProperties:this.backButtonProperties,showRightButton:this.showRightButton,rightButtonTitle:this.rightButtonTitle,showMiniNavControl:this.showMiniNav
});if(!this.isTablet()&&!this.isHandset()){_1.height=this.desktopNavigationBarHeight;_1.visibility="hidden"}
return this.createAutoChild("navigationBar",_1)}
,isc.A.listToolStrip_autoMaker=function isc_SplitPane_listToolStrip_autoMaker(_1){_1=isc.addProperties({},this.listToolStripProperties,_1);if(!this.isTablet()&&!this.isHandset()){_1.height=this.desktopNavigationBarHeight}
return this.createAutoChild("listToolStrip",_1)}
,isc.A.detailToolStrip_autoMaker=function isc_SplitPane_detailToolStrip_autoMaker(_1){_1=isc.addProperties({},this.detailToolStripProperties,_1,{titleLabelConstructor:this.detailTitleLabelConstructor,titleLabelDefaults:this.detailTitleLabelDefaults,titleLabelProperties:this.detailTitleLabelProperties
});var _2;if(this.isTablet()){_1.showMiniNavControl=this.showMiniNav;_1.leftButton_autoMaker=function(_1){return(this.creator.showSidePanelButton=this.creator.createAutoChild("showSidePanelButton",_1))}}else if(!this.isHandset()){_1.height=this.desktopNavigationBarHeight}
return this.createAutoChild("detailToolStrip",_1)}
,isc.A.destroy=function isc_SplitPane_destroy(){if(this.$138i!=null){isc.History.unregisterCallback(this.$138i);delete this.$138i}
if(this.$137k!=null){isc.Page.clearEvent("orientationChange",this.$137k);delete this.$137k}
this.Super("destroy",arguments)}
,isc.A.draw=function isc_SplitPane_draw(){this.Super("draw",arguments);this.$137n()}
,isc.A.$137m=function isc_SplitPane__setUpDefaultHistoryManagement(){if(!isc.History){this.logError("addHistoryEntries is true, but the History module is not loaded.")}else if(this.$138i==null){this.$138i=isc.History.registerCallback({target:this,methodName:"historyCallback"},true,true)}
this.$137n()}
,isc.A.setAddHistoryEntries=function isc_SplitPane_setAddHistoryEntries(_1){this.addHistoryEntries=_1;if(_1)this.$137m();else if(this.$138i!=null){isc.History.unregisterCallback(this.$138i);delete this.$138i}
}
,isc.A.$137n=function isc_SplitPane__maybeAddHistoryEntry(){if(!this.addHistoryEntries||!isc.History)return;if(!this.isDrawn())return;var _1=this.currentPane;var _2=this.$137l+_1;var _3=String(this.navigationTitle);var _4={$138l:this.$138l
};if(_1==="navigation"){if(!(this.isTablet()||this.isHandset()))return;_4.title=this.navigationTitle}else if(_1==="list"){if(!(this.isTablet()||this.isHandset()))return;_3+=" > "+(this.listTitle==null?"":String(this.listTitle));_4.title=this.listTitle}else if(_1==="detail"){if(!this.isHandset())return;if(this.$137t()){_3+=" > "+(this.listTitle==null?"":String(this.listTitle))}
_3+=" > "+(this.detailTitle==null?"":String(this.detailTitle));_4.title=this.detailTitle}
if(!isc.Page.isLoaded()){isc.Page.setEvent("load",function(){if(isc.History.readyForAnotherHistoryEntry())isc.History.addHistoryEntry(_2,_3,_4);else isc.Class.delayCall("addHistoryEntry",[_2,_3,_4],0,isc.History)},isc.Page.FIRE_ONCE)}else{if(isc.History.readyForAnotherHistoryEntry())isc.History.addHistoryEntry(_2,_3,_4);else isc.Class.delayCall("addHistoryEntry",[_2,_3,_4],0,isc.History)}
}
,isc.A.historyCallback=function isc_SplitPane_historyCallback(_1,_2){if(this.destroyed||_1==null)return;var _3=this.$137l;if(_1.startsWith(_3)){var _4=_1.substring(_3.length);if(_4==="navigation"){this.setNavigationTitle(_2.title);this.showNavigationPane(null,true)}else if(_4==="list"){this.showListPane(_2.title,_2.$138l,null,true)}else{this.showDetailPane(_2.title,_2.$138l,null,true)}
}
}
,isc.A.setCurrentPane=function isc_SplitPane_setCurrentPane(_1){if(_1==="navigation")this.showNavigationPane();else if(_1==="list")this.showListPane();else this.showDetailPane()}
,isc.A.setDetailToolButtons=function isc_SplitPane_setDetailToolButtons(_1){this.detailToolButtons=_1;this.updateDetailToolStrip()}
,isc.A.setPageOrientation=function isc_SplitPane_setPageOrientation(_1){if(this.pageOrientation!==_1){this.pageOrientation=_1;if(_1==null){if(this.$137k==null){this.$137k=isc.Page.setEvent("orientationChange",this)}
}else if(this.$137k!=null){isc.Page.clearEvent("orientationChange",this.$137k);delete this.$137k}
}
this.pageOrientationChange()}
,isc.A.getUISummary=function isc_SplitPane_getUISummary(_1,_2){var _3=this.Super("getUISummary",arguments);var _4=this.$254r;for(var i=0;i<_4.length;i++){var _6=this[_4[i]];if(!isc.isA.Canvas(_6))continue;if(_6.isVisible()&&!_6._generated){var _7=_6.getUISummary(_1);if(_3.members){_3.members.removeWhere("id",_6.getID())}
_3[_4[i]]=_7}
}
if(_3.members&&!_3.members.length){delete _3.members}
return _3}
,isc.A.pageOrientationChange=function isc_SplitPane_pageOrientationChange(){this.updateUI()}
,isc.A.$142j=function isc_SplitPane__getDetailPaneContainer(){var _1=this.detailPaneContainer;if(_1==null){_1=this.detailPaneContainer=this.createAutoChild("detailPaneContainer")}
var _2=[];if(this.detailPane!=null){_2.add(this.detailPane)}
if(this.detailToolButtons!=null&&!this.detailToolButtons.isEmpty()){this.updateDetailToolStrip();_2.add(this.detailToolStrip)}
_1.setMembers(_2);return _1}
,isc.A.updateUI=function isc_SplitPane_updateUI(_1,_2){var _3=this.currentUIConfig,_4=this.$79m,_5=this.currentUIConfig=this.getUIConfiguration(),_6=this.$79m=this.currentPane;if(!_1&&_5===_3&&_6===_4){if(_5==="handset"){this.$139h.$139e(this.$139h.currentPage,true)}
return}
this.updateNavigationBar(_2);if(_5==="handset"){this.setProperty("vertical",true);var _7;if(_3!=="handset"||_1){_7=[];if(this.navigationPane!=null)_7.add(this.navigationPane);if(this.listPane!=null)_7.add(this.listPane);_7.add(this.$142j());this.$139h.setPages(_7)}else{_7=this.$139h.pages}
var _8=[];if(this.navigationBar!=null)_8.add(this.navigationBar);_8.add(this.$139h);if(_6==="navigation"){this.$139h.setCurrentPage(0,_3!=="handset")}else if(_6==="list"){this.$139h.setCurrentPage(1,_3!=="handset")}else{this.$139h.setCurrentPage((this.$137t()?2:1),_3!=="handset")}
this.setMembers(_8)}else if(_5==="portrait"){this.setProperty("vertical",true);this.leftLayout.removeMembers(this.leftLayout.members);this.portraitSidePanel.setPagedPanel(this.$139h);this.updateDetailToolStrip();var _9=[this.detailToolStrip];if(this.detailPane!=null)_9.add(this.detailPane);this.setMembers(_9);var _7;if(_3!=="portrait"){_7=[];if(this.navigationPane!=null)_7.add(this.navigationPane);if(this.listPane!=null)_7.add(this.listPane);this.portraitSidePanel.pagedPanel.setPages(_7)}else{_7=this.portraitSidePanel.pagedPanel.pages}
if(_6==="navigation"){this.$139h.setCurrentPage(0,!this.portraitSidePanel.onScreen);if(this.isDrawn()&&this.isVisible()){this.$148z()}
}else if(_6==="list"){this.$139h.setCurrentPage(1,!this.portraitSidePanel.onScreen);if(this.isDrawn()&&this.isVisible()){this.$148z()}
}else{if(this.portraitSidePanel.onScreen){this.$148y()}
}
}else if(_5==="landscape"){this.setProperty("vertical",false);this.portraitSidePanel.setPagedPanel(null);if(this.portraitSidePanel.onScreen){this.portraitSidePanel.slideOut()}
this.updateDetailToolStrip();var _8=[];if(this.detailToolStrip!=null)_8.add(this.detailToolStrip);if(this.detailPane!=null)_8.add(this.detailPane);this.rightLayout.setMembers(_8);var _7;if(_3!=="landscape"){_7=[];if(this.navigationPane!=null)_7.add(this.navigationPane);if(this.listPane!=null)_7.add(this.listPane);this.$139h.setPages(_7)}else{_7=this.$139h.pages}
if(_6==="navigation"){this.$139h.setCurrentPage(0,_3!=="landscape")}else if(_6==="list"){this.$139h.setCurrentPage(1,_3!=="landscape")}
_8.setLength(0);if(this.navigationBar!=null)_8.add(this.navigationBar);_8.add(this.$139h);this.leftLayout.setMembers(_8);_8.setLength(0);_8.add(this.leftLayout);if(this.showResizeBars){this.leftLayout.setShowResizeBar(true)}else{this.leftLayout.setShowResizeBar(false);if(this.spacer==null){this.spacer=this.createAutoChild("spacer")}
_8.add(this.spacer)}
_8.add(this.rightLayout);this.setMembers(_8)}else{this.setProperty("vertical",false);var _8=[];if(this.navigationBar!=null)_8.add(this.navigationBar);if(this.navigationPane!=null)_8.add(this.navigationPane);this.leftLayout.setMembers(_8);this.leftLayout.setShowResizeBar(this.showResizeBars);this.updateListToolStrip();this.updateDetailToolStrip();_8.setLength(0);if(this.$137t()){if(this.listToolStrip!=null)_8.add(this.listToolStrip);_8.add(this.listPane);this.listPane.setShowResizeBar(this.showResizeBars)}
else if(this.editingOn&&this.editProxy&&this.editProxy.isTriplePane){var _10=isc.LayoutSpacer.create({height:"50%",showResizeBar:true});_8.add(_10)}
if(this.detailPane!=null){if(this.detailToolStrip!=null)_8.add(this.detailToolStrip);_8.add(this.detailPane)}
else if(this.editingOn&&this.editProxy&&this.editProxy.isTriplePane){var _10=isc.LayoutSpacer.create({height:"*"});_8.add(_10)}
this.rightLayout.setMembers(_8);this.setMembers([this.leftLayout,this.rightLayout])}
var _11=this.isRTL()&&!this.vertical;if(this.reverseOrder!=_11){this.reverseOrder=_11;this.reflow()}
}
,isc.A.$148z=function isc_SplitPane__engagePortraitSidePanel(){this.portraitClickMask.show();this.portraitClickMask.bringToFront();if(!this.portraitSidePanel.isDrawn())this.portraitSidePanel.draw();else this.portraitSidePanel.redraw();this.portraitSidePanel.slideIn();this.portraitSidePanel.show();this.portraitSidePanel.moveAbove(this.portraitClickMask)}
,isc.A.$148y=function isc_SplitPane__dismissPortraitSidePanel(){this.portraitSidePanel.slideOut();this.portraitClickMask.hide()}
,isc.A.updateListToolStrip=function isc_SplitPane_updateListToolStrip(){var _1=this.listToolStrip;if(_1==null)return;if(this.showListToolStrip!=false&&this.$137t()&&this.currentUIConfig==="desktop")
{this.updateListTitleLabel();var _2=[];if(_1.leftButton){_2.add(_1.leftButton)}
if(this.listTitleLabel!=null)_2.add(this.listTitleLabel);if(_1.rightButton){_2.add(_1.rightButton)}
_1.setMembers(_2);_1.show()}else{_1.hide()}
}
,isc.A.updateListTitleLabel=function isc_SplitPane_updateListTitleLabel(){if(this.showListTitleLabel==false)return;if(this.listTitleLabel==null){this.listTitleLabel=this.createAutoChild("listTitleLabel")}
this.listTitleLabel.setContents(this.listTitle)}
,isc.A.updateDetailToolStrip=function isc_SplitPane_updateDetailToolStrip(){var _1=this.detailToolStrip;if(_1==null)return;if(this.showDetailToolStrip==false){_1.hide();return}
var _2=this.currentUIConfig;var _3={showLeftButton:false,leftButtonTitle:null,title:null,controls:[]
};var _4=_3.controls;var _5=true;if(_2==="handset"){if(this.detailToolButtons==null||this.detailToolButtons.isEmpty()){_5=false}
_4.addList(this.detailToolButtons);_1.setProperty("align","center")}else if(_2==="portrait"){_3.showLeftButton=true;_3.leftButtonTitle=(this.currentPane!=="navigation"&&this.listPane
?this.listTitle
:this.navigationTitle);_3.shortLeftButtonTitle=_3.leftButtonTitle;_4.add(this.showSidePanelButton);if(this.detailNavigationControl!=null){_4.add(this.detailNavigationControl)}
_4.add("titleLabel");if(this.showDetailTitleLabel!=false)_3.title=this.detailTitle;if(this.detailToolButtons!=null)_4.addList(this.detailToolButtons);if(this.showMiniNav)_4.add("miniNavControl");_1.setProperty("align","left")}else{if(_2==="desktop"&&!this.$226c())_5=false;_4.add("titleLabel");if(this.showDetailTitleLabel!=false)_3.title=this.detailTitle;if(this.detailToolButtons!=null)_4.addList(this.detailToolButtons);_1.setProperty("align","left")}
if(_5)_1.show();else _1.hide();_1.setViewState(_3)}
,isc.A.$160c=function isc_SplitPane__getActiveNavigationBar(){if(this.currentUIConfig==="portrait"){return this.portraitSidePanel.navigationBar}else{return this.navigationBar}
}
,isc.A.updateNavigationBar=function isc_SplitPane_updateNavigationBar(_1){var _2=this.$160c();if(_2==null)return;if(this.showNavigationBar==false){_2.hide();return}
var _3;var _4={showLeftButton:_3,leftButtonTitle:_3,shortLeftButtonTitle:_3,alwaysShowLeftButtonTitle:_3,title:_3,controls:[]
};var _5=_4.controls;this.logInfo("updateNavigationBar, currentPane: "+this.currentPane+", currentUI: "+this.currentUIConfig);if(this.showLeftButton){if(this.leftButton==null){this.leftButton=this.createAutoChild("leftButton",{title:this.leftButtonTitle
})}else{this.leftButton.setTitle(this.leftButtonTitle)}
}
if((this.currentUIConfig==="handset"&&this.currentPane!=="navigation")||(this.currentUIConfig==="portrait"&&this.currentPane!=="navigation")||(this.currentUIConfig==="landscape"&&this.currentPane!=="navigation"&&this.$137t()))
{var _6;if(this.currentUIConfig==="landscape"){_6=(this.$137t()?this.listTitle
:this.navigationTitle)}else if(this.currentUIConfig==="portrait"){_6=(this.$137t()&&this.currentPane!=="navigation"?this.listTitle
:this.navigationTitle)}else{_6=(this.currentPane==="detail"
?this.detailTitle
:(this.currentPane==="list"
?this.listTitle
:this.navigationTitle))}
if(!_6)_6="&nbsp;";_4.title=_6;var _7;if(this.$138l!=null){_7=this.$138l}else{_7=this.isHandset()&&this.currentPane==="detail"&&this.$137t()
?this.listTitle
:this.navigationTitle}
_4.leftButtonTitle=_7;_4.showLeftButton=(this.currentUIConfig!=="portrait"||this.$137t());_5.add("leftButton")}else{if(this.currentUIConfig==="desktop"&&this.showNavigationBar==null&&!this.navigationTitle&&!this.showRightButton&&!this.showLeftButton)
{_2.hide();_4.title=isc.nbsp}else{_2.show();if(!_2.isDrawn()&&(_2.parentElement==null||_2.parentElement.isDrawn()))
{_2.draw()}
_4.title=(this.navigationTitle||isc.nbsp)}
_4.showLeftButton=false;_4.leftButtonTitle=null}
if(this.showLeftButton){_5.add(this.leftButton)}
_5.add("titleLabel");if(this.detailNavigationControl!=null){_5.add(this.detailNavigationControl)}
if(this.showMiniNav&&this.currentUIConfig==="handset"&&this.currentPane==="detail"){_5.add("miniNavControl")}
if(this.showRightButton){_5.add("rightButton")}
_4.rightButtonTitle=this.rightButtonTitle;_4.showRightButton=this.showRightButton;if(this.currentUIConfig==="portrait"){}else if(this.currentUIConfig==="landscape"){var _8=(this.navigationBarProperties&&this.navigationBarProperties.styleName)||(this.navigationBarDefaults&&this.navigationBarDefaults.styleName)||this.navigationBar.getClass().getInstanceProperty("styleName");_2.setStyleName(_8)}
var _9=(isc.Browser.$139c&&_2.skinUsesCSSTransitions);_2.setViewState(_4,_1,_9)}
,isc.A.getUIConfiguration=function isc_SplitPane_getUIConfiguration(){if(this.isHandset())return"handset";else if(this.isTablet()&&this.getPageOrientation()==="portrait")return"portrait";else if(this.isTablet()&&this.getPageOrientation()==="landscape")return"landscape";else return"desktop"}
,isc.A.setShowLeftButton=function isc_SplitPane_setShowLeftButton(_1){this.showLeftButton=_1;this.updateNavigationBar()}
,isc.A.setLeftButtonTitle=function isc_SplitPane_setLeftButtonTitle(_1){this.leftButtonTitle=_1;this.updateNavigationBar()}
,isc.A.setShowRightButton=function isc_SplitPane_setShowRightButton(_1){this.showRightButton=_1;this.updateNavigationBar()}
,isc.A.setRightButtonTitle=function isc_SplitPane_setRightButtonTitle(_1){this.rightButtonTitle=_1;this.updateNavigationBar()}
,isc.A.$79k=function isc_SplitPane__setNavigationPane(_1){var _2=this.navigationPane;if(_2!=null){if(_2===_1)return;delete _2.splitPane;this.$206r("navigation",_2)}
this.navigationPane=_1;if(_1!=null){_1.resizeTo("100%",_1.$po!=null?null:"100%");_1.splitPane=this;if(this.autoNavigate)this.$206q("navigation",_1)}
if(this.isTablet()||this.isHandset()){var _3=[];if(_1!=null)_3.add(_1);if(this.listPane!=null)_3.add(this.listPane);if(this.isHandset())_3.add(this.$142j());this.$139h.setPages(_3)}
}
,isc.A.setNavigationPane=function isc_SplitPane_setNavigationPane(_1){this.$79k(_1);this.updateUI(true)}
,isc.A.setNavigationTitle=function isc_SplitPane_setNavigationTitle(_1){this.navigationTitle=_1;this.updateNavigationBar()}
,isc.A.showNavigationPane=function isc_SplitPane_showNavigationPane(_1,_2,_3,_4){if(!this.navigationPane||!this.navigationPane.isVisible())_3=true;var _5=this.currentPane,_6=_5!=null&&_5!=="navigation";this.currentPane="navigation";this.updateUI(_2||_3,_1);if(_6){if(!_2){this.$137n()}
delete this.$138l;if(this.isDrawn()){var _7=this.$215p(_1,_2,_3,_4);this.$206s("navigation",_5,_7)}
}
}
,isc.A.$206s=function isc_SplitPane__paneChanged(_1,_2,_3){if(this.autoNavigate)delete this.$206t;if(this.paneChanged!=null)this.paneChanged(_1,_2,_3)}
,isc.A.$137t=function isc_SplitPane__hasListPane(){return this.listPane!=null}
,isc.A.$800=function isc_SplitPane__setListPane(_1){if(this.$137t()){var _2=this.listPane;if(_2===_1)return;delete _2.splitPane;this.$206r("list",_2)}
this.listPane=_1;if(_1!=null){_1.resizeTo("100%",_1.$po!=null?null:"100%");_1.splitPane=this;if(this.autoNavigate)this.$206q("list",_1)}
if(this.isTablet()||this.isHandset()){var _3=[];if(this.navigationPane!=null)_3.add(this.navigationPane);if(_1!=null)_3.add(_1);if(this.isHandset())_3.add(this.$142j());this.$139h.setPages(_3)}
}
,isc.A.setListPane=function isc_SplitPane_setListPane(_1){this.$800(_1);this.updateUI(true)}
,isc.A.showListPane=function isc_SplitPane_showListPane(_1,_2,_3,_4,_5,_6){if(!this.$137t()){this.logWarn("Attempted to show the list pane, but this SplitPane does not have a list pane. Ignoring.");return}
if(!this.listPane||!this.listPane.isVisible())_5=true;var _7=this.currentPane,_8=this.currentPane!=="list";if(_6&&this.hasDynamicProperty("listTitle"))_5=true;else if(_1!=null)this.listTitle=_1;if(_2!=null)this.$138l=_2;this.currentPane="list";this.updateUI(_1!=null||_2!=null||_4||_5,_3);if(_8){if(!_4){this.$137n()}
delete this.$138l;if(this.isDrawn()){var _9=this.$215p(_3,_4,_5,_6);this.$206s("list",_7,_9)}
}
}
,isc.A.setListTitle=function isc_SplitPane_setListTitle(_1){this.listTitle=_1;this.updateNavigationBar();this.updateListToolStrip();this.updateDetailToolStrip()}
,isc.A.$226c=function isc_SplitPane__hasDetailPane(){return this.detailPane!=null}
,isc.A.$79l=function isc_SplitPane__setDetailPane(_1){if(this.detailPane!=null){delete this.detailPane.splitPane}
this.detailPane=_1;if(_1){_1.resizeTo("100%",_1.$po!=null?null:"100%");_1.splitPane=this}
if(this.isHandset()){var _2=[];if(this.navigationPane!=null)_2.add(this.navigationPane);if(this.listPane!=null)_2.add(this.listPane);_2.add(this.$142j());this.$139h.setPages(_2)}
}
,isc.A.setDetailPane=function isc_SplitPane_setDetailPane(_1){this.$79l(_1);this.updateUI(true)}
,isc.A.showDetailPane=function isc_SplitPane_showDetailPane(_1,_2,_3,_4,_5,_6){if(!this.detailPane||!this.detailPane.isVisible())_5=true;var _7=this.currentPane,_8=this.currentPane!=="detail";if(_6&&this.hasDynamicProperty("detailTitle"))_5=true;else if(_1!=null)this.detailTitle=_1;if(_2!=null)this.$138l=_2;this.currentPane="detail";this.updateUI(_1!=null||_2!=null||_4||_5,_3);if(_8){if(!_4){this.$137n()}
delete this.$138l;if(this.isDrawn()){var _9=this.$215p(_3,_4,_5,_6);this.$206s("detail",_7,_9)}
}
}
,isc.A.setDetailTitle=function isc_SplitPane_setDetailTitle(_1){this.detailTitle=_1;if(this.currentUIConfig==="handset"){if(this.currentPane==="detail")this.updateNavigationBar()}else{this.updateDetailToolStrip()}
}
,isc.A.setDetailNavigationControl=function isc_SplitPane_setDetailNavigationControl(_1){this.detailNavigationControl=_1;var _2=this.currentUIConfig!=="landscape"&&this.currentPane==="detail";if(_2)this.updateUI(true)}
);isc.evalBoundary;isc.B.push(isc.A.$168p=function isc_SplitPane__parsePaneTitleTemplate(_1,_2){if(!isc.isA.DataBoundComponent(_2))return"";var _3=_2.getSelectedRecord(),_4=_2.getDataSource()
;var _5={titleField:(!_3||!_4)?"":_3[_4.getTitleField()],index:_3==null?-1:_2.getRecordIndex(_3),totalRows:_2.getTotalRows?_2.getTotalRows():1,record:_3
};return _1.evalDynamicString(this,_5)}
,isc.A.setListPaneTitleTemplate=function isc_SplitPane_setListPaneTitleTemplate(_1){this.listPaneTitleTemplate=_1;var _2=this.navigationPane?this.$206u("navigation",this.navigationPane):null;this.setListTitle(this.$168p(_1,_2))}
,isc.A.setDetailPaneTitleTemplate=function isc_SplitPane_setDetailPaneTitleTemplate(_1){this.detailPaneTitleTemplate=_1;var _2=this.listPane?this.$206u("list",this.listPane):null;this.setDetailTitle(this.$168p(_1,_2))}
,isc.A.navigatePane=function isc_SplitPane_navigatePane(_1,_2,_3,_4){var _5,_6=_4?isc.Log.INFO:isc.Log.WARN;if(isc.isA.Canvas(_1)){if(_1===this.navigationPane){_5=_1;_1="navigation"}else if(_1===this.listPane){_5=_1;_1="list"}else if(_1===this.detailPane){_5=_1;_1="detail"}else{this.logWarn("navigatePane(): Unknown target pane:"+isc.echoLeaf(_1)+". Will use the default target pane.");_1=null}
}else{if(_1==="navigation"){_5=this.navigationPane}else if(_1==="list"){_5=this.listPane;if(_5==null){this.logMessage(_6,"navigatePane(): The listPane cannot be the target because there isn't a listPane set. Will default to the detailPane.")}
}else if(_1==="detail"){_5=this.detailPane}
}
if(_5==null){if(this.$137t()){_1="list";_5=this.listPane}else{_1="detail";_5=this.detailPane}
}
if(_5==null){this.logInfo("navigatePane(): unable to navigate - can't resolve the targetPane");return}
if(_3==null)_3=this.currentPane;var _7;if(isc.isA.Canvas(_3)){if(_3===this.navigationPane){_7=_3;_3="navigation"}else if(_3===this.listPane){_7=_3;_3="list"}else if(_3===this.detailPane){_7=_3;_3="detail"}else{this.logWarn("navigatePane(): Unknown source pane:"+isc.echoLeaf(_3)+". Will use the default source pane.");_3=null}
}else{if(_3==="navigation"){_7=this.navigationPane}else if(_3==="list"){_7=this.listPane;if(_7==null){this.logMessage(_6,"navigatePane(): The listPane cannot be the source because there isn't a listPane set. Will use the default source pane.")}
}else if(_3==="detail"){_7=this.detailPane}
}
if(_7==null){if(_1==="detail"&&this.$137t()){_3="list";_7=this.listPane}else{_3="navigation";_7=this.navigationPane}
}
if(_7==null){this.logInfo("navigatePane(): unable to navigate - can't resolve the sourcePane");return}
var _8=this.$206u("source",_7);if(!_8){this.logMessage(_6,"navigatePane(): source pane isn't a DataBoundComponent")}
var _9=this.$206u("target",_5);if(!_9){this.logMessage(_6,"navigatePane(): target pane isn't a DataBoundComponent")}
var _10;if(_8&&_9&&_8!=_9){var _11=_8.getSelectedRecord();if(_11){var _12=_9.getDataSource(),_13=_8.getDataSource()
;if(isc.DynamicForm&&isc.isA.SearchForm(_9)||(_4&&_9.$2531()||_9.$2530()))
{var _14;if(_12&&_13&&(_13==_12||(_14=_12.getTreeRelationship(_13,null,true))&&(_14.childrenProperty||_14.parentIdField)))
{_10=false}
}else if(_12&&_13==_12){if(_9.editRecord)_9.editRecord(_11);else _9.setData([_11]);_10=false}else{var _15=this,_16=++this.navigationId;_10=_9.fetchRelatedData(_11,_8,function(){_15.$206v(_2,_1,_8,_16,!!_4)},null,true)}
}else{this.logInfo("navigatePane(): no selected record(s) found for "+_8)}
}
if(!_10){if(_10==null&&_4){this.logInfo("navigatePane(): cannot auto-navigate as proper source and target panes with related DataSources were not located")}else{this.$206v(_2,_1,_8,++this.navigationId,!!_4)}
}
}
,isc.A.$206v=function isc_SplitPane__completeNavigatePane(_1,_2,_3,_4,_5){if(_4!=this.navigationId){this.logInfo("navigatePane(): skipping delayed navigation to "+_2+" as another navigation has already been completed");return}
if(_3&&!_3.getSelectedRecord())_3=null;switch(_2){case"list":if(_1==null&&this.listPaneTitleTemplate!=null&&_3){_1=this.$168p(this.listPaneTitleTemplate,_3)}
this.showListPane(_1,null,"forward",null,null,_5);break;case"detail":if(_1==null&&this.detailPaneTitleTemplate!=null&&_3){_1=this.$168p(this.detailPaneTitleTemplate,_3)}
this.showDetailPane(_1,null,"forward",null,null,_5);break;case"navigation":this.showNavigationPane("forward",null,null,_5);break}
}
,isc.A.$215p=function isc_SplitPane__getNavigationMethod(_1,_2,_3,_4){if(_4!=null){return _4?"selectionChanged":"navigatePane"}else if(_3!=null){return _1=="back"?"backClick":"sideClick"}else if(_2){return"historyCallback"}
return"programmatic"}
,isc.A.$206u=function isc_SplitPane__getNavigatePaneComponent(_1,_2){if(isc.isA.DataBoundComponent(_2))return _2;var _3=_2.members||_2.children,_4=_3?this.$206w(_3):null;if(_4){this.logInfo("navigatePane(): using child canvas "+_4+" for the "+_1+" pane since "+_2+" isn't a DataBoundComponent")}
return _4}
,isc.A.$206w=function isc_SplitPane___getNavigatePaneComponent(_1){var _2=[];for(var i=0;i<_1.length;i++){var _4=_1[i];if(isc.isA.DataBoundComponent(_4)&&(!isc.DynamicForm||!isc.isA.SearchForm()))
{return _4}
_2.addList(_4.members||_4.children)}
return _2.length?this.$206w(_2):null}
,isc.A.$206q=function isc_SplitPane__observePane(_1,_2,_3){var _4=_1=="list"?"detail":"list",_5=this.$206u(_1,_2)
;if(_3){if(_2.$209i==_5)return;this.$206r(_1,_2)}
if(!_5)return;_2.$209i=_5;this.observe(_5,"selectionUpdated",function(){this.navigatePane(_4,null,_1,true);this.$206t=true});if(_5.recordClick)this.observe(_5,"recordClick",function(){if(this.$206t||this.currentPane!=_1)return;this.navigatePane(_4,null,_1,true)})}
,isc.A.$206r=function isc_SplitPane__ignorePane(_1,_2){var _3=_2.$209i;delete _2.$209i;if(!_3)return;this.ignore(_3,"selectionUpdated");this.ignore(_3,"recordClick")}
,isc.A.navigateListPane=function isc_SplitPane_navigateListPane(_1){this.navigatePane("list",_1,"navigation")}
,isc.A.navigateDetailPane=function isc_SplitPane_navigateDetailPane(_1){this.navigatePane("detail",_1,"list")}
);isc.B._maxIndex=isc.C+65;isc.SplitPane.registerStringMethods({navigationClick:"direction",paneChanged:"newPane, oldPane, navigationMethod",upClick:"",downClick:""});isc.defineClass("TriplePane","SplitPane");isc.defineClass("NavStackPagedPanel","SplitPanePagedPanel");isc.A=isc.NavStackPagedPanel.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.animateScrollDuration=300;isc.A.pagesContainerBaseStyle="navStackPagedPanelPagesContainer";isc.B.push(isc.A.push=function isc_NavStackPagedPanel_push(_1,_2){this.pages.add(_1);var _3=this.pages.length;var i=_3-1;this.$1462(_1,i,_3);this.setCurrentPage(i,false,_2)}
,isc.A.pop=function isc_NavStackPagedPanel_pop(_1){this.setCurrentPage(this.pages.length-2,false,{target:this,method:function(){this.pages[this.pages.length-1].deparent();this.pages.setLength(this.pages.length-1);if(_1!=null)this.fireCallback(_1)}
})}
,isc.A.setSinglePanel=function isc_NavStackPagedPanel_setSinglePanel(_1,_2){this.setPages([_1]);if(_2!=null)this.fireCallback(_2)}
);isc.B._maxIndex=isc.C+3;isc.defineClass("NavStack","VLayout");isc.A=isc.NavStack.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.navStackPagedPanelConstructor="NavStackPagedPanel";isc.A.navStackPagedPanelDefaults={width:"100%",height:"*"
};isc.A.navigationBarConstructor="NavigationBar";isc.A.navigationBarDefaults={autoParent:"none",hieght:44,rightPadding:5,leftPadding:5,defaultLayoutAlign:"center",overflow:"hidden",showLeftButton:false,navigationClick:function(_1){if("back"==_1){this.creator.pop()}
}
};isc.B.push(isc.A.initWidget=function isc_NavStack_initWidget(){this.Super("initWidget",arguments);if(this.navigationBar==null){this.navigationBar=this.createAutoChild("navigationBar")}
this.navStackPagedPanel=this.createAutoChild("navStackPagedPanel");this.setMembers([this.navigationBar,this.navStackPagedPanel])}
,isc.A.push=function isc_NavStack_push(_1,_2){if(this.$1430())return;this.navigationBar.push(_1);this.navStackPagedPanel.push(_1,_2);if(this.navStackPagedPanel.pages.length>1){this.navigationBar.setShowLeftButton(true)}
}
,isc.A.pop=function isc_NavStack_pop(_1){if(this.$1430())return;var _2=this.navigationBar.pop();if(this.navStackPagedPanel.pages.length<=2){this.navigationBar.setShowLeftButton(false)}
this.navStackPagedPanel.pop(_1)}
,isc.A.setSinglePanel=function isc_NavStack_setSinglePanel(_1,_2){this.navigationBar.setSinglePanel(_1);this.navStackPagedPanel.setSinglePanel(_1,_2);this.navigationBar.setShowLeftButton(false)}
,isc.A.$1430=function isc_NavStack__isAnimating(){return!!this.navStackPagedPanel.$35v}
);isc.B._maxIndex=isc.C+5;isc.ClassFactory.defineClass("Deck","Layout");isc.A=isc.Deck.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.$155w=true;isc.B.push(isc.A.setCurrentPane=function isc_Deck_setCurrentPane(_1){if(this.currentPane!=null&&(this.currentPane===_1||this.currentPane.ID==_1)){return}
var _2=false,_3=this.panes;for(var i=0,_5=_3.length;i<_5;++i){if(!_3[i])continue;var p=_3[i];var _7=p.$1893||p.getID();var _8=p.getLocalId();if(p.name==_1||_8==_1||_7==_1||p===_1){_1=_3[i];_1.setVisibility(isc.Canvas.INHERIT);_2=true;break}
}
if(!_2){if(this.editingOn){this.currentPane=_1}else{this.logWarn("setCurrentPane() failed: pane "+(isc.isA.Canvas(_1)?_1.getID():_1)+" was not found in the Deck.")}
}
}
,isc.A.hideCurrentPane=function isc_Deck_hideCurrentPane(){if(this.currentPane!=null)this.currentPane.setVisibility(isc.Canvas.HIDDEN)}
,isc.A.setPanes=function isc_Deck_setPanes(_1){if(_1==null)_1=[];for(var i=0,_3=_1.length;i<_3;++i){if(_1[i]!=null&&!isc.isA.Canvas(_1[i])){var _4=_1[i],_5=_4.replace("autoChild:","")
;_1[i]=_4=this.createCanvas(_4);if(_4)_4.$1893=_5}
}
var _6=this.currentPane;if(!isc.$75u||_1.length>0){delete this.currentPane}
for(var i=0,_3=_1.length;i<_3;++i){if(_1[i]!=null){var _4=_1[i],_5=_4.$1893||_4.getID(),_7=_4.getLocalId(),_8=_4.name,_9=(_6!=null&&(isc.isA.String(_6)?(_8==_6||_7==_6||_5==_6):(_4===_6)
))
;_4.setVisibility(_9?isc.Canvas.INHERIT:isc.Canvas.HIDDEN);if(_9)this.currentPane=_4}
}
this.panes=_1;if(this.currentPane!=null&&this.panes!=null&&!this.panes.contains(this.currentPane)){this.currentPane=null}
this.setMembers(_1)}
,isc.A.addPane=function isc_Deck_addPane(_1,_2){if(_1==null)return;var _3=this.panes.indexOf(_1);if(_3>=0){var _4=_2==null?this.panes.length:_2;if(_3<_4)_4--;this.panes.slideRange(_3,_3+1,_4);this.reorderMembers(_3,_3+1,_4)}else{if(_2==null){this.panes.add(_1)}else{this.panes.addAt(_1,_2)}
_1.setVisibility(isc.Canvas.HIDDEN);this.addMember(_1,_2)}
}
,isc.A.removePane=function isc_Deck_removePane(_1){if(_1==null)return;this.panes.remove(_1);this.removeMember(_1)}
,isc.A.initWidget=function isc_Deck_initWidget(){this.Super("initWidget",arguments);this.$253k=!this.panes&&this.currentPane;this.setPanes(this.panes)}
,isc.A.childVisibilityChanged=function isc_Deck_childVisibilityChanged(_1,_2){if(this.panes.contains(_1))this.paneVisibilityChanged(_1,_2);this.Super("childVisibilityChanged",arguments)}
,isc.A.paneVisibilityChanged=function isc_Deck_paneVisibilityChanged(_1,_2){if(_2===isc.Canvas.HIDDEN){if(_1===this.currentPane){this.currentPane=null;if(this.currentPaneChanged!=null)this.currentPaneChanged(this.currentPane)}
}else{var _3=this.currentPane;if(_3==null||_1!==_3){this.currentPane=_1;if(_3!=null){_3.setVisibility(isc.Canvas.HIDDEN)}
if(this.currentPaneChanged!=null)this.currentPaneChanged(this.currentPane)}
}
}
,isc.A.draw=function isc_Deck_draw(){var _1;if(!this.$155z&&this.currentPane===_1&&this.panes.length>0){this.setCurrentPane(this.panes[0]);this.$155z=true}
this.Super("draw",arguments)}
,isc.A.childRemoved=function isc_Deck_childRemoved(_1,_2){this.panes.remove(_1);if(_1===this.currentPane){this.currentPane=null;if(this.panes.length>0)this.panes[0].setVisibility(isc.Canvas.INHERIT);else if(this.currentPaneChanged!=null)this.currentPaneChanged(this.currentPane)}
}
);isc.B._maxIndex=isc.C+10;isc.Deck.registerStringMethods({currentPaneChanged:"currentPane"});isc.defineClass("NavPanel","SplitPane");isc.A=isc.NavPanel;isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.B.push(isc.A.$167h=function isc_c_NavPanel__getItemId(_1){if(_1.id!=null||_1.autoId!=null){return _1.id||_1.autoId}else if(_1.isHeader||_1.isSeparator){return null}else if(isc.isA.Canvas(_1.pane)){return _1.pane.getID()}else{return _1.pane}
}
,isc.A.$168t=function isc_c_NavPanel__flattenNavItemTree(_1){var _2=[];for(var i=0,_4=_1==null?0:_1.length;i<_4;++i){var _5=_1[i];_2.add(_5);if(isc.isAn.Array(_5.items)){_2.addList(this.$168t(_5.items))}
}
return _2}
);isc.B._maxIndex=isc.C+2;isc.A=isc.NavPanel.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.navGridDefaults={showHeader:false,leaveScrollbarGap:false,autoParent:"navLayout",defaultFields:[{name:"title"}
],recordIsEnabled:function(_1,_2,_3){var _4=this.creator;if(_4.editingOn&&_1!=null&&_1.isSeparator)return true;return this.Super("recordIsEnabled",arguments)},recordClick:function(_1,_2,_3,_4,_5,_6,_7){var _8=this.creator;if(_8.editingOn){_8.setCurrentItem(!_2.isHeader&&!_2.isSeparator&&_2.canSelect!=false?_2:null);_8.editContext.selectSingleComponent(_2);return false}
if(!_2.isHeader&&!_2.isSeparator&&_2.canSelect!=false){_8.setCurrentItem(_2)}
},recordDoubleClick:function(_1,_2,_3,_4,_5,_6,_7){var _8=this.creator;if(_8.editingOn&&!_2.isSeparator&&_8.editProxy.supportsInlineEdit&&_8.editContext.enableInlineEdit)
{_8.editProxy.startItemInlineEditing(_2,_3)}
},getIcon:function(_1){if(_1==null||_1.isHeader||_1.isSeparator)return null;return this.Super("getIcon",arguments)}
};isc.A.navGridConstructor="TreeGrid";isc.A.navLayoutConstructor="VLayout";isc.A.showListToolStrip=false;isc.A.navDeckDefaults={currentPane:null,currentPaneChanged:function(_1){var _2=this.creator;if(_2.$168u)return;if(_1==null){_2.setCurrentItem(null);return}
var _3=isc.NavPanel.$168t(_2.navItems);for(var i=0,_5=_3.length;i<_5;++i){var _6=_3[i];if(_6.isHeader||_6.isSeparator||_6.canSelect==false)continue;var _7=_6.pane;if(_7){if(isc.isA.String(_7)&&isc.isA.Canvas(window[_7])){_7=window[_7]}
if(_1===_7){_2.setCurrentItem(_6);return}
}
}
_2.logWarn("navDeck.currentPaneChanged(): Failed to find the selectable NavItem corresponding to "+isc.echo(_1))}
};isc.A.navDeckConstructor="Deck";isc.A.headerStyle="navItemHeader";isc.A.$2545=["title","isHeader"
];isc.B.push(isc.A.$206u=function isc_NavPanel__getNavigatePaneComponent(_1,_2){return _2==this.navLayout?this.navGrid:this.invokeSuper(isc.NavPanel,"$206u",_1,_2)}
,isc.A.$230n=function isc_NavPanel__refreshNavLayoutMembers(){var _1=[];_1.addList(this.navBeforeMembers);_1.add(this.navGrid);_1.addList(this.navAfterMembers);this.navLayout.setMembers(_1)}
,isc.A.setNavBeforeMembers=function isc_NavPanel_setNavBeforeMembers(_1){this.navBeforeMembers=_1;this.$230n()}
,isc.A.setNavAfterMembers=function isc_NavPanel_setNavAfterMembers(_1){this.navAfterMembers=_1;this.$230n()}
,isc.A.setNavItemBaseStyle=function isc_NavPanel_setNavItemBaseStyle(_1){this.navItemBaseStyle=_1;var _2=this.navGrid;if(isc.isAn.Instance(_2)){_2.setProperty("baseStyle",_1)}
}
,isc.A.initWidget=function isc_NavPanel_initWidget(){this.navigationPane=this.navLayout=this.createAutoChild("navLayout");this.navLayout.addMembers(this.navBeforeMembers);this.addAutoChild("navGrid",{isSeparatorProperty:"isSeparator",baseStyle:this.navItemBaseStyle
});this.navLayout.addMembers(this.navAfterMembers);var _1={currentPane:null,panes:null
};var _2=this.currentItem,_3=this.currentItemId;if(_2==null&&_3)_2=this.currentItem=this.$167i(_3);if(_2==null&&this.defaultToFirstItem&&this.navItems){_2=this.navItems[0]}
if(_2!=null){_1.currentPane=_2.pane;_1.panes=[_2.pane];_3=isc.NavPanel.$167h(_2);this.currentItemId=_3;this.currentPane="detail";this.detailTitle=_2.title}
if(this.deckStyle)_1.styleName=this.deckStyle;this.detailPane=this.navDeck=this.createAutoChild("navDeck",_1);this.Super("initWidget",arguments)}
,isc.A.$156e=function isc_NavPanel__processTreeAndReturnNavItemsPanes(_1){_1=isc.NavPanel.$168t(_1);var _2=[];for(var i=0,_4=_1.length;i<_4;++i){var _5=_1[i];if(_5.isHeader&&!_5.customStyle){_5.customStyle=this.headerStyle}
if(_5.isSeparator||_5.canSelect==false)continue;if(_5.pane){if(isc.isA.String(_5.pane)&&isc.isA.Canvas(window[_5.pane])){_2.add(window[_5.pane])}else{_2.add(_5.pane)}
}
}
return _2}
,isc.A.setNavItems=function isc_NavPanel_setNavItems(_1){this.navItems=_1;this.dataChanged(_1);if(!this.currentItem&&this.defaultToFirstItem&&_1&&_1.length>0){this.setCurrentItem(_1[0])}
}
,isc.A.getNavItem=function isc_NavPanel_getNavItem(_1){return this.$167i(_1)}
,isc.A.addNavItem=function isc_NavPanel_addNavItem(_1,_2){if(!this.navItems)this.navItems=[];_1.navPanel=this;if(_2==null)this.navItems.add(_1);else this.navItems.addAt(_1,_2);this.refreshData();if(!this.currentItem&&!this.$2210){this.$2210=true;this.delayCall("setInitialItem",[_1])}
}
,isc.A.removeNavItem=function isc_NavPanel_removeNavItem(_1){if(!this.navItems)return;this.navItems.remove(_1);if(this.editingOn&&this.navItems.length==0){var _2=this.editProxy.createInstructionPane(null,"NavPanel","navigationPane");this.setNavigationPane(_2)}
this.refreshData()}
,isc.A.refreshData=function isc_NavPanel_refreshData(){this.dataChanged(this.navItems)}
,isc.A.setInitialItem=function isc_NavPanel_setInitialItem(_1){this.setCurrentItem(_1);delete this.$2210}
,isc.A.getAllItems=function isc_NavPanel_getAllItems(_1){var _2=this,_3=[]
;if(_1){if(_1.items&&isc.isAn.Array(_1.items)){_1.items.map(function(_4){_3.add(_4);_3.addList(_2.getAllItems(_4))})}
}else if(this.navItems&&isc.isAn.Array(this.navItems)){this.navItems.map(function(_4){_3.add(_4);_3.addList(_2.getAllItems(_4))})}
return _3}
,isc.A.setCurrentItem=function isc_NavPanel_setCurrentItem(_1){if((_1==null&&this.currentItem==null)||_1===this.currentItem||this.$266o||this.destroying)
{return}
if(_1!=null){if(_1.isHeader||_1.isSeparator){return}
this.currentItem=_1;this.currentItemId=isc.NavPanel.$167h(_1)}else{this.currentItem=null;this.currentItemId=null}
this.$168u=true;if(_1!=null&&_1.pane!=null){this.navDeck.setCurrentPane(_1.pane);this.showDetailPane(_1.title,null,"forward");this.navGrid.selectSingleRecord(_1)}else{this.navDeck.hideCurrentPane();this.showNavigationPane("back");this.$206y(_1);if(this.editingOn&&_1)this.navGrid.selectSingleRecord(_1);else this.navGrid.deselectAllRecords()}
this.$168u=false}
,isc.A.$206y=function isc_NavPanel__setDetailTitleFromCurrentItem(_1){var _2=_1!=null&&_1.title&&(_1.pane!=null||!this.hideNavItemTitleWithoutPane);this.setDetailTitle(_2?_1.title:null)}
,isc.A.$167i=function isc_NavPanel__findItemById(_1){if(!_1)return null;var _2=this.$167j;if(_2!=null)return _2[_1];_2=this.$167j={};if(this.navItems==null)return null;var _3=_1;var _4=[this.navItems];for(var i=0;i<_4.length;++i){var _6=_4[i];for(var j=0,_8=_6.length;j<_8;++j){var _9=_6[j];_1=isc.NavPanel.$167h(_9);if(_1){if(_2.hasOwnProperty(_1)){this.logWarn("This NavPanel has two or more items with the same ID:'"+_1+"'.")}else{_2[_1]=_9}
}
var _10=_9.items;if(isc.isAn.Array(_10))_4.add(_10)}
}
for(var i=0;i<_4.length;++i){var _6=_4[i];for(var j=0,_8=_6.length;j<_8;++j){var _9=_6[j];if(_9.isHeader||_9.isSeparator)continue;var _11;if(isc.isA.Canvas(_9.pane))_11=_9.pane.getID();else _11=_9.pane;if(_11&&!_2.hasOwnProperty(_11)){_2[_11]=_9}
}
}
return _2[_3]}
,isc.A.setCurrentItemId=function isc_NavPanel_setCurrentItemId(_1){if(this.currentItemId==_1)return;this.setCurrentItem(this.$167i(_1))}
,isc.A.itemIsEnabled=function isc_NavPanel_itemIsEnabled(_1){var _2=this.$167i(_1);if(!_2)return;return(_2&&_2.enabled!=false&&_2.isSeparator!=true)}
,isc.A.setItemEnabled=function isc_NavPanel_setItemEnabled(_1,_2){if(_2==null)_2=true;var _3=this.$167i(_1);if(!_3)return;if(_3.enabled!=_2){_3.enabled=_2;this.refreshData();if(_3==this.currentItem){this.setCurrentItem(null)}
return true}
return false}
,isc.A.observeData=function isc_NavPanel_observeData(_1,_2){_2.remove(_1);if(!this.isObserving(_1,"dataChanged")){if(!this.$156f)this.$156f=[];if(!this.$156f.contains(_1))this.$156f.add(_1);this.observe(_1,"dataChanged","observer.dataChanged(observed)")}
for(var i=0;i<_1.length;i++){if(!_1[i].items)_1[i].items=[];this.observeData(_1[i].items,_2)}
}
,isc.A.dataChanged=function isc_NavPanel_dataChanged(_1){this.$167j=null;this.navDeck.setPanes(this.$156e(this.navItems));if(this.editingOn){var _2=false;var _3=this.navItems;for(var i=0,_5=_3.length;i<_5;++i){var _6=_3[i];if(isc.isAn.Array(_6.items)&&_6.items.length>0){_2=true;break}
}
if(this.isTree!=_2){this.editContext.setNodeProperties(this.editNode,{isTree:_2});this.navGrid.showOpener=_2}
}
var _7=isc.Tree.create({modelType:"children",nameProperty:"title",childrenProperty:"items",root:{items:this.navItems},isFolder:function(_9){return true}
});this.navGrid.setData(_7);if(this.autoOpenItems!=false){_7.openAll(_7.getRoot())}
var _8=this.$156f?isc.shallowClone(this.$156f):[];this.observeData(this.navItems,_8);this.$156f.removeList(_8)
for(var i=0;i<_8.length;i++){this.ignore(_8[i],"dataChanged")}
if(this.currentItem!=null&&!_7.contains(this.currentItem)){this.setCurrentItem(null)}
}
,isc.A.draw=function isc_NavPanel_draw(){if(!this.$156g){if(this.navItems&&this.navItems.length>0){if(this.isTree==null){this.isTree=false;for(var i=0;i<this.navItems.length;i++){if(this.navItems[i].items&&this.navItems[i].items.length>0){this.isTree=true;break}
}
}
}else{if(this.isTree==null)this.isTree=true;this.navItems=[]}
this.navGrid.showOpener=this.isTree;this.setNavItems(this.navItems);this.$156g=true;if(this.currentItem){this.$266o=true}
}
var _2=this.Super("draw",arguments);if(this.$266o){this.fireOnPause("selectItem",{target:this.navGrid,methodName:"selectSingleRecord",argNames:["record"],args:[this.currentItem]
})}
delete this.$266o;this.$263y();return _2}
,isc.A.setItemPane=function isc_NavPanel_setItemPane(_1,_2){this.$167j=null;if(_2){if(_1.pane&&_1.pane.$2074){_1.pane.markForDestroy()}
this.navDeck.addPane(_2)}else{this.navDeck.removePane(_1.pane);if(this.editingOn&&_1.pane&&!_1.pane.$2074){_2=this.editProxy.createInstructionPane(null,"Components","detailPane");this.navDeck.addPane(_2)}
}
_1.pane=_2;if(this.currentItem===_1){this.$168u=true;this.navDeck.setCurrentPane(_2);this.$168u=false;this.currentItem=_1;this.currentItemId=isc.NavPanel.$167h(_1)}
}
,isc.A.setDescendantEditableProperties=function isc_NavPanel_setDescendantEditableProperties(_1,_2,_3,_4,_5){this.Super("setDescendantEditableProperties",arguments);if(_1===this.currentItem){if((_2.hasOwnProperty("isHeader")||_2.hasOwnProperty("isSeparator"))&&(_1.isHeader||_1.isSeparator))
{this.setCurrentItem(null)}else{if(_2.hasOwnProperty("id")){var _6=this.currentItemId=isc.NavPanel.$167h(_1);this.editContext.setNodeProperties(this.editNode,{currentItemId:_6})}
if(_2.hasOwnProperty("title")){this.$206y(_1)}
}
}
_1.customStyle=_3.defaults.customStyle;this.setNavItems(this.navItems.duplicate())}
,isc.A.getUISummary=function isc_NavPanel_getUISummary(_1,_2){var _3=this.Super("getUISummary",arguments);_3.navItems=this.$2546(this.navItems);var _4=this.currentItemId;if(_4)_3.currentItemId=_4;if(this.navDeck){var _5=this.navDeck.currentPane;if(_5&&_5.isVisible()){_3.currentItemPane=_5.getUISummary(_1)}
}
var _6=this.navLayout;if(_6){var _7=[],_8=[],_9=this.navGrid;for(var i=0;i<_6.members;i++){var _11=_6.members[i];if(_11==_9)_9=null;else{if(_11&&_11.isVisible()&&!_11._generated){var _12=_11.getUISummary(_1);if(_9)_7.add(_12);else _8.add(_12)}
}
}
if(_7.length)_3.navBeforeMembers=_7;if(_8.length)_3.navAfterMembers=_8}
return _3}
,isc.A.$2546=function isc_NavPanel__getNavItemsUISummary(_1){var _2=[];for(var i=0;i<_1.length;i++){var _4=_1[i];_2.add(this.$2547(_4))}
return _2}
,isc.A.$2547=function isc_NavPanel__getNavItemUISummary(_1){var _2={};var _3,_4=this.$2545;for(var i=0;i<_4.length;i++){var _6=_4[i];if(_1.hasOwnProperty(_6)&&_1[_6]!==_3){_2[_6]=_1[_6]}
}
var _7=isc.NavPanel.$167h(_1);if(_7)_2.id=_7;var _8=_1.items;if(_8&&_8.length){_2.items=this.$2546(_8)}
return _2}
,isc.A.$235d=function isc_NavPanel__getRuleNamePrefix(_1){var _2=this.Super("$235d",arguments);if(_1.navItem){_2+=isc.$ag+_1.navItem}
return _2}
,isc.A.processEnableRule=function isc_NavPanel_processEnableRule(_1,_2){if(_2.targetObjectType=="NavItem"){var _3=this.itemIsEnabled(_2.navItem);if(_3!=_1){this.setItemEnabled(_2.navItem,!!_1);return true}else{return false}
}
return this.Super("processEnableRule",arguments)}
,isc.A.$263y=function isc_NavPanel__createNavPanelWhenRules(){if(this.$263z)return;var _1=this.getRuleScopeComponent();if(!_1)return null;var _2=[];var _3=[this.navItems];for(var i=0;i<_3.length;++i){var _5=_3[i];for(var j=0,_7=_5.length;j<_7;++j){var _8=_5[j],_9=isc.NavPanel.$167h(_8)
;if(_8.enableWhen){var _10=this.$1636("enable",_8.enableWhen,{targetObjectType:"NavItem",navItem:_9});if(_10.applyWhen&&_10.applyWhen.fixedValue!=null){_10.negateShouldApply=true}
_2.add(_10)}
var _11=_8.items;if(isc.isAn.Array(_11))_3.add(_11)}
}
if(_2.length>0){var _12=this.getRulesEngine();if(!_12){return}
_12.addMember(this);var _13=[];for(var i=_2.length-1;i>=0;i--){var _10=_2[i];if(_10.applyWhen&&_10.applyWhen.fixedValue!=null){delete _10.applyWhen;_13.add(_10);_2.removeAt(i)}
}
if(_13.length>0){_12.processRules(_13)}
for(var i=0;i<_2.length;i++){_12.addRule(_2[i])}
_12.processContextRules(_2,this)}
this.$263z=true}
,isc.A.$2630=function isc_NavPanel__removeNavPanelWhenRules(){var _1=this.getRuleScopeComponent();if(_1&&_1.rulesEngine){var _2=[this.navItems];for(var i=0;i<_2.length;++i){var _4=_2[i];for(var j=0,_6=_4.length;j<_6;++j){var _7=_4[j],_8=isc.NavPanel.$167h(_7)
;if(_7.enableWhen)this.$1637("enable",{navItem:_8});var _9=_7.items;if(isc.isAn.Array(_9))_2.add(_9)}
}
}
delete this.$263z}
);isc.B._maxIndex=isc.C+32;isc.defineClass("NavItem").addProperties({init:function(){this.Super("init",arguments);if(this.autoId)this.id=this.autoId;isc.ClassFactory.addGlobalID(this)},getNavPanel:function(){return this.navPanel},setPane:function(_1){this.navPanel.setItemPane(this,_1)},selectNavItem:function(){this.navPanel.setCurrentItem(this)},addItem:function(_1,_2){if(!this.items)this.items=[];_1.navPanel=this.navPanel;if(_2==null)this.items.add(_1);else this.items.addAt(_1,_2);this.navPanel.refreshData()},removeItem:function(_1){if(!this.items)return;this.items.remove(_1);this.navPanel.refreshData()},setEditableProperties:function(_1){if(this.navPanel){this.navPanel.setDescendantEditableProperties(this,_1,this.editNode)}
}});isc.defineClass("LocatorEditor","VLayout");isc.A=isc.LocatorEditor.getPrototype();isc.B=isc._allFuncs;isc.C=isc.B._maxIndex;isc.D=isc._funcClasses;isc.D[isc.C]=isc.A.Class;isc.A.width=500;isc.A.membersMargin=5;isc.A.defaultLayoutAlign="center";isc.A.canDragReposition=true;isc.A.canDragResize=true;isc.A.showEdges=true;isc.A.backgroundColor="lightgray";isc.A.canExpand=true;isc.A.expandUp=true;isc.A.expanded=true;isc.A.collapsedHeight=40;isc.A.stylePickerConstructor="DynamicForm";isc.A.stylePickerDefaults={border:"1px solid black",numCols:1,height:30,width:"100%",defaultItems:[{name:"header",editorType:"StaticTextItem",wrap:false,clipValue:true,showTitle:false,width:"100%",height:22,value:"Roll over segments to highlight",icons:[{src:"[SKIN]/headerIcons/minimize.png",prompt:"Collapse",showIf:function(_1,_2){return _1.creator.canExpand},click:function(_1,_2,_3){_1.creator.setExpanded(false)}
}
]
}
],itemChange:function(_1,_2,_3){return this.creator.updateLocatorStyle(_2)}
};isc.A.locatorStyle="full";isc.A.pathViewerConstructor="HLayout";isc.A.pathViewerDefaults={border:"1px solid black",height:"*",minHeight:70,width:"100%",align:"right",membersMargin:5,defaultLayoutAlign:"center",overflow:"auto"
};isc.A.pathTileConstructor="Button";isc.A.pathTileDefaults={height:50,width:150,getTitle:function(){return this.segment},setSegment:function(_1,_2){this.segmentIndex=_1;this.segment=_2;this.markForRedraw()},getStateSuffix:function(){if(this.excluded){return"Disabled"
}
return this.Super("getStateSuffix",arguments)},excluded:false,setExcluded:function(_1){this.excluded=_1;this.markForRedraw()},click:function(){if(this.excluded)return;this.customizeSegment()},customizeSegment:function(){this.creator.showCustomizeMenu(this)},showHover:true,canHover:true,hoverWrap:false,getHoverHTML:function(){if(this.creator.customizeMenu&&this.creator.customizeMenu.isVisible())return;if(this.excluded){return"Explicit locator segment not required"}
var _1=this.creator.getFormattedLocator(this.cumulativeDisplayLocator);var _2="<b>Hilighting on page:</b><br>"+_1;if(this.isSearchSegment){_2+="<br><b>This segment uses search-syntax to find the target element</b>"}
return _2},mouseOver:function(){this.creator.hilightSegment(this.cumulativeLocator,this.segment,this.segmentIndex)}
};isc.A.customizeMenuConstructor="Menu";isc.A.locatorDisplayConstructor="DynamicForm";isc.A.locatorDisplayDefaults={border:"1px solid black",width:"100%",height:30,numCols:1,defaultItems:[{name:"locator",width:"*",height:"*",vAlign:"center",editorType:"TextItem",showTitle:false,canEdit:false,readOnlyDisplay:"readOnly",icons:[{prompt:"Copy to clipboard",disableOnReadOnly:false,click:function(_1,_2,_3){_1.creator.copyCurrentLocator()}
},{src:"[SKIN]/headerIcons/maximize.png",prompt:"Expand",disableOnReadOnly:false,showIf:function(_1,_2){return _1.creator.canExpand&&!_1.creator.expanded},click:function(_1,_2,_3){_1.creator.setExpanded(true)}
}
]
}],canHover:true,showHover:true,itemHoverWrap:false,itemHoverHTML:function(_1){return this.creator.getFormattedLocator(_1.getValue())}
};isc.B.push(isc.A.initWidget=function isc_LocatorEditor_initWidget(){if(!this.expanded)this.setHeight(this.collapsedHeight);this.setResizeFrom(this.expanded?null:["L","R"]);this.stylePicker=this.createAutoChild("stylePicker",{visibility:this.expanded?"visible":"hidden",values:{style:this.locatorStyle}
}
);this.pathViewer=this.createAutoChild("pathViewer",{visibility:this.expanded?"visible":"hidden"
}
);this.locatorDisplay=this.createAutoChild("locatorDisplay");this.setMembers([this.stylePicker,this.pathViewer,this.locatorDisplay
]);return this.Super("initWidget",arguments)}
,isc.A.setExpanded=function isc_LocatorEditor_setExpanded(_1){if(this.expanded==_1)return;if(_1){this.stylePicker.show();this.pathViewer.show()}else{this.stylePicker.hide();this.pathViewer.hide()}
this.expanded=_1;this.setResizeFrom(_1?null:["L","R"]);var _2=this.getBottom();if(!_1)this.setHeight(this.collapsedHeight);this.reflowNow();if(this.expandUp){this.setTop(Math.max(0,_2-this.getVisibleHeight()))}
this.locatorDisplay.markForRedraw()}
,isc.A.updateLocatorStyle=function isc_LocatorEditor_updateLocatorStyle(_1){this.locatorStyle=_1;this.$261k=true;if(this.locator!=null){var _2=isc.AutoTest.getElement(this.locator);if(_2==null)return false;var _3=_1=="full"?isc.AutoTest.getFullPathLocator(_2):this.getLocatorForElement(_2);if(_3==null)return false;this.setLocator(_3)}
delete this.$261k}
,isc.A.getLocatorForElement=function isc_LocatorEditor_getLocatorForElement(_1){return isc.AutoTest.getLocator(_1)}
,isc.A.setLocatorStyle=function isc_LocatorEditor_setLocatorStyle(_1,_2){if(_1==this.locatorStyle)return;this.stylePicker.setValue("style",_1);if(_2){this.locatorStyle=_1}else{this.updateLocatorStyle(_1)}
}
,isc.A.showCustomizeMenu=function isc_LocatorEditor_showCustomizeMenu(_1){if(this.customizeMenu==null){var _2=this;this.customizeMenu=this.createAutoChild("customizeMenu",{items:[{title:"Truncate to here",enableIf:function(_1,_3,_4){return _2.pathViewer.members.length>(_1.segmentIndex+1)},click:function(_1,_3,_4){_2.setLocator(_1.cumulativeDisplayLocator)}
}
]
})}
this.customizeMenu.target=_1;this.customizeMenu.showContextMenu()}
,isc.A.hilightSegment=function isc_LocatorEditor_hilightSegment(_1,_2,_3){var _4=isc.AutoTest.getObject(_1),_5=isc.AutoTest.getElement(_1);if(isc.isA.Canvas(_4)&&((_5==_4.getHandle())||(_5==_4.getHandle())))
{isc.Log.hiliteCanvas(_4)}else{isc.Log.hiliteElement(_5)}
this.bringToFront();if(this.customizeMenu&&this.customizeMenu.isVisible())this.customizeMenu.bringToFront()}
,isc.A.copyCurrentLocator=function isc_LocatorEditor_copyCurrentLocator(){var _1=this.locatorDisplay.getItem("locator");var _2=_1&&_1.getDataElement();if(_2){_2.select();document.execCommand("copy");isc.notify("Locator copied to clipboard")
}
}
,isc.A.getFormattedLocator=function isc_LocatorEditor_getFormattedLocator(_1){if(_1==null||_1.length==0)return null;var _2=_1.split("/");var _3="";var _4="";for(var i=0;i<_2.length;i++){if(i==0&&_2[i]=="")continue;_3+="/";if(_2[i]!=""){_3+=_2[i]
_4+="&nbsp;&nbsp;&nbsp;&nbsp;"
_3+="<br>"+_4}
}
return _3}
,isc.A.setLocator=function isc_LocatorEditor_setLocator(_1){var _2=isc.AutoTest.getElement(_1);this.setLocatorForElement(_2,_1)}
,isc.A.setLocatorForElement=function isc_LocatorEditor_setLocatorForElement(_1,_2){var _3=isc.AutoTest.getFullPathLocator(_1);var _4=false;if(_2==null&&_1!=null){if(this.locatorStyle=="full")_2=_3;else _2=this.getLocatorForElement(_1)}else if(_2!=null){if(!this.$261k){var _5=(_2.startsWith("//:")||_2.substring(3,_2.length).contains("//"));var _6=_5?"default":"full";if(!this.$261k&&_6!=this.locatorStyle){this.setLocatorStyle(_6,true)}
}
}
this.targetElement=_1;this.locator=_2;this.locatorDisplay.setValue("locator",_2);this.pathViewer.members.callMethod("markForDestroy");this.pathViewer.setMembers([]);if(_3==null||_3.length<3)return;var _7=_3.substring(0,3);_3=_3.substring(3,_3.length);var _8=_3.split("/");_8[0]=_7+_8[0];var _9=[];var _10="";var _11=_2!=_3;var _12;if(_11){var _13=_2.substring(0,3);_2=_2.substring(3,_2.length);var _12=_2.split("/");_12[0]=_13+_12[0]}
var _14=0;var _15=_11?_12[0]:null;var _16=_15;var _17=_11?isc.AutoTest.getElement(_16):null;for(var i=0;i<_8.length;i++){var _19=_8[i];if(i!=0)_19="/"+_19;_10+=_19;var _20=_19;if(_20=="/"&&i==_8.length-1)break;var _21=false;var _22=_10;if(_11){var _23=isc.AutoTest.getElement(_10);if(_17==_23){_21=true;_20=_15;_14++;_15="/"+_12[_14];if(_15=="/"){_14++;_15+="/"+_12[_14]}
_22=_16;_16+=_15;_17=isc.AutoTest.getElement(_16)}
}
var _24=_2!=_3&&!_21;var _25=false;if(!_24&&_2!=_3){if(_20==_12[0])_25=_20.startsWith("//:");else _25=_20.startsWith("//")}
var _26=this.createAutoChild("pathTile",{cumulativeLocator:_10,cumulativeDisplayLocator:_22,segmentIndex:i,segment:_20,excluded:_24,isSearchSegment:_25
});_9.push(_26)}
this.pathViewer.setMembers(_9);this.pathViewer.delayCall("scrollToRight",null,100)}
);isc.B._maxIndex=isc.C+11;isc._nonDebugModules=(isc._nonDebugModules!=null?isc._nonDebugModules:[]);isc._nonDebugModules.push('Foundation');isc.checkForDebugAndNonDebugModules();isc._moduleEnd=isc._Foundation_end=(isc.timestamp?isc.timestamp():new Date().getTime());if(isc.Log&&isc.Log.logIsInfoEnabled('loadTime'))isc.Log.logInfo('Foundation module init time: '+(isc._moduleEnd-isc._moduleStart)+'ms','loadTime');delete isc.definingFramework;if(isc.Page)isc.Page.handleEvent(null,"moduleLoaded",{moduleName:'Foundation',loadTime:(isc._moduleEnd-isc._moduleStart)});}else{if(window.isc&&isc.Log&&isc.Log.logWarn)isc.Log.logWarn("Duplicate load of module 'Foundation'.");}
